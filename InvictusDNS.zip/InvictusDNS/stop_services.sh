#!/bin/bash
# Script para parar todos os serviços do InvictusDNS

# Parar servidor DNS
sudo pkill -f dns_server.py

# Parar painéis
pkill -f web_panel.py
pkill -f marketing_panel.py
pkill -f ai_panel.py

echo "Serviços parados."

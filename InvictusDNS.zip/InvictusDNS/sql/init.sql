-- InvictusDNS Enterprise Database Initialization
-- PostgreSQL 15+ compatible

-- Create databases for each service
CREATE DATABASE IF NOT EXISTS auth;
CREATE DATABASE IF NOT EXISTS user_db;
CREATE DATABASE IF NOT EXISTS dns;
CREATE DATABASE IF NOT EXISTS analytics;
CREATE DATABASE IF NOT EXISTS billing;

-- Create service-specific users
DO $$
BEGIN
   IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'auth_user') THEN
      CREATE USER auth_user WITH PASSWORD 'auth123';
   END IF;
END
$$;

DO $$
BEGIN
   IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'user_user') THEN
      CREATE USER user_user WITH PASSWORD 'user123';
   END IF;
END
$$;

DO $$
BEGIN
   IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'dns_user') THEN
      CREATE USER dns_user WITH PASSWORD 'dns123';
   END IF;
END
$$;

DO $$
BEGIN
   IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'analytics_user') THEN
      CREATE USER analytics_user WITH PASSWORD 'analytics123';
   END IF;
END
$$;

DO $$
BEGIN
   IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'billing_user') THEN
      CREATE USER billing_user WITH PASSWORD 'billing123';
   END IF;
END
$$;

-- Grant permissions
GRANT ALL PRIVILEGES ON DATABASE auth TO auth_user;
GRANT ALL PRIVILEGES ON DATABASE user_db TO user_user;
GRANT ALL PRIVILEGES ON DATABASE dns TO dns_user;
GRANT ALL PRIVILEGES ON DATABASE analytics TO analytics_user;
GRANT ALL PRIVILEGES ON DATABASE billing TO billing_user;

-- Create extensions
\c auth;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

\c user_db;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

\c dns;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

\c analytics;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "timescaledb";

\c billing;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Create indexes for better performance
\c auth;
CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_tenant_id ON users(tenant_id);
CREATE INDEX IF NOT EXISTS idx_refresh_tokens_user_id ON refresh_tokens(user_id);
CREATE INDEX IF NOT EXISTS idx_refresh_tokens_token ON refresh_tokens(token);

\c user_db;
CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_tenant_id ON users(tenant_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_user_id ON subscriptions(user_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_status ON subscriptions(status);
CREATE INDEX IF NOT EXISTS idx_invoices_user_id ON invoices(user_id);
CREATE INDEX IF NOT EXISTS idx_invoices_status ON invoices(status);

\c dns;
CREATE INDEX IF NOT EXISTS idx_dns_logs_timestamp ON dns_logs(timestamp);
CREATE INDEX IF NOT EXISTS idx_dns_logs_client_ip ON dns_logs(client_ip);
CREATE INDEX IF NOT EXISTS idx_dns_logs_domain ON dns_logs(domain);
CREATE INDEX IF NOT EXISTS idx_dns_logs_category ON dns_logs(category);
CREATE INDEX IF NOT EXISTS idx_threat_domains_domain ON threat_domains(domain);
CREATE INDEX IF NOT EXISTS idx_threat_domains_category ON threat_domains(category);

\c analytics;
-- TimescaleDB hypertables for time-series data
-- These will be created by the analytics service

\c billing;
CREATE INDEX IF NOT EXISTS idx_invoices_user_id ON invoices(user_id);
CREATE INDEX IF NOT EXISTS idx_invoices_status ON invoices(status);
CREATE INDEX IF NOT EXISTS idx_invoices_created_at ON invoices(created_at);
CREATE INDEX IF NOT EXISTS idx_payments_invoice_id ON payments(invoice_id);
CREATE INDEX IF NOT EXISTS idx_payments_status ON payments(status);

-- Create default tenant
\c auth;
INSERT INTO tenants (id, name, domain, is_active, max_users, created_at)
VALUES (
    'default-tenant-id',
    'Default Tenant',
    'invictusdns.com',
    true,
    1000,
    NOW()
) ON CONFLICT (id) DO NOTHING;

-- Create default admin user
INSERT INTO users (
    id, tenant_id, username, email, password_hash, full_name,
    is_active, is_verified, role, created_at, updated_at
) VALUES (
    'admin-user-id',
    'default-tenant-id',
    'admin',
    'admin@invictusdns.com',
    '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6fMmiP2Vy', -- password: admin123
    'System Administrator',
    true,
    true,
    'super_admin',
    NOW(),
    NOW()
) ON CONFLICT (id) DO NOTHING;

-- Create default plans
\c user_db;
INSERT INTO plans (
    id, name, description, price_monthly, price_yearly, currency,
    max_users, max_domains, features, is_active, created_at
) VALUES
(
    'starter-plan-id',
    'Starter',
    'Perfect for small businesses and home users',
    49.90,
    499.00,
    'BRL',
    5,
    10,
    '{"dns_resolution": true, "basic_security": true, "email_support": true, "api_access": false, "basic_analytics": false}',
    true,
    NOW()
),
(
    'professional-plan-id',
    'Professional',
    'For growing companies with advanced needs',
    149.90,
    1499.00,
    'BRL',
    25,
    50,
    '{"dns_resolution": true, "advanced_security": true, "priority_support": true, "api_access": true, "basic_analytics": true, "custom_filters": true}',
    true,
    NOW()
),
(
    'enterprise-plan-id',
    'Enterprise',
    'Full-featured solution for large organizations',
    499.90,
    4999.00,
    'BRL',
    100,
    500,
    '{"dns_resolution": true, "enterprise_security": true, "24_7_support": true, "api_access": true, "advanced_analytics": true, "custom_filters": true, "white_label": true, "dedicated_manager": true}',
    true,
    NOW()
) ON CONFLICT (id) DO NOTHING;

-- Create default threat categories
\c dns;
INSERT INTO threat_categories (id, name, description, severity, created_at) VALUES
('malware-category', 'Malware', 'Malicious software and command & control servers', 'high', NOW()),
('phishing-category', 'Phishing', 'Phishing and scam websites', 'high', NOW()),
('botnet-category', 'Botnet', 'Botnet infrastructure', 'medium', NOW()),
('spam-category', 'Spam', 'Spam sources and relays', 'low', NOW()),
('crypto-category', 'Cryptocurrency Mining', 'Unauthorized mining operations', 'medium', NOW()),
('adult-category', 'Adult Content', 'Pornography and adult websites', 'low', NOW())
ON CONFLICT (id) DO NOTHING;

-- Create monitoring tables
\c analytics;
-- DNS query analytics (TimescaleDB hypertable)
CREATE TABLE IF NOT EXISTS dns_query_metrics (
    time TIMESTAMPTZ NOT NULL,
    tenant_id TEXT NOT NULL,
    domain TEXT,
    client_ip INET,
    query_type TEXT,
    response_time DOUBLE PRECISION,
    blocked BOOLEAN DEFAULT false,
    threat_category TEXT
);

-- Convert to hypertable if TimescaleDB is available
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_extension WHERE extname = 'timescaledb') THEN
        PERFORM create_hypertable('dns_query_metrics', 'time', if_not_exists => TRUE);
    END IF;
END
$$;

-- System metrics
CREATE TABLE IF NOT EXISTS system_metrics (
    time TIMESTAMPTZ NOT NULL,
    service_name TEXT NOT NULL,
    metric_name TEXT NOT NULL,
    metric_value DOUBLE PRECISION,
    labels JSONB
);

DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_extension WHERE extname = 'timescaledb') THEN
        PERFORM create_hypertable('system_metrics', 'time', if_not_exists => TRUE);
    END IF;
END
$$;

-- Create indexes for analytics
CREATE INDEX IF NOT EXISTS idx_dns_metrics_tenant_time ON dns_query_metrics(tenant_id, time DESC);
CREATE INDEX IF NOT EXISTS idx_dns_metrics_domain ON dns_query_metrics(domain);
CREATE INDEX IF NOT EXISTS idx_dns_metrics_client_ip ON dns_query_metrics(client_ip);
CREATE INDEX IF NOT EXISTS idx_system_metrics_service ON system_metrics(service_name);
CREATE INDEX IF NOT EXISTS idx_system_metrics_name ON system_metrics(metric_name);

-- Billing analytics
\c billing;
CREATE TABLE IF NOT EXISTS revenue_metrics (
    date DATE NOT NULL PRIMARY KEY,
    total_revenue DECIMAL(10,2) DEFAULT 0,
    monthly_recurring_revenue DECIMAL(10,2) DEFAULT 0,
    new_subscriptions INTEGER DEFAULT 0,
    churned_subscriptions INTEGER DEFAULT 0,
    active_subscriptions INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS payment_transactions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    invoice_id UUID REFERENCES invoices(id),
    amount DECIMAL(10,2) NOT NULL,
    currency TEXT DEFAULT 'BRL',
    payment_method TEXT,
    status TEXT DEFAULT 'pending',
    stripe_payment_id TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    processed_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_payment_transactions_invoice ON payment_transactions(invoice_id);
CREATE INDEX IF NOT EXISTS idx_payment_transactions_status ON payment_transactions(status);
CREATE INDEX IF NOT EXISTS idx_payment_transactions_created ON payment_transactions(created_at);

-- Final message
\echo 'InvictusDNS Enterprise database initialized successfully!'
\echo 'Default admin user: admin@invictusdns.com / admin123'
\echo 'Available plans: Starter (R$ 49.90/month), Professional (R$ 149.90/month), Enterprise (R$ 499.90/month)'

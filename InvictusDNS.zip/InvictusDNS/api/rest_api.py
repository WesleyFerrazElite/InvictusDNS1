from flask import Flask, request, jsonify, session
from flask_restful import Api, Resource
from flask_jwt_extended import JWTManager, jwt_required, create_access_token, get_jwt_identity
import sqlite3
import os
from datetime import datetime, timedelta
import json

app = Flask(__name__)
app.config['JWT_SECRET_KEY'] = 'invictus-dns-jwt-secret-key-2024'
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(hours=1)
jwt = JWTManager(app)
api = Api(app)

DESKTOP_DIR = os.path.expanduser('~/Desktop')
DB_FILE = os.path.join(DESKTOP_DIR, 'InvictusDNS_Data', 'dados', 'dns_logs.db')

def get_db_connection():
    """Get database connection"""
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn

class Login(Resource):
    def post(self):
        data = request.get_json()
        username = data.get('username')
        password = data.get('password')

        if not username or not password:
            return {'message': 'Username and password required'}, 400

        conn = get_db_connection()
        user = conn.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
        conn.close()

        if user and user['password_hash'] == password:  # Simplified for demo
            access_token = create_access_token(identity=username)
            return {
                'access_token': access_token,
                'user': {
                    'username': user['username'],
                    'role': user['role']
                }
            }, 200

        return {'message': 'Invalid credentials'}, 401

class DNSLogs(Resource):
    @jwt_required()
    def get(self):
        """Get DNS logs with filtering"""
        limit = request.args.get('limit', 100, type=int)
        offset = request.args.get('offset', 0, type=int)
        domain = request.args.get('domain')
        client_ip = request.args.get('client_ip')
        category = request.args.get('category')

        conn = get_db_connection()
        query = 'SELECT * FROM dns_logs WHERE 1=1'
        params = []

        if domain:
            query += ' AND domain LIKE ?'
            params.append(f'%{domain}%')
        if client_ip:
            query += ' AND client_ip = ?'
            params.append(client_ip)
        if category:
            query += ' AND category = ?'
            params.append(category)

        query += ' ORDER BY timestamp DESC LIMIT ? OFFSET ?'
        params.extend([limit, offset])

        logs = conn.execute(query, params).fetchall()
        conn.close()

        return {
            'logs': [dict(log) for log in logs],
            'total': len(logs),
            'limit': limit,
            'offset': offset
        }, 200

class TrafficLogs(Resource):
    @jwt_required()
    def get(self):
        """Get traffic logs"""
        limit = request.args.get('limit', 100, type=int)
        offset = request.args.get('offset', 0, type=int)
        src_ip = request.args.get('src_ip')
        dst_ip = request.args.get('dst_ip')
        protocol = request.args.get('protocol')

        conn = get_db_connection()
        query = 'SELECT * FROM traffic_logs WHERE 1=1'
        params = []

        if src_ip:
            query += ' AND src_ip = ?'
            params.append(src_ip)
        if dst_ip:
            query += ' AND dst_ip = ?'
            params.append(dst_ip)
        if protocol:
            query += ' AND protocol = ?'
            params.append(protocol)

        query += ' ORDER BY timestamp DESC LIMIT ? OFFSET ?'
        params.extend([limit, offset])

        logs = conn.execute(query, params).fetchall()
        conn.close()

        return {
            'logs': [dict(log) for log in logs],
            'total': len(logs),
            'limit': limit,
            'offset': offset
        }, 200

class BlockedDomains(Resource):
    @jwt_required()
    def get(self):
        """Get blocked domains"""
        conn = get_db_connection()
        domains = conn.execute('SELECT * FROM blocked_domains').fetchall()
        conn.close()
        return {'domains': [dict(domain) for domain in domains]}, 200

    @jwt_required()
    def post(self):
        """Add blocked domain"""
        data = request.get_json()
        domain = data.get('domain')
        user_id = data.get('user_id', 1)

        if not domain:
            return {'message': 'Domain required'}, 400

        conn = get_db_connection()
        conn.execute('INSERT INTO blocked_domains (domain, user_id) VALUES (?, ?)',
                    (domain, user_id))
        conn.commit()
        conn.close()

        return {'message': 'Domain blocked successfully'}, 201

    @jwt_required()
    def delete(self, domain_id):
        """Remove blocked domain"""
        conn = get_db_connection()
        conn.execute('DELETE FROM blocked_domains WHERE id = ?', (domain_id,))
        conn.commit()
        conn.close()

        return {'message': 'Domain unblocked successfully'}, 200

class Statistics(Resource):
    @jwt_required()
    def get(self):
        """Get system statistics"""
        conn = get_db_connection()

        # DNS queries stats
        dns_stats = conn.execute('''
            SELECT
                COUNT(*) as total_queries,
                COUNT(DISTINCT client_ip) as unique_clients,
                AVG(response_time) as avg_response_time,
                COUNT(CASE WHEN category = 'threat' THEN 1 END) as blocked_queries
            FROM dns_logs
            WHERE timestamp >= datetime('now', '-24 hours')
        ''').fetchone()

        # Traffic stats
        traffic_stats = conn.execute('''
            SELECT
                COUNT(*) as total_packets,
                SUM(length) as total_bytes,
                COUNT(DISTINCT src_ip) as unique_sources
            FROM traffic_logs
            WHERE timestamp >= datetime('now', '-24 hours')
        ''').fetchone()

        conn.close()

        return {
            'dns': dict(dns_stats),
            'traffic': dict(traffic_stats),
            'timestamp': datetime.now().isoformat()
        }, 200

class Health(Resource):
    def get(self):
        """Health check endpoint"""
        return {
            'status': 'healthy',
            'timestamp': datetime.now().isoformat(),
            'version': '1.0.0'
        }, 200

# Register endpoints
api.add_resource(Login, '/api/login')
api.add_resource(DNSLogs, '/api/dns-logs')
api.add_resource(TrafficLogs, '/api/traffic-logs')
api.add_resource(BlockedDomains, '/api/blocked-domains', '/api/blocked-domains/<int:domain_id>')
api.add_resource(Statistics, '/api/statistics')
api.add_resource(Health, '/api/health')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)

import SwiftUI
import shared

struct ContentView: View {
    @State private var isConnected = false
    @State private var vpnActive = false
    @State private var dnsQueries = 0
    @State private var blockedThreats = 0
    @State private var secureTraffic = 0.0
    @State private var avgSpeed = 0.0
    @State private var logs: [String] = [
        "🚀 InvictusDNS App inicializado",
        "🧠 IA de segurança carregada",
        "🔄 Aguardando conexão neural..."
    ]

    private let api = InvictusDNSApi()

    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [
                    Color(hex: 0x0f0f23),
                    Color(hex: 0x1a1a2e),
                    Color(hex: 0x16213e),
                    Color(hex: 0x0f3460),
                    Color(hex: 0x1a1a2e)
                ]),
                startPoint: .top,
                endPoint: .bottom
            )
            .edgesIgnoringSafeArea(.all)

            ScrollView {
                VStack(spacing: 20) {
                    // Header
                    VStack(spacing: 10) {
                        Text("🛡️ InvictusDNS App")
                            .font(.system(size: 28, weight: .bold))
                            .multilineTextAlignment(.center)
                            .foregroundColor(.clear)
                            .overlay(
                                LinearGradient(
                                    gradient: Gradient(colors: [
                                        Color(hex: 0x00d4ff),
                                        Color(hex: 0xff6b6b),
                                        Color(hex: 0xffd93d),
                                        Color(hex: 0x6bcf7f)
                                    ]),
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                                .mask(
                                    Text("🛡️ InvictusDNS App")
                                        .font(.system(size: 28, weight: .bold))
                                        .multilineTextAlignment(.center)
                                )
                            )

                        Text("🧠 IA de Segurança Inteligente | 🔒 Proteção Avançada | ⚡ Performance Máxima")
                            .font(.system(size: 14))
                            .foregroundColor(Color(hex: 0xb8c5d6))
                            .multilineTextAlignment(.center)
                    }
                    .padding(20)
                    .background(Color.white.opacity(0.05))
                    .cornerRadius(20)
                    .padding(.horizontal, 20)

                    // Status Card
                    VStack(alignment: .leading, spacing: 15) {
                        HStack {
                            Circle()
                                .fill(isConnected ? Color(hex: 0x2ed573) : Color(hex: 0xff4757))
                                .frame(width: 20, height: 20)
                                .scaleEffect(isConnected ? 1.0 : 0.8)
                                .animation(.easeInOut(duration: 2).repeatForever(autoreverses: true), value: isConnected)

                            Text("Status da Conexão Neural")
                                .foregroundColor(Color(hex: 0x00d4ff))
                                .font(.system(size: 18, weight: .bold))
                        }

                        Text(isConnected ?
                             "🟢 Conectado ao InvictusDNS! Proteção neural ativa." :
                             "🔄 Inicializando sistemas de segurança...")
                            .foregroundColor(Color(hex: 0xb8c5d6))

                        VStack(spacing: 10) {
                            HStack(spacing: 10) {
                                Button(action: connectDNS) {
                                    Text("🚀 Conectar ao DNS Neural")
                                        .foregroundColor(.white)
                                        .fontWeight(.bold)
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 15)
                                        .background(Color(hex: 0x667eea))
                                        .cornerRadius(25)
                                }
                                .disabled(isConnected)

                                Button(action: toggleVPN) {
                                    Text(vpnActive ? "🔐 VPN Quântica Ativa" : "🔐 Ativar VPN Quântica")
                                        .foregroundColor(.white)
                                        .fontWeight(.bold)
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 15)
                                        .background(vpnActive ? Color(hex: 0xff3838) : Color(hex: 0xff6b6b))
                                        .cornerRadius(25)
                                }
                            }

                            if isConnected {
                                Button(action: disconnect) {
                                    Text("🔌 Desconectar")
                                        .foregroundColor(.white)
                                        .fontWeight(.bold)
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 15)
                                        .background(Color(hex: 0xff3838))
                                        .cornerRadius(25)
                                }
                            }
                        }
                    }
                    .padding(20)
                    .background(Color.white.opacity(0.08))
                    .cornerRadius(20)
                    .padding(.horizontal, 20)

                    // Metrics Grid
                    HStack(spacing: 10) {
                        // Left Card
                        VStack(alignment: .leading, spacing: 15) {
                            Text("📊 Métricas em Tempo Real")
                                .foregroundColor(Color(hex: 0xffd93d))
                                .font(.system(size: 16, weight: .bold))

                            MetricView(label: "Consultas DNS:", value: "\(dnsQueries)")
                            MetricView(label: "Tráfego Protegido:", value: String(format: "%.1f MB", secureTraffic))
                            MetricView(label: "Ameaças Neutralizadas:", value: "\(blockedThreats)")
                            MetricView(label: "Velocidade Neural:", value: String(format: "%.1f ms", avgSpeed))
                        }
                        .padding(15)
                        .background(Color.white.opacity(0.08))
                        .cornerRadius(20)
                        .frame(maxWidth: .infinity)

                        // Right Card
                        VStack(alignment: .leading, spacing: 15) {
                            Text("🤖 IA de Segurança")
                                .foregroundColor(Color(hex: 0xffd93d))
                                .font(.system(size: 16, weight: .bold))

                            MetricView(label: "Status da IA:", value: "🟢 Ativa", color: Color(hex: 0x6bcf7f))
                            MetricView(label: "Última Varredura:", value: "Agora")
                            MetricView(label: "Proteções Ativas:", value: "7")

                            Button(action: runAIScan) {
                                Text("🔍 Executar Varredura Neural")
                                    .foregroundColor(.white)
                                    .fontWeight(.bold)
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 12)
                                    .background(Color(hex: 0xff6b6b))
                                    .cornerRadius(20)
                            }
                        }
                        .padding(15)
                        .background(Color.white.opacity(0.08))
                        .cornerRadius(20)
                        .frame(maxWidth: .infinity)
                    }
                    .padding(.horizontal, 20)

                    // Logs Card
                    VStack(alignment: .leading, spacing: 15) {
                        Text("📋 Logs do Sistema")
                            .foregroundColor(Color(hex: 0xffd93d))
                            .font(.system(size: 18, weight: .bold))

                        ScrollView {
                            VStack(spacing: 8) {
                                ForEach(logs, id: \.self) { log in
                                    Text(log)
                                        .foregroundColor(.white)
                                        .font(.system(size: 12, design: .monospaced))
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                        .padding(12)
                                        .background(Color.white.opacity(0.05))
                                        .cornerRadius(8)
                                }
                            }
                        }
                        .frame(height: 200)
                    }
                    .padding(20)
                    .background(Color.white.opacity(0.08))
                    .cornerRadius(20)
                    .padding(.horizontal, 20)

                    // Alerts Card
                    VStack(alignment: .leading, spacing: 15) {
                        Text("⚠️ Alertas de Segurança")
                            .foregroundColor(Color(hex: 0xffd93d))
                            .font(.system(size: 18, weight: .bold))

                        Text("🛡️ Todos os sistemas seguros")
                            .foregroundColor(Color(hex: 0x6bcf7f))
                            .frame(maxWidth: .infinity)
                            .padding(15)
                            .background(Color.green.opacity(0.2))
                            .cornerRadius(15)
                    }
                    .padding(20)
                    .background(Color.white.opacity(0.08))
                    .cornerRadius(20)
                    .padding(.horizontal, 20)
                }
                .padding(.vertical, 20)
            }
        }
        .onAppear {
            startMonitoring()
        }
    }

    private func connectDNS() {
        Task {
            do {
                let response = try await api.connect()
                isConnected = true
                addLog("🟢 Conexão neural estabelecida com sucesso")
                addLog("🛡️ Firewall quântico ativado")
                addLog("🔍 IA iniciando monitoramento contínuo")
            } catch {
                addLog("❌ Falha na conexão com o servidor")
            }
        }
    }

    private func toggleVPN() {
        if !isConnected {
            // Show alert
            return
        }
        vpnActive.toggle()
        if vpnActive {
            addLog("🛡️ VPN Quântica ativada - Tráfego 100% criptografado")
            addLog("🔒 Protocolo de encriptação pós-quântico ativo")
        } else {
            addLog("🔓 VPN desativada")
        }
    }

    private func disconnect() {
        isConnected = false
        vpnActive = false
        addLog("🔌 Conexão neural encerrada")
    }

    private func runAIScan() {
        Task {
            do {
                let response = try await api.runAIScan()
                addLog("✅ Varredura concluída - Sistema 100% seguro")
            } catch {
                addLog("❌ Falha na varredura IA")
            }
        }
    }

    private func startMonitoring() {
        Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
            if isConnected {
                dnsQueries += Int.random(in: 5...20)
                secureTraffic += 0.1 + Double.random(in: 0...0.1)
                avgSpeed = 8.0 + Double.random(in: 0...5.0)

                if Double.random(in: 0...1) < 0.08 {
                    blockedThreats += 1
                    addLog("🚨 IA neutralizou ameaça automaticamente!")
                }
            }
        }

        Timer.scheduledTimer(withTimeInterval: 2.0, repeats: true) { _ in
            if isConnected && Double.random(in: 0...1) < 0.4 {
                let messages = [
                    "🔍 IA analisou domínio: \(generateRandomDomain())",
                    "🛡️ Tráfego seguro detectado: \(Int.random(in: 10...100))KB",
                    "⚡ Cache neural otimizado",
                    "🔒 Certificado SSL validado",
                    "📊 Métricas atualizadas"
                ]
                addLog(messages.randomElement()!)
            }
        }
    }

    private func addLog(_ message: String) {
        let timestamp = DateFormatter.localizedString(from: Date(), dateStyle: .none, timeStyle: .medium)
        logs.insert("\(timestamp) - \(message)", at: 0)
        if logs.count > 15 {
            logs.removeLast()
        }
    }

    private func generateRandomDomain() -> String {
        let domains = ["google.com", "github.com", "stackoverflow.com", "youtube.com", "netflix.com", "amazon.com", "microsoft.com", "apple.com"]
        return domains.randomElement()!
    }
}

struct MetricView: View {
    let label: String
    let value: String
    var color: Color = Color(hex: 0x00d4ff)

    var body: some View {
        HStack {
            Text(label)
                .foregroundColor(Color(hex: 0xb8c5d6))
                .fontWeight(.medium)
            Spacer()
            Text(value)
                .foregroundColor(color)
                .fontWeight(.bold)
                .font(.system(.body, design: .monospaced))
        }
        .padding(12)
        .background(Color.white.opacity(0.05))
        .cornerRadius(10)
    }
}

extension Color {
    init(hex: UInt) {
        self.init(
            .sRGB,
            red: Double((hex >> 16) & 0xff) / 255,
            green: Double((hex >> 08) & 0xff) / 255,
            blue: Double((hex >> 00) & 0xff) / 255,
            opacity: 1
        )
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

package com.invictus.dns

import io.ktor.client.*
import io.ktor.client.call.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.request.*
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

@Serializable
data class ConnectRequest(val action: String = "connect")

@Serializable
data class ScanRequest(val action: String = "scan")

@Serializable
data class ConnectResponse(val status: String, val message: String)

class InvictusDNSApi(private val baseUrl: String = "http://[SEU_IP]:3000") {
    private val client = HttpClient {
        install(ContentNegotiation) {
            json(Json {
                prettyPrint = true
                isLenient = true
            })
        }
    }

    suspend fun connect(): Result<ConnectResponse> {
        return try {
            val response = client.post("$baseUrl/connect") {
                contentType(ContentType.Application.Json)
                setBody(ConnectRequest())
            }
            Result.success(response.body())
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun runAIScan(): Result<ConnectResponse> {
        return try {
            val response = client.post("$baseUrl/ai_scan") {
                contentType(ContentType.Application.Json)
                setBody(ScanRequest())
            }
            Result.success(response.body())
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

package com.invictus.dns.android

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.invictus.dns.InvictusDNSApi
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            InvictusDNSApp()
        }
    }
}

@Composable
fun InvictusDNSApp() {
    val api = remember { InvictusDNSApi() }
    val scope = rememberCoroutineScope()

    var isConnected by remember { mutableStateOf(false) }
    var vpnActive by remember { mutableStateOf(false) }
    var dnsQueries by remember { mutableStateOf(0) }
    var blockedThreats by remember { mutableStateOf(0) }
    var secureTraffic by remember { mutableStateOf(0.0) }
    var avgSpeed by remember { mutableStateOf(0.0) }
    var logs by remember { mutableStateOf(listOf(
        "🚀 InvictusDNS App inicializado",
        "🧠 IA de segurança carregada",
        "🔄 Aguardando conexão neural..."
    )) }

    val pulseAnim = rememberInfiniteTransition()
    val scale by pulseAnim.animateFloat(
        initialValue = 1f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000),
            repeatMode = RepeatMode.Reverse
        )
    )

    LaunchedEffect(isConnected) {
        if (isConnected) {
            while (true) {
                kotlinx.coroutines.delay(1000)
                dnsQueries += (5..20).random()
                secureTraffic += 0.1 + kotlin.random.Random.nextDouble(0.1)
                avgSpeed = 8.0 + kotlin.random.Random.nextDouble() * 5.0

                if (kotlin.random.Random.nextDouble() < 0.08) {
                    blockedThreats++
                    addLog("🚨 IA neutralizou ameaça automaticamente!", logs) { logs = it }
                }
            }
        }
    }

    LaunchedEffect(isConnected) {
        if (isConnected) {
            while (true) {
                kotlinx.coroutines.delay(2000)
                if (kotlin.random.Random.nextDouble() < 0.4) {
                    val messages = listOf(
                        "🔍 IA analisou domínio: ${generateRandomDomain()}",
                        "🛡️ Tráfego seguro detectado: ${(10..100).random()}KB",
                        "⚡ Cache neural otimizado",
                        "🔒 Certificado SSL validado",
                        "📊 Métricas atualizadas"
                    )
                    addLog(messages.random(), logs) { logs = it }
                }
            }
        }
    }

    val gradientColors = listOf(
        Color(0xFF0f0f23),
        Color(0xFF1a1a2e),
        Color(0xFF16213e),
        Color(0xFF0f3460),
        Color(0xFF1a1a2e)
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(gradientColors))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                shape = RoundedCornerShape(20.dp),
                backgroundColor = Color.White.copy(alpha = 0.05f),
                elevation = 8.dp
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "🛡️ InvictusDNS App",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        style = androidx.compose.ui.text.TextStyle(
                            brush = Brush.horizontalGradient(
                                colors = listOf(
                                    Color(0xFF00d4ff),
                                    Color(0xFFff6b6b),
                                    Color(0xFFffd93d),
                                    Color(0xFF6bcf7f)
                                )
                            )
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "🧠 IA de Segurança Inteligente | 🔒 Proteção Avançada | ⚡ Performance Máxima",
                        fontSize = 14.sp,
                        color = Color(0xFFb8c5d6),
                        textAlign = TextAlign.Center
                    )
                }
            }

            // Status Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                shape = RoundedCornerShape(20.dp),
                backgroundColor = Color.White.copy(alpha = 0.08f),
                elevation = 8.dp
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(20.dp)
                                .scale(scale)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isConnected) Color(0xFF2ed573) else Color(0xFFff4757))
                        )
                        Spacer(modifier = Modifier.width(15.dp))
                        Text(
                            text = "Status da Conexão Neural",
                            color = Color(0xFF00d4ff),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(15.dp))
                    Text(
                        text = if (isConnected)
                            "🟢 Conectado ao InvictusDNS! Proteção neural ativa."
                        else
                            "🔄 Inicializando sistemas de segurança...",
                        color = Color(0xFFb8c5d6)
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Row(modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = {
                                scope.launch {
                                    api.connect().onSuccess {
                                        isConnected = true
                                        addLog("🟢 Conexão neural estabelecida com sucesso", logs) { logs = it }
                                        addLog("🛡️ Firewall quântico ativado", logs) { logs = it }
                                        addLog("🔍 IA iniciando monitoramento contínuo", logs) { logs = it }
                                    }.onFailure {
                                        addLog("❌ Falha na conexão com o servidor", logs) { logs = it }
                                    }
                                }
                            },
                            enabled = !isConnected,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFF667eea))
                        ) {
                            Text("🚀 Conectar ao DNS Neural", color = Color.White)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (!isConnected) {
                                    // Show alert
                                    return@Button
                                }
                                vpnActive = !vpnActive
                                if (vpnActive) {
                                    addLog("🛡️ VPN Quântica ativada - Tráfego 100% criptografado", logs) { logs = it }
                                    addLog("🔒 Protocolo de encriptação pós-quântico ativo", logs) { logs = it }
                                } else {
                                    addLog("🔓 VPN desativada", logs) { logs = it }
                                }
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                backgroundColor = if (vpnActive) Color(0xFFff3838) else Color(0xFFff6b6b)
                            )
                        ) {
                            Text(
                                if (vpnActive) "🔐 VPN Quântica Ativa" else "🔐 Ativar VPN Quântica",
                                color = Color.White
                            )
                        }
                    }
                    if (isConnected) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = {
                                isConnected = false
                                vpnActive = false
                                addLog("🔌 Conexão neural encerrada", logs) { logs = it }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFFff3838))
                        ) {
                            Text("🔌 Desconectar", color = Color.White)
                        }
                    }
                }
            }

            // Metrics Grid
            Row(modifier = Modifier.fillMaxWidth()) {
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .padding(end = 8.dp),
                    shape = RoundedCornerShape(20.dp),
                    backgroundColor = Color.White.copy(alpha = 0.08f),
                    elevation = 8.dp
                ) {
                    Column(modifier = Modifier.padding(15.dp)) {
                        Text(
                            text = "📊 Métricas em Tempo Real",
                            color = Color(0xFFffd93d),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(15.dp))
                        MetricItem("Consultas DNS:", dnsQueries.toString())
                        MetricItem("Tráfego Protegido:", "${secureTraffic.format(1)} MB")
                        MetricItem("Ameaças Neutralizadas:", blockedThreats.toString())
                        MetricItem("Velocidade Neural:", "${avgSpeed.format(1)} ms")
                    }
                }

                Card(
                    modifier = Modifier
                        .weight(1f)
                        .padding(start = 8.dp),
                    shape = RoundedCornerShape(20.dp),
                    backgroundColor = Color.White.copy(alpha = 0.08f),
                    elevation = 8.dp
                ) {
                    Column(modifier = Modifier.padding(15.dp)) {
                        Text(
                            text = "🤖 IA de Segurança",
                            color = Color(0xFFffd93d),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(15.dp))
                        MetricItem("Status da IA:", "🟢 Ativa", Color(0xFF6bcf7f))
                        MetricItem("Última Varredura:", "Agora")
                        MetricItem("Proteções Ativas:", "7")
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = {
                                scope.launch {
                                    api.runAIScan().onSuccess {
                                        addLog("✅ Varredura concluída - Sistema 100% seguro", logs) { logs = it }
                                    }.onFailure {
                                        addLog("❌ Falha na varredura IA", logs) { logs = it }
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFFff6b6b))
                        ) {
                            Text("🔍 Executar Varredura Neural", color = Color.White)
                        }
                    }
                }
            }

            // Logs Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                shape = RoundedCornerShape(20.dp),
                backgroundColor = Color.White.copy(alpha = 0.08f),
                elevation = 8.dp
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "📋 Logs do Sistema",
                        color = Color(0xFFffd93d),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(15.dp))
                    LazyColumn {
                        items(logs) { log ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                shape = RoundedCornerShape(8.dp),
                                backgroundColor = Color.White.copy(alpha = 0.05f)
                            ) {
                                Text(
                                    text = log,
                                    modifier = Modifier.padding(12.dp),
                                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                                    fontSize = 12.sp,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MetricItem(label: String, value: String, color: Color = Color(0xFF00d4ff)) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(10.dp))
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = Color(0xFFb8c5d6), fontWeight = FontWeight.W500)
        Text(
            text = value,
            color = color,
            fontWeight = FontWeight.Bold,
            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
        )
    }
}

fun addLog(message: String, currentLogs: List<String>, updateLogs: (List<String>) -> Unit) {
    val timestamp = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
    updateLogs(listOf("$timestamp - $message") + currentLogs.take(14))
}

fun generateRandomDomain(): String {
    val domains = listOf("google.com", "github.com", "stackoverflow.com", "youtube.com", "netflix.com", "amazon.com", "microsoft.com", "apple.com")
    return domains.random()
}

fun Double.format(digits: Int) = "%.${digits}f".format(this)

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  Dimensions,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import axios from 'axios';

const { width } = Dimensions.get('window');

const SERVER_IP = '[SEU_IP]'; // Substitua pelo IP real do servidor

const InvictusDNSApp: React.FC = () => {
  const [isConnected, setIsConnected] = useState(false);
  const [vpnActive, setVpnActive] = useState(false);
  const [dnsQueries, setDnsQueries] = useState(0);
  const [blockedThreats, setBlockedThreats] = useState(0);
  const [secureTraffic, setSecureTraffic] = useState(0.0);
  const [avgSpeed, setAvgSpeed] = useState(0.0);
  const [logs, setLogs] = useState<string[]>([
    '🚀 InvictusDNS App inicializado',
    '🧠 IA de segurança carregada',
    '🔄 Aguardando conexão neural...'
  ]);

  useEffect(() => {
    let statsInterval: NodeJS.Timeout;
    let logInterval: NodeJS.Timeout;

    if (isConnected) {
      statsInterval = setInterval(() => {
        setDnsQueries(prev => prev + Math.floor(Math.random() * 15) + 5);
        setSecureTraffic(prev => prev + Math.random() * 0.2);
        setAvgSpeed(8 + Math.random() * 5);

        if (Math.random() < 0.08) {
          setBlockedThreats(prev => prev + 1);
          showThreatAlert();
        }
      }, 1000);

      logInterval = setInterval(() => {
        if (Math.random() < 0.4) {
          const messages = [
            `🔍 IA analisou domínio: ${generateRandomDomain()}`,
            `🛡️ Tráfego seguro detectado: ${Math.floor(Math.random() * 100)}KB`,
            '⚡ Cache neural otimizado',
            '🔒 Certificado SSL validado',
            '📊 Métricas atualizadas'
          ];
          addLog(messages[Math.floor(Math.random() * messages.length)]);
        }
      }, 2000);
    }

    return () => {
      if (statsInterval) clearInterval(statsInterval);
      if (logInterval) clearInterval(logInterval);
    };
  }, [isConnected]);

  const connectDNS = async () => {
    try {
      const response = await axios.post(`http://${SERVER_IP}:3000/connect`, {
        action: 'connect'
      });

      if (response.status === 200) {
        setIsConnected(true);
        addLog('🟢 Conexão neural estabelecida com sucesso');
        addLog('🛡️ Firewall quântico ativado');
        addLog('🔍 IA iniciando monitoramento contínuo');
      } else {
        addLog('❌ Falha na conexão com o servidor');
      }
    } catch (error) {
      addLog('❌ Erro de rede');
    }
  };

  const toggleVPN = () => {
    if (!isConnected) {
      Alert.alert('Atenção', 'Conecte ao DNS Neural primeiro!');
      return;
    }

    setVpnActive(!vpnActive);
    if (!vpnActive) {
      addLog('🛡️ VPN Quântica ativada - Tráfego 100% criptografado');
      addLog('🔒 Protocolo de encriptação pós-quântico ativo');
    } else {
      addLog('🔓 VPN desativada');
    }
  };

  const disconnect = () => {
    setIsConnected(false);
    setVpnActive(false);
    addLog('🔌 Conexão neural encerrada');
  };

  const runAIScan = async () => {
    addLog('🔍 Iniciando varredura neural completa...');

    try {
      const response = await axios.post(`http://${SERVER_IP}:3000/ai_scan`, {
        action: 'scan'
      });

      if (response.status === 200) {
        addLog('✅ Varredura concluída - Sistema 100% seguro');
      } else {
        addLog('❌ Falha na varredura IA');
      }
    } catch (error) {
      addLog('❌ Erro na varredura');
    }
  };

  const showThreatAlert = () => {
    addLog('🚨 IA neutralizou ameaça automaticamente!');
    Alert.alert('🚨 Ameaça Detectada!', 'IA atuando automaticamente.');
  };

  const addLog = (message: string) => {
    const timestamp = new Date().toLocaleTimeString();
    setLogs(prev => [`${timestamp} - ${message}`, ...prev.slice(0, 14)]);
  };

  const generateRandomDomain = () => {
    const domains = ['google.com', 'github.com', 'stackoverflow.com', 'youtube.com', 'netflix.com', 'amazon.com', 'microsoft.com', 'apple.com'];
    return domains[Math.floor(Math.random() * domains.length)];
  };

  return (
    <LinearGradient
      colors={['#0f0f23', '#1a1a2e', '#16213e', '#0f3460', '#1a1a2e']}
      style={styles.container}
    >
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>🛡️ InvictusDNS App</Text>
          <Text style={styles.subtitle}>
            🧠 IA de Segurança Inteligente | 🔒 Proteção Avançada | ⚡ Performance Máxima
          </Text>
        </View>

        {/* Status Card */}
        <View style={styles.card}>
          <View style={styles.statusIndicator}>
            <View style={[styles.statusDot, isConnected && styles.connected]} />
            <Text style={styles.statusTitle}>Status da Conexão Neural</Text>
          </View>
          <Text style={styles.statusText}>
            {isConnected
              ? '🟢 Conectado ao InvictusDNS! Proteção neural ativa.'
              : '🔄 Inicializando sistemas de segurança...'
            }
          </Text>
          <View style={styles.buttonRow}>
            <TouchableOpacity
              style={[styles.button, styles.primary]}
              onPress={connectDNS}
              disabled={isConnected}
            >
              <Text style={styles.buttonText}>🚀 Conectar ao DNS Neural</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.button, vpnActive ? styles.danger : styles.secondary]}
              onPress={toggleVPN}
            >
              <Text style={styles.buttonText}>
                {vpnActive ? '🔐 VPN Quântica Ativa' : '🔐 Ativar VPN Quântica'}
              </Text>
            </TouchableOpacity>
          </View>
          {isConnected && (
            <TouchableOpacity
              style={[styles.button, styles.danger]}
              onPress={disconnect}
            >
              <Text style={styles.buttonText}>🔌 Desconectar</Text>
            </TouchableOpacity>
          )}
        </View>

        {/* Metrics Grid */}
        <View style={styles.grid}>
          <View style={styles.card}>
            <Text style={styles.cardTitle}>📊 Métricas em Tempo Real</Text>
            <View style={styles.metric}>
              <Text style={styles.metricLabel}>Consultas DNS:</Text>
              <Text style={styles.metricValue}>{dnsQueries.toLocaleString()}</Text>
            </View>
            <View style={styles.metric}>
              <Text style={styles.metricLabel}>Tráfego Protegido:</Text>
              <Text style={styles.metricValue}>{secureTraffic.toFixed(1)} MB</Text>
            </View>
            <View style={styles.metric}>
              <Text style={styles.metricLabel}>Ameaças Neutralizadas:</Text>
              <Text style={styles.metricValue}>{blockedThreats}</Text>
            </View>
            <View style={styles.metric}>
              <Text style={styles.metricLabel}>Velocidade Neural:</Text>
              <Text style={styles.metricValue}>{avgSpeed.toFixed(1)} ms</Text>
            </View>
          </View>

          <View style={styles.card}>
            <Text style={styles.cardTitle}>🤖 IA de Segurança</Text>
            <View style={styles.metric}>
              <Text style={styles.metricLabel}>Status da IA:</Text>
              <Text style={[styles.metricValue, styles.green]}>🟢 Ativa</Text>
            </View>
            <View style={styles.metric}>
              <Text style={styles.metricLabel}>Última Varredura:</Text>
              <Text style={styles.metricValue}>Agora</Text>
            </View>
            <View style={styles.metric}>
              <Text style={styles.metricLabel}>Proteções Ativas:</Text>
              <Text style={styles.metricValue}>7</Text>
            </View>
            <TouchableOpacity
              style={[styles.button, styles.secondary]}
              onPress={runAIScan}
            >
              <Text style={styles.buttonText}>🔍 Executar Varredura Neural</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Logs Card */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>📋 Logs do Sistema</Text>
          <ScrollView style={styles.logsContainer} showsVerticalScrollIndicator={false}>
            {logs.map((log, index) => (
              <View key={index} style={styles.logEntry}>
                <Text style={styles.logText}>{log}</Text>
              </View>
            ))}
          </ScrollView>
        </View>

        {/* Alerts Card */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>⚠️ Alertas de Segurança</Text>
          <View style={styles.alert}>
            <Text style={styles.alertText}>🛡️ Todos os sistemas seguros</Text>
          </View>
        </View>
      </ScrollView>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContainer: {
    padding: 20,
  },
  header: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 20,
    padding: 20,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    textAlign: 'center',
    backgroundColor: 'transparent',
    backgroundImage: 'linear-gradient(45deg, #00d4ff, #ff6b6b, #ffd93d, #6bcf7f)',
    backgroundClip: 'text',
    color: 'transparent',
  },
  subtitle: {
    fontSize: 14,
    color: '#b8c5d6',
    textAlign: 'center',
    marginTop: 10,
  },
  card: {
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    borderRadius: 20,
    padding: 20,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
  },
  statusIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  statusDot: {
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: '#ff4757',
    marginRight: 15,
  },
  connected: {
    backgroundColor: '#2ed573',
  },
  statusTitle: {
    color: '#00d4ff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  statusText: {
    color: '#b8c5d6',
    marginBottom: 20,
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  button: {
    flex: 1,
    paddingVertical: 15,
    paddingHorizontal: 10,
    borderRadius: 25,
    marginHorizontal: 5,
    alignItems: 'center',
  },
  primary: {
    backgroundColor: '#667eea',
  },
  secondary: {
    backgroundColor: '#ff6b6b',
  },
  danger: {
    backgroundColor: '#ff3838',
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  grid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  cardTitle: {
    color: '#ffd93d',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
  },
  metric: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    padding: 12,
    borderRadius: 10,
    marginBottom: 8,
    borderLeftWidth: 3,
    borderLeftColor: '#00d4ff',
  },
  metricLabel: {
    color: '#b8c5d6',
    fontWeight: '500',
  },
  metricValue: {
    color: '#00d4ff',
    fontWeight: 'bold',
    fontFamily: 'monospace',
  },
  green: {
    color: '#6bcf7f',
  },
  logsContainer: {
    maxHeight: 200,
  },
  logEntry: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    padding: 12,
    borderRadius: 8,
    marginBottom: 8,
    borderLeftWidth: 3,
    borderLeftColor: '#6bcf7f',
  },
  logText: {
    fontFamily: 'monospace',
    fontSize: 12,
    color: 'white',
  },
  alert: {
    backgroundColor: 'rgba(46, 213, 115, 0.2)',
    borderRadius: 15,
    padding: 15,
    borderWidth: 1,
    borderColor: 'rgba(46, 213, 115, 0.3)',
  },
  alertText: {
    color: '#6bcf7f',
    textAlign: 'center',
  },
});

export default InvictusDNSApp;

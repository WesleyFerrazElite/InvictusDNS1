// Configurações do App InvictusDNS
import 'dart:io';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Config {
  // IP do servidor - ALTERE AQUI PARA O IP REAL DO SEU SERVIDOR
  static const String serverIP = '[SEU_IP]'; // Exemplo: '192.168.1.100'

  // URLs dos endpoints
  static const String baseUrl = 'http://$serverIP:3000';
  static const String connectEndpoint = '$baseUrl/connect';
  static const String aiScanEndpoint = '$baseUrl/ai_scan';

  // Configurações de timeout
  static const Duration connectTimeout = Duration(seconds: 10);
  static const Duration receiveTimeout = Duration(seconds: 10);

  // Configurações de monitoramento
  static const Duration statsUpdateInterval = Duration(seconds: 1);
  static const Duration logUpdateInterval = Duration(seconds: 2);

  // Configurações de UI
  static const double cardBorderRadius = 20.0;
  static const double buttonBorderRadius = 25.0;
  static const double cardOpacity = 0.08;
  static const double metricOpacity = 0.05;

  // Cores do tema
  static const int primaryColor = 0xFF667eea;
  static const int secondaryColor = 0xFFff6b6b;
  static const int dangerColor = 0xFFff3838;
  static const int successColor = 0xFF2ed573;
  static const int warningColor = 0xFFffd93d;
  static const int infoColor = 0xFF00d4ff;
  static const int textPrimaryColor = 0xFFFFFFFF;
  static const int textSecondaryColor = 0xFFb8c5d6;
  static const int backgroundColor = 0xFF0f0f23;

  // Configurações de animação
  static const Duration pulseDuration = Duration(seconds: 2);
  static const Duration buttonAnimationDuration = Duration(milliseconds: 300);

  // Configurações de logs
  static const int maxLogs = 15;

  // Configurações de métricas
  static const int minDnsQueriesIncrement = 5;
  static const int maxDnsQueriesIncrement = 20;
  static const double minTrafficIncrement = 0.1;
  static const double maxTrafficIncrement = 0.2;
  static const double minSpeed = 8.0;
  static const double maxSpeed = 13.0;
  static const double threatProbability = 0.08;
  static const double logProbability = 0.4;

  // Lista de domínios para simulação
  static const List<String> domains = [
    'google.com',
    'github.com',
    'stackoverflow.com',
    'youtube.com',
    'netflix.com',
    'amazon.com',
    'microsoft.com',
    'apple.com',
    'facebook.com',
    'twitter.com'
  ];

  // Mensagens de log
  static const List<String> logMessages = [
    '🔍 IA analisou domínio: {domain}',
    '🛡️ Tráfego seguro detectado: {traffic}KB',
    '⚡ Cache neural otimizado',
    '🔒 Certificado SSL validado',
    '📊 Métricas atualizadas',
    '🔄 Conexão neural estável',
    '🛡️ Firewall quântico ativo',
    '📈 Performance otimizada'
  ];

  // Configurações de segurança
  static const bool enableHttps = false; // Mude para true em produção
  static const bool enableCertificatePinning = false; // Implementar em produção
  static const bool enableBiometricAuth = true;
  static const bool enableQuantumEncryption = true;
  static const bool enableRootDetection = true;
  static const bool enableIntegrityCheck = true;
  static const int maxRequestsPerMinute = 100;
  static const Duration biometricTimeout = Duration(minutes: 5);

  // Configurações de encriptação quântica
  static const String kyberKeySize = 'kyber768'; // kyber512, kyber768, kyber1024
  static const int aesKeySize = 256;
  static const String hashAlgorithm = 'SHA-256';

  // Arquivos críticos para verificação de integridade
  static const List<String> criticalFiles = [
    'lib/main.dart',
    'lib/config.dart',
    'assets/images/logo.png'
  ];

  // Checksums SHA-256 (atualizar após mudanças)
  static const Map<String, String> fileChecksums = {
    'lib/main.dart': '', // Gerar após implementação final
    'lib/config.dart': '', // Gerar após implementação final
  };

  // ID único do dispositivo
  static Future<String> getDeviceId() async {
    final prefs = await SharedPreferences.getInstance();
    String? deviceId = prefs.getString('device_id');

    if (deviceId != null) {
      return deviceId;
    }

    final deviceInfo = DeviceInfoPlugin();
    String newDeviceId;

    try {
      if (Platform.isAndroid) {
        final androidInfo = await deviceInfo.androidInfo;
        newDeviceId = androidInfo.id; // Android ID
      } else if (Platform.isIOS) {
        final iosInfo = await deviceInfo.iosInfo;
        newDeviceId = iosInfo.identifierForVendor ?? 'unknown'; // IDFV
      } else {
        newDeviceId = 'unknown_device_${DateTime.now().millisecondsSinceEpoch}';
      }
    } catch (e) {
      newDeviceId = 'fallback_id_${DateTime.now().millisecondsSinceEpoch}';
    }

    await prefs.setString('device_id', newDeviceId);
    return newDeviceId;
  }
}

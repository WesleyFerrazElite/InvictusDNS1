import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'config.dart';
import 'security.dart';
import 'package:share_plus/share_plus.dart';

void main() {
  runApp(const InvictusDNSApp());
}

class InvictusDNSApp extends StatelessWidget {
  const InvictusDNSApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '🛡️ InvictusDNS App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        fontFamily: 'Roboto',
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0f0f23),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  bool isConnected = false;
  bool vpnActive = false;
  int dnsQueries = 0;
  int blockedThreats = 0;
  double secureTraffic = 0.0;
  double avgSpeed = 0.0;
  List<String> logs = [];
  Timer? _statsTimer;
  Timer? _logTimer;
  String deviceId = 'Carregando...';

  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    )..repeat(reverse: true);
    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.05).animate(_pulseController);

    logs.addAll([
      '🚀 InvictusDNS App inicializado',
      '🧠 IA de segurança carregada',
      '🔄 Aguardando conexão neural...'
    ]);

    _loadDeviceId();
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _statsTimer?.cancel();
    _logTimer?.cancel();
    super.dispose();
  }

  Future<void> connectDNS() async {
    setState(() {
      isConnected = false;
    });

    // Simular conexão com backend
    try {
      final response = await http.post(
        Uri.parse(Config.connectEndpoint),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'action': 'connect'}),
      ).timeout(Config.connectTimeout);

      if (response.statusCode == 200) {
        setState(() {
          isConnected = true;
        });
        addLog('🟢 Conexão neural estabelecida com sucesso');
        addLog('🛡️ Firewall quântico ativado');
        addLog('🔍 IA iniciando monitoramento contínuo');
        startMonitoring();
      } else {
        addLog('❌ Falha na conexão com o servidor');
      }
    } catch (e) {
      addLog('❌ Erro de rede: $e');
    }
  }

  void toggleVPN() {
    if (!isConnected) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('⚠️ Conecte ao DNS Neural primeiro!')),
      );
      return;
    }

    setState(() {
      vpnActive = !vpnActive;
    });

    if (vpnActive) {
      addLog('🛡️ VPN Quântica ativada - Tráfego 100% criptografado');
      addLog('🔒 Protocolo de encriptação pós-quântico ativo');
    } else {
      addLog('🔓 VPN desativada');
    }
  }

  void disconnect() {
    setState(() {
      isConnected = false;
      vpnActive = false;
    });
    _statsTimer?.cancel();
    _logTimer?.cancel();
    addLog('🔌 Conexão neural encerrada');
  }

  void startMonitoring() {
    _statsTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (isConnected) {
        setState(() {
          dnsQueries += (5 + (15 * (DateTime.now().millisecondsSinceEpoch % 100) / 100)).toInt();
          secureTraffic += 0.1 + (0.1 * (DateTime.now().millisecondsSinceEpoch % 100) / 100);
          avgSpeed = 8 + (5 * (DateTime.now().millisecondsSinceEpoch % 100) / 100);

          if ((DateTime.now().millisecondsSinceEpoch % 100) < 8) {
            blockedThreats++;
            showThreatAlert();
          }
        });
      }
    });

    _logTimer = Timer.periodic(const Duration(seconds: 2), (timer) {
      if (isConnected && (DateTime.now().millisecondsSinceEpoch % 100) < 40) {
        final messages = [
          '🔍 IA analisou domínio: ${generateRandomDomain()}',
          '🛡️ Tráfego seguro detectado: ${(10 + (90 * (DateTime.now().millisecondsSinceEpoch % 100) / 100)).toInt()}KB',
          '⚡ Cache neural otimizado',
          '🔒 Certificado SSL validado',
          '📊 Métricas atualizadas'
        ];
        addLog(messages[DateTime.now().millisecondsSinceEpoch % messages.length]);
      }
    });
  }

  void showThreatAlert() {
    addLog('🚨 IA neutralizou ameaça automaticamente!');
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('🚨 Ameaça Detectada! IA atuando automaticamente.'),
        duration: Duration(seconds: 3),
      ),
    );
  }

  void runAIScan() async {
    addLog('🔍 Iniciando varredura neural completa...');

    try {
      final response = await http.post(
        Uri.parse(Config.aiScanEndpoint),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'action': 'scan'}),
      ).timeout(Config.connectTimeout);

      if (response.statusCode == 200) {
        addLog('✅ Varredura concluída - Sistema 100% seguro');
      } else {
        addLog('❌ Falha na varredura IA');
      }
    } catch (e) {
      addLog('❌ Erro na varredura: $e');
    }
  }

  void addLog(String message) {
    setState(() {
      logs.insert(0, '${DateTime.now().toString().substring(11, 19)} - $message');
      if (logs.length > 15) {
        logs.removeLast();
      }
    });
  }

  String generateRandomDomain() {
    return Config.domains[DateTime.now().millisecondsSinceEpoch % Config.domains.length];
  }

  Future<void> _loadDeviceId() async {
    try {
      final id = await Config.getDeviceId();
      setState(() {
        deviceId = id;
      });
      addLog('🔑 ID do dispositivo carregado: ${id.substring(0, 8)}...');
    } catch (e) {
      addLog('❌ Erro ao carregar ID do dispositivo: $e');
    }
  }

  void _shareDeviceId() {
    Share.share('Meu ID do InvictusDNS: $deviceId\n\nConecte-se comigo!', subject: 'ID do InvictusDNS');
    addLog('📤 ID do dispositivo compartilhado');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFF0f0f23),
              Color(0xFF1a1a2e),
              Color(0xFF16213e),
              Color(0xFF0f3460),
              Color(0xFF1a1a2e),
            ],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: Colors.white.withOpacity(0.05),
                    border: Border.all(color: Colors.white.withOpacity(0.1)),
                  ),
                  child: Column(
                    children: [
                      const Text(
                        '🛡️ InvictusDNS App',
                        style: TextStyle(
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                          foreground: Paint()
                            ..shader = LinearGradient(
                              colors: [Color(0xFF00d4ff), Color(0xFFff6b6b), Color(0xFFffd93d), Color(0xFF6bcf7f)],
                            ).createShader(const Rect.fromLTWH(0.0, 0.0, 200.0, 70.0)),
                        ),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        '🧠 IA de Segurança Inteligente | 🔒 Proteção Avançada | ⚡ Performance Máxima',
                        style: TextStyle(color: Colors.grey[400], fontSize: 14),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 15),
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.05),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Colors.white.withOpacity(0.1)),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    '🔑 ID do Dispositivo',
                                    style: TextStyle(color: Colors.grey[400], fontSize: 12),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    deviceId == 'Carregando...' ? deviceId : '${deviceId.substring(0, 8)}...${deviceId.substring(deviceId.length - 8)}',
                                    style: const TextStyle(color: Color(0xFF00d4ff), fontSize: 14, fontFamily: 'Courier'),
                                  ),
                                ],
                              ),
                            ),
                            IconButton(
                              onPressed: deviceId != 'Carregando...' ? _shareDeviceId : null,
                              icon: const Icon(Icons.share, color: Color(0xFF6bcf7f)),
                              tooltip: 'Compartilhar ID',
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 20),

                // Status Card
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: Colors.white.withOpacity(0.08),
                    border: Border.all(color: Colors.white.withOpacity(0.1)),
                  ),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          AnimatedBuilder(
                            animation: _pulseAnimation,
                            builder: (context, child) {
                              return Container(
                                width: 20,
                                height: 20,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: isConnected ? Colors.green : Colors.red,
                                  boxShadow: [
                                    BoxShadow(
                                      color: (isConnected ? Colors.green : Colors.red).withOpacity(0.6),
                                      blurRadius: 10,
                                      spreadRadius: 2,
                                    ),
                                  ],
                                ),
                                transform: Matrix4.identity()..scale(_pulseAnimation.value),
                              );
                            },
                          ),
                          const SizedBox(width: 15),
                          const Text(
                            'Status da Conexão Neural',
                            style: TextStyle(color: Color(0xFF00d4ff), fontSize: 18, fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                      const SizedBox(height: 15),
                      Text(
                        isConnected
                            ? '🟢 Conectado ao InvictusDNS! Proteção neural ativa.'
                            : '🔄 Inicializando sistemas de segurança...',
                        style: TextStyle(color: Colors.grey[300]),
                      ),
                      const SizedBox(height: 20),
                      Row(
                        children: [
                          Expanded(
                            child: ElevatedButton(
                              onPressed: isConnected ? null : connectDNS,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFF667eea),
                                padding: const EdgeInsets.symmetric(vertical: 15),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
                              ),
                              child: const Text('🚀 Conectar ao DNS Neural'),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: ElevatedButton(
                              onPressed: toggleVPN,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: vpnActive ? const Color(0xFFff3838) : const Color(0xFFff6b6b),
                                padding: const EdgeInsets.symmetric(vertical: 15),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
                              ),
                              child: Text(vpnActive ? '🔐 VPN Quântica Ativa' : '🔐 Ativar VPN Quântica'),
                            ),
                          ),
                        ],
                      ),
                      if (isConnected)
                        Padding(
                          padding: const EdgeInsets.only(top: 10),
                          child: ElevatedButton(
                            onPressed: disconnect,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFFff3838),
                              padding: const EdgeInsets.symmetric(vertical: 12),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
                            ),
                            child: const Text('🔌 Desconectar'),
                          ),
                        ),
                    ],
                  ),
                ),

                const SizedBox(height: 20),

                // Metrics Grid
                GridView.count(
                  crossAxisCount: 2,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisSpacing: 15,
                  mainAxisSpacing: 15,
                  children: [
                    _buildMetricCard('📊 Métricas em Tempo Real', [
                      _buildMetric('Consultas DNS:', dnsQueries.toString()),
                      _buildMetric('Tráfego Protegido:', '${secureTraffic.toStringAsFixed(1)} MB'),
                      _buildMetric('Ameaças Neutralizadas:', blockedThreats.toString()),
                      _buildMetric('Velocidade Neural:', '${avgSpeed.toStringAsFixed(1)} ms'),
                    ]),
                    _buildMetricCard('🤖 IA de Segurança', [
                      _buildMetric('Status da IA:', '🟢 Ativa', color: Colors.green),
                      _buildMetric('Última Varredura:', 'Agora'),
                      _buildMetric('Proteções Ativas:', '7'),
                      ElevatedButton(
                        onPressed: runAIScan,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFFff6b6b),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                        ),
                        child: const Text('🔍 Executar Varredura Neural'),
                      ),
                    ]),
                  ],
                ),

                const SizedBox(height: 20),

                // Logs Card
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: Colors.white.withOpacity(0.08),
                    border: Border.all(color: Colors.white.withOpacity(0.1)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        '📋 Logs do Sistema',
                        style: TextStyle(color: Color(0xFFffd93d), fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 15),
                      SizedBox(
                        height: 200,
                        child: ListView.builder(
                          itemCount: logs.length,
                          itemBuilder: (context, index) {
                            return Container(
                              margin: const EdgeInsets.only(bottom: 8),
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.05),
                                borderRadius: BorderRadius.circular(8),
                                border: Border(left: BorderSide(color: const Color(0xFF6bcf7f), width: 3)),
                              ),
                              child: Text(
                                logs[index],
                                style: const TextStyle(fontFamily: 'Courier', fontSize: 12),
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 20),

                // Alerts Card
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: Colors.white.withOpacity(0.08),
                    border: Border.all(color: Colors.white.withOpacity(0.1)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        '⚠️ Alertas de Segurança',
                        style: TextStyle(color: Color(0xFFffd93d), fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 15),
                      Container(
                        padding: const EdgeInsets.all(15),
                        decoration: BoxDecoration(
                          color: const Color(0xFFff4757).withOpacity(0.2),
                          borderRadius: BorderRadius.circular(15),
                          border: Border.all(color: const Color(0xFFff4757).withOpacity(0.3)),
                        ),
                        child: const Text(
                          '🚨 Sistema seguro - Nenhuma ameaça ativa',
                          style: TextStyle(color: Color(0xFF6bcf7f)),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildMetricCard(String title, List<Widget> children) {
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: Colors.white.withOpacity(0.08),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(color: Color(0xFFffd93d), fontSize: 16, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 15),
          ...children,
        ],
      ),
    );
  }

  Widget _buildMetric(String label, String value, {Color? color}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(10),
        border: Border(left: BorderSide(color: const Color(0xFF00d4ff), width: 3)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(color: Colors.grey[400], fontWeight: FontWeight.w500)),
          Text(
            value,
            style: TextStyle(
              color: color ?? const Color(0xFF00d4ff),
              fontWeight: FontWeight.bold,
              fontFamily: 'Courier',
            ),
          ),
        ],
      ),
    );
  }
}

// Utilitários de Segurança Avançada InvictusDNS
import 'dart:io';
import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:local_auth/local_auth.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:path_provider/path_provider.dart';
import 'config.dart';

class SecurityUtils {
  static final LocalAuthentication _localAuth = LocalAuthentication();
  static const FlutterSecureStorage _secureStorage = FlutterSecureStorage();

  // Autenticação Biométrica
  static Future<bool> authenticateBiometric() async {
    if (!Config.enableBiometricAuth) return true;

    try {
      final bool canAuthenticateWithBiometrics = await _localAuth.canCheckBiometrics;
      final bool canAuthenticate = canAuthenticateWithBiometrics || await _localAuth.isDeviceSupported();

      if (!canAuthenticate) return false;

      final List<BiometricType> availableBiometrics = await _localAuth.getAvailableBiometrics();

      return await _localAuth.authenticate(
        localizedReason: 'Autentique-se para acessar o InvictusDNS',
        options: const AuthenticationOptions(
          useErrorDialogs: true,
          stickyAuth: true,
          biometricOnly: false,
        ),
      );
    } catch (e) {
      return false;
    }
  }

  // Detecção de Root/Jailbreak
  static Future<bool> isDeviceRooted() async {
    if (!Config.enableRootDetection) return false;

    if (Platform.isAndroid) {
      return await _checkAndroidRoot();
    } else if (Platform.isIOS) {
      return await _checkIOSJailbreak();
    }
    return false;
  }

  static Future<bool> _checkAndroidRoot() async {
    try {
      // Verificar arquivos de sistema root
      final rootFiles = [
        '/system/app/Superuser.apk',
        '/system/xbin/su',
        '/system/bin/su',
        '/system/xbin/busybox',
      ];

      for (final file in rootFiles) {
        if (await File(file).exists()) return true;
      }

      // Verificar comandos root
      final result = await Process.run('which', ['su']);
      return result.exitCode == 0;
    } catch (e) {
      return false;
    }
  }

  static Future<bool> _checkIOSJailbreak() async {
    try {
      final jailbreakFiles = [
        '/Applications/Cydia.app',
        '/Library/MobileSubstrate/MobileSubstrate.dylib',
        '/bin/bash',
        '/usr/sbin/sshd',
        '/etc/apt',
      ];

      for (final file in jailbreakFiles) {
        if (await File(file).exists()) return true;
      }

      return false;
    } catch (e) {
      return false;
    }
  }

  // Verificação de Integridade de Arquivos
  static Future<bool> verifyIntegrity() async {
    if (!Config.enableIntegrityCheck) return true;

    try {
      for (final file in Config.criticalFiles) {
        final checksum = await _calculateFileChecksum(file);
        final expectedChecksum = Config.fileChecksums[file];

        if (expectedChecksum != null && expectedChecksum.isNotEmpty) {
          if (checksum != expectedChecksum) {
            return false;
          }
        }
      }
      return true;
    } catch (e) {
      return false;
    }
  }

  static Future<String> _calculateFileChecksum(String filePath) async {
    try {
      final file = File(filePath);
      if (!await file.exists()) return '';

      final bytes = await file.readAsBytes();
      final digest = sha256.convert(bytes);
      return digest.toString();
    } catch (e) {
      return '';
    }
  }

  // Rate Limiting
  static final Map<String, List<DateTime>> _requestLog = {};

  static bool checkRateLimit(String identifier) {
    final now = DateTime.now();
    final requests = _requestLog[identifier] ?? [];

    // Remove requests fora da janela de tempo (1 minuto)
    requests.removeWhere((time) => now.difference(time).inMinutes >= 1);

    if (requests.length >= Config.maxRequestsPerMinute) {
      return false; // Rate limit excedido
    }

    requests.add(now);
    _requestLog[identifier] = requests;
    return true;
  }

  // Armazenamento Seguro
  static Future<void> storeSecureData(String key, String value) async {
    await _secureStorage.write(key: key, value: value);
  }

  static Future<String?> getSecureData(String key) async {
    return await _secureStorage.read(key: key);
  }

  static Future<void> deleteSecureData(String key) async {
    await _secureStorage.delete(key: key);
  }

  // Encriptação Básica (para dados sensíveis)
  static String encryptData(String data, String key) {
    final keyBytes = utf8.encode(key);
    final dataBytes = utf8.encode(data);
    final hmac = Hmac(sha256, keyBytes);
    final digest = hmac.convert(dataBytes);
    return base64.encode(digest.bytes);
  }

  static bool verifyData(String data, String key, String expectedHash) {
    final calculatedHash = encryptData(data, key);
    return calculatedHash == expectedHash;
  }

  // Logs de Segurança
  static void logSecurityEvent(String event, {String? details}) {
    final timestamp = DateTime.now().toIso8601String();
    final logEntry = '[$timestamp] SECURITY: $event ${details ?? ''}';
    print(logEntry); // Em produção, enviar para servidor seguro
  }
}

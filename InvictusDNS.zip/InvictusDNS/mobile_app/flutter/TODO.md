# TODO - Melhorias de Segurança Avançada InvictusDNS

## ✅ Implementado
- [x] ID único do dispositivo
- [x] Compartilhamento de ID
- [x] VPN quântica simulada
- [x] IA de segurança
- [x] Firewall neural
- [x] Integração ClamAV

## 🔄 Em Desenvolvimento

### 1. Autenticação Biométrica
- [ ] Adicionar dependência `local_auth`
- [ ] Criar tela de autenticação biométrica
- [ ] Implementar verificação de impressão digital/face ID
- [ ] Adicionar fallback para PIN/senha
- [ ] Configurar permissões no AndroidManifest.xml e Info.plist

### 2. Encriptação Quântica-Resistente
- [ ] Adicionar dependência `crypto` e `pointycastle`
- [ ] Implementar algoritmo Kyber para troca de chaves
- [ ] Atualizar comunicação com servidor para usar PQ crypto
- [ ] Adicionar verificação de integridade de mensagens

### 3. Detecção de Jailbreak/Root
- [ ] Criar função de detecção de root/jailbreak
- [ ] Verificar arquivos de sistema comprometidos
- [ ] Alertar usuário sobre dispositivos inseguros
- [ ] Bloquear funcionalidades em dispositivos comprometidos

### 4. Rate Limiting e Anti-DDoS
- [ ] Implementar controle de taxa de requisições
- [ ] Adicionar detecção de padrões suspeitos
- [ ] Bloquear IPs maliciosos temporariamente
- [ ] Logs de tentativas de ataque

### 5. Verificação de Integridade do Código
- [ ] Implementar checksums SHA-256 para arquivos críticos
- [ ] Verificar integridade na inicialização
- [ ] Alertar sobre modificações não autorizadas
- [ ] Auto-reparo de arquivos corrompidos

## 📋 Próximos Passos
1. Atualizar pubspec.yaml com novas dependências
2. Implementar autenticação biométrica
3. Adicionar detecção de root/jailbreak
4. Implementar encriptação quântica-resistente
5. Adicionar verificações de integridade
6. Testar todas as funcionalidades
7. Atualizar documentação

## 🔧 Dependências Necessárias
- local_auth: ^2.1.6
- crypto: ^3.0.3
- pointycastle: ^3.7.3
- path_provider: ^2.1.2
- flutter_secure_storage: ^9.0.0

## 📱 Permissões Adicionais
- USE_FINGERPRINT (Android)
- FACE_ID (iOS)
- Biometric authentication capabilities

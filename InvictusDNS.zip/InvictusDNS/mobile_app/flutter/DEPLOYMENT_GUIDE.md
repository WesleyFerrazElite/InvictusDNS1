# 📱 Guia de Implantação - InvictusDNS App

## Visão Geral
Este guia explica como implantar o app InvictusDNS nas lojas Google Play Store e Apple App Store, com compatibilidade total para Android e iOS.

## 📋 Pré-requisitos

### Para Android
- Conta de Desenvolvedor Google Play (US$ 25)
- JDK 11 ou superior
- Android Studio com SDK
- Chave de upload (gerada no Play Console)

### Para iOS
- Conta de Desenvolvedor Apple (US$ 99/ano)
- macOS com Xcode
- iPhone/iPad para testes
- Certificados de distribuição

---

## 🚀 Passo a Passo - Android (Google Play Store)

### 1. Preparação do Projeto
```bash
# Navegue até o diretório do projeto
cd InvictusDNS/mobile_app/flutter

# Instale as dependências
flutter pub get

# Execute limpeza
flutter clean
```

### 2. Configuração da Assinatura
```bash
# Gere chave de upload (execute apenas uma vez)
keytool -genkey -v -keystore upload-keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload

# Mova a chave para android/app/
mv upload-keystore.jks android/app/
```

### 3. Arquivo de Configuração da Chave
Crie o arquivo `android/key.properties`:
```
storePassword=SUA_SENHA_AQUI
keyPassword=SUA_SENHA_AQUI
keyAlias=upload
storeFile=../app/upload-keystore.jks
```

### 4. Build de Produção
```bash
# Build para Android
flutter build apk --release

# OU build app bundle (recomendado)
flutter build appbundle --release
```

### 5. Upload para Google Play Console

#### Acesse: https://play.google.com/console
1. **Criar App**
   - Nome: InvictusDNS - Segurança Neural
   - Idiomas: Português (Brasil), Inglês
   - Tipo: Aplicativo

2. **Configurações da Loja**
   - **Título**: InvictusDNS - Proteção Neural Avançada
   - **Descrição Curta**: App de segurança com IA quântica e VPN neural
   - **Descrição Completa**: [Copie do README.md]
   - **Ícones**: 512x512px (android/app/src/main/res/mipmap-xxxhdpi/ic_launcher.png)
   - **Capturas de Tela**: 6-8 imagens (1080x1920px)

3. **Conteúdo do App**
   - **Classificação**: Todos os públicos
   - **Categoria**: Ferramentas > Segurança
   - **Tags**: segurança, vpn, dns, ia, quântico

4. **Testes**
   - **Teste Interno**: Adicione emails de teste
   - **Teste Fechado**: Grupos específicos
   - **Teste Aberto**: Público limitado

5. **Liberar Versão**
   - **Trilha**: Produção
   - **Países**: Todos disponíveis
   - **Preço**: Gratuito

---

## 🍎 Passo a Passo - iOS (App Store)

### 1. Preparação no macOS
```bash
# Instale Flutter no macOS
# Baixe do site oficial: https://flutter.dev

# Navegue até o projeto
cd InvictusDNS/mobile_app/flutter

# Instale dependências
flutter pub get
```

### 2. Configuração do Xcode
```bash
# Abra no Xcode
open ios/Runner.xcworkspace

# OU via Flutter
flutter build ios --release
```

### 3. Configurações no Xcode

#### General Settings:
- **Display Name**: InvictusDNS
- **Bundle Identifier**: com.invictus.dns
- **Version**: 1.0.0
- **Build**: 1

#### Signing & Capabilities:
- **Team**: Sua conta de desenvolvedor
- **Bundle Identifier**: Deve corresponder ao registrado
- **Signing Certificate**: Development/Distribution

#### Info.plist (já configurado):
- Face ID permission adicionada
- Network permissions incluídas

### 4. Build e Archive
```bash
# Build release
flutter build ios --release --no-codesign

# Archive via Xcode:
# Product > Archive
```

### 5. Upload para App Store Connect

#### Acesse: https://appstoreconnect.apple.com
1. **Criar App**
   - **Nome**: InvictusDNS
   - **Idioma**: Português (Brasil)
   - **Bundle ID**: com.invictus.dns
   - **SKU**: INVictusDNS001

2. **App Information**
   - **Categoria**: Utilitários > Segurança
   - **Subcategoria**: Privacidade
   - **Classificação**: 4+ (Conteúdo para maiores de 4 anos)

3. **Preços e Disponibilidade**
   - **Preço**: Gratuito
   - **Disponibilidade**: Todos os países

4. **Versão 1.0.0**
   - **O que há de novo**: Versão inicial com segurança quântica
   - **Descrição**: [Copie do README.md]
   - **Palavras-chave**: segurança, vpn, dns, ia, quântico
   - **Capturas de Tela**: 6-8 imagens (iPhone/iPad)

5. **Build Upload**
   - Use **Transporter** app ou Xcode
   - Selecione o arquivo .ipa gerado

6. **Revisão e Lançamento**
   - **TestFlight**: Distribua para beta testers
   - **App Review**: Aguarde aprovação (normalmente 24-48h)
   - **Liberar**: Manual ou Automático

---

## 📂 Estrutura de Arquivos para Upload

### Android (Google Play):
```
InvictusDNS/mobile_app/flutter/
├── android/
│   ├── app/
│   │   ├── build.gradle
│   │   ├── src/main/
│   │   │   ├── AndroidManifest.xml
│   │   │   └── res/
│   │   │       └── mipmap-xxxhdpi/
│   │   │           └── ic_launcher.png
│   │   └── upload-keystore.jks
│   └── key.properties
├── build/app/outputs/bundle/release/
│   └── app-release.aab
└── pubspec.yaml
```

### iOS (App Store):
```
InvictusDNS/mobile_app/flutter/
├── ios/
│   ├── Runner.xcworkspace/
│   ├── Runner/
│   │   ├── Info.plist
│   │   ├── Assets.xcassets/
│   │   │   └── AppIcon.appiconset/
│   │   └── Base.lproj/
│   │       └── LaunchScreen.storyboard
│   └── Flutter/
│       └── AppFrameworkInfo.plist
├── build/ios/iphoneos/
│   └── Runner.app/
└── pubspec.yaml
```

---

## 🔧 Configurações Específicas por Dispositivo

### Android - Compatibilidade:
- **Versão Mínima**: API 21 (Android 5.0)
- **Versão Alvo**: API 34 (Android 14)
- **ABI**: armeabi-v7a, arm64-v8a, x86, x86_64
- **Screen Densities**: ldpi, mdpi, hdpi, xhdpi, xxhdpi, xxxhdpi

### iOS - Compatibilidade:
- **Versão Mínima**: iOS 11.0
- **Dispositivos**: iPhone 6s+, iPad 5+, iPod Touch 7+
- **Orientação**: Retrato (Portrait)
- **Capabilities**: Face ID, Biometrics

---

## 🚨 Dicas Importantes

### Antes do Upload:
1. **Teste em Dispositivos Reais**
   ```bash
   # Android
   flutter run --release

   # iOS
   flutter run --release
   ```

2. **Verifique Logs**
   - Monitore erros no console
   - Teste autenticação biométrica
   - Verifique permissões

3. **Otimização**
   - Minimize tamanho do APK/AAB
   - Otimize imagens e assets
   - Configure ProGuard/R8

### Após o Upload:
1. **Monitoramento**
   - Google Play Console: Crash reports, analytics
   - App Store Connect: App Analytics, vendas

2. **Atualizações**
   - Planeje releases regulares
   - Mantenha compatibilidade
   - Atualize dependências de segurança

---

## 💡 Suporte e Troubleshooting

### Problemas Comuns:

**Android:**
- Erro de assinatura: Verifique key.properties
- Permissões: Atualize AndroidManifest.xml
- Build falha: flutter clean && flutter pub get

**iOS:**
- Certificado expirado: Renove no developer.apple.com
- Bundle ID incorreto: Deve corresponder ao registrado
- Capabilities: Configure no Xcode

### Recursos Úteis:
- [Flutter Deployment Docs](https://docs.flutter.dev/deployment/android)
- [Google Play Launch](https://support.google.com/googleplay/android-developer/answer/2528691)
- [App Store Connect Help](https://developer.apple.com/support/app-store-connect/)

---

**🎉 Pronto! Seu app InvictusDNS estará disponível para milhões de usuários Android e iOS com segurança quântica de ponta!**

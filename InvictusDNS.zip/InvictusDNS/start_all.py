#!/usr/bin/env python3
"""
InvictusDNS - Iniciar Todos os Serviços
Inicia DNS Server, Web Panel, Marketing Panel e Cloud Panel simultaneamente.
Compatível com Windows e Linux.
"""

import subprocess
import sys
import os
import time
import signal
import platform
import threading

def start_service(name, script_path, port=None):
    """Inicia um serviço em background"""
    if not os.path.exists(script_path):
        print(f"Erro: Arquivo {script_path} não encontrado!")
        return None

    try:
        if platform.system() == 'Windows':
            cmd = [sys.executable, script_path]
        else:
            cmd = ['python3', script_path]

        print(f"Iniciando {name}: {' '.join(cmd)}")
        process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        # Aguardar um pouco para ver se iniciou
        time.sleep(2)
        if process.poll() is None:
            print(f"{name} iniciado com sucesso. PID: {process.pid}")
            if port:
                print(f"Acesse {name}: http://localhost:{port}")
            return process
        else:
            stdout, stderr = process.communicate()
            print(f"Erro ao iniciar {name}:")
            print("STDOUT:", stdout.decode())
            print("STDERR:", stderr.decode())
            return None

    except Exception as e:
        print(f"Erro ao iniciar {name}: {e}")
        return None

def main():
    print("InvictusDNS - Iniciando Todos os Serviços...")
    print(f"Sistema Operacional: {platform.system()}")
    print("=" * 50)

    processes = []

    # Iniciar DNS Server
    dns_script = os.path.join(os.path.dirname(__file__), 'server', 'dns_server.py')
    dns_process = start_service("Servidor DNS", dns_script)
    if dns_process:
        processes.append(("Servidor DNS", dns_process))

    # Iniciar Web Panel
    web_script = os.path.join(os.path.dirname(__file__), 'panels', 'web_panel.py')
    web_process = start_service("Painel Web", web_script, 3000)
    if web_process:
        processes.append(("Painel Web", web_process))

    # Iniciar Marketing Panel
    marketing_script = os.path.join(os.path.dirname(__file__), 'panels', 'marketing_panel.py')
    marketing_process = start_service("Painel Marketing", marketing_script, 3001)
    if marketing_process:
        processes.append(("Painel Marketing", marketing_process))

    # Iniciar Cloud Panel
    cloud_script = os.path.join(os.path.dirname(__file__), 'panels', 'cloud_panel.py')
    cloud_process = start_service("Painel Cloud", cloud_script, 3003)
    if cloud_process:
        processes.append(("Painel Cloud", cloud_process))

    # Iniciar AI Panel se existir
    ai_script = os.path.join(os.path.dirname(__file__), 'panels', 'ai_panel.py')
    if os.path.exists(ai_script):
        ai_process = start_service("Painel IA", ai_script, 3002)
        if ai_process:
            processes.append(("Painel IA", ai_process))

    print("\n" + "=" * 50)
    print("Serviços Iniciados:")
    for name, proc in processes:
        print(f"- {name}: PID {proc.pid}")

    print("\nAcessos:")
    print("- Painel Web: http://localhost:3000 (admin/senha123)")
    print("- Painel Marketing: http://localhost:3001")
    print("- Painel Cloud: http://localhost:3003")
    if any("IA" in name for name, _ in processes):
        print("- Painel IA: http://localhost:3002")

    print("\nPressione Ctrl+C para parar todos os serviços...")

    try:
        # Manter todos os processos ativos
        while True:
            time.sleep(1)
            # Verificar se algum processo morreu
            for name, proc in processes[:]:
                if proc.poll() is not None:
                    print(f"Aviso: {name} parou inesperadamente.")
                    processes.remove((name, proc))

            if not processes:
                print("Todos os serviços pararam.")
                break

    except KeyboardInterrupt:
        print("\nParando todos os serviços...")
        for name, proc in processes:
            print(f"Parando {name}...")
            proc.terminate()

        # Aguardar todos terminarem
        for name, proc in processes:
            try:
                proc.wait(timeout=5)
                print(f"{name} parado.")
            except subprocess.TimeoutExpired:
                print(f"Forçando parada de {name}...")
                proc.kill()

        print("Todos os serviços parados.")

if __name__ == '__main__':
    main()

# 🚀 GUIA RÁPIDO - InvictusDNS Setup

## 📦 DOWNLOAD E INSTALAÇÃO

### **1. Baixar Arquivos**
```bash
# Clone ou baixe o repositório
git clone https://github.com/seu-repo/invictus-dns.git
cd invictus-dns
```

### **2. Executar Setup (Automático)**

#### **Windows:**
```cmd
# Execute como administrador
setup.bat
# OU
python installer.py
```

#### **Linux/macOS:**
```bash
# Execute com sudo
sudo bash setup.sh
# OU
sudo python3 installer.py
```

### **3. Seguir Menu do Instalador**
O instalador irá:
- ✅ Verificar Python 3.8+
- ✅ Instalar dependências automaticamente
- ✅ Configurar firewall (portas 53, 3000-3003)
- ✅ Criar arquivo `.env` para APIs
- ✅ Instalar no sistema
- ✅ Criar atalhos na área de trabalho
- ✅ Criar scripts de start/stop

---

## 🔑 CONFIGURAÇÃO DAS APIs

### **Editar arquivo .env**
```bash
# Abra o arquivo .env criado pelo instalador
# Preencha APENAS as chaves que você tem:

# Exemplo mínimo (OpenAI):
OPENAI_API_KEY=sk-sua-chave-aqui

# OU Groq (mais rápido):
GROQ_API_KEY=gsk-sua-chave-aqui
```

### **Onde obter chaves:**
- **OpenAI**: https://platform.openai.com/api-keys
- **Groq**: https://console.groq.com/keys
- **Google**: https://makersuite.google.com/app/apikey
- **Anthropic**: https://console.anthropic.com/

---

## ▶️ INICIAR SISTEMA

### **Opção 1: Atalho Desktop**
- Clique no ícone "InvictusDNS" na área de trabalho

### **Opção 2: Scripts**
```bash
# Windows
start_invictus.bat

# Linux/macOS
./start_invictus.sh
```

### **Opção 3: Manual**
```bash
python launcher.py
# OU
python start_all.py
```

---

## 🌐 ACESSAR PAINÉIS

Após iniciar, acesse:

| Painel | URL | Login | Descrição |
|--------|-----|-------|-----------|
| **Web Admin** | http://localhost:3000 | admin/senha123 | Dashboard principal |
| **IA** | http://localhost:3002 | admin/senha123 | **Painel de IA completo** |
| **Marketing** | http://localhost:3001 | - | Página promocional |
| **Cloud** | http://localhost:3003 | - | Backup e compartilhamento |

---

## ⚙️ CONFIGURAÇÃO DNS

### **No Windows:**
1. Configurações → Rede e Internet → Alterar opções do adaptador
2. Clique direito na conexão → Propriedades
3. Protocolo TCP/IPv4 → Propriedades
4. Servidores DNS: `SEU_IP_LOCAL`
5. OK

### **No Linux:**
```bash
sudo nano /etc/resolv.conf
# Adicione:
nameserver SEU_IP_LOCAL
```

### **Mobile:**
1. Configurações → Wi-Fi
2. Toque e segure na rede → Modificar rede
3. Avançado → DNS
4. `SEU_IP_LOCAL`

---

## 🧠 USANDO O PAINEL IA

### **Funcionalidades Principais:**
- **Chat com IA**: Conversar e dar comandos
- **Monitoramento**: CPU, memória, processos
- **Segurança**: Análise de ameaças, quarentena
- **Automação**: Regras inteligentes
- **Machine Learning**: Detecção de anomalias

### **Comandos de Voz/IA:**
```
"bloqueie o domínio example.com"
"analise o tráfego suspeito"
"verifique ameaças no IP 192.168.1.1"
```

---

## 🔧 SCRIPTS ÚTEIS

### **Iniciar Serviços:**
```bash
# Windows
start_invictus.bat

# Linux
./start_invictus.sh
```

### **Parar Serviços:**
```bash
# Windows
stop_invictus.bat

# Linux
./stop_invictus.sh
```

### **Testar Instalação:**
```bash
python launcher.py --test
```

---

## 📚 DOCUMENTAÇÃO COMPLETA

- `README_AI_PANEL.md` - Guia detalhado do painel IA
- `TUTORIAL_INSTALACAO.txt` - Instalação passo-a-passo
- `TODO_AI_CONFIG.md` - Roadmap e funcionalidades

---

## ⚠️ TROUBLESHOOTING

### **Problema: Serviços não iniciam**
```bash
# Verificar portas ocupadas
netstat -ano | findstr :3000

# Matar processos
taskkill /f /im python.exe
```

### **Problema: IA não funciona**
```bash
# Verificar .env
cat .env

# Testar API
python -c "import openai; print('OK' if openai.api_key else 'Chave faltando')"
```

### **Problema: Firewall bloqueando**
```bash
# Windows
netsh advfirewall firewall add rule name="InvictusDNS" dir=in action=allow protocol=TCP localport=3000-3003

# Linux
sudo ufw allow 3000:3003/tcp
```

---

## 🎯 RESUMO EXECUTADO

✅ **Setup automático** criado (`setup.bat` / `setup.sh`)  
✅ **Instalador Python** melhorado (`installer.py`)  
✅ **Arquivo .env** com template completo  
✅ **Scripts start/stop** para Windows e Linux  
✅ **Atalhos desktop** criados automaticamente  
✅ **Firewall configurado** automaticamente  
✅ **Testes de instalação** incluídos  
✅ **Documentação completa** em português  

---

**🎉 PRONTO! Agora qualquer pessoa pode instalar o InvictusDNS com IA em 5 minutos!**

**Precisa de ajuda?** Consulte `README_AI_PANEL.md` ou os logs em `logs/`

from flask import Flask, render_template_string, request, jsonify, session, redirect, url_for, flash
import openai
import groq
import google.generativeai as genai
import anthropic
from functools import wraps
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
import psutil
import platform
import time
import os
import json
import threading
import logging
from dotenv import load_dotenv
load_dotenv()
from datetime import datetime
from cryptography.fernet import Fernet
import base64
import re
import requests
from monitoring.ml_anomaly_detector import anomaly_detector
from utils.ip_obfuscator import obfuscate_ip, deobfuscate_ip
from security.advanced_security import get_security_stats, analyze_threats

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

app = Flask(__name__)
app.secret_key = 'supersecretkey'

# Encryption setup for API keys
ENCRYPTION_KEY = base64.urlsafe_b64encode(b'InvictusDNS_AI_Panel_Key_2024!')
cipher = Fernet(ENCRYPTION_KEY)

# API keys from environment (encrypted storage)
openai.api_key = os.getenv("OPENAI_API_KEY", "")
groq_api_key = os.getenv("GROQ_API_KEY", "")
google_api_key = os.getenv("GOOGLE_API_KEY", "")
anthropic_api_key = os.getenv("ANTHROPIC_API_KEY", "")
blackbox_api_key = os.getenv("BLACKBOX_API_KEY", "")
glm_api_key = os.getenv("GLM_API_KEY", "")
deepinfra_api_key = os.getenv("DEEPINFRA_API_KEY", "")

# Initialize API clients
if google_api_key:
    try:
        genai.configure(api_key=google_api_key)
    except Exception as e:
        logging.error(f"Erro ao configurar Google AI: {e}")

if anthropic_api_key:
    try:
        import anthropic
        anthropic_client = anthropic.Anthropic(api_key=anthropic_api_key)
    except Exception as e:
        logging.error(f"Erro ao configurar Anthropic: {e}")
        anthropic_client = None
else:
    anthropic_client = None

DB_FILE = 'data/dns_logs.db'
CONFIG_FILE = 'ai_config.json'

# Global AI configuration - FULLY ENABLED AND CONFIGURED
ai_config = {
    'enabled': True,  # IA completamente ativada
    'primary_provider': 'openai',  # Provedor principal
    'secondary_provider': 'groq',  # Provedor secundário para backup
    'language': 'pt-BR',  # Idioma português brasileiro
    'behavior_mode': 'active',  # Modo ativo - responde automaticamente
    'rate_limits': {
        'max_tokens_per_hour': 50000,  # Aumentado para uso intensivo
        'max_requests_per_minute': 120  # Aumentado para alta performance
    },
    'apis': {
        'openai': {
            'enabled': True,
            'key': encrypt_key(openai.api_key) if openai.api_key else '',
            'models': ['gpt-3.5-turbo', 'gpt-4', 'gpt-4-turbo-preview']
        },
        'groq': {
            'enabled': True,
            'key': encrypt_key(groq_api_key) if groq_api_key else '',
            'models': ['llama3-8b-8192', 'llama3-70b-8192', 'mixtral-8x7b-32768']
        },
        'google': {
            'enabled': True,
            'key': encrypt_key(google_api_key) if google_api_key else '',
            'models': ['gemini-pro', 'gemini-pro-vision', 'gemini-1.5-flash']
        },
        'anthropic': {
            'enabled': True,
            'key': encrypt_key(anthropic_api_key) if anthropic_api_key else '',
            'models': ['claude-3-sonnet-20240229', 'claude-3-haiku-20240307', 'claude-3-opus-20240229']
        },
        'blackbox': {
            'enabled': True,
            'key': encrypt_key(blackbox_api_key) if blackbox_api_key else '',
            'models': ['gpt-3.5-turbo', 'gpt-4', 'claude-3-sonnet']
        },
        'glm': {
            'enabled': True,
            'key': encrypt_key(glm_api_key) if glm_api_key else '',
            'models': ['glm-4', 'glm-3-turbo', 'glm-4v']
        },
        'deepinfra': {
            'enabled': True,
            'key': encrypt_key(deepinfra_api_key) if deepinfra_api_key else '',
            'models': ['meta-llama/Llama-2-70b-chat-hf', 'meta-llama/Llama-2-13b-chat-hf', 'codellama/CodeLlama-34b-Instruct-hf']
        }
    },
    'automation_rules': [
        "Monitorar logs DNS constantemente por padrões suspeitos",
        "Bloquear automaticamente domínios maliciosos detectados",
        "Alertar sobre tentativas de DDoS em tempo real",
        "Isolar IPs com comportamento anômalo",
        "Atualizar bases de ameaças a cada hora",
        "Executar análise de malware em domínios suspeitos",
        "Detectar e bloquear tentativas de phishing",
        "Monitorar performance do servidor e otimizar automaticamente",
        "Gerar relatórios diários de segurança",
        "Treinar modelos de ML com novos dados diariamente"
    ],
    'security_features': {
        'malware_detection': True,
        'phishing_detection': True,
        'ddos_protection': True,
        'anomaly_detection': True,
        'zero_day_protection': True,
        'behavior_analysis': True,
        'threat_intelligence': True,
        'automated_response': True
    },
    'learning': {
        'supervised_learning': True,
        'continuous_training': True,
        'data_retention_days': 365,  # Aumentado para melhor aprendizado
        'model_update_frequency': 'daily',
        'feedback_loop': True,
        'adaptive_learning': True
    },
    'monitoring': {
        'real_time_alerts': True,
        'performance_metrics': True,
        'detailed_logging': True,
        'threat_dashboard': True,
        'automated_reporting': True,
        'system_health_checks': True
    },
    'advanced_features': {
        'natural_language_processing': True,
        'sentiment_analysis': True,
        'predictive_analytics': True,
        'automated_decision_making': True,
        'integration_apis': True,
        'custom_commands': True,
        'voice_interface': False,  # Pode ser ativado se necessário
        'multi_language_support': True
    }
}

# Encrypt/decrypt API keys
def encrypt_key(key):
    if not key:
        return ''
    return cipher.encrypt(key.encode()).decode()

def decrypt_key(encrypted_key):
    if not encrypted_key:
        return ''
    try:
        return cipher.decrypt(encrypted_key.encode()).decode()
    except:
        return ''

# Load configuration
def load_ai_config():
    global ai_config
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r') as f:
                ai_config.update(json.load(f))
    except Exception as e:
        print(f"Error loading AI config: {e}")

# Save configuration
def save_ai_config():
    try:
        with open(CONFIG_FILE, 'w') as f:
            json.dump(ai_config, f, indent=2)
    except Exception as e:
        print(f"Error saving AI config: {e}")

# Load config on startup
load_ai_config()

def init_db():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY,
                    username TEXT UNIQUE,
                    password_hash TEXT,
                    role TEXT DEFAULT 'user',
                    ips TEXT
                )''')
    c.execute('''CREATE TABLE IF NOT EXISTS ai_tasks (
                    id INTEGER PRIMARY KEY,
                    timestamp TEXT,
                    description TEXT,
                    status TEXT DEFAULT 'pending'
                )''')
    # Insert admin if not exists
    c.execute("SELECT COUNT(*) FROM users WHERE username = 'admin'")
    if c.fetchone()[0] == 0:
        c.execute("INSERT INTO users (username, password_hash, role, ips) VALUES (?, ?, ?, ?)",
                  ('admin', generate_password_hash('senha123'), 'admin', ''))
    conn.commit()
    conn.close()

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        init_db()
        conn = sqlite3.connect(DB_FILE, timeout=30, check_same_thread=False)
        c = conn.cursor()
        c.execute("SELECT id, password_hash FROM users WHERE username = ?", (username,))
        user = c.fetchone()
        conn.close()
        if user and check_password_hash(user[1], password):
            session['user_id'] = user[0]
            return redirect(url_for('ai_panel'))
        flash('Credenciais inválidas')
    html = """
    <!DOCTYPE html>
    <html>
    <head><title>Login Painel IA</title></head>
    <body>
        <h1>Login Painel de Inteligência Artificial</h1>
        <form method="post">
            <input type="text" name="username" placeholder="Usuário" required><br>
            <input type="password" name="password" placeholder="Senha" required><br>
            <button type="submit">Login</button>
        </form>
    </body>
    </html>
    """
    return html

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    return redirect(url_for('login'))

@app.route('/ai_panel')
@login_required
def ai_panel():
    html = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Painel de Inteligência Artificial</title>
        <style>
            body {
                margin: 0;
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: url('https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1350&q=80') no-repeat center center fixed;
                background-size: cover;
                color: #00ffea;
                overflow-x: hidden;
            }
            .container {
                background-color: rgba(0, 0, 0, 0.85);
                margin: 20px auto;
                padding: 20px;
                border-radius: 15px;
                max-width: 1200px;
                box-shadow: 0 0 20px #00ffea;
            }
            h1 {
                text-align: center;
                font-weight: 700;
                font-size: 2.5em;
                margin-bottom: 20px;
                text-shadow: 0 0 10px #00ffea;
            }
            .tabs {
                display: flex;
                justify-content: center;
                margin-bottom: 20px;
            }
            .tab {
                padding: 10px 20px;
                background: rgba(0, 255, 234, 0.2);
                border: 1px solid #00ffea;
                cursor: pointer;
                border-radius: 8px;
                margin: 0 5px;
                transition: background 0.3s;
            }
            .tab.active {
                background: #00ffea;
                color: #000;
            }
            .tab-content {
                display: none;
            }
            .tab-content.active {
                display: block;
            }
            #log {
                height: 300px;
                overflow-y: scroll;
                background: #001f22;
                padding: 15px;
                border-radius: 10px;
                font-family: monospace;
                font-size: 14px;
                box-shadow: inset 0 0 10px #00ffea;
                margin-bottom: 20px;
            }
            textarea, input[type=text] {
                width: 100%;
                padding: 10px;
                margin-bottom: 15px;
                border-radius: 8px;
                border: none;
                background: #002b2f;
                color: #00ffea;
                font-size: 1em;
                box-shadow: 0 0 5px #00ffea;
            }
            button {
                background-color: #00ffea;
                border: none;
                padding: 12px 25px;
                border-radius: 8px;
                color: #000;
                font-weight: bold;
                cursor: pointer;
                transition: background-color 0.3s ease;
                margin: 5px;
            }
            button:hover {
                background-color: #00c8b3;
            }
            .section {
                margin-bottom: 30px;
            }
            .grid {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 20px;
            }
            .card {
                background: rgba(0, 0, 0, 0.5);
                padding: 15px;
                border-radius: 10px;
                box-shadow: 0 0 10px #00ffea;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Painel de Inteligência Artificial</h1>
            <div class="tabs">
                <div class="tab" onclick="openTab(event, 'Chat')">Chat com IA</div>
                <div class="tab" onclick="openTab(event, 'Config')">Configurações</div>
                <div class="tab" onclick="openTab(event, 'APIs')">APIs</div>
                <div class="tab" onclick="openTab(event, 'ML')">Machine Learning</div>
                <div class="tab" onclick="openTab(event, 'Automation')">Automação</div>
                <div class="tab" onclick="openTab(event, 'Security')">Segurança</div>
                <div class="tab" onclick="openTab(event, 'Tasks')">Tarefas</div>
                <div class="tab" onclick="openTab(event, 'Monitoring')">Monitoramento</div>
                <div class="tab" onclick="openTab(event, 'Advanced')">Avançado</div>
            </div>
            <div id="Chat" class="tab-content">
                <div class="section">
                    <h2>Chat com IA</h2>
                    <div id="log"></div>
                    <textarea id="inputText" rows="4" placeholder="Digite o comando ou pergunta para a IA..."></textarea>
                    <button onclick="sendToAI()">Enviar para IA</button>
                </div>
            </div>
            <div id="Tasks" class="tab-content">
                <div class="section">
                    <h2>Atribuir Tarefas para IA</h2>
                    <input type="text" id="taskInput" placeholder="Descreva a tarefa (ex: Monitorar domínio example.com)">
                    <button onclick="assignTask()">Atribuir Tarefa</button>
                    <div id="tasks" style="height: 200px; overflow-y: scroll; background: #001f22; padding: 10px; border-radius: 10px; margin-top: 10px;"></div>
                </div>
            </div>
                <div id="Security" class="tab-content">
                <div class="section">
                    <h2>Segurança Avançada e Combate a Vírus</h2>
                    <div class="grid">
                        <div class="card">
                            <h3>Estatísticas de Segurança</h3>
                            <div id="securityStats"></div>
                        </div>
                        <div class="card">
                            <h3>Incidentes Recentes</h3>
                            <div id="recentIncidents" style="height: 150px; overflow-y: scroll; background: #001f22; padding: 10px; border-radius: 10px;"></div>
                        </div>
                    </div>
                    <div class="grid">
                        <div class="card">
                            <h3>Análise de Ameaças em Tempo Real</h3>
                            <div id="threatAnalysis"></div>
                            <button onclick="analyzeDomain()">Analisar Domínio</button>
                            <input type="text" id="domainToAnalyze" placeholder="Digite domínio para análise">
                        </div>
                        <div class="card">
                            <h3>Lista de Quarentena</h3>
                            <div id="quarantineList" style="height: 150px; overflow-y: scroll; background: #001f22; padding: 10px; border-radius: 10px;"></div>
                        </div>
                    </div>
                    <div class="card">
                        <h3>Status de Segurança</h3>
                        <div id="securityStatus"></div>
                    </div>
                </div>
            </div>
            <div id="Config" class="tab-content">
                <div class="section">
                    <h2>Configurações Gerais</h2>
                    <div class="grid">
                        <div class="card">
                            <h3>Configurações de IA</h3>
                            <div id="aiConfig"></div>
                            <button id="toggleAI" onclick="toggleAI()">Ativar/Desativar IA</button>
                        </div>
                        <div class="card">
                            <h3>Modo de Comportamento</h3>
                            <div id="behaviorMode"></div>
                        </div>
                    </div>
                    <div class="card">
                        <h3>Limites de Taxa</h3>
                        <div id="rateLimits"></div>
                    </div>
                </div>
            </div>
            <div id="APIs" class="tab-content">
                <div class="section">
                    <h2>Gerenciamento de APIs</h2>
                    <div class="grid">
                        <div class="card">
                            <h3>Status das APIs</h3>
                            <div id="apiStatus"></div>
                            <div id="apiToggles"></div>
                        </div>
                        <div class="card">
                            <h3>Chaves de API</h3>
                            <div id="apiKeys"></div>
                        </div>
                    </div>
                    <div class="card">
                        <h3>Modelos Disponíveis</h3>
                        <div id="models"></div>
                    </div>
                </div>
            </div>
            <div id="Automation" class="tab-content">
                <div class="section">
                    <h2>Regras de Automação</h2>
                    <div class="grid">
                        <div class="card">
                            <h3>Regras Ativas</h3>
                            <div id="activeRules"></div>
                        </div>
                        <div class="card">
                            <h3>Adicionar Regra</h3>
                            <input type="text" id="newRule" placeholder="Descreva a nova regra">
                            <button onclick="addRule()">Adicionar Regra</button>
                        </div>
                    </div>
                    <div class="card">
                        <h3>Histórico de Execuções</h3>
                        <div id="ruleHistory" style="height: 150px; overflow-y: scroll; background: #001f22; padding: 10px; border-radius: 10px;"></div>
                    </div>
                </div>
            </div>
            <div id="ML" class="tab-content">
                <div class="section">
                    <h2>Machine Learning - Detecção de Anomalias</h2>
                    <div class="grid">
                        <div class="card">
                            <h3>Status do Modelo</h3>
                            <div id="mlStatus"></div>
                            <button onclick="trainML()">Treinar Modelo</button>
                        </div>
                        <div class="card">
                            <h3>Estatísticas de Anomalias</h3>
                            <div id="anomalyStats"></div>
                        </div>
                    </div>
                    <div class="card">
                        <h3>Últimas Anomalias Detectadas</h3>
                        <div id="recentAnomalies" style="height: 150px; overflow-y: scroll; background: #001f22; padding: 10px; border-radius: 10px;"></div>
                    </div>
                </div>
            </div>
            <div id="Monitoring" class="tab-content">
                <div class="section">
                    <h2>Monitoramento do Sistema</h2>
                    <div class="grid">
                        <div class="card">
                            <h3>Uso de CPU e Memória</h3>
                            <div id="osUsage"></div>
                        </div>
                        <div class="card">
                            <h3>Saúde do Sistema</h3>
                            <div id="systemHealth"></div>
                        </div>
                    </div>
                    <div class="grid">
                        <div class="card">
                            <h3>Processos Ativos</h3>
                            <div id="processes" style="height: 150px; overflow-y: scroll; background: #001f22; padding: 10px; border-radius: 10px;"></div>
                        </div>
                        <div class="card">
                            <h3>Status da IA</h3>
                            <div id="aiStatus"></div>
                        </div>
                    </div>
                    <div class="card">
                        <h3>Informações do Sistema</h3>
                        <div id="systemInfo"></div>
                    </div>
                </div>
            </div>
            <div id="Advanced" class="tab-content">
                <div class="section">
                    <h2>Configurações Avançadas</h2>
                    <div class="grid">
                        <div class="card">
                            <h3>Configuração Completa da IA</h3>
                            <div id="fullConfig" style="height: 300px; overflow-y: scroll; background: #001f22; padding: 10px; border-radius: 10px; font-family: monospace; font-size: 12px;"></div>
                        </div>
                        <div class="card">
                            <h3>Controles Avançados</h3>
                            <button onclick="exportConfig()">Exportar Configuração</button>
                            <button onclick="importConfig()">Importar Configuração</button>
                            <button onclick="resetToDefaults()">Restaurar Padrões</button>
                            <button onclick="advancedBackup()">Backup Avançado</button>
                        </div>
                    </div>
                    <div class="card">
                        <h3>Diagnóstico do Sistema</h3>
                        <div id="systemDiagnostics"></div>
                        <button onclick="runDiagnostics()">Executar Diagnóstico</button>
                    </div>
                </div>
            </div>
        </div>
        <script>
            function openTab(evt, tabName) {
                var i, tabcontent, tablinks;
                tabcontent = document.getElementsByClassName("tab-content");
                for (i = 0; i < tabcontent.length; i++) {
                    tabcontent[i].style.display = "none";
                }
                tablinks = document.getElementsByClassName("tab");
                for (i = 0; i < tablinks.length; i++) {
                    tablinks[i].className = tablinks[i].className.replace(" active", "");
                }
                document.getElementById(tabName).style.display = "block";
                evt.currentTarget.className += " active";
            }
            async function sendToAI() {
                const input = document.getElementById('inputText').value;
                if (!input.trim()) return;
                appendLog('Você: ' + input);
                document.getElementById('inputText').value = '';

                // Show typing indicator
                const typingDiv = document.createElement('div');
                typingDiv.id = 'typing';
                typingDiv.innerHTML = 'IA está digitando...';
                document.getElementById('log').appendChild(typingDiv);
                document.getElementById('log').scrollTop = document.getElementById('log').scrollHeight;

                try {
                    const response = await fetch('/api/ai_interact', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({message: input})
                    });
                    const data = await response.json();

                    // Remove typing indicator
                    const typingElement = document.getElementById('typing');
                    if (typingElement) typingElement.remove();

                    appendLog('IA: ' + data.reply);

                    // Auto-execute commands from AI response
                    await executeAICommands(data.reply);
                } catch (error) {
                    const typingElement = document.getElementById('typing');
                    if (typingElement) typingElement.remove();
                    appendLog('Erro: Não foi possível conectar com a IA');
                }
            }

            async function executeAICommands(reply) {
                // Extract and execute commands from AI response
                const commandPatterns = [
                    { pattern: /bloquear domínio ([a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/i, action: 'block_domain' },
                    { pattern: /desbloquear domínio ([a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/i, action: 'unblock_domain' },
                    { pattern: /bloquear IP ([\d.]+)/i, action: 'block_ip' },
                    { pattern: /desbloquear IP ([\d.]+)/i, action: 'unblock_ip' }
                ];

                for (const { pattern, action } of commandPatterns) {
                    const match = reply.match(pattern);
                    if (match) {
                        const target = match[1];
                        await sendCommand(action, target);
                        appendLog(`Comando executado: ${action} ${target}`);
                    }
                }
            }
            function extractDomain(text) {
                const match = text.match(/block_domain\s+(\S+)/) || text.match(/unblock_domain\s+(\S+)/);
                return match ? match[1] : null;
            }
            function extractIP(text) {
                const match = text.match(/block_ip\s+(\S+)/) || text.match(/unblock_ip\s+(\S+)/);
                return match ? match[1] : null;
            }
            async function sendCommand(command, target) {
                try {
                    const response = await fetch('/api/ai_command', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({command: command, target: target})
                    });
                    const data = await response.json();
                    appendLog('✅ Comando executado: ' + command + ' ' + target);
                } catch (error) {
                    appendLog('❌ Erro ao executar comando: ' + command + ' ' + target);
                }
            }
            async function assignTask() {
                const task = document.getElementById('taskInput').value;
                if (!task.trim()) return;
                const response = await fetch('/api/assign_task', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({task: task})
                });
                const data = await response.json();
                document.getElementById('taskInput').value = '';
                fetchTasks();
            }
            async function fetchTasks() {
                const response = await fetch('/api/tasks');
                const data = await response.json();
                const tasksDiv = document.getElementById('tasks');
                tasksDiv.innerHTML = data.map(task => `<div>${task.timestamp}: ${task.description}</div>`).join('');
            }
            async function fetchSecurityStats() {
                const response = await fetch('/api/security_stats');
                const data = await response.json();
                const statsDiv = document.getElementById('securityStats');
                statsDiv.innerHTML = `
                    <div>Domínios em Quarentena: ${data.quarantined_domains || 0}</div>
                    <div>Incidentes Totais: ${data.incident_count || 0}</div>
                    <div>Bases de Ameaças:</div>
                    <div>- Malware: ${data.threat_databases_size?.malware_domains || 0}</div>
                    <div>- Phishing: ${data.threat_databases_size?.phishing_sites || 0}</div>
                    <div>- C2 Servers: ${data.threat_databases_size?.c2_servers || 0}</div>
                `;
            }
            async function fetchRecentIncidents() {
                const response = await fetch('/api/security_stats');
                const data = await response.json();
                const incidentsDiv = document.getElementById('recentIncidents');
                if (data.recent_incidents && data.recent_incidents.length > 0) {
                    incidentsDiv.innerHTML = data.recent_incidents.map(incident =>
                        `<div>${incident.timestamp}: ${incident.action} - ${incident.target} (${incident.reason})</div>`
                    ).join('');
                } else {
                    incidentsDiv.innerHTML = '<div>Nenhum incidente recente</div>';
                }
            }
            async function fetchQuarantineList() {
                const response = await fetch('/api/quarantine_list');
                const data = await response.json();
                const quarantineDiv = document.getElementById('quarantineList');
                if (data.length > 0) {
                    quarantineDiv.innerHTML = data.map(domain => `<div>🔒 ${domain}</div>`).join('');
                } else {
                    quarantineDiv.innerHTML = '<div>Lista de quarentena vazia</div>';
                }
            }
            async function analyzeDomain() {
                const domain = document.getElementById('domainToAnalyze').value;
                if (!domain.trim()) return;
                const response = await fetch('/api/analyze_domain', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({domain: domain})
                });
                const data = await response.json();
                const analysisDiv = document.getElementById('threatAnalysis');
                analysisDiv.innerHTML = `
                    <div><strong>Domínio:</strong> ${data.domain}</div>
                    <div><strong>Score de Ameaça:</strong> ${(data.overall_threat_score * 100).toFixed(1)}%</div>
                    <div><strong>Ameaça Detectada:</strong> ${data.threat_detected ? 'SIM' : 'NÃO'}</div>
                    <div><strong>Malware:</strong> ${data.malware_analysis?.threat_level || 'N/A'}</div>
                    <div><strong>Phishing:</strong> ${data.phishing_analysis?.is_phishing ? 'SIM' : 'NÃO'}</div>
                    <div><strong>C2 Server:</strong> ${data.c2_analysis?.is_c2 ? 'SIM' : 'NÃO'}</div>
                `;
            }
            async function fetchSecurityStatus() {
                const response = await fetch('/api/security_status');
                const data = await response.json();
                const statusDiv = document.getElementById('securityStatus');
                statusDiv.innerHTML = `
                    <div>Firewall: ${data.firewall}</div>
                    <div>Antivírus: ${data.antivirus}</div>
                    <div>Última Verificação: ${data.last_scan}</div>
                `;
            }
            async function fetchOSUsage() {
                const response = await fetch('/api/os_usage');
                const data = await response.json();
                const usageDiv = document.getElementById('osUsage');
                usageDiv.innerHTML = `
                    <div>CPU: ${data.cpu}%</div>
                    <div>Memória: ${data.memory}%</div>
                    <div>Disco: ${data.disk}%</div>
                `;
            }
            async function fetchProcesses() {
                const response = await fetch('/api/processes');
                const data = await response.json();
                const processesDiv = document.getElementById('processes');
                processesDiv.innerHTML = data.slice(0, 10).map(proc => `<div>${proc.pid}: ${proc.name}</div>`).join('');
            }
            async function fetchSystemInfo() {
                const response = await fetch('/api/system_info');
                const data = await response.json();
                const infoDiv = document.getElementById('systemInfo');
                infoDiv.innerHTML = `
                    <div>SO: ${data.os}</div>
                    <div>Versão: ${data.version}</div>
                    <div>Uptime: ${data.uptime}</div>
                `;
            }
            function appendLog(message) {
                const log = document.getElementById('log');
                log.innerHTML += message + '<br>';
                log.scrollTop = log.scrollHeight;
            }
            // Initialize
            document.getElementsByClassName('tab')[0].click();
            async function fetchAIConfig() {
                const response = await fetch('/api/ai_config');
                const data = await response.json();
                const configDiv = document.getElementById('aiConfig');
                configDiv.innerHTML = `
                    <div>Ativado: ${data.enabled ? 'Sim' : 'Não'}</div>
                    <div>Provedor Primário: ${data.primary_provider}</div>
                    <div>Provedor Secundário: ${data.secondary_provider}</div>
                    <div>Idioma: ${data.language}</div>
                `;
            }
            async function fetchBehaviorMode() {
                const response = await fetch('/api/behavior_mode');
                const data = await response.json();
                const modeDiv = document.getElementById('behaviorMode');
                modeDiv.innerHTML = `<div>Modo: ${data.mode}</div>`;
            }
            async function fetchRateLimits() {
                const response = await fetch('/api/rate_limits');
                const data = await response.json();
                const limitsDiv = document.getElementById('rateLimits');
                limitsDiv.innerHTML = `
                    <div>Máx. Tokens/Hora: ${data.max_tokens_per_hour}</div>
                    <div>Máx. Requisições/Minuto: ${data.max_requests_per_minute}</div>
                `;
            }
            async function fetchAPIStatus() {
                const response = await fetch('/api/api_status');
                const data = await response.json();
                const statusDiv = document.getElementById('apiStatus');
                statusDiv.innerHTML = Object.entries(data).map(([api, status]) => `<div>${api}: ${status ? 'Ativo' : 'Inativo'}</div>`).join('');
                const togglesDiv = document.getElementById('apiToggles');
                togglesDiv.innerHTML = Object.entries(data).map(([api, status]) =>
                    `<button onclick="toggleAPI('${api}')">${status ? 'Desativar' : 'Ativar'} ${api}</button>`
                ).join('');
            }
            async function fetchAPIKeys() {
                const response = await fetch('/api/api_keys');
                const data = await response.json();
                const keysDiv = document.getElementById('apiKeys');
                keysDiv.innerHTML = Object.entries(data).map(([api, hasKey]) => `<div>${api}: ${hasKey ? 'Configurada' : 'Não configurada'}</div>`).join('');
            }
            async function fetchModels() {
                const response = await fetch('/api/models');
                const data = await response.json();
                const modelsDiv = document.getElementById('models');
                modelsDiv.innerHTML = Object.entries(data).map(([api, models]) => `<div>${api}: ${models.join(', ')}</div>`).join('');
            }
            async function fetchActiveRules() {
                const response = await fetch('/api/active_rules');
                const data = await response.json();
                const rulesDiv = document.getElementById('activeRules');
                rulesDiv.innerHTML = data.map(rule => `<div>${rule}</div>`).join('');
            }
            async function addRule() {
                const rule = document.getElementById('newRule').value;
                if (!rule.trim()) return;
                const response = await fetch('/api/add_rule', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({rule: rule})
                });
                const data = await response.json();
                document.getElementById('newRule').value = '';
                fetchActiveRules();
            }
            async function fetchRuleHistory() {
                const response = await fetch('/api/rule_history');
                const data = await response.json();
                const historyDiv = document.getElementById('ruleHistory');
                historyDiv.innerHTML = data.map(entry => `<div>${entry.timestamp}: ${entry.action}</div>`).join('');
            }
            async function toggleAI() {
                const response = await fetch('/api/toggle_ai', { method: 'POST' });
                const data = await response.json();
                fetchAIConfig();
                fetchAPIStatus();
            }
            async function toggleAPI(api) {
                const response = await fetch('/api/toggle_api', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({api: api})
                });
                const data = await response.json();
                fetchAPIStatus();
            }
            async function trainML() {
                const response = await fetch('/api/train_ml', { method: 'POST' });
                const data = await response.json();
                alert(data.message);
                fetchMLStatus();
            }
            async function fetchMLStatus() {
                const response = await fetch('/api/ml_status');
                const data = await response.json();
                const statusDiv = document.getElementById('mlStatus');
                statusDiv.innerHTML = `
                    <div>Status: ${data.status}</div>
                    <div>Consultas 24h: ${data.total_queries_24h || 0}</div>
                    <div>Anomalias 24h: ${data.anomalies_24h || 0}</div>
                    <div>Taxa de Anomalias: ${(data.anomaly_rate * 100 || 0).toFixed(2)}%</div>
                `;
            }
            async function fetchAnomalyStats() {
                const response = await fetch('/api/anomaly_stats');
                const data = await response.json();
                const statsDiv = document.getElementById('anomalyStats');
                statsDiv.innerHTML = `
                    <div>Total Consultas: ${data.total_queries_24h || 0}</div>
                    <div>Anomalias Detectadas: ${data.anomalies_24h || 0}</div>
                    <div>Taxa: ${(data.anomaly_rate * 100 || 0).toFixed(2)}%</div>
                `;
            }
            async function fetchRecentAnomalies() {
                const response = await fetch('/api/recent_anomalies');
                const data = await response.json();
                const anomaliesDiv = document.getElementById('recentAnomalies');
                anomaliesDiv.innerHTML = data.map(anomaly =>
                    `<div>${anomaly.timestamp}: ${anomaly.client_ip} -> ${anomaly.domain} (Score: ${anomaly.score.toFixed(3)})</div>`
                ).join('');
            }
            // Initialize
            document.getElementsByClassName('tab')[0].click();
            setInterval(fetchTasks, 2000);
            setInterval(fetchSecurityStatus, 5000);
            setInterval(fetchOSUsage, 2000);
            setInterval(fetchProcesses, 5000);
            setInterval(fetchSystemInfo, 10000);
            setInterval(fetchAIConfig, 5000);
            setInterval(fetchBehaviorMode, 5000);
            setInterval(fetchRateLimits, 5000);
            setInterval(fetchAPIStatus, 5000);
            setInterval(fetchAPIKeys, 5000);
            setInterval(fetchModels, 5000);
            setInterval(fetchActiveRules, 5000);
            setInterval(fetchRuleHistory, 5000);
            setInterval(fetchMLStatus, 5000);
            setInterval(fetchAnomalyStats, 5000);
            setInterval(fetchRecentAnomalies, 5000);
            setInterval(fetchSecurityStats, 5000);
            setInterval(fetchRecentIncidents, 5000);
            setInterval(fetchQuarantineList, 5000);
        </script>
    </body>
    </html>
    """
    return render_template_string(html)

@app.route('/api/ai_interact', methods=['POST'])
@login_required
def ai_interact():
    data = request.get_json()
    message = data.get('message', '')
    if not message:
        return jsonify({'reply': 'Por favor, envie uma mensagem válida.'})

    reply = None
    logging.info(f"IA recebeu mensagem: {message}")

    # Enhanced AI interaction with command processing
    processed_message, commands = process_ai_commands(message)

    # Try primary provider first
    primary_provider = ai_config['primary_provider']
    reply = call_ai_provider(primary_provider, processed_message)

    # Fallback to secondary if primary fails
    if not reply:
        secondary_provider = ai_config['secondary_provider']
        if secondary_provider != primary_provider:
            logging.info(f"Tentando provedor secundário: {secondary_provider}")
            reply = call_ai_provider(secondary_provider, processed_message)

    # Execute commands if any
    if commands and reply:
        reply += execute_ai_commands(commands)

    if not reply:
        reply = "Erro ao comunicar com a IA: Verifique as chaves de API e configuração."

    logging.info(f"IA respondeu: {reply[:100]}...")
    return jsonify({'reply': reply})

def process_ai_commands(message):
    """Process natural language commands for AI actions"""
    commands = []
    processed_message = message

    # Command patterns
    command_patterns = {
        'block_domain': r'bloque[ia]r?\s+(?:o\s+)?dom[íi]nio\s+([a-zA-Z0-9.-]+\.[a-zA-Z]{2,})',
        'unblock_domain': r'desbloque[ia]r?\s+(?:o\s+)?dom[íi]nio\s+([a-zA-Z0-9.-]+\.[a-zA-Z]{2,})',
        'block_ip': r'bloque[ia]r?\s+(?:o\s+)?IP\s+([\d.]+)',
        'unblock_ip': r'desbloque[ia]r?\s+(?:o\s+)?IP\s+([\d.]+)',
        'analyze_domain': r'analis[ae]r?\s+(?:o\s+)?dom[íi]nio\s+([a-zA-Z0-9.-]+\.[a-zA-Z]{2,})',
        'system_status': r'status\s+do\s+sistema|como\s+est[áa]\s+o\s+servidor',
        'security_report': r'relat[óo]rio\s+de\s+seguran[çca]|status\s+de\s+seguran[çca]',
        'train_ml': r'trein[ae]r?\s+(?:o\s+)?modelo|atualiz[ae]r?\s+ML',
        'clear_cache': r'limp[ae]r?\s+cache|esvaziar\s+cache',
        'restart_service': r'reinici[ae]r?\s+servi[çc]o|restart\s+(?:do\s+)?servidor'
    }

    for command_type, pattern in command_patterns.items():
        match = re.search(pattern, message, re.IGNORECASE)
        if match:
            target = match.group(1) if len(match.groups()) > 0 else None
            commands.append({'type': command_type, 'target': target})
            # Remove command from message for cleaner AI processing
            processed_message = re.sub(pattern, '', processed_message, flags=re.IGNORECASE)

    return processed_message.strip(), commands

def call_ai_provider(provider, message):
    """Call specific AI provider with enhanced error handling"""
    try:
        provider_config = ai_config['apis'].get(provider, {})
        if not provider_config.get('enabled', False):
            return None

        api_key = decrypt_key(provider_config.get('key', ''))
        if not api_key:
            return None

        if provider == 'openai':
            return call_openai(api_key, message)
        elif provider == 'groq':
            return call_groq(api_key, message)
        elif provider == 'google':
            return call_google(api_key, message)
        elif provider == 'anthropic':
            return call_anthropic(api_key, message)
        elif provider == 'blackbox':
            return call_blackbox(api_key, message)
        elif provider == 'glm':
            return call_glm(api_key, message)
        elif provider == 'deepinfra':
            return call_deepinfra(api_key, message)

    except Exception as e:
        logging.error(f"Erro no provedor {provider}: {e}")
        return None

    return None

def call_openai(api_key, message):
    try:
        import openai
        openai.api_key = api_key
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "Você é uma IA avançada do InvictusDNS. Responda em português brasileiro de forma útil e técnica."},
                {"role": "user", "content": message}
            ],
            max_tokens=1000,
            temperature=0.7,
        )
        return response.choices[0].message['content'].strip()
    except Exception as e:
        logging.error(f"OpenAI error: {e}")
        return None

def call_groq(api_key, message):
    try:
        client = groq.Groq(api_key=api_key)
        response = client.chat.completions.create(
            model="llama3-8b-8192",
            messages=[
                {"role": "system", "content": "Você é uma IA avançada do InvictusDNS. Responda em português brasileiro de forma útil e técnica."},
                {"role": "user", "content": message}
            ],
            max_tokens=1000,
            temperature=0.7,
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        logging.error(f"Groq error: {e}")
        return None

def call_google(api_key, message):
    try:
        genai.configure(api_key=api_key)
        model = genai.GenerativeModel('gemini-1.5-flash')
        response = model.generate_content(message)
        return response.text.strip()
    except Exception as e:
        logging.error(f"Google error: {e}")
        return None

def call_anthropic(api_key, message):
    try:
        if anthropic_client:
            message_obj = anthropic_client.messages.create(
                model="claude-3-haiku-20240307",
                max_tokens=1000,
                system="Você é uma IA avançada do InvictusDNS. Responda em português brasileiro de forma útil e técnica.",
                messages=[{"role": "user", "content": message}]
            )
            return message_obj.content[0].text.strip()
    except Exception as e:
        logging.error(f"Anthropic error: {e}")
        return None

def call_blackbox(api_key, message):
    try:
        import openai as bb_openai
        bb_openai.api_key = api_key
        bb_openai.api_base = "https://api.blackbox.ai/api"
        response = bb_openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "Você é uma IA avançada do InvictusDNS. Responda em português brasileiro de forma útil e técnica."},
                {"role": "user", "content": message}
            ],
            max_tokens=1000,
            temperature=0.7,
        )
        return response.choices[0].message['content'].strip()
    except Exception as e:
        logging.error(f"Blackbox error: {e}")
        return None

def call_glm(api_key, message):
    try:
        import openai as glm_openai
        glm_openai.api_key = api_key
        glm_openai.api_base = "https://open.bigmodel.cn/api/paas/v4/"
        response = glm_openai.ChatCompletion.create(
            model="glm-4",
            messages=[
                {"role": "system", "content": "Você é uma IA avançada do InvictusDNS. Responda em português brasileiro de forma útil e técnica."},
                {"role": "user", "content": message}
            ],
            max_tokens=1000,
            temperature=0.7,
        )
        return response.choices[0].message['content'].strip()
    except Exception as e:
        logging.error(f"GLM error: {e}")
        return None

def call_deepinfra(api_key, message):
    try:
        import openai as di_openai
        di_openai.api_key = api_key
        di_openai.api_base = "https://api.deepinfra.com/v1/openai"
        response = di_openai.ChatCompletion.create(
            model="meta-llama/Llama-2-70b-chat-hf",
            messages=[
                {"role": "system", "content": "Você é uma IA avançada do InvictusDNS. Responda em português brasileiro de forma útil e técnica."},
                {"role": "user", "content": message}
            ],
            max_tokens=1000,
            temperature=0.7,
        )
        return response.choices[0].message['content'].strip()
    except Exception as e:
        logging.error(f"DeepInfra error: {e}")
        return None

def execute_ai_commands(commands):
    """Execute AI commands and return results"""
    results = []
    for command in commands:
        cmd_type = command['type']
        target = command['target']

        try:
            if cmd_type == 'block_domain':
                # Implement domain blocking
                results.append(f"Domínio {target} bloqueado com sucesso.")
            elif cmd_type == 'unblock_domain':
                results.append(f"Domínio {target} desbloqueado com sucesso.")
            elif cmd_type == 'block_ip':
                results.append(f"IP {target} bloqueado com sucesso.")
            elif cmd_type == 'unblock_ip':
                results.append(f"IP {target} desbloqueado com sucesso.")
            elif cmd_type == 'analyze_domain':
                analysis = analyze_threats(obfuscate_ip('127.0.0.1'), target)
                results.append(f"Análise de {target}: Score de ameaça {analysis.get('overall_threat_score', 0):.2f}")
            elif cmd_type == 'system_status':
                cpu = psutil.cpu_percent()
                mem = psutil.virtual_memory()
                results.append(f"CPU: {cpu}%, Memória: {mem.percent}%")
            elif cmd_type == 'security_report':
                stats = get_security_stats()
                results.append(f"Domínios em quarentena: {stats.get('quarantined_domains', 0)}")
            elif cmd_type == 'train_ml':
                success, message = anomaly_detector.train_model()
                results.append(f"Treinamento ML: {'Sucesso' if success else 'Falhou'} - {message}")
            elif cmd_type == 'clear_cache':
                results.append("Cache limpo com sucesso.")
            elif cmd_type == 'restart_service':
                results.append("Serviço reiniciado com sucesso.")
        except Exception as e:
            results.append(f"Erro ao executar {cmd_type}: {str(e)}")

    return " " + " ".join(results) if results else ""

@app.route('/api/assign_task', methods=['POST'])
@login_required
def assign_task():
    data = request.get_json()
    task = data.get('task', '')
    if not task:
        return jsonify({'error': 'Tarefa inválida'})
    init_db()
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("INSERT INTO ai_tasks (timestamp, description) VALUES (?, ?)", (datetime.now().isoformat(), task))
    conn.commit()
    conn.close()
    return jsonify({'status': 'success'})

@app.route('/api/tasks')
@login_required
def api_tasks():
    init_db()
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("SELECT timestamp, description FROM ai_tasks ORDER BY id DESC LIMIT 20")
    tasks = [{'timestamp': row[0], 'description': row[1]} for row in c.fetchall()]
    conn.close()
    return jsonify(tasks)

@app.route('/api/security_status')
@login_required
def api_security_status():
    # Mock security status, in real implementation check actual firewall/antivirus
    return jsonify({
        'firewall': 'Ativo',
        'antivirus': 'Atualizado',
        'last_scan': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    })

@app.route('/api/os_usage')
@login_required
def api_os_usage():
    cpu = psutil.cpu_percent(interval=1)
    mem = psutil.virtual_memory()
    disk = psutil.disk_usage('/')
    return jsonify({
        'cpu': round(cpu, 1),
        'memory': round(mem.percent, 1),
        'disk': round(disk.percent, 1)
    })

@app.route('/api/processes')
@login_required
def api_processes():
    processes = []
    for proc in psutil.process_iter(['pid', 'name']):
        try:
            processes.append({'pid': proc.info['pid'], 'name': proc.info['name']})
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    return jsonify(processes[:20])  # Top 20

@app.route('/api/system_info')
@login_required
def api_system_info():
    uptime = time.time() - psutil.boot_time()
    hours, remainder = divmod(int(uptime), 3600)
    minutes, seconds = divmod(remainder, 60)
    uptime_str = f"{hours}h {minutes}m {seconds}s"
    return jsonify({
        'os': platform.system() + ' ' + platform.release(),
        'version': platform.version(),
        'uptime': uptime_str
    })

@app.route('/api/ai_config')
@login_required
def api_ai_config():
    return jsonify({
        'enabled': ai_config['enabled'],
        'primary_provider': ai_config['primary_provider'],
        'secondary_provider': ai_config['secondary_provider'],
        'language': ai_config['language']
    })

@app.route('/api/behavior_mode')
@login_required
def api_behavior_mode():
    return jsonify({'mode': ai_config['behavior_mode']})

@app.route('/api/rate_limits')
@login_required
def api_rate_limits():
    return jsonify(ai_config['rate_limits'])

@app.route('/api/api_status')
@login_required
def api_api_status():
    status = {}
    for api, config in ai_config['apis'].items():
        status[api] = config['enabled']
    return jsonify(status)

@app.route('/api/api_keys')
@login_required
def api_api_keys():
    keys = {}
    for api, config in ai_config['apis'].items():
        keys[api] = bool(config['key'])
    return jsonify(keys)

@app.route('/api/models')
@login_required
def api_models():
    models = {}
    for api, config in ai_config['apis'].items():
        models[api] = config['models']
    return jsonify(models)

@app.route('/api/active_rules')
@login_required
def api_active_rules():
    return jsonify(ai_config['automation_rules'])

@app.route('/api/add_rule', methods=['POST'])
@login_required
def api_add_rule():
    data = request.get_json()
    rule = data.get('rule', '')
    if rule:
        ai_config['automation_rules'].append(rule)
        save_ai_config()
    return jsonify({'status': 'success'})

@app.route('/api/rule_history')
@login_required
def api_rule_history():
    # Mock history, in real implementation track executions
    return jsonify([{'timestamp': datetime.now().isoformat(), 'action': 'Regra executada'}])

@app.route('/api/toggle_ai', methods=['POST'])
@login_required
def api_toggle_ai():
    global ai_config
    ai_config['enabled'] = not ai_config['enabled']
    save_ai_config()
    return jsonify({'status': 'success', 'enabled': ai_config['enabled']})

@app.route('/api/toggle_api', methods=['POST'])
@login_required
def api_toggle_api():
    data = request.get_json()
    api = data.get('api')
    if api in ai_config['apis']:
        ai_config['apis'][api]['enabled'] = not ai_config['apis'][api]['enabled']
        save_ai_config()
        return jsonify({'status': 'success', 'api': api, 'enabled': ai_config['apis'][api]['enabled']})
    return jsonify({'status': 'error', 'message': 'API not found'})

@app.route('/api/train_ml', methods=['POST'])
@login_required
def api_train_ml():
    success, message = anomaly_detector.train_model()
    return jsonify({'success': success, 'message': message})

@app.route('/api/ml_status')
@login_required
def api_ml_status():
    stats = anomaly_detector.get_anomaly_stats()
    return jsonify(stats)

@app.route('/api/anomaly_stats')
@login_required
def api_anomaly_stats():
    stats = anomaly_detector.get_anomaly_stats()
    return jsonify(stats)

@app.route('/api/recent_anomalies')
@login_required
def api_recent_anomalies():
    try:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT timestamp, client_ip, domain, anomaly_score
            FROM dns_logs
            WHERE anomaly_score < -0.5
            ORDER BY timestamp DESC
            LIMIT 20
        """)
        anomalies = []
        for row in cursor.fetchall():
            # IPs já estão ofuscados no banco, mas podemos mostrar como estão
            anomalies.append({
                'timestamp': row[0],
                'client_ip': row[1],  # Já ofuscado
                'domain': row[2],
                'score': row[3]
            })
        conn.close()
        return jsonify(anomalies)
    except Exception as e:
        return jsonify({'error': str(e)})

@app.route('/api/security_stats')
@login_required
def api_security_stats():
    try:
        stats = get_security_stats()
        return jsonify(stats)
    except Exception as e:
        return jsonify({'error': str(e)})

@app.route('/api/quarantine_list')
@login_required
def api_quarantine_list():
    try:
        from security.advanced_security import advanced_security
        quarantine_list = list(advanced_security.quarantine_list)
        return jsonify(quarantine_list)
    except Exception as e:
        return jsonify({'error': str(e)})

@app.route('/api/analyze_domain', methods=['POST'])
@login_required
def api_analyze_domain():
    try:
        data = request.get_json()
        domain = data.get('domain', '')
        if not domain:
            return jsonify({'error': 'Domínio não fornecido'})

        # Simular IP do cliente para análise
        mock_client_ip = obfuscate_ip('127.0.0.1')
        analysis = analyze_threats(mock_client_ip, domain)
        return jsonify(analysis)
    except Exception as e:
        return jsonify({'error': str(e)})

@app.route('/api/ai_command', methods=['POST'])
@login_required
def api_ai_command():
    try:
        data = request.get_json()
        command = data.get('command', '')
        target = data.get('target', '')

        logging.info(f"Executando comando IA: {command} {target}")

        if command == 'block_domain':
            # Implementar bloqueio de domínio
            return jsonify({'status': 'success', 'message': f'Domínio {target} bloqueado'})
        elif command == 'unblock_domain':
            return jsonify({'status': 'success', 'message': f'Domínio {target} desbloqueado'})
        elif command == 'block_ip':
            return jsonify({'status': 'success', 'message': f'IP {target} bloqueado'})
        elif command == 'unblock_ip':
            return jsonify({'status': 'success', 'message': f'IP {target} desbloqueado'})
        else:
            return jsonify({'status': 'error', 'message': 'Comando não reconhecido'})

    except Exception as e:
        logging.error(f"Erro no comando IA: {e}")
        return jsonify({'status': 'error', 'message': str(e)})

@app.route('/api/advanced_config')
@login_required
def api_advanced_config():
    return jsonify(ai_config)

@app.route('/api/update_config', methods=['POST'])
@login_required
def api_update_config():
    try:
        data = request.get_json()
        section = data.get('section', '')
        updates = data.get('updates', {})

        if section in ai_config:
            ai_config[section].update(updates)
            save_ai_config()
            return jsonify({'status': 'success'})
        else:
            return jsonify({'status': 'error', 'message': 'Seção não encontrada'})

    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)})

@app.route('/api/system_health')
@login_required
def api_system_health():
    try:
        health_data = {
            'cpu_percent': psutil.cpu_percent(interval=1),
            'memory_percent': psutil.virtual_memory().percent,
            'disk_percent': psutil.disk_usage('/').percent,
            'network_connections': len(psutil.net_connections()),
            'uptime': time.time() - psutil.boot_time(),
            'ai_status': 'online' if ai_config['enabled'] else 'offline',
            'active_providers': [p for p, c in ai_config['apis'].items() if c['enabled']]
        }
        return jsonify(health_data)
    except Exception as e:
        return jsonify({'error': str(e)})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3002, debug=False)

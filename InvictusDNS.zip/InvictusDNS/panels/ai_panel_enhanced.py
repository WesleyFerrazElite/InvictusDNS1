from flask import Flask, render_template_string, request, jsonify, session, redirect, url_for, flash
import openai
import groq
import google.generativeai as genai
import anthropic
from functools import wraps
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
import psutil
import platform
import time
import os
from dotenv import load_dotenv
load_dotenv()
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'supersecretkey'

# API keys from environment
openai.api_key = os.getenv("OPENAI_API_KEY")
groq_api_key = os.getenv("GROQ_API_KEY")
google_api_key = os.getenv("GOOGLE_API_KEY")
anthropic_api_key = os.getenv("ANTHROPIC_API_KEY")
blackbox_api_key = os.getenv("BLACKBOX_API_KEY")
glm_api_key = os.getenv("GLM_API_KEY")
deepinfra_api_key = os.getenv("DEEPINFRA_API_KEY")

DB_FILE = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data', 'dns_logs.db')

# Variável global para controle da IA
ai_enabled = True

def init_db():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY,
                    username TEXT UNIQUE,
                    password_hash TEXT,
                    role TEXT DEFAULT 'user',
                    ips TEXT
                )''')
    c.execute('''CREATE TABLE IF NOT EXISTS ai_tasks (
                    id INTEGER PRIMARY KEY,
                    timestamp TEXT,
                    description TEXT,
                    status TEXT DEFAULT 'pending'
                )''')
    # Insert admin if not exists
    c.execute("SELECT COUNT(*) FROM users WHERE username = 'admin'")
    if c.fetchone()[0] == 0:
        c.execute("INSERT INTO users (username, password_hash, role, ips) VALUES (?, ?, ?, ?)",
                  ('admin', generate_password_hash('senha123'), 'admin', ''))
    conn.commit()
    conn.close()

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        init_db()
        conn = sqlite3.connect(DB_FILE, timeout=30, check_same_thread=False)
        c = conn.cursor()
        c.execute("SELECT id, password_hash FROM users WHERE username = ?", (username,))
        user = c.fetchone()
        conn.close()
        if user and check_password_hash(user[1], password):
            session['user_id'] = user[0]
            return redirect(url_for('dashboard'))
        flash('Credenciais inválidas')
    return render_template_string("""
    <!DOCTYPE html>
    <html>
    <head>
        <title>InvictusDNS AI Panel - Login</title>
        <style>
            body { font-family: Arial, sans-serif; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); margin: 0; padding: 0; display: flex; justify-content: center; align-items: center; height: 100vh; }
            .login-container { background: white; padding: 40px; border-radius: 10px; box-shadow: 0 15px 35px rgba(0,0,0,0.1); width: 400px; }
            h1 { text-align: center; color: #333; margin-bottom: 30px; }
            input { width: 100%; padding: 12px; margin: 10px 0; border: 1px solid #ddd; border-radius: 5px; box-sizing: border-box; }
            button { width: 100%; padding: 12px; background: #667eea; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; }
            button:hover { background: #5a6fd8; }
            .alert { color: red; text-align: center; margin-top: 10px; }
        </style>
    </head>
    <body>
        <div class="login-container">
            <h1>🧠 InvictusDNS AI Panel</h1>
            <form method="post">
                <input type="text" name="username" placeholder="Usuário" required><br>
                <input type="password" name="password" placeholder="Senha" required><br>
                <button type="submit">Entrar</button>
            </form>
            {% with messages = get_flashed_messages() %}
                {% if messages %}
                    <div class="alert">{{ messages[0] }}</div>
                {% endif %}
            {% endwith %}
        </div>
    </body>
    </html>
    """)

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template_string("""
    <!DOCTYPE html>
    <html>
    <head>
        <title>InvictusDNS AI Panel - Dashboard</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background: #f5f5f5; }
            .header { background: white; padding: 20px; border-radius: 10px; margin-bottom: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            .header h1 { margin: 0; color: #333; }
            .status { display: inline-block; padding: 5px 15px; border-radius: 20px; font-size: 14px; }
            .status.active { background: #4CAF50; color: white; }
            .status.inactive { background: #f44336; color: white; }
            .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; }
            .card { background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            .card h3 { margin-top: 0; color: #333; }
            .metric { display: flex; justify-content: space-between; margin: 10px 0; }
            .metric-value { font-weight: bold; color: #667eea; }
            .btn { padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; font-size: 14px; margin: 5px; }
            .btn-primary { background: #667eea; color: white; }
            .btn-secondary { background: #6c757d; color: white; }
            .btn-danger { background: #dc3545; color: white; }
            .switch { position: relative; display: inline-block; width: 60px; height: 34px; }
            .switch input { opacity: 0; width: 0; height: 0; }
            .slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #ccc; transition: .4s; border-radius: 34px; }
            .slider:before { position: absolute; content: ""; height: 26px; width: 26px; left: 4px; bottom: 4px; background-color: white; transition: .4s; border-radius: 50%; }
            input:checked + .slider { background-color: #2196F3; }
            input:checked + .slider:before { transform: translateX(26px); }
            .chat-container { max-height: 400px; overflow-y: auto; border: 1px solid #ddd; padding: 10px; margin: 10px 0; }
            .message { margin: 5px 0; padding: 8px; border-radius: 5px; }
            .message.user { background: #e3f2fd; text-align: right; }
            .message.ai { background: #f5f5f5; }
        </style>
    </head>
    <body>
        <div class="header">
            <h1>🧠 InvictusDNS AI Panel</h1>
            <div>
                <span class="status active" id="ai-status">IA Ativa</span>
                <label class="switch">
                    <input type="checkbox" id="ai-toggle" checked onchange="toggleAI(this.checked)">
                    <span class="slider"></span>
                </label>
            </div>
        </div>

        <div class="grid">
            <div class="card">
                <h3>📊 Status do Sistema</h3>
                <div class="metric">
                    <span>CPU:</span>
                    <span class="metric-value" id="cpu-usage">Carregando...</span>
                </div>
                <div class="metric">
                    <span>Memória:</span>
                    <span class="metric-value" id="mem-usage">Carregando...</span>
                </div>
                <div class="metric">
                    <span>Disco:</span>
                    <span class="metric-value" id="disk-usage">Carregando...</span>
                </div>
                <button class="btn btn-primary" onclick="updateSystemInfo()">Atualizar</button>
            </div>

            <div class="card">
                <h3>🤖 Provedores de IA</h3>
                <div id="providers-list">
                    Carregando provedores...
                </div>
            </div>

            <div class="card">
                <h3>⚙️ Configurações Avançadas</h3>
                <div>
                    <label>Temperatura: <input type="range" id="temperature" min="0" max="2" step="0.1" value="0.7" onchange="updateConfig()"></label>
                    <span id="temp-value">0.7</span>
                </div>
                <div>
                    <label>Max Tokens: <input type="number" id="max-tokens" value="500" onchange="updateConfig()"></label>
                </div>
                <button class="btn btn-primary" onclick="loadFullConfig()">Carregar Config</button>
                <button class="btn btn-secondary" onclick="exportConfig()">Exportar</button>
                <button class="btn btn-danger" onclick="resetToDefaults()">Reset</button>
            </div>

            <div class="card">
                <h3>💬 Chat com IA</h3>
                <div class="chat-container" id="chat-messages"></div>
                <input type="text" id="chat-input" placeholder="Digite sua mensagem..." style="width: 70%; padding: 8px;">
                <button class="btn btn-primary" onclick="sendMessage()" style="width: 25%;">Enviar</button>
            </div>

            <div class="card">
                <h3>🔧 Ações Rápidas</h3>
                <button class="btn btn-primary" onclick="runDiagnostics()">Diagnóstico</button>
                <button class="btn btn-secondary" onclick="showTasks()">Ver Tarefas</button>
                <button class="btn btn-danger" onclick="clearLogs()">Limpar Logs</button>
            </div>
        </div>

        <script>
            let aiEnabled = true;

            function updateSystemInfo() {
                fetch('/api/os_usage')
                    .then(response => response.json())
                    .then(data => {
                        document.getElementById('cpu-usage').textContent = data.cpu + '%';
                        document.getElementById('mem-usage').textContent = data.memory + '%';
                        document.getElementById('disk-usage').textContent = data.disk + '%';
                    })
                    .catch(error => console.error('Erro:', error));
            }

            function toggleAI(enabled) {
                aiEnabled = enabled;
                document.getElementById('ai-status').textContent = enabled ? 'IA Ativa' : 'IA Inativa';
                document.getElementById('ai-status').className = 'status ' + (enabled ? 'active' : 'inactive');

                fetch('/api/toggle_ai', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ enabled: enabled })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        alert('IA ' + (enabled ? 'ativada' : 'desativada') + ' com sucesso!');
                    } else {
                        alert('Erro: ' + data.error);
                    }
                });
            }

            function loadProviders() {
                fetch('/api/get_full_config')
                    .then(response => response.json())
                    .then(data => {
                        const providers = data.apis || {};
                        let html = '';
                        for (const [provider, config] of Object.entries(providers)) {
                            const checked = config.enabled ? 'checked' : '';
                            html += `
                                <div>
                                    <label>${provider.toUpperCase()}:
                                        <label class="switch">
                                            <input type="checkbox" ${checked} onchange="toggleProvider('${provider}', this.checked)">
                                            <span class="slider"></span>
                                        </label>
                                    </label>
                                </div>
                            `;
                        }
                        document.getElementById('providers-list').innerHTML = html;
                    })
                    .catch(error => console.error('Erro:', error));
            }

            function toggleProvider(provider, enabled) {
                fetch('/api/toggle_provider', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ provider: provider, enabled: enabled })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        console.log(`${provider} ${enabled ? 'ativado' : 'desativado'}`);
                    } else {
                        alert('Erro: ' + data.error);
                    }
                });
            }

            function updateConfig() {
                const temperature = document.getElementById('temperature').value;
                const maxTokens = document.getElementById('max-tokens').value;

                document.getElementById('temp-value').textContent = temperature;

                fetch('/api/update_config', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        temperature: parseFloat(temperature),
                        max_tokens: parseInt(maxTokens)
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        console.log('Configuração atualizada');
                    } else {
                        alert('Erro: ' + data.error);
                    }
                });
            }

            function loadFullConfig() {
                fetch('/api/get_full_config')
                    .then(response => response.json())
                    .then(data => {
                        console.log('Configuração completa:', data);
                        alert('Configuração carregada! Verifique o console para detalhes.');
                    })
                    .catch(error => console.error('Erro:', error));
            }

            function exportConfig() {
                fetch('/api/export_config')
                    .then(response => response.json())
                    .then(data => {
                        const blob = new Blob([JSON.stringify(data.config, null, 2)], { type: 'application/json' });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = data.filename;
                        document.body.appendChild(a);
                        a.click();
                        document.body.removeChild(a);
                        URL.revokeObjectURL(url);
                    })
                    .catch(error => console.error('Erro:', error));
            }

            function resetToDefaults() {
                if (confirm('Tem certeza que deseja resetar todas as configurações para o padrão?')) {
                    fetch('/api/reset_config')
                        .then(response => response.json())
                        .then(data => {
                            if (data.status === 'success') {
                                alert('Configurações resetadas com sucesso!');
                                location.reload();
                            } else {
                                alert('Erro: ' + data.error);
                            }
                        });
                }
            }

            function sendMessage() {
                const input = document.getElementById('chat-input');
                const message = input.value.trim();
                if (!message) return;

                // Adicionar mensagem do usuário
                addMessage('user', message);
                input.value = '';

                // Enviar para IA
                fetch('/api/chat', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ message: message })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.reply) {
                        addMessage('ai', data.reply);
                    } else if (data.error) {
                        addMessage('ai', 'Erro: ' + data.error);
                    }
                })
                .catch(error => {
                    addMessage('ai', 'Erro de conexão: ' + error.message);
                });
            }

            function addMessage(type, text) {
                const container = document.getElementById('chat-messages');
                const messageDiv = document.createElement('div');
                messageDiv.className = 'message ' + type;
                messageDiv.textContent = text;
                container.appendChild(messageDiv);
                container.scrollTop = container.scrollHeight;
            }

            function runDiagnostics() {
                alert('Executando diagnóstico... (Funcionalidade em desenvolvimento)');
            }

            function showTasks() {
                fetch('/api/tasks')
                    .then(response => response.json())
                    .then(data => {
                        let message = 'Tarefas pendentes:\\n';
                        data.forEach(task => {
                            message += `- ${task.timestamp}: ${task.description}\\n`;
                        });
                        alert(message || 'Nenhuma tarefa pendente.');
                    })
                    .catch(error => console.error('Erro:', error));
            }

            function clearLogs() {
                if (confirm('Tem certeza que deseja limpar todos os logs?')) {
                    alert('Logs limpares! (Funcionalidade em desenvolvimento)');
                }
            }

            // Inicialização
            updateSystemInfo();
            loadProviders();
            setInterval(updateSystemInfo, 30000); // Atualizar a cada 30 segundos

            // Suporte a Enter no chat
            document.getElementById('chat-input').addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    sendMessage();
                }
            });
        </script>
    </body>
    </html>
    """)

@app.route('/api/chat', methods=['POST'])
@login_required
def api_chat():
    if not ai_enabled:
        return jsonify({'reply': 'IA está desativada. Ative a IA para usar o chat.'})

    data = request.get_json()
    message = data.get('message', '')
    if not message:
        return jsonify({'error': 'Mensagem vazia'})

    # Tentar provedores em ordem
    reply = None
    for provider in ['openai', 'groq', 'google', 'anthropic', 'blackbox', 'glm', 'deepinfra']:
        try:
            if provider == 'openai' and openai.api_key:
                response = openai.ChatCompletion.create(
                    model="gpt-3.5-turbo",
                    messages=[{"role": "user", "content": message}],
                    max_tokens=500,
                    temperature=0.7
                )
                reply = response.choices[0].message.content
                break
            elif provider == 'groq' and groq_api_key:
                client = groq.Client(api_key=groq_api_key)
                response = client.chat.completions.create(
                    model="llama3-8b-8192",
                    messages=[{"role": "user", "content": message}],
                    max_tokens=500,
                    temperature=0.7
                )
                reply = response.choices[0].message.content
                break
            elif provider == 'google' and google_api_key:
                genai.configure(api_key=google_api_key)
                model = genai.GenerativeModel('gemini-1.5-flash')
                response = model.generate_content(message)
                reply = response.text
                break
            elif provider == 'anthropic' and anthropic_api_key:
                client = anthropic.Anthropic(api_key=anthropic_api_key)
                response = client.messages.create(
                    model="claude-3-haiku-20240307",
                    max_tokens=500,
                    temperature=0.7,
                    messages=[{"role": "user", "content": message}]
                )
                reply = response.content[0].text
                break
            elif provider == 'blackbox' and blackbox_api_key:
                # Implementação Blackbox
                reply = "Blackbox AI: " + message[::-1]  # Placeholder
                break
            elif provider == 'glm' and glm_api_key:
                # Implementação GLM
                reply = "GLM AI: " + message.upper()  # Placeholder
                break
            elif provider == 'deepinfra' and deepinfra_api_key:
                # Implementação DeepInfra
                reply = "DeepInfra AI: " + message  # Placeholder
                break
        except Exception as e:
            print(f"Erro com {provider}: {e}")
            continue

    if not reply:
        reply = "Erro ao comunicar com a IA: Verifique as chaves de API."
    print(f"Reply: {reply}")
    return jsonify({'reply': reply})

@app.route('/api/toggle_ai', methods=['POST'])
@login_required
def toggle_ai():
    data = request.get_json()
    enabled = data.get('enabled', True)

    # Atualizar configuração global
    global ai_enabled
    ai_enabled = enabled

    # Salvar no arquivo de configuração
    try:
        import json
        config_path = 'ai_config.json'
        if os.path.exists(config_path):
            with open(config_path, 'r') as f:
                config = json.load(f)
        else:
            config = {}

        config['ai_enabled'] = enabled

        with open(config_path, 'w') as f:
            json.dump(config, f, indent=2)

        return jsonify({'status': 'success', 'ai_enabled': enabled})
    except Exception as e:
        return jsonify({'error': str(e)})

@app.route('/api/toggle_provider', methods=['POST'])
@login_required
def toggle_provider():
    data = request.get_json()
    provider = data.get('provider')
    enabled = data.get('enabled', True)

    if not provider:
        return jsonify({'error': 'Provider não especificado'})

    try:
        import json
        config_path = 'ai_config.json'
        if os.path.exists(config_path):
            with open(config_path, 'r') as f:
                config = json.load(f)
        else:
            config = {}

        if 'apis' not in config:
            config['apis'] = {}

        if provider not in config['apis']:
            config['apis'][provider] = {}

        config['apis'][provider]['enabled'] = enabled

        with open(config_path, 'w') as f:
            json.dump(config, f, indent=2)

        return jsonify({'status': 'success', 'provider': provider, 'enabled': enabled})
    except Exception as e:
        return jsonify({'error': str(e)})

@app.route('/api/update_config', methods=['POST'])
@login_required
def update_config():
    data = request.get_json()

    try:
        import json
        config_path = 'ai_config.json'
        if os.path.exists(config_path):
            with open(config_path, 'r') as f:
                config = json.load(f)
        else:
            config = {}

        # Atualizar configurações específicas
        if 'temperature' in data:
            for provider in config.get('apis', {}):
                if 'temperature' in config['apis'][provider]:
                    config['apis'][provider]['temperature'] = data['temperature']

        if 'max_tokens' in data:
            for provider in config.get('apis', {}):
                if 'max_tokens' in config['apis'][provider]:
                    config['apis'][provider]['max_tokens'] = data['max_tokens']

        if 'rate_limits' in data:
            config['rate_limits'] = data['rate_limits']

        with open(config_path, 'w') as f:
            json.dump(config, f, indent=2)

        return jsonify({'status': 'success', 'updated': list(data.keys())})
    except Exception as e:
        return jsonify({'error': str(e)})

@app.route('/api/get_full_config')
@login_required
def get_full_config():
    try:
        import json
        config_path = 'ai_config.json'
        if os.path.exists(config_path):
            with open(config_path, 'r') as f:
                config = json.load(f)
        else:
            config = {}

        return jsonify(config)
    except Exception as e:
        return jsonify({'error': str(e)})

@app.route('/api/export_config')
@login_required
def export_config():
    try:
        import json
        config_path = 'ai_config.json'
        if os.path.exists(config_path):
            with open(config_path, 'r') as f:
                config = json.load(f)
        else:
            config = {}

        return jsonify({'config': config, 'filename': 'ai_config_backup.json'})
    except Exception as e:
        return jsonify({'error': str(e)})

@app.route('/api/import_config', methods=['POST'])
@login_required
def import_config():
    data = request.get_json()
    config = data.get('config')

    if not config:
        return jsonify({'error': 'Configuração não fornecida'})

    try:
        import json
        config_path = 'ai_config.json'

        with open(config_path, 'w') as f:
            json.dump(config, f, indent=2)

        return jsonify({'status': 'success', 'message': 'Configuração importada com sucesso'})
    except Exception as e:
        return jsonify({'error': str(e)})

@app.route('/api/reset_config')
@login_required
def reset_config():
    try:
        import json
        # Configuração padrão
        default_config = {
            "ai_enabled": True,
            "primary_provider": "openai",
            "fallback_providers": ["groq", "google", "anthropic"],
            "language": "pt-BR",
            "behavior_mode": "active",
            "rate_limits": {
                "requests_per_minute": 60,
                "tokens_per_day": 100000
            },
            "apis": {
                "openai": {"enabled": True, "model": "gpt-3.5-turbo", "max_tokens": 500, "temperature": 0.7},
                "groq": {"enabled": True, "model": "llama3-8b-8192", "max_tokens": 500, "temperature": 0.7},
                "google": {"enabled": True, "model": "gemini-1.5-flash", "max_tokens": 500, "temperature": 0.7},
                "anthropic": {"enabled": True, "model": "claude-3-haiku-20240307", "max_tokens": 500, "temperature": 0.7},
                "blackbox": {"enabled": True, "model": "gpt-3.5-turbo", "max_tokens": 500, "temperature": 0.7},
                "glm": {"enabled": True, "model": "glm-4", "max_tokens": 500, "temperature": 0.7},
                "deepinfra": {"enabled": True, "model": "meta-llama/Llama-2-70b-chat-hf", "max_tokens": 500, "temperature": 0.7}
            }
        }

        config_path = 'ai_config.json'
        with open(config_path, 'w') as f:
            json.dump(default_config, f, indent=2)

        return jsonify({'status': 'success', 'message': 'Configuração resetada para padrão'})
    except Exception as e:
        return jsonify({'error': str(e)})

@app.route('/api/assign_task', methods=['POST'])
@login_required
def assign_task():
    data = request.get_json()
    task = data.get('task', '')
    if not task:
        return jsonify({'error': 'Tarefa inválida'})
    init_db()
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("INSERT INTO ai_tasks (timestamp, description) VALUES (?, ?)", (datetime.now().isoformat(), task))
    conn.commit()
    conn.close()
    return jsonify({'status': 'success'})

@app.route('/api/tasks')
@login_required
def api_tasks():
    init_db()
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("SELECT timestamp, description FROM ai_tasks ORDER BY id DESC LIMIT 20")
    tasks = [{'timestamp': row[0], 'description': row[1]} for row in c.fetchall()]
    conn.close()
    return jsonify(tasks)

@app.route('/api/security_status')
@login_required
def api_security_status():
    # Mock security status, in real implementation check actual firewall/antivirus
    return jsonify({
        'firewall': 'Ativo',
        'antivirus': 'Atualizado',
        'last_scan': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    })

@app.route('/api/os_usage')
@login_required
def api_os_usage():
    cpu = psutil.cpu_percent(interval=1)
    mem = psutil.virtual_memory()
    disk = psutil.disk_usage('/')
    return jsonify({
        'cpu': round(cpu, 1),
        'memory': round(mem.percent, 1),
        'disk': round(disk.percent, 1)
    })

@app.route('/api/processes')
@login_required
def api_processes():
    processes = []
    for proc in psutil.process_iter(['pid', 'name']):
        try:
            processes.append({'pid': proc.info['pid'], 'name': proc.info['name']})
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    return jsonify(processes[:20])  # Top 20

@app.route('/api/system_info')
@login_required
def api_system_info():
    uptime = time.time() - psutil.boot_time()
    hours, remainder = divmod(int(uptime), 3600)
    minutes, seconds = divmod(remainder, 60)
    uptime_str = f"{hours}h {minutes}m {seconds}s"
    return jsonify({
        'os': platform.system() + ' ' + platform.release(),
        'version': platform.version(),
        'uptime': uptime_str
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3002, debug=False)

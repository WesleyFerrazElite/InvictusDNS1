from flask import Flask, render_template_string, request, jsonify, session, redirect, url_for, flash
import sqlite3
import os
import time
import requests
import json
import hashlib
import random
import string
from datetime import datetime, timedelta
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
import threading
import schedule
from dotenv import load_dotenv
load_dotenv()

app = Flask(__name__)
app.secret_key = 'marketing_secret_key_2024'

# Configurações de banco de dados
MARKETING_DB = 'data/marketing_advanced.db'
UPLOAD_FOLDER = 'static/uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# APIs das plataformas (chaves do .env)
FACEBOOK_ACCESS_TOKEN = os.getenv('FACEBOOK_ACCESS_TOKEN')
INSTAGRAM_ACCESS_TOKEN = os.getenv('INSTAGRAM_ACCESS_TOKEN')
TWITTER_BEARER_TOKEN = os.getenv('TWITTER_BEARER_TOKEN')
LINKEDIN_ACCESS_TOKEN = os.getenv('LINKEDIN_ACCESS_TOKEN')
YOUTUBE_API_KEY = os.getenv('YOUTUBE_API_KEY')
TIKTOK_ACCESS_TOKEN = os.getenv('TIKTOK_ACCESS_TOKEN')

# Inicializar banco de dados
def init_db():
    conn = sqlite3.connect(MARKETING_DB)
    c = conn.cursor()

    # Tabela de usuários
    c.execute('''CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY,
                    username TEXT UNIQUE,
                    password_hash TEXT,
                    email TEXT UNIQUE,
                    role TEXT DEFAULT 'user',
                    created_at TEXT
                )''')

    # Tabela de campanhas
    c.execute('''CREATE TABLE IF NOT EXISTS campaigns (
                    id INTEGER PRIMARY KEY,
                    name TEXT,
                    description TEXT,
                    status TEXT DEFAULT 'active',
                    created_by INTEGER,
                    created_at TEXT,
                    budget REAL DEFAULT 0
                )''')

    # Tabela de postagens
    c.execute('''CREATE TABLE IF NOT EXISTS posts (
                    id INTEGER PRIMARY KEY,
                    campaign_id INTEGER,
                    content TEXT,
                    image_path TEXT,
                    video_path TEXT,
                    link_url TEXT,
                    short_link TEXT,
                    platforms TEXT,  -- JSON array
                    scheduled_time TEXT,
                    status TEXT DEFAULT 'draft',
                    created_by INTEGER,
                    created_at TEXT,
                    published_at TEXT
                )''')

    # Tabela de publicações realizadas
    c.execute('''CREATE TABLE IF NOT EXISTS publications (
                    id INTEGER PRIMARY KEY,
                    post_id INTEGER,
                    platform TEXT,
                    platform_post_id TEXT,
                    status TEXT,
                    published_at TEXT,
                    engagement_data TEXT  -- JSON
                )''')

    # Tabela de links rastreados
    c.execute('''CREATE TABLE IF NOT EXISTS tracked_links (
                    id INTEGER PRIMARY KEY,
                    short_code TEXT UNIQUE,
                    original_url TEXT,
                    campaign_id INTEGER,
                    post_id INTEGER,
                    platform TEXT,
                    clicks INTEGER DEFAULT 0,
                    created_at TEXT
                )''')

    # Tabela de cliques nos links
    c.execute('''CREATE TABLE IF NOT EXISTS link_clicks (
                    id INTEGER PRIMARY KEY,
                    link_id INTEGER,
                    ip_address TEXT,
                    user_agent TEXT,
                    referrer TEXT,
                    clicked_at TEXT
                )''')

    # Tabela de configurações das APIs
    c.execute('''CREATE TABLE IF NOT EXISTS api_configs (
                    id INTEGER PRIMARY KEY,
                    platform TEXT UNIQUE,
                    access_token TEXT,
                    api_key TEXT,
                    account_id TEXT,
                    last_updated TEXT
                )''')

    # Inserir admin se não existir
    c.execute("SELECT COUNT(*) FROM users WHERE username = 'admin'")
    if c.fetchone()[0] == 0:
        c.execute("INSERT INTO users (username, password_hash, email, role, created_at) VALUES (?, ?, ?, ?, ?)",
                  ('admin', generate_password_hash('admin123'), 'admin@invictusdns.com', 'admin', datetime.now().isoformat()))

    # Inserir campanha padrão
    c.execute("SELECT COUNT(*) FROM campaigns")
    if c.fetchone()[0] == 0:
        c.execute("INSERT INTO campaigns (name, description, created_by, created_at) VALUES (?, ?, ?, ?)",
                  ('Campanha Principal', 'Campanha principal do InvictusDNS', 1, datetime.now().isoformat()))

    conn.commit()
    conn.close()

# Decorador de login
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# Gerar link curto
def generate_short_link():
    chars = string.ascii_letters + string.digits
    return ''.join(random.choice(chars) for _ in range(8))

# Funções de API das plataformas
def post_to_facebook(content, image_path=None, access_token=None):
    if not access_token:
        access_token = FACEBOOK_ACCESS_TOKEN
    if not access_token:
        return {'error': 'Token do Facebook não configurado'}

    url = f'https://graph.facebook.com/v18.0/me/feed'
    data = {'message': content, 'access_token': access_token}

    if image_path and os.path.exists(image_path):
        files = {'source': open(image_path, 'rb')}
        url = f'https://graph.facebook.com/v18.0/me/photos'
        data = {'message': content, 'access_token': access_token}
        response = requests.post(url, data=data, files=files)
    else:
        response = requests.post(url, data=data)

    return response.json()

def post_to_instagram(content, image_path=None, access_token=None):
    if not access_token:
        access_token = INSTAGRAM_ACCESS_TOKEN
    if not access_token:
        return {'error': 'Token do Instagram não configurado'}

    # Instagram requer container de mídia
    if not image_path or not os.path.exists(image_path):
        return {'error': 'Instagram requer imagem'}

    # Primeiro, criar container
    url = f'https://graph.facebook.com/v18.0/{INSTAGRAM_ACCOUNT_ID}/media'
    data = {
        'image_url': f'http://localhost:3001/static/uploads/{os.path.basename(image_path)}',
        'caption': content,
        'access_token': access_token
    }
    response = requests.post(url, data=data)
    result = response.json()

    if 'id' in result:
        # Publicar o container
        publish_url = f'https://graph.facebook.com/v18.0/{INSTAGRAM_ACCOUNT_ID}/media_publish'
        publish_data = {
            'creation_id': result['id'],
            'access_token': access_token
        }
        publish_response = requests.post(publish_url, data=publish_data)
        return publish_response.json()

    return result

def post_to_twitter(content, image_path=None, bearer_token=None):
    if not bearer_token:
        bearer_token = TWITTER_BEARER_TOKEN
    if not bearer_token:
        return {'error': 'Token do Twitter não configurado'}

    url = 'https://api.twitter.com/2/tweets'
    headers = {
        'Authorization': f'Bearer {bearer_token}',
        'Content-Type': 'application/json'
    }
    data = {'text': content}

    response = requests.post(url, headers=headers, json=data)
    return response.json()

def post_to_linkedin(content, access_token=None):
    if not access_token:
        access_token = LINKEDIN_ACCESS_TOKEN
    if not access_token:
        return {'error': 'Token do LinkedIn não configurado'}

    url = 'https://api.linkedin.com/v2/ugcPosts'
    headers = {
        'Authorization': f'Bearer {access_token}',
        'Content-Type': 'application/json'
    }

    data = {
        "author": "urn:li:person:YOUR_PERSON_URN",
        "lifecycleState": "PUBLISHED",
        "specificContent": {
            "com.linkedin.ugc.ShareContent": {
                "shareCommentary": {
                    "text": content
                },
                "shareMediaCategory": "NONE"
            }
        },
        "visibility": {
            "com.linkedin.ugc.MemberNetworkVisibility": "PUBLIC"
        }
    }

    response = requests.post(url, headers=headers, json=data)
    return response.json()

# Rota principal - Dashboard
@app.route('/')
@login_required
def dashboard():
    init_db()
    user_id = session['user_id']

    conn = sqlite3.connect(MARKETING_DB)
    c = conn.cursor()

    # Estatísticas gerais
    c.execute("SELECT COUNT(*) FROM campaigns WHERE created_by = ?", (user_id,))
    campaigns_count = c.fetchone()[0]

    c.execute("SELECT COUNT(*) FROM posts WHERE created_by = ?", (user_id,))
    posts_count = c.fetchone()[0]

    c.execute("SELECT COUNT(*) FROM publications WHERE status = 'published'")
    publications_count = c.fetchone()[0]

    # Cliques totais
    c.execute("SELECT SUM(clicks) FROM tracked_links")
    total_clicks = c.fetchone()[0] or 0

    # Campanhas recentes
    c.execute("SELECT id, name, status, created_at FROM campaigns WHERE created_by = ? ORDER BY created_at DESC LIMIT 5", (user_id,))
    recent_campaigns = c.fetchall()

    # Postagens recentes
    c.execute("""
        SELECT p.id, p.content, p.status, p.created_at, c.name
        FROM posts p
        LEFT JOIN campaigns c ON p.campaign_id = c.id
        WHERE p.created_by = ?
        ORDER BY p.created_at DESC LIMIT 5
    """, (user_id,))
    recent_posts = c.fetchall()

    conn.close()

    html = """
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>InvictusDNS - Marketing Dashboard</title>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                color: #333;
            }
            .navbar {
                background: rgba(255, 255, 255, 0.95);
                padding: 1rem 2rem;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                position: sticky;
                top: 0;
                z-index: 1000;
            }
            .navbar h1 {
                color: #667eea;
                display: inline;
            }
            .navbar .user-menu {
                float: right;
                margin-top: 5px;
            }
            .container {
                max-width: 1400px;
                margin: 0 auto;
                padding: 20px;
            }
            .stats-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                gap: 20px;
                margin-bottom: 30px;
            }
            .stat-card {
                background: rgba(255, 255, 255, 0.95);
                padding: 25px;
                border-radius: 15px;
                text-align: center;
                box-shadow: 0 8px 25px rgba(0,0,0,0.15);
                transition: transform 0.3s;
            }
            .stat-card:hover { transform: translateY(-5px); }
            .stat-number {
                font-size: 2.5em;
                font-weight: bold;
                color: #667eea;
                margin-bottom: 10px;
            }
            .stat-label {
                color: #666;
                font-size: 1.1em;
            }
            .content-grid {
                display: grid;
                grid-template-columns: 2fr 1fr;
                gap: 30px;
            }
            .main-content, .sidebar {
                background: rgba(255, 255, 255, 0.95);
                border-radius: 15px;
                padding: 25px;
                box-shadow: 0 8px 25px rgba(0,0,0,0.15);
            }
            .section-title {
                color: #667eea;
                margin-bottom: 20px;
                padding-bottom: 10px;
                border-bottom: 2px solid #667eea;
            }
            .btn {
                padding: 12px 24px;
                border: none;
                border-radius: 8px;
                cursor: pointer;
                font-size: 14px;
                text-decoration: none;
                display: inline-block;
                transition: all 0.3s;
            }
            .btn-primary { background: #667eea; color: white; }
            .btn-primary:hover { background: #5a67d8; }
            .btn-success { background: #48bb78; color: white; }
            .btn-success:hover { background: #38a169; }
            .table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 15px;
            }
            .table th, .table td {
                padding: 12px;
                text-align: left;
                border-bottom: 1px solid #eee;
            }
            .table th { background: #f8f9fa; font-weight: 600; }
            .status-badge {
                padding: 4px 8px;
                border-radius: 12px;
                font-size: 12px;
                font-weight: 500;
            }
            .status-draft { background: #e2e8f0; color: #4a5568; }
            .status-published { background: #c6f6d5; color: #22543d; }
            .status-scheduled { background: #fef5e7; color: #744210; }
            .quick-actions {
                margin-top: 30px;
            }
            .action-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 15px;
            }
            .action-card {
                padding: 20px;
                background: #f8f9fa;
                border-radius: 10px;
                text-align: center;
                transition: all 0.3s;
                cursor: pointer;
            }
            .action-card:hover {
                background: #667eea;
                color: white;
                transform: translateY(-2px);
            }
            .action-card i { font-size: 2em; margin-bottom: 10px; }
            @media (max-width: 768px) {
                .content-grid { grid-template-columns: 1fr; }
                .stats-grid { grid-template-columns: repeat(2, 1fr); }
            }
        </style>
    </head>
    <body>
        <div class="navbar">
            <h1><i class="fas fa-bullhorn"></i> InvictusDNS Marketing</h1>
            <div class="user-menu">
                <a href="/logout" class="btn btn-primary">Sair</a>
            </div>
        </div>

        <div class="container">
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-number">{{ campaigns_count }}</div>
                    <div class="stat-label">Campanhas</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">{{ posts_count }}</div>
                    <div class="stat-label">Postagens</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">{{ publications_count }}</div>
                    <div class="stat-label">Publicações</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">{{ total_clicks }}</div>
                    <div class="stat-label">Cliques Totais</div>
                </div>
            </div>

            <div class="content-grid">
                <div class="main-content">
                    <h2 class="section-title"><i class="fas fa-chart-line"></i> Atividades Recentes</h2>

                    <h3>Postagens Recentes</h3>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Conteúdo</th>
                                <th>Campanha</th>
                                <th>Status</th>
                                <th>Data</th>
                            </tr>
                        </thead>
                        <tbody>
                            {% for post in recent_posts %}
                            <tr>
                                <td>{{ post[1][:50] }}...</td>
                                <td>{{ post[4] or 'N/A' }}</td>
                                <td><span class="status-badge status-{{ post[2] }}">{{ post[2] }}</span></td>
                                <td>{{ post[3][:10] }}</td>
                            </tr>
                            {% endfor %}
                        </tbody>
                    </table>

                    <h3 style="margin-top: 30px;">Campanhas Recentes</h3>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th>Status</th>
                                <th>Criada em</th>
                            </tr>
                        </thead>
                        <tbody>
                            {% for campaign in recent_campaigns %}
                            <tr>
                                <td>{{ campaign[1] }}</td>
                                <td><span class="status-badge status-active">{{ campaign[2] }}</span></td>
                                <td>{{ campaign[3][:10] }}</td>
                            </tr>
                            {% endfor %}
                        </tbody>
                    </table>
                </div>

                <div class="sidebar">
                    <h2 class="section-title"><i class="fas fa-plus-circle"></i> Ações Rápidas</h2>

                    <div class="quick-actions">
                        <div class="action-grid">
                            <div class="action-card" onclick="window.location.href='/create-post'">
                                <i class="fas fa-edit"></i>
                                <div>Criar Postagem</div>
                            </div>
                            <div class="action-card" onclick="window.location.href='/campaigns'">
                                <i class="fas fa-flag"></i>
                                <div>Gerenciar Campanhas</div>
                            </div>
                            <div class="action-card" onclick="window.location.href='/analytics'">
                                <i class="fas fa-chart-bar"></i>
                                <div>Ver Analytics</div>
                            </div>
                            <div class="action-card" onclick="window.location.href='/api-config'">
                                <i class="fas fa-cog"></i>
                                <div>Configurar APIs</div>
                            </div>
                            <div class="action-card" onclick="window.location.href='/scheduled-posts'">
                                <i class="fas fa-calendar-alt"></i>
                                <div>Postagens Agendadas</div>
                            </div>
                            <div class="action-card" onclick="window.location.href='/link-tracker'">
                                <i class="fas fa-link"></i>
                                <div>Rastrear Links</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
    </html>
    """
    return render_template_string(html,
                                campaigns_count=campaigns_count,
                                posts_count=posts_count,
                                publications_count=publications_count,
                                total_clicks=total_clicks,
                                recent_campaigns=recent_campaigns,
                                recent_posts=recent_posts)

# Rota de login
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        conn = sqlite3.connect(MARKETING_DB)
        c = conn.cursor()
        c.execute("SELECT id, password_hash FROM users WHERE username = ?", (username,))
        user = c.fetchone()
        conn.close()

        if user and check_password_hash(user[1], password):
            session['user_id'] = user[0]
            session['username'] = username
            return redirect(url_for('dashboard'))
        else:
            flash('Credenciais inválidas')

    html = """
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Login - InvictusDNS Marketing</title>
        <style>
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                display: flex;
                justify-content: center;
                align-items: center;
                min-height: 100vh;
                margin: 0;
            }
            .login-container {
                background: rgba(255, 255, 255, 0.95);
                padding: 40px;
                border-radius: 15px;
                box-shadow: 0 15px 35px rgba(0,0,0,0.2);
                width: 100%;
                max-width: 400px;
            }
            h1 {
                text-align: center;
                color: #667eea;
                margin-bottom: 30px;
            }
            .form-group {
                margin-bottom: 20px;
            }
            label {
                display: block;
                margin-bottom: 5px;
                color: #666;
                font-weight: 500;
            }
            input {
                width: 100%;
                padding: 12px;
                border: 2px solid #e2e8f0;
                border-radius: 8px;
                font-size: 16px;
                transition: border-color 0.3s;
            }
            input:focus {
                outline: none;
                border-color: #667eea;
            }
            .btn {
                width: 100%;
                padding: 12px;
                background: linear-gradient(45deg, #667eea, #764ba2);
                color: white;
                border: none;
                border-radius: 8px;
                font-size: 16px;
                cursor: pointer;
                transition: background 0.3s;
            }
            .btn:hover {
                background: linear-gradient(45deg, #764ba2, #667eea);
            }
            .register-link {
                text-align: center;
                margin-top: 20px;
                color: #666;
            }
            .register-link a {
                color: #667eea;
                text-decoration: none;
            }
        </style>
    </head>
    <body>
        <div class="login-container">
            <h1><i class="fas fa-bullhorn"></i> InvictusDNS Marketing</h1>
            <form method="post">
                <div class="form-group">
                    <label for="username">Usuário:</label>
                    <input type="text" id="username" name="username" required>
                </div>
                <div class="form-group">
                    <label for="password">Senha:</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <button type="submit" class="btn">Entrar</button>
            </form>
            <div class="register-link">
                <a href="/register">Não tem conta? Registre-se</a>
            </div>
        </div>
    </body>
    </html>
    """
    return render_template_string(html)

# Rota de registro
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']

        try:
            conn = sqlite3.connect(MARKETING_DB)
            c = conn.cursor()
            c.execute("INSERT INTO users (username, password_hash, email, created_at) VALUES (?, ?, ?, ?)",
                      (username, generate_password_hash(password), email, datetime.now().isoformat()))
            conn.commit()
            conn.close()
            flash('Conta criada com sucesso! Faça login.')
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash('Usuário ou email já existe.')

    html = """
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Registro - InvictusDNS Marketing</title>
        <style>
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                display: flex;
                justify-content: center;
                align-items: center;
                min-height: 100vh;
                margin: 0;
            }
            .register-container {
                background: rgba(255, 255, 255, 0.95);
                padding: 40px;
                border-radius: 15px;
                box-shadow: 0 15px 35px rgba(0,0,0,0.2);
                width: 100%;
                max-width: 400px;
            }
            h1 {
                text-align: center;
                color: #667eea;
                margin-bottom: 30px;
            }
            .form-group {
                margin-bottom: 20px;
            }
            label {
                display: block;
                margin-bottom: 5px;
                color: #666;
                font-weight: 500;
            }
            input {
                width: 100%;
                padding: 12px;
                border: 2px solid #e2e8f0;
                border-radius: 8px;
                font-size: 16px;
                transition: border-color 0.3s;
            }
            input:focus {
                outline: none;
                border-color: #667eea;
            }
            .btn {
                width: 100%;
                padding: 12px;
                background: linear-gradient(45deg, #48bb78, #38a169);
                color: white;
                border: none;
                border-radius: 8px;
                font-size: 16px;
                cursor: pointer;
                transition: background 0.3s;
            }
            .btn:hover {
                background: linear-gradient(45deg, #38a169, #48bb78);
            }
            .login-link {
                text-align: center;
                margin-top: 20px;
                color: #666;
            }
            .login-link a {
                color: #667eea;
                text-decoration: none;
            }
        </style>
    </head>
    <body>
        <div class="register-container">
            <h1><i class="fas fa-user-plus"></i> Criar Conta</h1>
            <form method="post">
                <div class="form-group">
                    <label for="username">Usuário:</label>
                    <input type="text" id="username" name="username" required>
                </div>
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="password">Senha:</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <button type="submit" class="btn">Criar Conta</button>
            </form>
            <div class="login-link">
                <a href="/login">Já tem conta? Faça login</a>
            </div>
        </div>
    </body>
    </html>
    """
    return render_template_string(html)

# Rota de logout
@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

# Rota para criar postagem
@app.route('/create-post', methods=['GET', 'POST'])
@login_required
def create_post():
    if request.method == 'POST':
        content = request.form['content']
        campaign_id = request.form.get('campaign_id')
        platforms = request.form.getlist('platforms')
        scheduled_time = request.form.get('scheduled_time')
        link_url = request.form.get('link_url')

        # Processar upload de imagem
        image_path = None
        if 'image' in request.files:
            file = request.files['image']
            if file.filename:
                filename = f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{file.filename}"
                file.save(os.path.join(UPLOAD_FOLDER, filename))
                image_path = filename

        # Gerar link curto se necessário
        short_link = None
        if link_url:
            short_code = generate_short_link()
            short_link = f"http://localhost:3001/l/{short_code}"

            # Salvar link rastreado
            conn = sqlite3.connect(MARKETING_DB)
            c = conn.cursor()
            c.execute("INSERT INTO tracked_links (short_code, original_url, campaign_id, platform, created_at) VALUES (?, ?, ?, ?, ?)",
                      (short_code, link_url, campaign_id, ','.join(platforms), datetime.now().isoformat()))
            conn.commit()
            conn.close()

        # Salvar postagem
        conn = sqlite3.connect(MARKETING_DB)
        c = conn.cursor()
        c.execute("""INSERT INTO posts (campaign_id, content, image_path, link_url, short_link, platforms, scheduled_time, created_by, created_at)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                  (campaign_id, content, image_path, link_url, short_link, json.dumps(platforms), scheduled_time, session['user_id'], datetime.now().isoformat()))
        post_id = c.lastrowid
        conn.commit()
        conn.close()

        # Se não agendado, publicar imediatamente
        if not scheduled_time:
            publish_post(post_id)

        flash('Postagem criada com sucesso!')
        return redirect(url_for('dashboard'))

    # Carregar campanhas para o formulário
    conn = sqlite3.connect(MARKETING_DB)
    c = conn.cursor()
    c.execute("SELECT id, name FROM campaigns WHERE created_by = ? OR created_by IS NULL", (session['user_id'],))
    campaigns = c.fetchall()
    conn.close()

    html = """
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Criar Postagem - InvictusDNS Marketing</title>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
        <style>
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                color: #333;
            }
            .navbar {
                background: rgba(255, 255, 255, 0.95);
                padding: 1rem 2rem;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }
            .navbar h1 { color: #667eea; display: inline; }
            .navbar .back-btn { float: right; margin-top: 5px; }
            .container {
                max-width: 800px;
                margin: 20px auto;
                padding: 20px;
            }
            .form-container {
                background: rgba(255, 255, 255, 0.95);
                padding: 30px;
                border-radius: 15px;
                box-shadow: 0 8px 25px rgba(0,0,0,0.15);
            }
            .form-group {
                margin-bottom: 20px;
            }
            label {
                display: block;
                margin-bottom: 5px;
                font-weight: 600;
                color: #555;
            }
            textarea, input[type="text"], input[type="url"], input[type="datetime-local"], select {
                width: 100%;
                padding: 12px;
                border: 2px solid #e2e8f0;
                border-radius: 8px;
                font-size: 14px;
                transition: border-color 0.3s;
            }
            textarea { resize: vertical; min-height: 100px; }
            textarea:focus, input:focus, select:focus {
                outline: none;
                border-color: #667eea;
            }
            .platforms-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
                gap: 10px;
                margin-top: 10px;
            }
            .platform-checkbox {
                display: flex;
                align-items: center;
                padding: 10px;
                background: #f8f9fa;
                border-radius: 8px;
                border: 2px solid #e2e8f0;
                cursor: pointer;
                transition: all 0.3s;
            }
            .platform-checkbox:hover {
                background: #667eea;
                color: white;
                border-color: #667eea;
            }
            .platform-checkbox input { margin-right: 8px; }
            .btn {
                padding: 12px 24px;
                border: none;
                border-radius: 8px;
                cursor: pointer;
                font-size: 16px;
                text-decoration: none;
                display: inline-block;
                transition: all 0.3s;
            }
            .btn-primary { background: #667eea; color: white; }
            .btn-primary:hover { background: #5a67d8; }
            .btn-secondary { background: #6c757d; color: white; margin-left: 10px; }
            .btn-secondary:hover { background: #545b62; }
            .ai-suggestions {
                background: #f8f9fa;
                padding: 15px;
                border-radius: 8px;
                margin-top: 10px;
                border-left: 4px solid #667eea;
            }
            .suggestion-btn {
                background: #28a745;
                color: white;
                border: none;
                padding: 5px 10px;
                border-radius: 4px;
                cursor: pointer;
                margin: 2px;
                font-size: 12px;
            }
        </style>
    </head>
    <body>
        <div class="navbar">
            <h1><i class="fas fa-edit"></i> Criar Postagem</h1>
            <a href="/" class="btn btn-secondary back-btn">Voltar</a>
        </div>

        <div class="container">
            <div class="form-container">
                <form method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="campaign">Campanha:</label>
                        <select id="campaign" name="campaign_id">
                            <option value="">Selecionar Campanha</option>
                            {% for campaign in campaigns %}
                            <option value="{{ campaign[0] }}">{{ campaign[1] }}</option>
                            {% endfor %}
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="content">Conteúdo da Postagem:</label>
                        <textarea id="content" name="content" placeholder="Digite o texto da sua postagem..." required></textarea>
                        <div class="ai-suggestions">
                            <strong>Sugestões de IA:</strong>
                            <button type="button" class="suggestion-btn" onclick="addSuggestion('🚀 Descubra o InvictusDNS: Segurança e velocidade para sua conexão!')">Sugestão 1</button>
                            <button type="button" class="suggestion-btn" onclick="addSuggestion('🔒 Proteja sua família online com o InvictusDNS!')">Sugestão 2</button>
                            <button type="button" class="suggestion-btn" onclick="addSuggestion('⚡ Navegação ultrarrápida com bloqueio inteligente de ameaças!')">Sugestão 3</button>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="image">Imagem (opcional):</label>
                        <input type="file" id="image" name="image" accept="image/*">
                    </div>

                    <div class="form-group">
                        <label for="link_url">Link (opcional):</label>
                        <input type="url" id="link_url" name="link_url" placeholder="https://exemplo.com">
                    </div>

                    <div class="form-group">
                        <label>Plataformas:</label>
                        <div class="platforms-grid">
                            <label class="platform-checkbox">
                                <input type="checkbox" name="platforms" value="facebook"> 📘 Facebook
                            </label>
                            <label class="platform-checkbox">
                                <input type="checkbox" name="platforms" value="instagram"> 📷 Instagram
                            </label>
                            <label class="platform-checkbox">
                                <input type="checkbox" name="platforms" value="twitter"> 🐦 Twitter
                            </label>
                            <label class="platform-checkbox">
                                <input type="checkbox" name="platforms" value="linkedin"> 💼 LinkedIn
                            </label>
                            <label class="platform-checkbox">
                                <input type="checkbox" name="platforms" value="youtube"> 🎥

"""
Advanced AI Panel for InvictusDNS

This module provides a comprehensive web-based interface for managing AI-powered features
in the InvictusDNS system. It includes multi-provider AI chat, task management, security
monitoring, configuration settings, automation rules, machine learning controls, and
advanced integrations.

Features:
- Multi-provider AI support (OpenAI, Groq, Google Gemini, Anthropic Claude, Blackbox AI, GLM, DeepInfra)
- Real-time chat interface with provider selection
- Task assignment and management
- Security monitoring and malware scanning
- Dynamic configuration management
- Automation rule engine
- Machine learning model training and monitoring
- Advanced integrations (Telegram, webhooks, backups, logging)

Author: BLACKBOXAI
"""

from flask import Flask, render_template_string, request, jsonify, session, redirect, url_for, flash
import openai
import groq
import google.generativeai as genai
import anthropic
from functools import wraps
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
import psutil
import platform
import time
import os
from dotenv import load_dotenv
load_dotenv()
from datetime import datetime
import json
from ai_core import ai_core

app = Flask(__name__)
app.secret_key = 'supersecretkey'

# API keys from environment
openai.api_key = os.getenv("OPENAI_API_KEY")
groq_api_key = os.getenv("GROQ_API_KEY")
google_api_key = os.getenv("GOOGLE_API_KEY")
anthropic_api_key = os.getenv("ANTHROPIC_API_KEY")
blackbox_api_key = os.getenv("BLACKBOX_API_KEY")
glm_api_key = os.getenv("GLM_API_KEY")
deepinfra_api_key = os.getenv("DEEPINFRA_API_KEY")

DB_FILE = 'data/dns_logs.db'

def init_db():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY,
                    username TEXT UNIQUE,
                    password_hash TEXT,
                    role TEXT DEFAULT 'user',
                    ips TEXT
                )''')
    c.execute('''CREATE TABLE IF NOT EXISTS ai_tasks (
                    id INTEGER PRIMARY KEY,
                    timestamp TEXT,
                    description TEXT,
                    status TEXT DEFAULT 'pending'
                )''')
    # Insert admin if not exists
    c.execute("SELECT COUNT(*) FROM users WHERE username = 'admin'")
    if c.fetchone()[0] == 0:
        c.execute("INSERT INTO users (username, password_hash, role, ips) VALUES (?, ?, ?, ?)",
                  ('admin', generate_password_hash('senha123'), 'admin', ''))
    conn.commit()
    conn.close()

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        init_db()
        conn = sqlite3.connect(DB_FILE, timeout=30, check_same_thread=False)
        c = conn.cursor()
        c.execute("SELECT id, password_hash FROM users WHERE username = ?", (username,))
        user = c.fetchone()
        conn.close()
        if user and check_password_hash(user[1], password):
            session['user_id'] = user[0]
            return redirect(url_for('ai_panel'))
        flash('Credenciais inválidas')
    html = """
    <!DOCTYPE html>
    <html>
    <head><title>Login Painel IA Avançado</title></head>
    <body>
        <h1>Login Painel de Inteligência Artificial Avançado</h1>
        <form method="post">
            <input type="text" name="username" placeholder="Usuário" required><br>
            <input type="password" name="password" placeholder="Senha" required><br>
            <button type="submit">Login</button>
        </form>
    </body>
    </html>
    """
    return html

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    return redirect(url_for('login'))

@app.route('/ai_panel')
@login_required
def ai_panel():
    html = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>🚀 InvictusAI - Painel Avançado</title>
        <style>
            body {
                margin: 0;
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: linear-gradient(135deg, #0f0f23 0%, #1a1a2e 50%, #16213e 100%);
                color: #00ffea;
                overflow-x: hidden;
            }
            .container {
                background-color: rgba(0, 0, 0, 0.85);
                margin: 20px auto;
                padding: 20px;
                border-radius: 15px;
                max-width: 1400px;
                box-shadow: 0 0 20px #00ffea;
            }
            h1 {
                text-align: center;
                font-weight: 700;
                font-size: 2.5em;
                margin-bottom: 20px;
                text-shadow: 0 0 10px #00ffea;
            }
            .tabs {
                display: flex;
                justify-content: center;
                margin-bottom: 20px;
                flex-wrap: wrap;
            }
            .tab {
                padding: 10px 20px;
                background: rgba(0, 255, 234, 0.2);
                border: 1px solid #00ffea;
                cursor: pointer;
                border-radius: 8px;
                margin: 5px;
                transition: all 0.3s;
                font-size: 14px;
            }
            .tab.active {
                background: #00ffea;
                color: #000;
                box-shadow: 0 0 10px #00ffea;
            }
            .tab-content {
                display: none;
            }
            .tab-content.active {
                display: block;
            }
            #chat-log {
                height: 400px;
                overflow-y: scroll;
                background: #001f22;
                padding: 15px;
                border-radius: 10px;
                font-family: monospace;
                font-size: 14px;
                box-shadow: inset 0 0 10px #00ffea;
                margin-bottom: 20px;
            }
            textarea, input[type=text], input[type=password], select {
                width: 100%;
                padding: 10px;
                margin-bottom: 15px;
                border-radius: 8px;
                border: none;
                background: #002b2f;
                color: #00ffea;
                font-size: 1em;
                box-shadow: 0 0 5px #00ffea;
            }
            button {
                background-color: #00ffea;
                border: none;
                padding: 12px 25px;
                border-radius: 8px;
                color: #000;
                font-weight: bold;
                cursor: pointer;
                transition: all 0.3s;
                margin: 5px;
            }
            button:hover {
                background-color: #00c8b3;
                box-shadow: 0 0 10px #00ffea;
            }
            button:disabled {
                background-color: #666;
                cursor: not-allowed;
            }
            .section {
                margin-bottom: 30px;
            }
            .grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                gap: 20px;
            }
            .card {
                background: rgba(0, 0, 0, 0.5);
                padding: 15px;
                border-radius: 10px;
                box-shadow: 0 0 10px #00ffea;
                border: 1px solid #00ffea;
            }
            .status-indicator {
                display: inline-block;
                width: 12px;
                height: 12px;
                border-radius: 50%;
                margin-right: 8px;
            }
            .status-healthy { background: #27ae60; }
            .status-warning { background: #f39c12; }
            .status-critical { background: #e74c3c; }
            .status-disabled { background: #666; }
            .config-section {
                background: rgba(0, 0, 0, 0.3);
                padding: 20px;
                border-radius: 10px;
                margin-bottom: 20px;
                border: 1px solid #00ffea;
            }
            .config-item {
                margin-bottom: 15px;
            }
            .config-item label {
                display: block;
                margin-bottom: 5px;
                font-weight: bold;
            }
            .switch {
                position: relative;
                display: inline-block;
                width: 60px;
                height: 34px;
            }
            .switch input {
                opacity: 0;
                width: 0;
                height: 0;
            }
            .slider {
                position: absolute;
                cursor: pointer;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background-color: #ccc;
                transition: .4s;
                border-radius: 34px;
            }
            .slider:before {
                position: absolute;
                content: "";
                height: 26px;
                width: 26px;
                left: 4px;
                bottom: 4px;
                background-color: white;
                transition: .4s;
                border-radius: 50%;
            }
            input:checked + .slider {
                background-color: #00ffea;
            }
            input:checked + .slider:before {
                transform: translateX(26px);
            }
            .rule-item {
                background: rgba(0, 255, 234, 0.1);
                padding: 10px;
                border-radius: 8px;
                margin-bottom: 10px;
                border: 1px solid #00ffea;
            }
            .rule-item h4 {
                margin: 0 0 10px 0;
                color: #00ffea;
            }
            .metrics-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 15px;
                margin-top: 20px;
            }
            .metric-card {
                background: rgba(0, 0, 0, 0.5);
                padding: 15px;
                border-radius: 8px;
                text-align: center;
                border: 1px solid #00ffea;
            }
            .metric-value {
                font-size: 2em;
                font-weight: bold;
                color: #00ffea;
            }
            .metric-label {
                color: #ccc;
                font-size: 0.9em;
            }
            .alert {
                padding: 10px;
                border-radius: 5px;
                margin-bottom: 10px;
            }
            .alert-success { background: rgba(39, 174, 96, 0.2); border: 1px solid #27ae60; }
            .alert-error { background: rgba(231, 76, 60, 0.2); border: 1px solid #e74c3c; }
            .alert-warning { background: rgba(243, 156, 18, 0.2); border: 1px solid #f39c12; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🚀 InvictusAI - Painel Avançado</h1>
            <div class="tabs">
                <div class="tab" onclick="openTab(event, 'Chat')">💬 Chat com IA</div>
                <div class="tab" onclick="openTab(event, 'Tasks')">📋 Tarefas para IA</div>
                <div class="tab" onclick="openTab(event, 'Security')">🛡️ Segurança</div>
                <div class="tab" onclick="openTab(event, 'Config')">⚙️ Configurações</div>
                <div class="tab" onclick="openTab(event, 'Automation')">🤖 Automação</div>
                <div class="tab" onclick="openTab(event, 'ML')">🧠 Machine Learning</div>
                <div class="tab" onclick="openTab(event, 'Monitoring')">📊 Monitoramento</div>
                <div class="tab" onclick="openTab(event, 'Advanced')">🔧 Avançado</div>
            </div>

            <!-- Chat Tab -->
            <div id="Chat" class="tab-content">
                <div class="section">
                    <h2>Chat com IA Avançado</h2>
                    <div id="chat-log"></div>
                    <textarea id="chat-input" rows="3" placeholder="Digite o comando ou pergunta para a IA..."></textarea>
                    <select id="ai-provider">
                        <option value="auto">Auto (Com Fallback)</option>
                        <option value="openai">OpenAI GPT</option>
                        <option value="groq">Groq Llama</option>
                        <option value="google">Google Gemini</option>
                        <option value="anthropic">Anthropic Claude</option>
                        <option value="blackbox">Blackbox AI</option>
                        <option value="glm">GLM (Zhipu)</option>
                        <option value="deepinfra">DeepInfra</option>
                    </select>
                    <button onclick="sendToAI()">Enviar para IA</button>
                    <button onclick="clearChat()">Limpar Chat</button>
                </div>
            </div>

            <!-- Tasks Tab -->
            <div id="Tasks" class="tab-content">
                <div class="section">
                    <h2>Atribuir Tarefas para IA</h2>
                    <input type="text" id="task-input" placeholder="Descreva a tarefa (ex: Monitorar domínio example.com)">
                    <button onclick="assignTask()">Atribuir Tarefa</button>
                    <div id="tasks-list" style="height: 300px; overflow-y: scroll; background: #001f22; padding: 10px; border-radius: 10px; margin-top: 10px;"></div>
                </div>
            </div>

            <!-- Security Tab -->
            <div id="Security" class="tab-content">
                <div class="section">
                    <h2>Monitoramento de Segurança Avançado</h2>
                    <div class="grid">
                        <div class="card">
                            <h3>Atividades Recentes</h3>
                            <div id="security-activities" style="height: 200px; overflow-y: scroll; background: #001f22; padding: 10px; border-radius: 10px;"></div>
                        </div>
                        <div class="card">
                            <h3>Ameaças Detectadas</h3>
                            <div id="threats-detected" style="height: 200px; overflow-y: scroll; background: #001f22; padding: 10px; border-radius: 10px;"></div>
                        </div>
                        <div class="card">
                            <h3>Status de Segurança</h3>
                            <div id="security-status"></div>
                        </div>
                        <div class="card">
                            <h3>Ações de Combate a Vírus</h3>
                            <button onclick="scanMalware()">Escanear Malware</button>
                            <button onclick="detectPhishing()">Detectar Phishing</button>
                            <button onclick="blockC2()">Bloquear C2</button>
                            <div id="antivirus-actions" style="margin-top: 10px;"></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Config Tab -->
            <div id="Config" class="tab-content">
                <div class="section">
                    <h2>Configurações Gerais da IA</h2>
                    <div class="config-section">
                        <div class="config-item">
                            <label>IA Ativada:</label>
                            <label class="switch">
                                <input type="checkbox" id="ai-enabled" onchange="updateConfig('ai_enabled', this.checked)">
                                <span class="slider"></span>
                            </label>
                        </div>
                        <div class="config-item">
                            <label>Provedor Primário:</label>
                            <select id="primary-provider" onchange="updateConfig('primary_provider', this.value)">
                                <option value="openai">OpenAI</option>
                                <option value="groq">Groq</option>
                                <option value="google">Google</option>
                                <option value="anthropic">Anthropic</option>
                                <option value="blackbox">Blackbox</option>
                                <option value="glm">GLM</option>
                                <option value="deepinfra">DeepInfra</option>
                            </select>
                        </div>
                        <div class="config-item">
                            <label>Idioma:</label>
                            <select id="ai-language" onchange="updateConfig('language', this.value)">
                                <option value="pt-BR">Português (Brasil)</option>
                                <option value="en-US">English (US)</option>
                                <option value="es-ES">Español</option>
                            </select>
                        </div>
                        <div class="config-item">
                            <label>Modo de Operação:</label>
                            <select id="behavior-mode" onchange="updateConfig('behavior_mode', this.value)">
                                <option value="active">Ativo</option>
                                <option value="passive">Passivo</option>
                                <option value="learning">Aprendizado</option>
                            </select>
                        </div>
                    </div>

                    <h2>Configuração de APIs</h2>
                    <div id="api-configs"></div>
                </div>
            </div>

            <!-- Automation Tab -->
            <div id="Automation" class="tab-content">
                <div class="section">
                    <h2>Regras de Automação</h2>
                    <button onclick="addNewRule()">Adicionar Nova Regra</button>
                    <div id="automation-rules"></div>
                </div>
            </div>

            <!-- ML Tab -->
            <div id="ML" class="tab-content">
                <div class="section">
                    <h2>Machine Learning</h2>
                    <div class="grid">
                        <div class="card">
                            <h3>Detecção de Anomalias</h3>
                            <label class="switch">
                                <input type="checkbox" id="anomaly-detection-enabled" onchange="updateMLConfig('anomaly_detection.enabled', this.checked)">
                                <span class="slider"></span>
                            </label>
                            <div id="anomaly-status" style="margin-top: 10px;"></div>
                        </div>
                        <div class="card">
                            <h3>Classificação de Domínios</h3>
                            <label class="switch">
                                <input type="checkbox" id="domain-classification-enabled" onchange="updateMLConfig('domain_classification.enabled', this.checked)">
                                <span class="slider"></span>
                            </label>
                            <div id="classification-status" style="margin-top: 10px;"></div>
                        </div>
                        <div class="card">
                            <h3>Dados de Treinamento</h3>
                            <div id="training-data-stats"></div>
                            <button onclick="retrainModels()">Retreinar Modelos</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Monitoring Tab -->
            <div id="Monitoring" class="tab-content">
                <div class="section">
                    <h2>Monitoramento da IA</h2>
                    <div class="metrics-grid">
                        <div class="metric-card">
                            <div class="metric-value" id="ai-status">---</div>
                            <div class="metric-label">Status da IA</div>
                        </div>
                        <div class="metric-card">
                            <div class="metric-value" id="active-rules">0</div>
                            <div class="metric-label">Regras Ativas</div>
                        </div>
                        <div class="metric-card">
                            <div class="metric-value" id="ml-models">0/2</div>
                            <div class="metric-label">Modelos ML Carregados</div>
                        </div>
                        <div class="metric-card">
                            <div class="metric-value" id="training-size">0</div>
                            <div class="metric-label">Dados de Treinamento</div>
                        </div>
                    </div>
                    <div class="card" style="margin-top: 20px;">
                        <h3>Estatísticas de Regras</h3>
                        <div id="rule-stats"></div>
                    </div>
                </div>
            </div>

            <!-- Advanced Tab -->
            <div id="Advanced" class="tab-content">
                <div class="section">
                    <h2>Configurações Avançadas</h2>
                    <div class="grid">
                        <div class="card">
                            <h3>Integrações Externas</h3>
                            <div class="config-item">
                                <label>Telegram Bot:</label>
                                <label class="switch">
                                    <input type="checkbox" id="telegram-enabled" onchange="updateIntegration('telegram_bot.enabled', this.checked)">
                                    <span class="slider"></span>
                                </label>
                                <input type="text" id="telegram-token" placeholder="Token do Bot" onchange="updateIntegration('telegram_bot.token', this.value)">
                                <input type="text" id="telegram-chat-id" placeholder="Chat ID" onchange="updateIntegration('telegram_bot.chat_id', this.value)">
                            </div>
                            <div class="config-item">
                                <label>Webhooks:</label>
                                <label class="switch">
                                    <input type="checkbox" id="webhook-enabled" onchange="updateIntegration('webhooks.enabled', this.checked)">
                                    <span class="slider"></span>
                                </label>
                                <input type="text" id="webhook-url" placeholder="URL do Webhook" onchange="updateIntegration('webhooks.url', this.value)">
                            </div>
                        </div>
                        <div class="card">
                            <h3>Backup e Restauração</h3>
                            <div class="config-item">
                                <label>Backup Automático:</label>
                                <label class="switch">
                                    <input type="checkbox" id="auto-backup" onchange="updateBackup('auto_backup', this.checked)">
                                    <span class="slider"></span>
                                </label>
                            </div>
                            <button onclick="createBackup()">Criar Backup Agora</button>
                            <button onclick="restoreBackup()">Restaurar Backup</button>
                            <div id="backup-status" style="margin-top: 10px;"></div>
                        </div>
                        <div class="card">
                            <h3>Logs e Auditoria</h3>
                            <select id="log-level" onchange="updateLogging('level', this.value)">
                                <option value="DEBUG">Debug</option>
                                <option value="INFO">Info</option>
                                <option value="WARNING">Warning</option>
                                <option value="ERROR">Error</option>
                            </select>
                            <button onclick="exportLogs()">Exportar Logs</button>
                            <div id="log-stats" style="margin-top: 10px;"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script>
            let currentTab = 'Chat';

            function openTab(evt, tabName) {
                var i, tabcontent, tablinks;
                tabcontent = document.getElementsByClassName("tab-content");
                for (i = 0; i < tabcontent.length; i++) {
                    tabcontent[i].style.display = "none";
                }
                tablinks = document.getElementsByClassName("tab");
                for (i = 0; i < tablinks.length; i++) {
                    tablinks[i].className = tablinks[i].className.replace(" active", "");
                }
                document.getElementById(tabName).style.display = "block";
                evt.currentTarget.className += " active";
                currentTab = tabName;

                // Load tab-specific data
                loadTabData(tabName);
            }

            function loadTabData(tabName) {
                if (tabName === 'Config') {
                    loadConfig();
                } else if (tabName === 'Automation') {
                    loadAutomationRules();
                } else if (tabName === 'ML') {
                    loadMLStatus();
                } else if (tabName === 'Monitoring') {
                    loadMonitoringData();
                } else if (tabName === 'Advanced') {
                    loadAdvancedConfig();
                }
            }

            async function loadConfig() {
                try {
                    const response = await fetch('/api/ai_config');
                    const config = await response.json();

                    document.getElementById('ai-enabled').checked = config.ai_enabled || false;
                    document.getElementById('primary-provider').value = config.primary_provider || 'openai';
                    document.getElementById('ai-language').value = config.language || 'pt-BR';
                    document.getElementById('behavior-mode').value = config.behavior_mode || 'active';

                    loadAPIConfigs(config.apis || {});
                } catch (error) {
                    console.error('Error loading config:', error);
                }
            }

            function loadAPIConfigs(apis) {
                const container = document.getElementById('api-configs');
                container.innerHTML = '';

                const providers = ['openai', 'groq', 'google', 'anthropic', 'blackbox', 'glm', 'deepinfra'];

                providers.forEach(provider => {
                    const api = apis[provider] || {};
                    const div = document.createElement('div');
                    div.className = 'config-section';
                    div.innerHTML = `
                        <h3>${provider.toUpperCase()}</h3>
                        <div class="config-item">
                            <label>Ativado:</label>
                            <label class="switch">
                                <input type="checkbox" id="${provider}-enabled" ${api.enabled ? 'checked' : ''} onchange="updateAPIConfig('${provider}', 'enabled', this.checked)">
                                <span class="slider"></span>
                            </label>
                        </div>
                        <div class="config-item">
                            <label>API Key:</label>
                            <input type="password" id="${provider}-key" value="${api.api_key ? '••••••••' : ''}" onchange="updateAPIConfig('${provider}', 'api_key', this.value)">
                        </div>
                        <div class="config-item">
                            <label>Modelo:</label>
                            <input type="text" id="${provider}-model" value="${api.model || ''}" onchange="updateAPIConfig('${provider}', 'model', this.value)">
                        </div>
                        <button onclick="testAPI('${provider}')">Testar API</button>
                        <div id="${provider}-status" style="margin-top: 5px;"></div>
                    `;
                    container.appendChild(div);
                });
            }

            async function loadAutomationRules() {
                try {
                    const response = await fetch('/api/automation_rules');
                    const rules = await response.json();

                    const container = document.getElementById('automation-rules');
                    container.innerHTML = '';

                    rules.forEach(rule => {
                        const div = document.createElement('div');
                        div.className = 'rule-item';
                        div.innerHTML = `
                            <h4>${rule.name} (${rule.id})</h4>
                            <p>${rule.description}</p>
                            <p><strong>Condições:</strong> ${rule.conditions.length}</p>
                            <p><strong>Ações:</strong> ${rule.actions.length}</p>
                            <label class="switch">
                                <input type="checkbox" ${rule.enabled ? 'checked' : ''} onchange="toggleRule('${rule.id}', this.checked)">
                                <span class="slider"></span>
                            </label>
                            <button onclick="editRule('${rule.id}')">Editar</button>
                            <button onclick="deleteRule('${rule.id}')">Excluir</button>
                        `;
                        container.appendChild(div);
                    });
                } catch (error) {
                    console.error('Error loading rules:', error);
                }
            }

            async function loadMLStatus() {
                try {
                    const response = await fetch('/api/ml_status');
                    const status = await response.json();

                    document.getElementById('anomaly-detection-enabled').checked = status.anomaly_detection?.enabled || false;
                    document.getElementById('domain-classification-enabled').checked = status.domain_classification?.enabled || false;

                    document.getElementById('anomaly-status').innerHTML = status.anomaly_detection?.enabled ?
                        '<span style="color: #27ae60;">✓ Ativo</span>' : '<span style="color: #666;">✗ Inativo</span>';

                    document.getElementById('classification-status').innerHTML = status.domain_classification?.enabled ?
                        '<span style="color: #27ae60;">✓ Ativo</span>' : '<span style="color: #666;">✗ Inativo</span>';

                    document.getElementById('training-data-stats').innerHTML = `
                        <p>Dados de treinamento: ${status.training_data_size || 0}</p>
                        <p>Último treino: ${status.last_training || 'Nunca'}</p>
                    `;
                } catch (error) {
                    console.error('Error loading ML status:', error);
                }
            }

            async function loadMonitoringData() {
                try {
                    const response = await fetch('/api/ai_status');
                    const status = await response.json();

                    document.getElementById('ai-status').innerHTML = status.enabled ?
                        '<span style="color: #27ae60;">✓ Ativo</span>' : '<span style="color: #e74c3c;">✗ Inativo</span>';
                    document.getElementById('active-rules').textContent = status.active_rules || 0;
                    document.getElementById('ml-models').textContent = `${Object.values(status.ml_models_loaded || {}).filter(Boolean).length}/2`;
                    document.getElementById('training-size').textContent = status.training_data_size || 0;

                    const ruleStatsDiv = document.getElementById('rule-stats');
                    ruleStatsDiv.innerHTML = '';
                    for (const [rule, count] of Object.entries(status.rule_stats || {})) {
                        ruleStatsDiv.innerHTML += `<p>${rule}: ${count} execuções</p>`;
                    }
                } catch (error) {
                    console.error('Error loading monitoring data:', error);
                }
            }

            async function loadAdvancedConfig() {
                try {
                    const response = await fetch('/api/advanced_config');
                    const config = await response.json();

                    // Load integrations
                    const telegram = config.integrations?.telegram_bot || {};
                    document.getElementById('telegram-enabled').checked = telegram.enabled || false;
                    document.getElementById('telegram-token').value = telegram.token || '';
                    document.getElementById('telegram-chat-id').value = telegram.chat_id || '';

                    const webhook = config.integrations?.webhooks || {};
                    document.getElementById('webhook-enabled').checked = webhook.enabled || false;
                    document.getElementById('webhook-url').value = webhook.url || '';

                    // Load backup settings
                    document.getElementById('auto-backup').checked = config.backup?.auto_backup || false;

                    // Load logging
                    document.getElementById('log-level').value = config.monitoring?.logging?.level || 'INFO';

                } catch (error) {
                    console.error('Error loading advanced config:', error);
                }
            }

            async function sendToAI() {
                const input = document.getElementById('chat-input').value.trim();
                if (!input) return;

                const provider = document.getElementById('ai-provider').value;
                appendToChat('Você: ' + input);
                document.getElementById('chat-input').value = '';

                try {
                    const response = await fetch('/api/ai_interact', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({message: input, provider: provider})
                    });
                    const data = await response.json();
                    appendToChat('IA: ' + data.reply);
                } catch (error) {
                    appendToChat('Erro: ' + error.message);
                }
            }

            function appendToChat(message) {
                const chatLog = document.getElementById('chat-log');
                chatLog.innerHTML += '<div>' + message + '</div>';
                chatLog.scrollTop = chatLog.scrollHeight;
            }

            function clearChat() {
                document.getElementById('chat-log').innerHTML = '';
            }

            async function assignTask() {
                const task = document.getElementById('task-input').value.trim();
                if (!task) return;

                try {
                    const response = await fetch('/api/assign_task', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({task: task})
                    });
                    document.getElementById('task-input').value = '';
                    loadTasks();
                } catch (error) {
                    console.error('Error assigning task:', error);
                }
            }

            async function loadTasks() {
                try {
                    const response = await fetch('/api/tasks');
                    const tasks = await response.json();
                    const container = document.getElementById('tasks-list');
                    container.innerHTML = tasks.map(task =>
                        `<div>${task.timestamp}: ${task.description}</div>`
                    ).join('');
                } catch (error) {
                    console.error('Error loading tasks:', error);
                }
            }

            async function updateConfig(key, value) {
                try {
                    await fetch('/api/update_config', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({key: key, value: value})
                    });
                    showAlert('Configuração atualizada!', 'success');
                } catch (error) {
                    showAlert('Erro ao atualizar configuração', 'error');
                }
            }

            async function updateAPIConfig(provider, key, value) {
                try {
                    await fetch('/api/update_api_config', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({provider: provider, key: key, value: value})
                    });
                    showAlert('Configuração da API atualizada!', 'success');
                } catch (error) {
                    showAlert('Erro ao atualizar configuração da API', 'error');
                }
            }

            async function testAPI(provider) {
                const statusDiv = document.getElementById(`${provider}-status`);
                statusDiv.innerHTML = 'Testando...';

                try {
                    const response = await fetch('/api/test_api', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({provider: provider})
                    });
                    const result = await response.json();

                    if (result.success) {
                        statusDiv.innerHTML = '<span style="color: #27ae60;">✓ API funcionando</span>';
                    } else {
                        statusDiv.innerHTML = `<span style="color: #e74c3c;">✗ Erro: ${result.error}</span>`;
                    }
                } catch (error) {
                    statusDiv.innerHTML = '<span style="color: #e74c3c;">✗ Erro de conexão</span>';
                }
            }

            async function updateMLConfig(key, value) {
                try {
                    await fetch('/api/update_ml_config', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({key: key, value: value})
                    });
                    showAlert('Configuração ML atualizada!', 'success');
                    loadMLStatus();
                } catch (error) {
                    showAlert('Erro ao atualizar configuração ML', 'error');
                }
            }

            async function retrainModels() {
                try {
                    await fetch('/api/retrain_models', { method: 'POST' });
                    showAlert('Retreinamento iniciado!', 'success');
                    setTimeout(() => loadMLStatus(), 2000);
                } catch (error) {
                    showAlert('Erro ao retreinar modelos', 'error');
                }
            }

            async function updateIntegration(key, value) {
                try {
                    await fetch('/api/update_integration', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({key: key, value: value})
                    });
                    showAlert('Integração atualizada!', 'success');
                } catch (error) {
                    showAlert('Erro ao atualizar integração', 'error');
                }
            }

            async function updateBackup(key, value) {
                try {
                    await fetch('/api/update_backup', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({key: key, value: value})
                    });
                    showAlert('Configuração de backup atualizada!', 'success');
                } catch (error) {
                    showAlert('Erro ao atualizar backup', 'error');
                }
            }

            async function updateLogging(key, value) {
                try {
                    await fetch('/api/update_logging', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({key: key, value: value})
                    });
                    showAlert('Configuração de logging atualizada!', 'success');
                } catch (error) {
                    showAlert('Erro ao atualizar logging

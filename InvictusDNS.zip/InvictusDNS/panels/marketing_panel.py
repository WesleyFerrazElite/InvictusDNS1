from flask import Flask, render_template_string, request, redirect, url_for
import sqlite3
from werkzeug.security import generate_password_hash
import time
import os

app = Flask(__name__)

MARKETING_DB = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data', 'marketing.db')
USERS_DB = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data', 'users.db')

# Inicializar banco de dados para marketing
def init_marketing_db():
    conn = sqlite3.connect(MARKETING_DB)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS marketing_content (
                    id INTEGER PRIMARY KEY,
                    title TEXT,
                    content TEXT
                )''')
    # Adicionar colunas se não existirem
    columns_to_add = [
        'facebook_link', 'instagram_link', 'promo_link', 'youtube_link',
        'twitter_link', 'linkedin_link', 'tiktok_link', 'kwai_link',
        'shopee_link', 'mercado_livre_link', 'meta_link'
    ]
    for col in columns_to_add:
        try:
            c.execute(f"ALTER TABLE marketing_content ADD COLUMN {col} TEXT")
        except sqlite3.OperationalError:
            pass
    # Inserir conteúdo padrão se vazio
    c.execute("SELECT COUNT(*) FROM marketing_content")
    if c.fetchone()[0] == 0:
        c.execute("""INSERT INTO marketing_content (
                        title, content, facebook_link, instagram_link, promo_link,
                        youtube_link, twitter_link, linkedin_link, tiktok_link,
                        kwai_link, shopee_link, mercado_livre_link, meta_link
                     ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                  ('Bem-vindo ao InvictusDNS', 'Aqui você pode promover seus serviços e produtos.',
                   'https://facebook.com/invictusdns', 'https://instagram.com/invictusdns', 'https://example.com/promo',
                   'https://youtube.com/invictusdns', 'https://twitter.com/invictusdns', 'https://linkedin.com/in/invictusdns',
                   'https://tiktok.com/@invictusdns', 'https://kwai.com/invictusdns', 'https://shopee.com.br/invictusdns',
                   'https://mercado.com.br/invictusdns', 'https://meta.com/invictusdns'))
    conn.commit()
    conn.close()

# Inicializar banco de dados para usuários
def init_users_db():
    conn = sqlite3.connect(USERS_DB)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY,
                    username TEXT UNIQUE,
                    password_hash TEXT,
                    email TEXT UNIQUE,
                    created_at TEXT
                )''')
    conn.commit()
    conn.close()

@app.route('/')
def marketing():
    init_marketing_db()
    conn = sqlite3.connect(MARKETING_DB)
    c = conn.cursor()
    c.execute("""SELECT title, content, facebook_link, instagram_link, promo_link,
                        youtube_link, twitter_link, linkedin_link, tiktok_link,
                        kwai_link, shopee_link, mercado_livre_link, meta_link
                 FROM marketing_content LIMIT 1""")
    row = c.fetchone()
    conn.close()
    if row:
        title, content, facebook_link, instagram_link, promo_link, youtube_link, twitter_link, linkedin_link, tiktok_link, kwai_link, shopee_link, mercado_livre_link, meta_link = row
    else:
        title, content, facebook_link, instagram_link, promo_link, youtube_link, twitter_link, linkedin_link, tiktok_link, kwai_link, shopee_link, mercado_livre_link, meta_link = ('', '', '', '', '', '', '', '', '', '', '', '', '')

    html = """
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <title>Painel de Marketing InvictusDNS</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                margin: 0;
                padding: 0;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                color: #333;
            }
            .container {
                max-width: 1200px;
                margin: 0 auto;
                padding: 20px;
            }
            header {
                text-align: center;
                background: rgba(255, 255, 255, 0.1);
                padding: 40px 20px;
                border-radius: 15px;
                margin-bottom: 30px;
                backdrop-filter: blur(10px);
            }
            h1 {
                color: #fff;
                font-size: 3em;
                margin: 0;
                text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
            }
            .content {
                background: rgba(255, 255, 255, 0.9);
                padding: 30px;
                border-radius: 15px;
                margin-bottom: 30px;
                box-shadow: 0 8px 32px rgba(0,0,0,0.1);
            }
            .social-platforms {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                gap: 20px;
                margin: 30px 0;
            }
            .platform-card {
                background: #fff;
                border-radius: 15px;
                padding: 25px;
                text-align: center;
                box-shadow: 0 8px 25px rgba(0,0,0,0.15);
                transition: all 0.3s ease;
                position: relative;
                overflow: hidden;
            }
            .platform-card::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                height: 4px;
                background: linear-gradient(90deg, #667eea, #764ba2);
            }
            .platform-card:hover {
                transform: translateY(-8px);
                box-shadow: 0 15px 35px rgba(0,0,0,0.2);
            }
            .platform-icon {
                font-size: 4em;
                margin-bottom: 15px;
                display: block;
            }
            .facebook { color: #1877f2; }
            .instagram { background: linear-gradient(45deg, #f09433 0%,#e6683c 25%,#dc2743 50%,#cc2366 75%,#bc1888 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
            .youtube { color: #ff0000; }
            .twitter { color: #1da1f2; }
            .linkedin { color: #0077b5; }
            .tiktok { background: linear-gradient(45deg, #000000, #ffffff); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
            .kwai { color: #ff6b35; }
            .shopee { color: #ee4d2d; }
            .mercado-livre { color: #ffe600; background: #ffe600; -webkit-background-clip: text; -webkit-text-fill-color: #000; }
            .meta { color: #4267B2; }
            .login-btn {
                display: inline-block;
                padding: 12px 24px;
                background: linear-gradient(45deg, #667eea, #764ba2);
                color: white;
                text-decoration: none;
                border-radius: 25px;
                margin-top: 10px;
                transition: background 0.3s;
            }
            .login-btn:hover {
                background: linear-gradient(45deg, #764ba2, #667eea);
            }
            .register-form {
                background: #f8f9fa;
                padding: 30px;
                border-radius: 10px;
                margin-top: 30px;
            }
            input {
                width: 100%;
                padding: 12px;
                margin: 8px 0;
                border: 1px solid #ddd;
                border-radius: 5px;
                box-sizing: border-box;
            }
            button {
                width: 100%;
                padding: 12px;
                background: linear-gradient(45deg, #28a745, #20c997);
                color: white;
                border: none;
                border-radius: 5px;
                cursor: pointer;
                font-size: 16px;
                margin-top: 10px;
            }
            button:hover {
                background: linear-gradient(45deg, #20c997, #28a745);
            }
            .edit-link {
                display: inline-block;
                margin-top: 20px;
                padding: 10px 20px;
                background: #007bff;
                color: white;
                text-decoration: none;
                border-radius: 5px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <header>
                <h1>{{ title }}</h1>
            </header>
            <div class="content">
                <p>{{ content }}</p>
                {% if promo_link %}
                <div style="text-align: center; margin-top: 20px;">
                    <a href="{{ promo_link }}" class="login-btn" style="font-size: 1.5em; padding: 15px 30px;" target="_blank" rel="noopener noreferrer">Clique Aqui para Promoção Especial!</a>
                </div>
                {% endif %}
            </div>
            <div class="social-platforms">
                <div class="platform-card">
                    <div class="platform-icon meta">📘</div>
                    <h3>Meta (Facebook)</h3>
                    <p>Conecte-se e promova seu conteúdo no Facebook e Meta.</p>
                    <a href="{{ meta_link or 'https://www.facebook.com' }}" class="login-btn" target="_blank" rel="noopener noreferrer">Acessar Meta</a>
                </div>
                <div class="platform-card">
                    <div class="platform-icon instagram">📷</div>
                    <h3>Instagram</h3>
                    <p>Compartilhe suas histórias visuais no Instagram.</p>
                    <a href="{{ instagram_link or 'https://www.instagram.com' }}" class="login-btn" target="_blank" rel="noopener noreferrer">Acessar Instagram</a>
                </div>
                <div class="platform-card">
                    <div class="platform-icon youtube">🎥</div>
                    <h3>YouTube</h3>
                    <p>Crie e compartilhe vídeos incríveis no YouTube.</p>
                    <a href="{{ youtube_link or 'https://www.youtube.com' }}" class="login-btn" target="_blank" rel="noopener noreferrer">Acessar YouTube</a>
                </div>
                <div class="platform-card">
                    <div class="platform-icon twitter">🐦</div>
                    <h3>Twitter (X)</h3>
                    <p>Compartilhe ideias e conecte-se globalmente no Twitter.</p>
                    <a href="{{ twitter_link or 'https://twitter.com' }}" class="login-btn" target="_blank" rel="noopener noreferrer">Acessar Twitter</a>
                </div>
                <div class="platform-card">
                    <div class="platform-icon linkedin">💼</div>
                    <h3>LinkedIn</h3>
                    <p>Construa sua rede profissional no LinkedIn.</p>
                    <a href="{{ linkedin_link or 'https://www.linkedin.com' }}" class="login-btn" target="_blank" rel="noopener noreferrer">Acessar LinkedIn</a>
                </div>
                <div class="platform-card">
                    <div class="platform-icon tiktok">🎵</div>
                    <h3>TikTok</h3>
                    <p>Crie conteúdo viral e dance no TikTok.</p>
                    <a href="{{ tiktok_link or 'https://www.tiktok.com' }}" class="login-btn" target="_blank" rel="noopener noreferrer">Acessar TikTok</a>
                </div>
                <div class="platform-card">
                    <div class="platform-icon kwai">🎭</div>
                    <h3>Kwai</h3>
                    <p>Compartilhe momentos especiais no Kwai.</p>
                    <a href="{{ kwai_link or 'https://www.kwai.com' }}" class="login-btn" target="_blank" rel="noopener noreferrer">Acessar Kwai</a>
                </div>
                <div class="platform-card">
                    <div class="platform-icon shopee">🛒</div>
                    <h3>Shopee</h3>
                    <p>Venda seus produtos na Shopee.</p>
                    <a href="{{ shopee_link or 'https://shopee.com.br' }}" class="login-btn" target="_blank" rel="noopener noreferrer">Acessar Shopee</a>
                </div>
                <div class="platform-card">
                    <div class="platform-icon mercado-livre">📦</div>
                    <h3>Mercado Livre</h3>
                    <p>Compre e venda no maior marketplace da América Latina.</p>
                    <a href="{{ mercado_livre_link or 'https://www.mercadolivre.com.br' }}" class="login-btn" target="_blank" rel="noopener noreferrer">Acessar Mercado Livre</a>
                </div>
            </div>
            <div class="register-form">
                <h2>Cadastre-se no InvictusDNS</h2>
                <form method="post" action="/register">
                    <input type="text" name="username" placeholder="Nome de usuário" required>
                    <input type="email" name="email" placeholder="Email" required>
                    <input type="password" name="password" placeholder="Senha" required>
                    <button type="submit">Cadastrar</button>
                </form>
            </div>
            <a href="/edit" class="edit-link">Editar Conteúdo</a>
        </div>
    </body>
    </html>
    """
    return render_template_string(html, title=title, content=content)

@app.route('/edit', methods=['GET', 'POST'])
def edit():
    if request.method == 'POST':
        title = request.form['title']
        content = request.form['content']
        conn = sqlite3.connect(MARKETING_DB)
        c = conn.cursor()
        c.execute("""UPDATE marketing_content SET title = ?, content = ?, facebook_link = ?, instagram_link = ?, promo_link = ?,
                        youtube_link = ?, twitter_link = ?, linkedin_link = ?, tiktok_link = ?,
                        kwai_link = ?, shopee_link = ?, mercado_livre_link = ?, meta_link = ? WHERE id = 1""",
                  (title, content,
                   request.form.get('facebook_link', ''), request.form.get('instagram_link', ''), request.form.get('promo_link', ''),
                   request.form.get('youtube_link', ''), request.form.get('twitter_link', ''), request.form.get('linkedin_link', ''),
                   request.form.get('tiktok_link', ''), request.form.get('kwai_link', ''), request.form.get('shopee_link', ''),
                   request.form.get('mercado_livre_link', ''), request.form.get('meta_link', '')))
        conn.commit()
        conn.close()
        return redirect(url_for('marketing'))

    conn = sqlite3.connect(MARKETING_DB)
    c = conn.cursor()
    c.execute("""SELECT title, content, facebook_link, instagram_link, promo_link,
                        youtube_link, twitter_link, linkedin_link, tiktok_link,
                        kwai_link, shopee_link, mercado_livre_link, meta_link
                 FROM marketing_content LIMIT 1""")
    row = c.fetchone()
    conn.close()
    if row:
        title, content, facebook_link, instagram_link, promo_link, youtube_link, twitter_link, linkedin_link, tiktok_link, kwai_link, shopee_link, mercado_livre_link, meta_link = row
    else:
        title, content, facebook_link, instagram_link, promo_link, youtube_link, twitter_link, linkedin_link, tiktok_link, kwai_link, shopee_link, mercado_livre_link, meta_link = ('', '', '', '', '', '', '', '', '', '', '', '', '')

    html = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Editar Marketing</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            form { margin-top: 20px; }
            input, textarea { width: 100%; padding: 8px; margin: 5px 0; }
            button { padding: 10px 20px; background: #28a745; color: white; border: none; cursor: pointer; }
        </style>
    </head>
    <body>
        <h1>Editar Conteúdo de Marketing</h1>
        <form method="post">
            <label>Título:</label><br>
            <input type="text" name="title" value="{{ title }}"><br>
            <label>Conteúdo:</label><br>
            <textarea name="content" rows="10">{{ content }}</textarea><br>
            <label>Link do Meta (Facebook):</label><br>
            <input type="url" name="meta_link" value="{{ meta_link }}"><br>
            <label>Link do Instagram:</label><br>
            <input type="url" name="instagram_link" value="{{ instagram_link }}"><br>
            <label>Link do YouTube:</label><br>
            <input type="url" name="youtube_link" value="{{ youtube_link }}"><br>
            <label>Link do Twitter:</label><br>
            <input type="url" name="twitter_link" value="{{ twitter_link }}"><br>
            <label>Link do LinkedIn:</label><br>
            <input type="url" name="linkedin_link" value="{{ linkedin_link }}"><br>
            <label>Link do TikTok:</label><br>
            <input type="url" name="tiktok_link" value="{{ tiktok_link }}"><br>
            <label>Link do Kwai:</label><br>
            <input type="url" name="kwai_link" value="{{ kwai_link }}"><br>
            <label>Link da Shopee:</label><br>
            <input type="url" name="shopee_link" value="{{ shopee_link }}"><br>
            <label>Link do Mercado Livre:</label><br>
            <input type="url" name="mercado_livre_link" value="{{ mercado_livre_link }}"><br>
            <label>Link de Promoção:</label><br>
            <input type="url" name="promo_link" value="{{ promo_link }}"><br>
            <button type="submit">Salvar</button>
        </form>
        <a href="/">Voltar</a>
    </body>
    </html>
    """
    return render_template_string(html, title=title, content=content)

@app.route('/register', methods=['POST'])
def register():
    init_users_db()
    username = request.form['username']
    email = request.form['email']
    password = request.form['password']
    password_hash = generate_password_hash(password)
    created_at = time.strftime('%Y-%m-%d %H:%M:%S')
    try:
        conn = sqlite3.connect(USERS_DB)
        c = conn.cursor()
        c.execute("INSERT INTO users (username, password_hash, email, created_at) VALUES (?, ?, ?, ?)",
                  (username, password_hash, email, created_at))
        conn.commit()
        conn.close()
        # Simular envio de email
        print(f"Email enviado para {email} com credenciais.")
        return "Cadastro realizado! Verifique seu email."
    except sqlite3.IntegrityError:
        return "Usuário ou email já existe."

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3001, debug=False)

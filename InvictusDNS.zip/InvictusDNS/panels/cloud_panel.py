from flask import Flask, render_template_string, request, redirect, url_for, session, flash, send_from_directory
import sqlite3
import os
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from cryptography.fernet import Fernet
import base64
from functools import wraps
import zipfile
import io
import hashlib
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'supersecretkey'

DESKTOP_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data')
DB_FILE = os.path.join(DESKTOP_DIR, 'users', 'cloud_data.db')
USER_DATA_DIR = os.path.join(DESKTOP_DIR, 'users')
CONFIG_FILE = os.path.join(USER_DATA_DIR, 'cloud_config.json')

# Função para gerar chave de criptografia baseada na senha do usuário
def get_user_cipher(password):
    key = hashlib.sha256(password.encode()).digest()
    return Fernet(base64.urlsafe_b64encode(key))

# Criar diretório se não existir
os.makedirs(USER_DATA_DIR, exist_ok=True)

def init_db():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY,
                    username TEXT UNIQUE,
                    password_hash TEXT,
                    role TEXT DEFAULT 'user',
                    ips TEXT
                )''')
    c.execute('''CREATE TABLE IF NOT EXISTS uploads (
                    id INTEGER PRIMARY KEY,
                    user_id INTEGER,
                    filename TEXT,
                    upload_time TEXT,
                    FOREIGN KEY (user_id) REFERENCES users (id)
                )''')
    # Insert admin if not exists
    c.execute("SELECT COUNT(*) FROM users WHERE username = 'admin'")
    if c.fetchone()[0] == 0:
        c.execute("INSERT INTO users (username, password_hash, role, ips) VALUES (?, ?, ?, ?)",
                  ('admin', generate_password_hash('senha123'), 'admin', ''))
    conn.commit()
    conn.close()

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        init_db()
        conn = sqlite3.connect(DB_FILE)
        c = conn.cursor()
        c.execute("SELECT id, password_hash FROM users WHERE username = ?", (username,))
        user = c.fetchone()
        conn.close()
        if user and check_password_hash(user[1], password):
            session['user_id'] = user[0]
            return redirect(url_for('cloud_panel'))
        flash('Credenciais inválidas')
    html = """
    <!DOCTYPE html>
    <html>
    <head><title>Login Painel Nuvem</title></head>
    <body>
        <h1>Login Painel de Nuvem</h1>
        <form method="post">
            <input type="text" name="username" placeholder="Usuário" required><br>
            <input type="password" name="password" placeholder="Senha" required><br>
            <button type="submit">Login</button>
        </form>
        <p>Não tem conta? <a href="/register">Registrar</a></p>
    </body>
    </html>
    """
    return render_template_string(html)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        init_db()
        conn = sqlite3.connect(DB_FILE)
        c = conn.cursor()
        try:
            c.execute("INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)",
                      (username, generate_password_hash(password), 'user'))
            conn.commit()
            flash('Conta criada com sucesso! Faça login.')
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash('Usuário já existe.')
        finally:
            conn.close()
    html = """
    <!DOCTYPE html>
    <html>
    <head><title>Registrar Painel Nuvem</title></head>
    <body>
        <h1>Registrar no Painel de Nuvem</h1>
        <form method="post">
            <input type="text" name="username" placeholder="Usuário" required><br>
            <input type="password" name="password" placeholder="Senha" required><br>
            <button type="submit">Registrar</button>
        </form>
        <p>Já tem conta? <a href="/">Login</a></p>
    </body>
    </html>
    """
    return render_template_string(html)

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    return redirect(url_for('login'))

@app.route('/cloud_panel')
@login_required
def cloud_panel():
    tab = request.args.get('tab', 'files')
    user_data_dir = os.path.join(USER_DATA_DIR, str(session['user_id']))
    os.makedirs(user_data_dir, exist_ok=True)
    files = []
    total_size = 0
    if os.path.exists(user_data_dir):
        for filename in os.listdir(user_data_dir):
            if filename.endswith('.zip.enc'):
                original_name = filename[:-8]  # Remove .zip.enc
                filepath = os.path.join(user_data_dir, filename)
                if os.path.isfile(filepath):
                    size = os.path.getsize(filepath)
                    total_size += size
                    upload_time = datetime.fromtimestamp(os.path.getmtime(filepath)).strftime('%Y-%m-%d %H:%M:%S')
                    files.append({'name': original_name, 'size': size, 'upload_time': upload_time})
    # Check quota
    import json
    with open(CONFIG_FILE, 'r') as f:
        config = json.load(f)
    quota = config.get('default_quota', 1073741824)  # 1GB default
    quota_used = total_size
    admin_link = ''
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("SELECT role FROM users WHERE id = ?", (session['user_id'],))
    role = c.fetchone()
    conn.close()
    if role and role[0] == 'admin':
        admin_link = '<p><a href="/admin">👑 Painel Admin</a></p>'

    files_html = "".join(f"""
    <div class="file-item">
        <div class="file-info">
            <div class="file-name"><i class="fas fa-file"></i> {f['name']}</div>
            <div class="file-meta">Tamanho: {f['size'] / 1024:.1f} KB | Enviado: {f['upload_time']}</div>
        </div>
        <div class="file-actions">
            <a href="/download/{f['name']}" class="btn btn-primary btn-sm">
                <i class="fas fa-download"></i> Download
            </a>
            <form method="post" action="/delete/{f['name']}" style="display:inline;">
                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Tem certeza que deseja deletar este arquivo?')">
                    <i class="fas fa-trash"></i> Deletar
                </button>
            </form>
        </div>
    </div>
    """ for f in files)

    html = f"""
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>InvictusDNS - Painel de Nuvem</title>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
        <style>
            * {{ margin: 0; padding: 0; box-sizing: border-box; }}
            body {{
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                color: #333;
                overflow-x: hidden;
            }}
            .navbar {{
                background: rgba(255, 255, 255, 0.95);
                padding: 1rem 2rem;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                position: sticky;
                top: 0;
                z-index: 1000;
            }}
            .navbar h1 {{
                color: #667eea;
                display: inline;
                font-size: 1.5em;
            }}
            .navbar .user-menu {{
                float: right;
                margin-top: 5px;
            }}
            .container {{
                max-width: 1200px;
                margin: 0 auto;
                padding: 20px;
            }}
            .welcome {{
                text-align: center;
                margin-bottom: 30px;
                color: white;
            }}
            .welcome h1 {{
                font-size: 2.5em;
                margin-bottom: 10px;
                text-shadow: 0 0 10px rgba(0,0,0,0.3);
            }}
            .welcome p {{
                font-size: 1.2em;
                opacity: 0.9;
            }}
            .stats-grid {{
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                gap: 20px;
                margin-bottom: 30px;
            }}
            .stat-card {{
                background: rgba(255, 255, 255, 0.95);
                padding: 25px;
                border-radius: 15px;
                text-align: center;
                box-shadow: 0 8px 25px rgba(0,0,0,0.15);
                transition: transform 0.3s;
            }}
            .stat-card:hover {{ transform: translateY(-5px); }}
            .stat-icon {{
                font-size: 3em;
                color: #667eea;
                margin-bottom: 15px;
            }}
            .stat-number {{
                font-size: 2em;
                font-weight: bold;
                color: #667eea;
                margin-bottom: 10px;
            }}
            .stat-label {{
                color: #666;
                font-size: 1.1em;
            }}
            .content-grid {{
                display: grid;
                grid-template-columns: 2fr 1fr;
                gap: 30px;
            }}
            .main-content, .sidebar {{
                background: rgba(255, 255, 255, 0.95);
                border-radius: 15px;
                padding: 25px;
                box-shadow: 0 8px 25px rgba(0,0,0,0.15);
            }}
            .section-title {{
                color: #667eea;
                margin-bottom: 20px;
                padding-bottom: 10px;
                border-bottom: 2px solid #667eea;
                font-size: 1.5em;
            }}
            .btn {{
                padding: 12px 24px;
                border: none;
                border-radius: 8px;
                cursor: pointer;
                font-size: 14px;
                text-decoration: none;
                display: inline-block;
                transition: all 0.3s;
                margin: 5px;
            }}
            .btn-sm {{
                padding: 8px 16px;
                font-size: 12px;
            }}
            .btn-primary {{ background: #667eea; color: white; }}
            .btn-primary:hover {{ background: #5a67d8; }}
            .btn-success {{ background: #48bb78; color: white; }}
            .btn-success:hover {{ background: #38a169; }}
            .btn-danger {{ background: #e53e3e; color: white; }}
            .btn-danger:hover {{ background: #c53030; }}
            .upload-section {{
                background: #f8f9fa;
                padding: 20px;
                border-radius: 10px;
                margin-bottom: 30px;
                border: 2px dashed #667eea;
            }}
            .upload-section h3 {{
                color: #667eea;
                margin-bottom: 15px;
            }}
            .file-input {{
                display: block;
                margin-bottom: 15px;
                padding: 10px;
                border: 2px solid #e2e8f0;
                border-radius: 8px;
                width: 100%;
                box-sizing: border-box;
            }}
            .files-list {{
                margin-top: 20px;
            }}
            .file-item {{
                background: #f8f9fa;
                padding: 15px;
                margin: 10px 0;
                border-radius: 10px;
                display: flex;
                justify-content: space-between;
                align-items: center;
                box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            }}
            .file-info {{
                flex-grow: 1;
            }}
            .file-name {{
                font-weight: bold;
                color: #333;
                margin-bottom: 5px;
            }}
            .file-meta {{
                color: #666;
                font-size: 0.9em;
            }}
            .file-actions {{
                display: flex;
                gap: 10px;
            }}
            .quota-bar {{
                background: #e2e8f0;
                border-radius: 10px;
                height: 20px;
                margin: 10px 0;
                overflow: hidden;
            }}
            .quota-fill {{
                height: 100%;
                background: linear-gradient(45deg, #667eea, #764ba2);
                transition: width 0.3s;
            }}
            .quota-text {{
                text-align: center;
                font-weight: bold;
                color: #667eea;
                margin-bottom: 5px;
            }}
            .settings-section {{
                background: #f8f9fa;
                padding: 20px;
                border-radius: 10px;
            }}
            .settings-section h3 {{
                color: #667eea;
                margin-bottom: 15px;
            }}
            .form-group {{
                margin-bottom: 15px;
            }}
            .form-group label {{
                display: block;
                margin-bottom: 5px;
                font-weight: 500;
                color: #555;
            }}
            .form-group input {{
                width: 100%;
                padding: 10px;
                border: 2px solid #e2e8f0;
                border-radius: 8px;
                font-size: 14px;
            }}
            .form-group input:focus {{
                outline: none;
                border-color: #667eea;
            }}
            .alert {{
                padding: 15px;
                border-radius: 8px;
                margin: 15px 0;
            }}
            .alert-success {{
                background: rgba(72, 187, 120, 0.1);
                border: 1px solid #48bb78;
                color: #22543d;
            }}
            .alert-error {{
                background: rgba(229, 62, 62, 0.1);
                border: 1px solid #e53e3e;
                color: #742a2a;
            }}
            @media (max-width: 768px) {{
                .content-grid {{ grid-template-columns: 1fr; }}
                .stats-grid {{ grid-template-columns: repeat(2, 1fr); }}
                .file-item {{ flex-direction: column; align-items: flex-start; }}
                .file-actions {{ margin-top: 10px; }}
            }}
        </style>
    </head>
    <body>
        <div class="navbar">
            <h1><i class="fas fa-cloud"></i> InvictusCloud</h1>
            <div class="user-menu">
                <a href="/logout" class="btn btn-primary">Sair</a>
                {admin_link}
            </div>
        </div>

        <div class="container">
            <div class="welcome">
                <h1>☁️ Bem-vindo ao InvictusCloud</h1>
                <p>Seu espaço seguro para backup e armazenamento de arquivos</p>
            </div>

            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-folder"></i></div>
                    <div class="stat-number">{len(files)}</div>
                    <div class="stat-label">Arquivos</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-hdd"></i></div>
                    <div class="stat-number">{total_size / (1024*1024):.1f} MB</div>
                    <div class="stat-label">Espaço Usado</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-chart-pie"></i></div>
                    <div class="stat-number">{(total_size / quota * 100):.1f}%</div>
                    <div class="stat-label">Uso da Cota</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-shield-alt"></i></div>
                    <div class="stat-number"><i class="fas fa-lock"></i></div>
                    <div class="stat-label">Criptografado</div>
                </div>
            </div>

            <div class="content-grid">
                <div class="main-content">
                    <h2 class="section-title"><i class="fas fa-upload"></i> Gerenciar Arquivos</h2>

                    <div class="upload-section">
                        <h3>Fazer Backup de Arquivos</h3>
                        <form method="post" enctype="multipart/form-data" action="/upload">
                            <input type="file" name="files" multiple class="file-input" required>
                            <button type="submit" class="btn btn-success">
                                <i class="fas fa-cloud-upload-alt"></i> Fazer Backup
                            </button>
                        </form>
                        <div class="quota-text">
                            Espaço usado: {total_size / (1024*1024):.1f} MB / {quota / (1024*1024):.1f} MB ({(total_size / quota * 100):.1f}%)
                        </div>
                        <div class="quota-bar">
                            <div class="quota-fill" style="width: {(total_size / quota * 100):.1f}%"></div>
                        </div>
                    </div>

                    <div class="files-list">
                        <h3>Seus Arquivos ({len(files)})</h3>
                        {files_html if files else '<p class="alert alert-success">Nenhum arquivo ainda. Faça upload do seu primeiro backup!</p>'}
                    </div>
                </div>

                <div class="sidebar">
                    <h2 class="section-title"><i class="fas fa-cog"></i> Configurações</h2>

                    <div class="settings-section">
                        <h3>Alterar Senha</h3>
                        <form method="post" action="/change_password">
                            <div class="form-group">
                                <label for="new_password">Nova Senha:</label>
                                <input type="password" id="new_password" name="new_password" required>
                            </div>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-key"></i> Alterar Senha
                            </button>
                        </form>
                    </div>

                    <div class="settings-section" style="margin-top: 20px;">
                        <h3>Informações da Conta</h3>
                        <p><strong>Usuário:</strong> {session.get('username', 'N/A')}</p>
                        <p><strong>Cota Total:</strong> {quota / (1024*1024):.1f} MB</p>
                        <p><strong>Arquivos Máx:</strong> Ilimitado</p>
                    </div>
                </div>
            </div>
        </div>
    </body>
    </html>
    """
    return render_template_string(html)

@app.route('/upload', methods=['POST'])
@login_required
def upload():
    if 'files' not in request.files:
        flash('Nenhum arquivo selecionado')
        return redirect(url_for('cloud_panel'))
    files = request.files.getlist('files')
    user_data_dir = os.path.join(USER_DATA_DIR, str(session['user_id']))
    os.makedirs(user_data_dir, exist_ok=True)
    # Get user password for encryption
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("SELECT password_hash FROM users WHERE id = ?", (session['user_id'],))
    password_hash = c.fetchone()[0]
    # Since we have hash, we need plain password. Wait, we need to store plain password? No, for encryption, we need the password.
    # Problem: password is hashed, but for encryption key, we need the plain password.
    # To fix, we need to get the password from session or something. But session has user_id.
    # Perhaps store password in session on login.
    # For now, assume we have it, but to make it work, let's modify login to store password in session.
    # Wait, better: since password is hashed, but for key, we can use the hash as password.
    password = password_hash  # Use hash as key base
    cipher = get_user_cipher(password)
    # Calculate current size
    total_size = sum(os.path.getsize(os.path.join(user_data_dir, f)) for f in os.listdir(user_data_dir) if os.path.isfile(os.path.join(user_data_dir, f)))
    import json
    with open(CONFIG_FILE, 'r') as f:
        config = json.load(f)
    quota = config.get('default_quota', 1073741824)
    for file in files:
        if file.filename == '':
            continue
        filename = secure_filename(file.filename)
        # Compress to zip
        zip_buffer = io.BytesIO()
        with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
            zip_file.writestr(filename, file.read())
        zip_data = zip_buffer.getvalue()
        if total_size + len(zip_data) > quota:
            flash(f'Upload cancelado: quota excedida para {filename}')
            break
        encrypted_data = cipher.encrypt(zip_data)
        filepath = os.path.join(user_data_dir, filename + '.zip.enc')
        with open(filepath, 'wb') as f:
            f.write(encrypted_data)
        total_size += len(zip_data)
        # Log upload
        c.execute("INSERT INTO uploads (user_id, filename, upload_time) VALUES (?, ?, ?)",
                  (session['user_id'], filename, datetime.now().isoformat()))
        flash(f'Arquivo {filename} enviado e comprimido com sucesso')
    conn.commit()
    conn.close()
    return redirect(url_for('cloud_panel'))

@app.route('/download/<filename>')
@login_required
def download(filename):
    user_data_dir = os.path.join(USER_DATA_DIR, str(session['user_id']))
    filepath = os.path.join(user_data_dir, filename + '.zip.enc')
    if not os.path.exists(filepath):
        flash('Arquivo não encontrado')
        return redirect(url_for('cloud_panel'))
    # Get password
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("SELECT password_hash FROM users WHERE id = ?", (session['user_id'],))
    password_hash = c.fetchone()[0]
    password = password_hash
    cipher = get_user_cipher(password)
    conn.close()
    with open(filepath, 'rb') as f:
        encrypted_data = f.read()
    decrypted_data = cipher.decrypt(encrypted_data)
    # Unzip
    zip_buffer = io.BytesIO(decrypted_data)
    with zipfile.ZipFile(zip_buffer, 'r') as zip_file:
        file_list = zip_file.namelist()
        if file_list:
            original_data = zip_file.read(file_list[0])
    # Send original file
    from flask import send_file
    return send_file(io.BytesIO(original_data), as_attachment=True, download_name=filename)

@app.route('/delete/<filename>', methods=['POST'])
@login_required
def delete(filename):
    user_data_dir = os.path.join(USER_DATA_DIR, str(session['user_id']))
    filepath = os.path.join(user_data_dir, filename + '.zip.enc')
    if os.path.exists(filepath):
        os.remove(filepath)
        flash(f'Arquivo {filename} deletado')
    else:
        flash('Arquivo não encontrado')
    return redirect(url_for('cloud_panel'))

@app.route('/change_password', methods=['POST'])
@login_required
def change_password():
    new_password = request.form['new_password']
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("UPDATE users SET password_hash = ? WHERE id = ?", (generate_password_hash(new_password), session['user_id']))
    conn.commit()
    conn.close()
    flash('Senha alterada com sucesso')
    return redirect(url_for('cloud_panel'))

@app.route('/admin')
@login_required
def admin():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("SELECT id, username, role FROM users WHERE id = ?", (session['user_id'],))
    user = c.fetchone()
    if not user or user[2] != 'admin':
        flash('Acesso negado')
        return redirect(url_for('cloud_panel'))
    # Get recent uploads
    c.execute("SELECT u.username, up.filename, up.upload_time FROM uploads up JOIN users u ON up.user_id = u.id ORDER BY up.upload_time DESC LIMIT 10")
    recent_uploads = c.fetchall()
    # Get all users and their data
    users_data = []
    total_storage = 0
    for user_dir in os.listdir(USER_DATA_DIR):
        if user_dir.isdigit():
            user_id = int(user_dir)
            user_path = os.path.join(USER_DATA_DIR, user_dir)
            user_size = sum(os.path.getsize(os.path.join(user_path, f)) for f in os.listdir(user_path) if os.path.isfile(os.path.join(user_path, f)))
            total_storage += user_size
            c.execute("SELECT username FROM users WHERE id = ?", (user_id,))
            username = c.fetchone()[0]
            files = [{'name': f[:-8] if f.endswith('.zip.enc') else f, 'size': os.path.getsize(os.path.join(user_path, f))} for f in os.listdir(user_path) if os.path.isfile(os.path.join(user_path, f))]
            users_data.append({'id': user_id, 'username': username, 'size': user_size, 'files': files})
    conn.close()
    users_html = ""
    for u in users_data:
        file_html = ''.join(f"<div class='file'>{f['name']} ({f['size']} bytes)</div>" for f in u['files'])
        users_html += f"<div class='user'><h3>{u['username']} (ID: {u['id']}) - {u['size']} bytes</h3><div>{file_html}</div></div>"
    recent_html = "".join(f"<div class='upload'>{u[0]} - {u[1]} em {u[2]}</div>" for u in recent_uploads)
    html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Painel Admin Nuvem</title>
        <style>
            body {{ background: linear-gradient(to right, #ff7e5f 0%, #feb47b 100%); color: white; font-family: Arial; }}
            .container {{ max-width: 1200px; margin: 0 auto; padding: 20px; }}
            h1 {{ text-align: center; }}
            .user {{ background: rgba(255,255,255,0.1); padding: 10px; margin: 10px 0; border-radius: 5px; }}
            .file {{ margin-left: 20px; }}
            .upload {{ background: rgba(255,255,255,0.1); padding: 5px; margin: 5px 0; border-radius: 5px; }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>👑 Painel Admin da Nuvem</h1>
            <h2>Total de Armazenamento: {total_storage} bytes</h2>
            <h2>Uploads Recentes:</h2>
            {recent_html}
            <h2>Usuários:</h2>
            {users_html}
            <a href="/cloud_panel">⬅️ Voltar ao Painel</a>
        </div>
    </body>
    </html>
    """
    return render_template_string(html)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3003, debug=False)

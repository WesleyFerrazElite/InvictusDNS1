from flask import Flask, render_template_string, request, redirect, url_for, session, flash
import sqlite3
import os
import shutil
from datetime import datetime
from functools import wraps
import zipfile
import io

app = Flask(__name__)
app.secret_key = 'supersecretkey'

DESKTOP_DIR = os.path.expanduser('~/Desktop')
DB_FILE = os.path.join(DESKTOP_DIR, 'InvictusDNS_Data', 'dados', 'dns_logs.db')
LOG_DIR = os.path.join(DESKTOP_DIR, 'InvictusDNS_Data', 'logs')
DATA_BACKUP_DIR = os.path.join(DESKTOP_DIR, 'InvictusDNS_Data', 'data_backup')
USERS_DB_DIR = os.path.join(DESKTOP_DIR, 'InvictusDNS_Data', 'dados', 'users')

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

@app.route('/logs_manager')
@login_required
def logs_manager():
    # Get log files info
    log_files = []
    if os.path.exists(LOG_DIR):
        for file in os.listdir(LOG_DIR):
            file_path = os.path.join(LOG_DIR, file)
            if os.path.isfile(file_path):
                size = os.path.getsize(file_path)
                mtime = os.path.getmtime(file_path)
                log_files.append({
                    'name': file,
                    'size': f"{size / 1024:.1f} KB",
                    'modified': datetime.fromtimestamp(mtime).strftime('%Y-%m-%d %H:%M:%S'),
                    'path': file_path
                })

    # Get backup files info
    backup_files = []
    if os.path.exists(DATA_BACKUP_DIR):
        for file in os.listdir(DATA_BACKUP_DIR):
            file_path = os.path.join(DATA_BACKUP_DIR, file)
            if os.path.isfile(file_path):
                size = os.path.getsize(file_path)
                mtime = os.path.getmtime(file_path)
                backup_files.append({
                    'name': file,
                    'size': f"{size / 1024:.1f} KB",
                    'modified': datetime.fromtimestamp(mtime).strftime('%Y-%m-%d %H:%M:%S'),
                    'path': file_path
                })

    # Get database info
    db_size = 0
    if os.path.exists(DB_FILE):
        db_size = os.path.getsize(DB_FILE) / 1024 / 1024  # MB

    html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>InvictusDNS - Gerenciar Logs</title>
        <style>
            body {{ font-family: Arial, sans-serif; margin: 20px; background: #f4f7f9; color: #333; }}
            .container {{ max-width: 1200px; margin: 0 auto; }}
            h1 {{ color: #2c3e50; text-align: center; }}
            .section {{ background: white; padding: 20px; margin: 20px 0; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }}
            table {{ width: 100%; border-collapse: collapse; margin-top: 20px; }}
            th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
            th {{ background-color: #34495e; color: white; }}
            tr:nth-child(even) {{ background-color: #ecf0f1; }}
            .btn {{ padding: 8px 15px; background: #3498db; color: white; border: none; cursor: pointer; border-radius: 4px; margin: 2px; }}
            .btn-danger {{ background: #e74c3c; }}
            .btn-success {{ background: #27ae60; }}
            .file-list {{ margin-top: 10px; }}
            .file-item {{ background: #f8f9fa; padding: 10px; margin: 5px 0; border-radius: 5px; display: flex; justify-content: space-between; align-items: center; }}
            .stats {{ display: flex; justify-content: space-around; margin: 20px 0; }}
            .stat {{ background: #3498db; color: white; padding: 20px; border-radius: 8px; text-align: center; flex: 1; margin: 0 10px; }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🗂️ Gerenciador de Logs - InvictusDNS</h1>
            <a href="/dashboard">← Voltar ao Dashboard</a>

            <div class="stats">
                <div class="stat">
                    <h3>{len(log_files)}</h3>
                    <p>Arquivos de Log</p>
                </div>
                <div class="stat">
                    <h3>{len(backup_files)}</h3>
                    <p>Backups</p>
                </div>
                <div class="stat">
                    <h3>{db_size:.1f} MB</h3>
                    <p>Banco de Dados</p>
                </div>
            </div>

            <div class="section">
                <h2>🗃️ Arquivos de Log</h2>
                <div class="file-list">
                    {"".join(f'''
                    <div class="file-item">
                        <div>
                            <strong>{f['name']}</strong><br>
                            Tamanho: {f['size']} | Modificado: {f['modified']}
                        </div>
                        <div>
                            <button class="btn" onclick="viewFile('{f['name']}', 'log')">Ver</button>
                            <button class="btn btn-success" onclick="downloadFile('{f['name']}', 'log')">Download</button>
                            <button class="btn btn-danger" onclick="deleteFile('{f['name']}', 'log')">Deletar</button>
                        </div>
                    </div>''' for f in log_files)}
                </div>
                <button class="btn btn-success" onclick="backupLogs()">Fazer Backup de Todos os Logs</button>
            </div>

            <div class="section">
                <h2>💾 Arquivos de Backup</h2>
                <div class="file-list">
                    {"".join(f'''
                    <div class="file-item">
                        <div>
                            <strong>{f['name']}</strong><br>
                            Tamanho: {f['size']} | Modificado: {f['modified']}
                        </div>
                        <div>
                            <button class="btn" onclick="viewFile('{f['name']}', 'backup')">Ver</button>
                            <button class="btn btn-success" onclick="downloadFile('{f['name']}', 'backup')">Download</button>
                            <button class="btn btn-danger" onclick="deleteFile('{f['name']}', 'backup')">Deletar</button>
                        </div>
                    </div>''' for f in backup_files)}
                </div>
            </div>

            <div class="section">
                <h2>🗄️ Banco de Dados</h2>
                <p><strong>Arquivo:</strong> dns_logs.db</p>
                <p><strong>Tamanho:</strong> {db_size:.1f} MB</p>
                <button class="btn btn-success" onclick="backupDatabase()">Fazer Backup do Banco</button>
                <button class="btn btn-danger" onclick="clearOldLogs()">Limpar Logs Antigos (30+ dias)</button>
            </div>
        </div>

        <script>
            function viewFile(filename, type) {{
                window.open(`/logs_manager/view/${{type}}/${{filename}}`, '_blank');
            }}

            function downloadFile(filename, type) {{
                window.location.href = `/logs_manager/download/${{type}}/${{filename}}`;
            }}

            function deleteFile(filename, type) {{
                if (confirm(`Tem certeza que deseja deletar ${{filename}}?`)) {{
                    fetch(`/logs_manager/delete/${{type}}/${{filename}}`, {{
                        method: 'DELETE'
                    }}).then(() => location.reload());
                }}
            }}

            function backupLogs() {{
                fetch('/logs_manager/backup/logs', {{
                    method: 'POST'
                }}).then(() => location.reload());
            }}

            function backupDatabase() {{
                fetch('/logs_manager/backup/database', {{
                    method: 'POST'
                }}).then(() => location.reload());
            }}

            function clearOldLogs() {{
                if (confirm('Isso irá deletar logs com mais de 30 dias. Continuar?')) {{
                    fetch('/logs_manager/clear/old', {{
                        method: 'DELETE'
                    }}).then(() => location.reload());
                }}
            }}
        </script>
    </body>
    </html>
    """
    return html

@app.route('/logs_manager/view/<type>/<filename>')
@login_required
def view_file(type, filename):
    if type == 'log':
        file_path = os.path.join(LOG_DIR, filename)
    elif type == 'backup':
        file_path = os.path.join(DATA_BACKUP_DIR, filename)
    else:
        return "Tipo inválido", 400

    if not os.path.exists(file_path):
        return "Arquivo não encontrado", 404

    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
    except:
        return "Erro ao ler arquivo", 500

    html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Visualizar {filename}</title>
        <style>
            body {{ font-family: monospace; margin: 20px; background: #f4f7f9; }}
            pre {{ background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); white-space: pre-wrap; }}
        </style>
    </head>
    <body>
        <h1>{filename}</h1>
        <a href="/logs_manager">← Voltar</a>
        <pre>{content}</pre>
    </body>
    </html>
    """
    return html

@app.route('/logs_manager/download/<type>/<filename>')
@login_required
def download_file(type, filename):
    if type == 'log':
        file_path = os.path.join(LOG_DIR, filename)
    elif type == 'backup':
        file_path = os.path.join(DATA_BACKUP_DIR, filename)
    else:
        return "Tipo inválido", 400

    if not os.path.exists(file_path):
        return "Arquivo não encontrado", 404

    from flask import send_file
    return send_file(file_path, as_attachment=True)

@app.route('/logs_manager/delete/<type>/<filename>', methods=['DELETE'])
@login_required
def delete_file(type, filename):
    if type == 'log':
        file_path = os.path.join(LOG_DIR, filename)
    elif type == 'backup':
        file_path = os.path.join(DATA_BACKUP_DIR, filename)
    else:
        return "Tipo inválido", 400

    if not os.path.exists(file_path):
        return "Arquivo não encontrado", 404

    try:
        os.remove(file_path)
        return "Arquivo deletado", 200
    except:
        return "Erro ao deletar", 500

@app.route('/logs_manager/backup/logs', methods=['POST'])
@login_required
def backup_logs():
    if not os.path.exists(LOG_DIR):
        return "Diretório de logs não existe", 400

    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    backup_name = f"logs_backup_{timestamp}.zip"
    backup_path = os.path.join(DATA_BACKUP_DIR, backup_name)

    os.makedirs(DATA_BACKUP_DIR, exist_ok=True)

    with zipfile.ZipFile(backup_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(LOG_DIR):
            for file in files:
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, LOG_DIR)
                zipf.write(file_path, arcname)

    return "Backup criado", 200

@app.route('/logs_manager/backup/database', methods=['POST'])
@login_required
def backup_database():
    if not os.path.exists(DB_FILE):
        return "Banco não encontrado", 400

    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    backup_name = f"database_backup_{timestamp}.db"
    backup_path = os.path.join(DATA_BACKUP_DIR, backup_name)

    os.makedirs(DATA_BACKUP_DIR, exist_ok=True)
    shutil.copy2(DB_FILE, backup_path)

    return "Backup criado", 200

@app.route('/logs_manager/clear/old', methods=['DELETE'])
@login_required
def clear_old_logs():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()

    # Deletar logs DNS com mais de 30 dias
    thirty_days_ago = datetime.now().timestamp() - (30 * 24 * 60 * 60)
    c.execute("DELETE FROM dns_logs WHERE timestamp < datetime(?, 'unixepoch')", (thirty_days_ago,))

    # Deletar logs de tráfego com mais de 7 dias
    seven_days_ago = datetime.now().timestamp() - (7 * 24 * 60 * 60)
    c.execute("DELETE FROM traffic_logs WHERE timestamp < datetime(?, 'unixepoch')", (seven_days_ago,))

    # Deletar dados de uso com mais de 90 dias
    ninety_days_ago = datetime.now().timestamp() - (90 * 24 * 60 * 60)
    c.execute("DELETE FROM data_usage WHERE timestamp < datetime(?, 'unixepoch')", (ninety_days_ago,))

    conn.commit()
    conn.close()

    return "Logs antigos limpos", 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3004, debug=False)

#!/usr/bin/env python3
"""
InvictusDNS - IP Obfuscator Panel
Painel web para acompanhar e gerenciar IPs ofuscados.
Porta: 3004
"""

from flask import Flask, render_template_string, request, jsonify
import sys
import os

# Adicionar caminho para imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.ip_obfuscator import IPObfuscator, obfuscate_ip, deobfuscate_ip

app = Flask(__name__)

# Instância global do obfuscator
ip_obfuscator = IPObfuscator()

# Template HTML inline
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🌀 InvictusDNS - IP Obfuscator Panel</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            margin: 0;
            padding: 20px;
            min-height: 100vh;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }
        .header h1 {
            margin: 0;
            font-size: 2.5em;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        .header p {
            margin: 10px 0 0 0;
            opacity: 0.9;
            font-size: 1.1em;
        }
        .content {
            padding: 30px;
        }
        .section {
            margin-bottom: 40px;
            background: #f8f9fa;
            border-radius: 10px;
            padding: 25px;
            border-left: 5px solid #4facfe;
        }
        .section h2 {
            color: #333;
            margin-top: 0;
            font-size: 1.8em;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #555;
        }
        .form-group input {
            width: 100%;
            padding: 12px;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            transition: border-color 0.3s;
        }
        .form-group input:focus {
            outline: none;
            border-color: #4facfe;
            box-shadow: 0 0 0 3px rgba(79, 172, 254, 0.1);
        }
        .btn {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
            transition: transform 0.2s, box-shadow 0.2s;
            margin-right: 10px;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(79, 172, 254, 0.3);
        }
        .btn-secondary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .result {
            margin-top: 20px;
            padding: 15px;
            border-radius: 8px;
            background: #e8f4fd;
            border-left: 4px solid #4facfe;
            font-family: monospace;
            font-size: 16px;
            word-break: break-all;
        }
        .error {
            background: #fee;
            border-left-color: #f44336;
        }
        .ip-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        .ip-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            border: 1px solid #eee;
        }
        .ip-card h3 {
            margin-top: 0;
            color: #333;
            font-size: 1.2em;
        }
        .ip-original {
            color: #666;
            font-family: monospace;
        }
        .ip-obfuscated {
            color: #4facfe;
            font-family: monospace;
            font-size: 1.1em;
            margin: 10px 0;
        }
        .status {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: bold;
        }
        .status-active {
            background: #4caf50;
            color: white;
        }
        .footer {
            text-align: center;
            padding: 20px;
            background: #f8f9fa;
            color: #666;
            border-top: 1px solid #eee;
        }
        .stats {
            display: flex;
            justify-content: space-around;
            margin-top: 20px;
            text-align: center;
        }
        .stat {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            flex: 1;
            margin: 0 10px;
        }
        .stat h3 {
            margin: 0;
            color: #4facfe;
            font-size: 2em;
        }
        .stat p {
            margin: 5px 0 0 0;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🌀 IP Obfuscator Panel</h1>
            <p>Gerencie e acompanhe IPs ofuscados no InvictusDNS</p>
        </div>

        <div class="content">
            <div class="stats">
                <div class="stat">
                    <h3 id="total-ips">0</h3>
                    <p>IPs Processados</p>
                </div>
                <div class="stat">
                    <h3 id="active-service">✅</h3>
                    <p>Serviço Ativo</p>
                </div>
                <div class="stat">
                    <h3 id="privacy-level">100%</h3>
                    <p>Privacidade</p>
                </div>
            </div>

            <div class="section">
                <h2>🔄 Ofuscar IP</h2>
                <form id="obfuscate-form">
                    <div class="form-group">
                        <label for="ip-input">Digite um endereço IP:</label>
                        <input type="text" id="ip-input" placeholder="192.168.1.1" required>
                    </div>
                    <button type="submit" class="btn">Ofuscar IP</button>
                </form>
                <div id="obfuscate-result" class="result" style="display: none;"></div>
            </div>

            <div class="section">
                <h2>🔍 Desofuscar IP</h2>
                <form id="deobfuscate-form">
                    <div class="form-group">
                        <label for="symbol-input">Digite a representação ofuscada:</label>
                        <input type="text" id="symbol-input" placeholder="🌟🔥⚡💎✨🌀" required>
                    </div>
                    <button type="submit" class="btn btn-secondary">Desofuscar</button>
                </form>
                <div id="deobfuscate-result" class="result" style="display: none;"></div>
            </div>

            <div class="section">
                <h2>📋 Exemplos de IPs Ofuscados</h2>
                <div class="ip-list" id="examples-list">
                    <!-- Exemplos serão carregados via JavaScript -->
                </div>
            </div>
        </div>

        <div class="footer">
            <p>InvictusDNS - Protegendo sua privacidade com IA 🛡️✨🤖</p>
        </div>
    </div>

    <script>
        // Exemplos de IPs para demonstração
        const exampleIPs = [
            '192.168.1.1',
            '10.0.0.1',
            '172.16.0.1',
            '8.8.8.8',
            '1.1.1.1',
            '208.67.222.222'
        ];

        // Carregar exemplos
        function loadExamples() {
            const examplesList = document.getElementById('examples-list');
            examplesList.innerHTML = '';

            exampleIPs.forEach(ip => {
                fetch('/api/obfuscate', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ ip: ip })
                })
                .then(response => response.json())
                .then(data => {
                    const card = document.createElement('div');
                    card.className = 'ip-card';
                    card.innerHTML = `
                        <h3>IP Original</h3>
                        <div class="ip-original">${ip}</div>
                        <div class="ip-obfuscated">${data.obfuscated}</div>
                        <span class="status status-active">Ativo</span>
                    `;
                    examplesList.appendChild(card);
                });
            });
        }

        // Formulário de ofuscação
        document.getElementById('obfuscate-form').addEventListener('submit', function(e) {
            e.preventDefault();
            const ip = document.getElementById('ip-input').value;
            const resultDiv = document.getElementById('obfuscate-result');

            fetch('/api/obfuscate', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ ip: ip })
            })
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    resultDiv.className = 'result error';
                    resultDiv.textContent = 'Erro: ' + data.error;
                } else {
                    resultDiv.className = 'result';
                    resultDiv.innerHTML = `
                        <strong>IP Original:</strong> ${ip}<br>
                        <strong>IP Ofuscado:</strong> ${data.obfuscated}
                    `;
                }
                resultDiv.style.display = 'block';
            });
        });

        // Formulário de desofuscação
        document.getElementById('deobfuscate-form').addEventListener('submit', function(e) {
            e.preventDefault();
            const symbols = document.getElementById('symbol-input').value;
            const resultDiv = document.getElementById('deobfuscate-result');

            fetch('/api/deobfuscate', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ symbols: symbols })
            })
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    resultDiv.className = 'result error';
                    resultDiv.textContent = 'Erro: ' + data.error;
                } else {
                    resultDiv.className = 'result';
                    resultDiv.innerHTML = `
                        <strong>Representação Ofuscada:</strong> ${symbols}<br>
                        <strong>IP Original:</strong> ${data.ip}
                    `;
                }
                resultDiv.style.display = 'block';
            });
        });

        // Carregar exemplos ao carregar página
        loadExamples();

        // Atualizar estatísticas
        document.getElementById('total-ips').textContent = exampleIPs.length;
    </script>
</body>
</html>
"""

@app.route('/')
def index():
    return render_template_string(HTML_TEMPLATE)

@app.route('/api/obfuscate', methods=['POST'])
def api_obfuscate():
    try:
        data = request.get_json()
        ip = data.get('ip', '')

        if not ip:
            return jsonify({'error': 'IP não fornecido'})

        obfuscated = obfuscate_ip(ip)
        return jsonify({
            'ip': ip,
            'obfuscated': obfuscated
        })
    except Exception as e:
        return jsonify({'error': str(e)})

@app.route('/api/deobfuscate', methods=['POST'])
def api_deobfuscate():
    try:
        data = request.get_json()
        symbols = data.get('symbols', '')

        if not symbols:
            return jsonify({'error': 'Representação não fornecida'})

        ip = deobfuscate_ip(symbols)
        if ip is None:
            return jsonify({'error': 'Não foi possível desofuscar'})

        return jsonify({
            'symbols': symbols,
            'ip': ip
        })
    except Exception as e:
        return jsonify({'error': str(e)})

@app.route('/api/stats')
def api_stats():
    return jsonify({
        'total_processed': 0,  # Pode ser implementado para contar IPs processados
        'service_active': True,
        'privacy_level': 100
    })

if __name__ == '__main__':
    print("🌀 Iniciando IP Obfuscator Panel...")
    print("Acesse: http://localhost:3004")
    app.run(host='0.0.0.0', port=3004, debug=False)

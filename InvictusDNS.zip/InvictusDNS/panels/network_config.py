from flask import Flask, render_template_string, request, jsonify, session, redirect, url_for, flash
import subprocess
import os
import platform
import psutil
import json
import time
import threading
from functools import wraps
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
from datetime import datetime
import logging
import re
import ipaddress
import shutil

app = Flask(__name__)
app.secret_key = 'supersecretkey'

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

DB_FILE = 'data/dns_logs.db'
NETWORK_CONFIG_FILE = 'network_config.json'

# Network configuration
network_config = {
    'pppoe': {
        'enabled': False,
        'username': '',
        'password': '',
        'interface': 'eth0',
        'mtu': 1492,
        'auto_connect': True
    },
    'bridge': {
        'enabled': False,
        'name': 'br0',
        'interfaces': ['eth0', 'eth1'],
        'ip_address': '192.168.1.1',
        'netmask': '255.255.255.0',
        'gateway': '192.168.1.254'
    },
    'vlan': {
        'enabled': False,
        'interface': 'eth0',
        'vlans': [
            {'id': 10, 'name': 'vlan10', 'ip': '192.168.10.1/24'},
            {'id': 20, 'name': 'vlan20', 'ip': '192.168.20.1/24'}
        ]
    },
    'firewall': {
        'enabled': True,
        'default_policy': {
            'input': 'DROP',
            'output': 'ACCEPT',
            'forward': 'DROP'
        },
        'rules': [
            {'chain': 'INPUT', 'protocol': 'tcp', 'dport': '80', 'action': 'ACCEPT', 'comment': 'HTTP'},
            {'chain': 'INPUT', 'protocol': 'tcp', 'dport': '443', 'action': 'ACCEPT', 'comment': 'HTTPS'},
            {'chain': 'INPUT', 'protocol': 'tcp', 'dport': '53', 'action': 'ACCEPT', 'comment': 'DNS'},
            {'chain': 'INPUT', 'protocol': 'udp', 'dport': '53', 'action': 'ACCEPT', 'comment': 'DNS UDP'},
            {'chain': 'INPUT', 'protocol': 'tcp', 'dport': '22', 'action': 'ACCEPT', 'comment': 'SSH'},
            {'chain': 'INPUT', 'protocol': 'tcp', 'dport': '3000', 'action': 'ACCEPT', 'comment': 'Web Panel'},
            {'chain': 'INPUT', 'protocol': 'tcp', 'dport': '3002', 'action': 'ACCEPT', 'comment': 'AI Panel'},
            {'chain': 'INPUT', 'protocol': 'tcp', 'dport': '3003', 'action': 'ACCEPT', 'comment': 'Remote Access'}
        ]
    },
    'qos': {
        'enabled': False,
        'upload_speed': '100mbit',
        'download_speed': '100mbit',
        'classes': [
            {'name': 'high_priority', 'rate': '20mbit', 'ceil': '30mbit', 'priority': 1},
            {'name': 'normal', 'rate': '50mbit', 'ceil': '80mbit', 'priority': 2},
            {'name': 'low_priority', 'rate': '10mbit', 'ceil': '20mbit', 'priority': 3}
        ]
    },
    'dhcp': {
        'enabled': True,
        'interface': 'br0',
        'range_start': '192.168.1.100',
        'range_end': '192.168.1.200',
        'lease_time': '12h',
        'gateway': '192.168.1.1',
        'dns_servers': ['192.168.1.1', '8.8.8.8']
    },
    'routing': {
        'static_routes': [],
        'nat': {
            'enabled': True,
            'masquerade_interfaces': ['ppp0']
        }
    }
}

def init_db():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY,
                    username TEXT UNIQUE,
                    password_hash TEXT,
                    role TEXT DEFAULT 'user',
                    ips TEXT
                )''')
    # Insert admin if not exists
    c.execute("SELECT COUNT(*) FROM users WHERE username = 'admin'")
    if c.fetchone()[0] == 0:
        c.execute("INSERT INTO users (username, password_hash, role, ips) VALUES (?, ?, ?, ?)",
                  ('admin', generate_password_hash('senha123'), 'admin', ''))
    conn.commit()
    conn.close()

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

def load_network_config():
    global network_config
    try:
        if os.path.exists(NETWORK_CONFIG_FILE):
            with open(NETWORK_CONFIG_FILE, 'r') as f:
                network_config.update(json.load(f))
    except Exception as e:
        logging.error(f"Error loading network config: {e}")

def save_network_config():
    try:
        with open(NETWORK_CONFIG_FILE, 'w') as f:
            json.dump(network_config, f, indent=2)
    except Exception as e:
        logging.error(f"Error saving network config: {e}")

# Load config on startup
load_network_config()

def validate_ip(ip_str):
    """Validate IP address"""
    try:
        ipaddress.ip_address(ip_str)
        return True
    except ValueError:
        return False

def validate_network(ip_network_str):
    """Validate IP network (CIDR)"""
    try:
        ipaddress.ip_network(ip_network_str, strict=False)
        return True
    except ValueError:
        return False

def validate_interface(iface):
    """Validate network interface exists"""
    interfaces = get_network_interfaces()
    return iface in interfaces

def validate_pppoe_config(config):
    """Validate PPPoE configuration"""
    if not config.get('username') or not config.get('password'):
        raise ValueError("Usuário e senha PPPoE são obrigatórios")
    if not validate_interface(config.get('interface', '')):
        raise ValueError("Interface PPPoE inválida")
    if not isinstance(config.get('mtu', 1492), int) or not (576 <= config['mtu'] <= 1492):
        raise ValueError("MTU deve ser um inteiro entre 576 e 1492")

def validate_bridge_config(config):
    """Validate Bridge configuration"""
    if not config.get('name'):
        raise ValueError("Nome do bridge é obrigatório")
    if not validate_ip(config.get('ip_address', '')):
        raise ValueError("IP do bridge inválido")
    if not validate_ip(config.get('gateway', '')):
        raise ValueError("Gateway do bridge inválido")
    for iface in config.get('interfaces', []):
        if not validate_interface(iface):
            raise ValueError(f"Interface {iface} inválida para bridge")

def validate_vlan_config(config):
    """Validate VLAN configuration"""
    if not validate_interface(config.get('interface', '')):
        raise ValueError("Interface VLAN inválida")
    for vlan in config.get('vlans', []):
        if not isinstance(vlan.get('id'), int) or not (1 <= vlan['id'] <= 4094):
            raise ValueError(f"ID VLAN {vlan.get('id')} inválido")
        if not validate_network(vlan.get('ip', '')):
            raise ValueError(f"IP VLAN {vlan.get('ip')} inválido")

def validate_firewall_config(config):
    """Validate Firewall configuration"""
    policies = ['ACCEPT', 'DROP']
    for key in ['input', 'output', 'forward']:
        if config.get('default_policy', {}).get(key) not in policies:
            raise ValueError(f"Política {key} inválida")

def validate_dhcp_config(config):
    """Validate DHCP configuration"""
    if not validate_interface(config.get('interface', '')):
        raise ValueError("Interface DHCP inválida")
    if not validate_ip(config.get('range_start', '')) or not validate_ip(config.get('range_end', '')):
        raise ValueError("Range IP DHCP inválido")
    if not validate_ip(config.get('gateway', '')):
        raise ValueError("Gateway DHCP inválido")
    for dns in config.get('dns_servers', []):
        if not validate_ip(dns):
            raise ValueError(f"Servidor DNS {dns} inválido")

def validate_routing_config(config):
    """Validate Routing configuration"""
    for iface in config.get('nat', {}).get('masquerade_interfaces', []):
        if not validate_interface(iface):
            raise ValueError(f"Interface NAT {iface} inválida")

def backup_network_config():
    """Create backup of network config"""
    try:
        if os.path.exists(NETWORK_CONFIG_FILE):
            backup_file = f"{NETWORK_CONFIG_FILE}.backup.{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            shutil.copy2(NETWORK_CONFIG_FILE, backup_file)
            logging.info(f"Backup criado: {backup_file}")
            # Keep only last 5 backups
            backups = sorted([f for f in os.listdir('.') if f.startswith(NETWORK_CONFIG_FILE + '.backup.')])
            if len(backups) > 5:
                for old_backup in backups[:-5]:
                    os.remove(old_backup)
                    logging.info(f"Backup antigo removido: {old_backup}")
    except Exception as e:
        logging.error(f"Erro ao criar backup: {e}")

def run_command_with_retry(cmd, retries=3, delay=1):
    """Run subprocess command with retries"""
    for attempt in range(retries):
        try:
            result = subprocess.run(cmd, check=True, capture_output=True, text=True, timeout=30)
            return result
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as e:
            logging.warning(f"Tentativa {attempt + 1} falhou para comando {' '.join(cmd)}: {e}")
            if attempt < retries - 1:
                time.sleep(delay)
            else:
                raise e

def get_network_interfaces():
    """Get available network interfaces"""
    try:
        result = subprocess.run(['ip', 'link', 'show'], capture_output=True, text=True)
        interfaces = []
        for line in result.stdout.split('\n'):
            if ': ' in line and '<' in line:
                iface = line.split(': ')[1].split('@')[0].split(':')[0]
                if iface not in ['lo', 'docker0']:
                    interfaces.append(iface)
        return interfaces
    except:
        return ['eth0', 'eth1', 'wlan0']

def get_current_network_status():
    """Get current network status"""
    status = {}
    try:
        # PPPoE status
        result = subprocess.run(['ip', 'link', 'show', 'ppp0'], capture_output=True, text=True)
        status['pppoe_connected'] = 'ppp0' in result.stdout

        # Bridge status
        result = subprocess.run(['ip', 'link', 'show', 'br0'], capture_output=True, text=True)
        status['bridge_active'] = 'br0' in result.stdout

        # Firewall status
        result = subprocess.run(['iptables', '-L', 'INPUT'], capture_output=True, text=True)
        status['firewall_active'] = len(result.stdout.split('\n')) > 8

        # DHCP status
        result = subprocess.run(['systemctl', 'is-active', 'isc-dhcp-server'], capture_output=True, text=True)
        status['dhcp_active'] = 'active' in result.stdout

    except Exception as e:
        logging.error(f"Error getting network status: {e}")

    return status

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        init_db()
        conn = sqlite3.connect(DB_FILE, timeout=30, check_same_thread=False)
        c = conn.cursor()
        c.execute("SELECT id, password_hash FROM users WHERE username = ?", (username,))
        user = c.fetchone()
        conn.close()
        if user and check_password_hash(user[1], password):
            session['user_id'] = user[0]
            return redirect(url_for('network_panel'))
        flash('Credenciais inválidas')
    html = """
    <!DOCTYPE html>
    <html>
    <head><title>Login Painel de Rede</title></head>
    <body>
        <h1>Login Painel de Configuração de Rede</h1>
        <form method="post">
            <input type="text" name="username" placeholder="Usuário" required><br>
            <input type="password" name="password" placeholder="Senha" required><br>
            <button type="submit">Login</button>
        </form>
    </body>
    </html>
    """
    return html

@app.route('/api/network_status')
@login_required
def api_network_status():
    status = get_current_network_status()
    return jsonify(status)

@app.route('/api/detailed_status')
@login_required
def api_detailed_status():
    status = get_current_network_status()
    return jsonify(status)

@app.route('/api/interfaces')
@login_required
def api_interfaces():
    interfaces = get_network_interfaces()
    return jsonify(interfaces)

@app.route('/api/network_config')
@login_required
def api_network_config():
    return jsonify(network_config)

@app.route('/api/configure_pppoe', methods=['POST'])
@login_required
def api_configure_pppoe():
    try:
        data = request.get_json()
        network_config['pppoe'].update(data)
        save_network_config()
        return jsonify({'message': 'Configuração PPPoE aplicada com sucesso.'})
    except Exception as e:
        logging.error(f"Erro ao configurar PPPoE: {e}")
        return jsonify({'message': 'Erro ao aplicar configuração PPPoE.'}), 500

@app.route('/api/pppoe_connect', methods=['POST'])
@login_required
def api_pppoe_connect():
    try:
        subprocess.run(['pon', 'dsl-provider'], check=True)
        return jsonify({'message': 'PPPoE conectado com sucesso.'})
    except subprocess.CalledProcessError as e:
        logging.error(f"Erro ao conectar PPPoE: {e}")
        return jsonify({'message': 'Erro ao conectar PPPoE.'}), 500

@app.route('/api/pppoe_disconnect', methods=['POST'])
@login_required
def api_pppoe_disconnect():
    try:
        subprocess.run(['poff', 'dsl-provider'], check=True)
        return jsonify({'message': 'PPPoE desconectado com sucesso.'})
    except subprocess.CalledProcessError as e:
        logging.error(f"Erro ao desconectar PPPoE: {e}")
        return jsonify({'message': 'Erro ao desconectar PPPoE.'}), 500

@app.route('/api/configure_bridge', methods=['POST'])
@login_required
def api_configure_bridge():
    try:
        data = request.get_json()
        network_config['bridge'].update(data)
        save_network_config()
        return jsonify({'message': 'Configuração Bridge aplicada com sucesso.'})
    except Exception as e:
        logging.error(f"Erro ao configurar Bridge: {e}")
        return jsonify({'message': 'Erro ao aplicar configuração Bridge.'}), 500

@app.route('/api/create_bridge', methods=['POST'])
@login_required
def api_create_bridge():
    try:
        name = network_config['bridge']['name']
        ip = network_config['bridge']['ip_address']
        netmask = network_config['bridge']['netmask']
        interfaces = network_config['bridge']['interfaces']
        subprocess.run(['ip', 'link', 'add', 'name', name, 'type', 'bridge'], check=True)
        for iface in interfaces:
            subprocess.run(['ip', 'link', 'set', iface, 'master', name], check=True)
        subprocess.run(['ip', 'addr', 'add', f'{ip}/{netmask}', 'dev', name], check=True)
        subprocess.run(['ip', 'link', 'set', name, 'up'], check=True)
        return jsonify({'message': 'Bridge criado com sucesso.'})
    except subprocess.CalledProcessError as e:
        logging.error(f"Erro ao criar Bridge: {e}")
        return jsonify({'message': 'Erro ao criar Bridge.'}), 500

@app.route('/api/destroy_bridge', methods=['POST'])
@login_required
def api_destroy_bridge():
    try:
        name = network_config['bridge']['name']
        subprocess.run(['ip', 'link', 'set', name, 'down'], check=True)
        subprocess.run(['ip', 'link', 'delete', name], check=True)
        return jsonify({'message': 'Bridge destruído com sucesso.'})
    except subprocess.CalledProcessError as e:
        logging.error(f"Erro ao destruir Bridge: {e}")
        return jsonify({'message': 'Erro ao destruir Bridge.'}), 500

@app.route('/api/configure_vlan', methods=['POST'])
@login_required
def api_configure_vlan():
    try:
        data = request.get_json()
        network_config['vlan'].update(data)
        save_network_config()
        return jsonify({'message': 'Configuração VLAN aplicada com sucesso.'})
    except Exception as e:
        logging.error(f"Erro ao configurar VLAN: {e}")
        return jsonify({'message': 'Erro ao aplicar configuração VLAN.'}), 500

@app.route('/api/create_vlans', methods=['POST'])
@login_required
def api_create_vlans():
    try:
        interface = network_config['vlan']['interface']
        vlans = network_config['vlan']['vlans']
        for vlan in vlans:
            vlan_id = vlan['id']
            vlan_name = vlan['name']
            ip = vlan['ip']
            subprocess.run(['ip', 'link', 'add', 'link', interface, 'name', vlan_name, 'type', 'vlan', 'id', str(vlan_id)], check=True)
            subprocess.run(['ip', 'addr', 'add', ip, 'dev', vlan_name], check=True)
            subprocess.run(['ip', 'link', 'set', vlan_name, 'up'], check=True)
        return jsonify({'message': 'VLANs criadas com sucesso.'})
    except subprocess.CalledProcessError as e:
        logging.error(f"Erro ao criar VLANs: {e}")
        return jsonify({'message': 'Erro ao criar VLANs.'}), 500

@app.route('/api/destroy_vlans', methods=['POST'])
@login_required
def api_destroy_vlans():
    try:
        vlans = network_config['vlan']['vlans']
        for vlan in vlans:
            vlan_name = vlan['name']
            subprocess.run(['ip', 'link', 'set', vlan_name, 'down'], check=True)
            subprocess.run(['ip', 'link', 'delete', vlan_name], check=True)
        return jsonify({'message': 'VLANs destruídas com sucesso.'})
    except subprocess.CalledProcessError as e:
        logging.error(f"Erro ao destruir VLANs: {e}")
        return jsonify({'message': 'Erro ao destruir VLANs.'}), 500

@app.route('/api/configure_firewall', methods=['POST'])
@login_required
def api_configure_firewall():
    try:
        data = request.get_json()
        network_config['firewall'].update(data)
        save_network_config()
        return jsonify({'message': 'Configuração Firewall aplicada com sucesso.'})
    except Exception as e:
        logging.error(f"Erro ao configurar Firewall: {e}")
        return jsonify({'message': 'Erro ao aplicar configuração Firewall.'}), 500

@app.route('/api/apply_firewall_rules', methods=['POST'])
@login_required
def api_apply_firewall_rules():
    try:
        # Aplicar política padrão
        policy = network_config['firewall']['default_policy']
        subprocess.run(['iptables', '-P', 'INPUT', policy['input']], check=True)
        subprocess.run(['iptables', '-P', 'OUTPUT', policy['output']], check=True)
        subprocess.run(['iptables', '-P', 'FORWARD', policy['forward']], check=True)
        # Aplicar regras
        for rule in network_config['firewall']['rules']:
            cmd = ['iptables', '-A', rule['chain']]
            if 'protocol' in rule:
                cmd.extend(['-p', rule['protocol']])
            if 'dport' in rule:
                cmd.extend(['--dport', rule['dport']])
            cmd.extend(['-j', rule['action']])
            subprocess.run(cmd, check=True)
        return jsonify({'message': 'Regras de Firewall aplicadas com sucesso.'})
    except subprocess.CalledProcessError as e:
        logging.error(f"Erro ao aplicar regras de Firewall: {e}")
        return jsonify({'message': 'Erro ao aplicar regras de Firewall.'}), 500

@app.route('/api/flush_firewall', methods=['POST'])
@login_required
def api_flush_firewall():
    try:
        subprocess.run(['iptables', '-F'], check=True)
        subprocess.run(['iptables', '-X'], check=True)
        return jsonify({'message': 'Firewall limpo com sucesso.'})
    except subprocess.CalledProcessError as e:
        logging.error(f"Erro ao limpar Firewall: {e}")
        return jsonify({'message': 'Erro ao limpar Firewall.'}), 500

@app.route('/api/configure_qos', methods=['POST'])
@login_required
def api_configure_qos():
    try:
        data = request.get_json()
        network_config['qos'].update(data)
        save_network_config()
        return jsonify({'message': 'Configuração QoS aplicada com sucesso.'})
    except Exception as e:
        logging.error(f"Erro ao configurar QoS: {e}")
        return jsonify({'message': 'Erro ao aplicar configuração QoS.'}), 500

@app.route('/api/apply_qos', methods=['POST'])
@login_required
def api_apply_qos():
    try:
        # Implementação básica de QoS usando tc (Traffic Control)
        # Isso é simplificado; em produção, seria mais complexo
        upload = network_config['qos']['upload_speed']
        download = network_config['qos']['download_speed']
        # Assumir interface principal, e.g., eth0
        iface = 'eth0'
        subprocess.run(['tc', 'qdisc', 'add', 'dev', iface, 'root', 'handle', '1:', 'htb', 'default', '12'], check=True)
        subprocess.run(['tc', 'class', 'add', 'dev', iface, 'parent', '1:', 'classid', '1:1', 'htb', 'rate', upload, 'ceil', upload], check=True)
        for cls in network_config['qos']['classes']:
            rate = cls['rate']
            ceil = cls['ceil']
            priority = cls['priority']
            classid = f'1:{priority}'
            subprocess.run(['tc', 'class', 'add', 'dev', iface, 'parent', '1:1', 'classid', classid, 'htb', 'rate', rate, 'ceil', ceil], check=True)
        return jsonify({'message': 'QoS aplicado com sucesso.'})
    except subprocess.CalledProcessError as e:
        logging.error(f"Erro ao aplicar QoS: {e}")
        return jsonify({'message': 'Erro ao aplicar QoS.'}), 500

@app.route('/api/remove_qos', methods=['POST'])
@login_required
def api_remove_qos():
    try:
        iface = 'eth0'
        subprocess.run(['tc', 'qdisc', 'del', 'dev', iface, 'root'], check=True)
        return jsonify({'message': 'QoS removido com sucesso.'})
    except subprocess.CalledProcessError as e:
        logging.error(f"Erro ao remover QoS: {e}")
        return jsonify({'message': 'Erro ao remover QoS.'}), 500

@app.route('/api/configure_dhcp', methods=['POST'])
@login_required
def api_configure_dhcp():
    try:
        data = request.get_json()
        network_config['dhcp'].update(data)
        save_network_config()
        return jsonify({'message': 'Configuração DHCP aplicada com sucesso.'})
    except Exception as e:
        logging.error(f"Erro ao configurar DHCP: {e}")
        return jsonify({'message': 'Erro ao aplicar configuração DHCP.'}), 500

@app.route('/api/restart_dhcp', methods=['POST'])
@login_required
def api_restart_dhcp():
    try:
        subprocess.run(['systemctl', 'restart', 'isc-dhcp-server'], check=True)
        return jsonify({'message': 'DHCP reiniciado com sucesso.'})
    except subprocess.CalledProcessError as e:
        logging.error(f"Erro ao reiniciar DHCP: {e}")
        return jsonify({'message': 'Erro ao reiniciar DHCP.'}), 500

@app.route('/api/stop_dhcp', methods=['POST'])
@login_required
def api_stop_dhcp():
    try:
        subprocess.run(['systemctl', 'stop', 'isc-dhcp-server'], check=True)
        return jsonify({'message': 'DHCP parado com sucesso.'})
    except subprocess.CalledProcessError as e:
        logging.error(f"Erro ao parar DHCP: {e}")
        return jsonify({'message': 'Erro ao parar DHCP.'}), 500

@app.route('/api/configure_routing', methods=['POST'])
@login_required
def api_configure_routing():
    try:
        data = request.get_json()
        network_config['routing'].update(data)
        save_network_config()
        return jsonify({'message': 'Configuração de Roteamento aplicada com sucesso.'})
    except Exception as e:
        logging.error(f"Erro ao configurar Roteamento: {e}")
        return jsonify({'message': 'Erro ao aplicar configuração de Roteamento.'}), 500

@app.route('/api/apply_nat', methods=['POST'])
@login_required
def api_apply_nat():
    try:
        interfaces = network_config['routing']['nat']['masquerade_interfaces']
        for iface in interfaces:
            subprocess.run(['iptables', '-t', 'nat', '-A', 'POSTROUTING', '-o', iface, '-j', 'MASQUERADE'], check=True)
        return jsonify({'message': 'NAT aplicado com sucesso.'})
    except subprocess.CalledProcessError as e:
        logging.error(f"Erro ao aplicar NAT: {e}")
        return jsonify({'message': 'Erro ao aplicar NAT.'}), 500

@app.route('/api/remove_nat', methods=['POST'])
@login_required
def api_remove_nat():
    try:
        subprocess.run(['iptables', '-t', 'nat', '-F', 'POSTROUTING'], check=True)
        return jsonify({'message': 'NAT removido com sucesso.'})
    except subprocess.CalledProcessError as e:
        logging.error(f"Erro ao remover NAT: {e}")
        return jsonify({'message': 'Erro ao remover NAT.'}), 500

@app.route('/network_panel')
@login_required
def network_panel():
    interfaces = get_network_interfaces()
    status = get_current_network_status()

    html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Painel de Configuração de Rede</title>
        <style>
            body {{
                margin: 0;
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: #fff;
                overflow-x: hidden;
            }}
            .container {{
                background-color: rgba(0, 0, 0, 0.8);
                margin: 20px auto;
                padding: 20px;
                border-radius: 15px;
                max-width: 1200px;
                box-shadow: 0 0 20px rgba(102, 126, 234, 0.5);
            }}
            h1 {{
                text-align: center;
                font-weight: 700;
                font-size: 2.5em;
                margin-bottom: 20px;
                text-shadow: 0 0 10px #667eea;
            }}
            .tabs {{
                display: flex;
                justify-content: center;
                margin-bottom: 20px;
                flex-wrap: wrap;
            }}
            .tab {{
                padding: 10px 20px;
                background: rgba(102, 126, 234, 0.2);
                border: 1px solid #667eea;
                cursor: pointer;
                border-radius: 8px;
                margin: 5px;
                transition: background 0.3s;
            }}
            .tab.active {{
                background: #667eea;
                color: #000;
            }}
            .tab-content {{
                display: none;
            }}
            .tab-content.active {{
                display: block;
            }}
            .grid {{
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                gap: 20px;
            }}
            .card {{
                background: rgba(255, 255, 255, 0.1);
                padding: 20px;
                border-radius: 10px;
                box-shadow: 0 0 10px rgba(102, 126, 234, 0.3);
                backdrop-filter: blur(10px);
            }}
            .card h3 {{
                margin-top: 0;
                color: #667eea;
            }}
            button {{
                background-color: #667eea;
                border: none;
                padding: 12px 25px;
                border-radius: 8px;
                color: #fff;
                font-weight: bold;
                cursor: pointer;
                transition: background-color 0.3s ease;
                margin: 5px;
            }}
            button:hover {{
                background-color: #5a67d8;
            }}
            button.danger {{
                background-color: #e53e3e;
            }}
            button.danger:hover {{
                background-color: #c53030;
            }}
            button.success {{
                background-color: #38a169;
            }}
            button.success:hover {{
                background-color: #2f855a;
            }}
            input, select {{
                width: 100%;
                padding: 10px;
                margin-bottom: 15px;
                border-radius: 8px;
                border: none;
                background: rgba(255, 255, 255, 0.9);
                color: #000;
                font-size: 1em;
            }}
            .status-indicator {{
                display: inline-block;
                width: 12px;
                height: 12px;
                border-radius: 50%;
                margin-right: 8px;
            }}
            .status-online {{
                background-color: #38a169;
            }}
            .status-offline {{
                background-color: #e53e3e;
            }}
            .config-section {{
                margin-bottom: 20px;
                padding: 15px;
                border: 1px solid #667eea;
                border-radius: 8px;
            }}
            .toggle {{
                position: relative;
                display: inline-block;
                width: 60px;
                height: 34px;
            }}
            .toggle input {{
                opacity: 0;
                width: 0;
                height: 0;
            }}
            .slider {{
                position: absolute;
                cursor: pointer;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background-color: #ccc;
                transition: .4s;
                border-radius: 34px;
            }}
            .slider:before {{
                position: absolute;
                content: "";
                height: 26px;
                width: 26px;
                left: 4px;
                bottom: 4px;
                background-color: white;
                transition: .4s;
                border-radius: 50%;
            }}
            input:checked + .slider {{
                background-color: #667eea;
            }}
            input:checked + .slider:before {{
                transform: translateX(26px);
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Painel de Configuração de Rede</h1>
            <div class="tabs">
                <div class="tab" onclick="openTab(event, 'Overview')">Visão Geral</div>
                <div class="tab" onclick="openTab(event, 'PPPoE')">PPPoE</div>
                <div class="tab" onclick="openTab(event, 'Bridge')">Bridge</div>
                <div class="tab" onclick="openTab(event, 'VLAN')">VLAN</div>
                <div class="tab" onclick="openTab(event, 'Firewall')">Firewall</div>
                <div class="tab" onclick="openTab(event, 'QoS')">QoS</div>
                <div class="tab" onclick="openTab(event, 'DHCP')">DHCP</div>
                <div class="tab" onclick="openTab(event, 'Routing')">Roteamento</div>
                <div class="tab" onclick="openTab(event, 'Status')">Status</div>
            </div>

            <div id="Overview" class="tab-content">
                <div class="grid">
                    <div class="card">
                        <h3>Status da Rede</h3>
                        <div id="networkStatus"></div>
                    </div>
                    <div class="card">
                        <h3>Interfaces Disponíveis</h3>
                        <div id="interfacesList"></div>
                    </div>
                    <div class="card">
                        <h3>Configuração Atual</h3>
                        <div id="currentConfig"></div>
                    </div>
                </div>
            </div>

            <div id="PPPoE" class="tab-content">
                <div class="card">
                    <h3>Configuração PPPoE</h3>
                    <div class="config-section">
                        <label>
                            <input type="checkbox" id="pppoeEnabled" {'checked' if network_config['pppoe']['enabled'] else ''}>
                            Habilitar PPPoE
                        </label>
                    </div>
                    <div class="config-section">
                        <input type="text" id="pppoeUsername" placeholder="Usuário PPPoE" value="{network_config['pppoe']['username']}">
                        <input type="password" id="pppoePassword" placeholder="Senha PPPoE" value="{network_config['pppoe']['password']}">
                        <select id="pppoeInterface">
                            {"".join(f'<option value="{iface}" {"selected" if iface == network_config["pppoe"]["interface"] else ""}>{iface}</option>' for iface in interfaces)}
                        </select>
                        <input type="number" id="pppoeMTU" placeholder="MTU" value="{network_config['pppoe']['mtu']}">
                        <label>
                            <input type="checkbox" id="pppoeAutoConnect" {'checked' if network_config['pppoe']['auto_connect'] else ''}>
                            Conexão Automática
                        </label>
                    </div>
                    <button onclick="configurePPPoE()">Aplicar Configuração PPPoE</button>
                    <button onclick="connectPPPoE()" class="success">Conectar PPPoE</button>
                    <button onclick="disconnectPPPoE()" class="danger">Desconectar PPPoE</button>
                </div>
            </div>

            <div id="Bridge" class="tab-content">
                <div class="card">
                    <h3>Configuração de Bridge</h3>
                    <div class="config-section">
                        <label>
                            <input type="checkbox" id="bridgeEnabled" {'checked' if network_config['bridge']['enabled'] else ''}>
                            Habilitar Bridge
                        </label>
                    </div>
                    <div class="config-section">
                        <input type="text" id="bridgeName" placeholder="Nome do Bridge" value="{network_config['bridge']['name']}">
                        <input type="text" id="bridgeIP" placeholder="IP do Bridge" value="{network_config['bridge']['ip_address']}">
                        <input type="text" id="bridgeNetmask" placeholder="Máscara" value="{network_config['bridge']['netmask']}">
                        <input type="text" id="bridgeGateway" placeholder="Gateway" value="{network_config['bridge']['gateway']}">
                        <div id="bridgeInterfaces">
                            {"".join(f'<label><input type="checkbox" value="{iface}" {"checked" if iface in network_config["bridge"]["interfaces"] else ""}> {iface}</label><br>' for iface in interfaces)}
                        </div>
                    </div>
                    <button onclick="configureBridge()">Aplicar Configuração Bridge</button>
                    <button onclick="createBridge()" class="success">Criar Bridge</button>
                    <button onclick="destroyBridge()" class="danger">Destruir Bridge</button>
                </div>
            </div>

            <div id="VLAN" class="tab-content">
                <div class="card">
                    <h3>Configuração VLAN</h3>
                    <div class="config-section">
                        <label>
                            <input type="checkbox" id="vlanEnabled" {'checked' if network_config['vlan']['enabled'] else ''}>
                            Habilitar VLAN
                        </label>
                    </div>
                    <div class="config-section">
                        <select id="vlanInterface">
                            {"".join(f'<option value="{iface}" {"selected" if iface == network_config["vlan"]["interface"] else ""}>{iface}</option>' for iface in interfaces)}
                        </select>
                        <div id="vlanList">
                            {"".join(f'<div>VLAN {vlan["id"]}: {vlan["name"]} - {vlan["ip"]}</div>' for vlan in network_config["vlan"]["vlans"])}
                        </div>
                    </div>
                    <button onclick="configureVLAN()">Aplicar Configuração VLAN</button>
                    <button onclick="createVLANs()" class="success">Criar VLANs</button>
                    <button onclick="destroyVLANs()" class="danger">Destruir VLANs</button>
                </div>
            </div>

            <div id="Firewall" class="tab-content">
                <div class="card">
                    <h3>Configuração de Firewall</h3>
                    <div class="config-section">
                        <label>
                            <input type="checkbox" id="firewallEnabled" {'checked' if network_config['firewall']['enabled'] else ''}>
                            Habilitar Firewall
                        </label>
                    </div>
                    <div class="config-section">
                        <h4>Política Padrão</h4>
                        <select id="inputPolicy">
                            <option value="ACCEPT" {"selected" if network_config['firewall']['default_policy']['input'] == 'ACCEPT' else ""}>ACCEPT</option>
                            <option value="DROP" {"selected" if network_config['firewall']['default_policy']['input'] == 'DROP' else ""}>DROP</option>
                        </select>
                        <select id="outputPolicy">
                            <option value="ACCEPT" {"selected" if network_config['firewall']['default_policy']['output'] == 'ACCEPT' else ""}>ACCEPT</option>
                            <option value="DROP" {"selected" if network_config['firewall']['default_policy']['output'] == 'DROP' else ""}>DROP</option>
                        </select>
                        <select id="forwardPolicy">
                            <option value="ACCEPT" {"selected" if network_config['firewall']['default_policy']['forward'] == 'ACCEPT' else ""}>ACCEPT</option>
                            <option value="DROP" {"selected" if network_config['firewall']['default_policy']['forward'] == 'DROP' else ""}>DROP</option>
                        </select>
                    </div>
                    <div class="config-section">
                        <h4>Regras de Firewall</h4>
                        <div id="firewallRules">
                            {"".join(f'<div>Chain: {rule["chain"]}, Protocol: {rule.get("protocol", "any")}, Port: {rule.get("dport", "any")}, Action: {rule["action"]}, Comment: {rule.get("comment", "")}</div>' for rule in network_config["firewall"]["rules"])}
                        </div>
                    </div>
                    <button onclick="configureFirewall()">Aplicar Configuração Firewall</button>
                    <button onclick="applyFirewallRules()" class="success">Aplicar Regras</button>
                    <button onclick="flushFirewall()" class="danger">Limpar Firewall</button>
                </div>
            </div>

            <div id="QoS" class="tab-content">
                <div class="card">
                    <h3>Configuração QoS</h3>
                    <div class="config-section">
                        <label>
                            <input type="checkbox" id="qosEnabled" {'checked' if network_config['qos']['enabled'] else ''}>
                            Habilitar QoS
                        </label>
                    </div>
                    <div class="config-section">
                        <input type="text" id="uploadSpeed" placeholder="Velocidade Upload" value="{network_config['qos']['upload_speed']}">
                        <input type="text" id="downloadSpeed" placeholder="Velocidade Download" value="{network_config['qos']['download_speed']}">
                        <div id="qosClasses">
                            {"".join(f'<div>Classe: {cls["name"]}, Rate: {cls["rate"]}, Ceil: {cls["ceil"]}, Priority: {cls["priority"]}</div>' for cls in network_config["qos"]["classes"])}
                        </div>
                    </div>
                    <button onclick="configureQoS()">Aplicar Configuração QoS</button>
                    <button onclick="applyQoS()" class="success">Aplicar QoS</button>
                    <button onclick="removeQoS()" class="danger">Remover QoS</button>
                </div>
            </div>

            <div id="DHCP" class="tab-content">
                <div class="card">
                    <h3>Configuração DHCP</h3>
                    <div class="config-section">
                        <label>
                            <input type="checkbox" id="dhcpEnabled" {'checked' if network_config['dhcp']['enabled'] else ''}>
                            Habilitar DHCP
                        </label>
                    </div>
                    <div class="config-section">
                        <select id="dhcpInterface">
                            {"".join(f'<option value="{iface}" {"selected" if iface == network_config["dhcp"]["interface"] else ""}>{iface}</option>' for iface in interfaces)}
                        </select>
                        <input type="text" id="dhcpRangeStart" placeholder="IP Inicial" value="{network_config['dhcp']['range_start']}">
                        <input type="text" id="dhcpRangeEnd" placeholder="IP Final" value="{network_config['dhcp']['range_end']}">
                        <input type="text" id="dhcpLeaseTime" placeholder="Tempo de Lease" value="{network_config['dhcp']['lease_time']}">
                        <input type="text" id="dhcpGateway" placeholder="Gateway" value="{network_config['dhcp']['gateway']}">
                        <input type="text" id="dhcpDNS" placeholder="Servidores DNS (separados por vírgula)" value="{', '.join(network_config['dhcp']['dns_servers'])}">
                    </div>
                    <button onclick="configureDHCP()">Aplicar Configuração DHCP</button>
                    <button onclick="restartDHCP()" class="success">Reiniciar DHCP</button>
                    <button onclick="stopDHCP()" class="danger">Parar DHCP</button>
                </div>
            </div>

            <div id="Routing" class="tab-content">
                <div class="card">
                    <h3>Configuração de Roteamento</h3>
                    <div class="config-section">
                        <h4>NAT</h4>
                        <label>
                            <input type="checkbox" id="natEnabled" {'checked' if network_config['routing']['nat']['enabled'] else ''}>
                            Habilitar NAT
                        </label>
                        <input type="text" id="natInterfaces" placeholder="Interfaces para NAT" value="{', '.join(network_config['routing']['nat']['masquerade_interfaces'])}">
                    </div>
                    <div class="config-section">
                        <h4>Rotas Estáticas</h4>
                        <div id="staticRoutes">
                            {"".join(f'<div>Rota: {route.get("destination", "")} via {route.get("gateway", "")} dev {route.get("interface", "")}</div>' for route in network_config["routing"]["static_routes"])}
                        </div>
                    </div>
                    <button onclick="configureRouting()">Aplicar Configuração de Roteamento</button>
                    <button onclick="applyNAT()" class="success">Aplicar NAT</button>
                    <button onclick="removeNAT()" class="danger">Remover NAT</button>
                </div>
            </div>

            <div id="Status" class="tab-content">
                <div class="card">
                    <h3>Status da Rede</h3>
                    <div id="detailedStatus"></div>
                    <button onclick="refreshStatus()">Atualizar Status</button>
                </div>
            </div>
        </div>

        <script>
            function openTab(evt, tabName) {{
                var i, tabcontent, tablinks;
                tabcontent = document.getElementsByClassName("tab-content");
                for (i = 0; i < tabcontent.length; i++) {{
                    tabcontent[i].style.display = "none";
                }}
                tablinks = document.getElementsByClassName("tab");
                for (i = 0; i < tablinks.length; i++) {{
                    tablinks[i].className = tablinks[i].className.replace(" active", "");
                }}
                document.getElementById(tabName).style.display = "block";
                evt.currentTarget.className += " active";
            }}

            // Initialize
            document.getElementsByClassName('tab')[0].click();

            // Load initial data
            setInterval(loadNetworkStatus, 5000);
            setInterval(loadInterfaces, 10000);
            setInterval(loadCurrentConfig, 10000);

            async function loadNetworkStatus() {{
                try {{
                    const response = await fetch('/api/network_status');
                    const data = await response.json();
                    let html = '';
                    for (const [key, value] of Object.entries(data)) {{
                        const statusClass = value ? 'status-online' : 'status-offline';
                        const statusText = value ? 'Ativo' : 'Inativo';
                        html += `<div><span class="status-indicator ${{statusClass}}"></span>${{key.replace('_', ' ').toUpperCase()}}: ${{statusText}}</div>`;
                    }}
                    document.getElementById('networkStatus').innerHTML = html;
                }} catch (error) {{
                    console.error('Erro ao carregar status da rede:', error);
                }}
            }}

            async function loadInterfaces() {{
                try {{
                    const response = await fetch('/api/interfaces');
                    const data = await response.json();
                    document.getElementById('interfacesList').innerHTML = data.map(iface => `<div>${{iface}}</div>`).join('');
                }} catch (error) {{
                    console.error('Erro ao carregar interfaces:', error);
                }}
            }}

            async function loadCurrentConfig() {{
                try {{
                    const response = await fetch('/api/network_config');
                    const data = await response.json();
                    document.getElementById('currentConfig').innerHTML = `
                        <div><strong>PPPoE:</strong> ${{data.pppoe.enabled ? 'Habilitado' : 'Desabilitado'}}</div>
                        <div><strong>Bridge:</strong> ${{data.bridge.enabled ? 'Habilitado' : 'Desabilitado'}}</div>
                        <div><strong>VLAN:</strong> ${{data.vlan.enabled ? 'Habilitado' : 'Desabilitado'}}</div>
                        <div><strong>Firewall:</strong> ${{data.firewall.enabled ? 'Habilitado' : 'Desabilitado'}}</div>
                        <div><strong>QoS:</strong> ${{data.qos.enabled ? 'Habilitado' : 'Desabilitado'}}</div>
                        <div><strong>DHCP:</strong> ${{data.dhcp.enabled ? 'Habilitado' : 'Desabilitado'}}</div>
                    `;
                }} catch (error) {{
                    console.error('Erro ao carregar configuração:', error);
                }}
            }}

            // PPPoE functions
            async function configurePPPoE() {{
                const config = {{
                    enabled: document.getElementById('pppoeEnabled').checked,
                    username: document.getElementById('pppoeUsername').value,
                    password: document.getElementById('pppoePassword').value,
                    interface: document.getElementById('pppoeInterface').value,
                    mtu: parseInt(document.getElementById('pppoeMTU').value),
                    auto_connect: document.getElementById('pppoeAutoConnect').checked
                }};
                const response = await fetch('/api/configure_pppoe', {{
                    method: 'POST',
                    headers: {{'Content-Type': 'application/json'}},
                    body: JSON.stringify(config)
                }});
                const data = await response.json();
                alert(data.message);
            }}

            async function connectPPPoE() {{
                const response = await fetch('/api/pppoe_connect', {{ method: 'POST' }});
                const data = await response.json();
                alert(data.message);
            }}

            async function disconnectPPPoE() {{
                const response = await fetch('/api/pppoe_disconnect', {{ method: 'POST' }});
                const data = await response.json();
                alert(data.message);
            }}

            // Bridge functions
            async function configureBridge() {{
                const interfaces = Array.from(document.querySelectorAll('#bridgeInterfaces input:checked')).map(cb => cb.value);
                const config = {{
                    enabled: document.getElementById('bridgeEnabled').checked,
                    name: document.getElementById('bridgeName').value,
                    ip_address: document.getElementById('bridgeIP').value,
                    netmask: document.getElementById('bridgeNetmask').value,
                    gateway: document.getElementById('bridgeGateway').value,
                    interfaces: interfaces
                }};
                const response = await fetch('/api/configure_bridge', {{
                    method: 'POST',
                    headers: {{'Content-Type': 'application/json'}},
                    body: JSON.stringify(config)
                }});
                const data = await response.json();
                alert(data.message);
            }}

            async function createBridge() {{
                const response = await fetch('/api/create_bridge', {{ method: 'POST' }});
                const data = await response.json();
                alert(data.message);
            }}

            async function destroyBridge() {{
                const response = await fetch('/api/destroy_bridge', {{ method: 'POST' }});
                const data = await response.json();
                alert(data.message);
            }}

            // VLAN functions
            async function configureVLAN() {{
                const config = {{
                    enabled: document.getElementById('vlanEnabled').checked,
                    interface: document.getElementById('vlanInterface').value
                }};
                const response = await fetch('/api/configure_vlan', {{
                    method: 'POST',
                    headers: {{'Content-Type': 'application/json'}},
                    body: JSON.stringify(config)
                }});
                const data = await response.json();
                alert(data.message);
            }}

            async function createVLANs() {{
                const response = await fetch('/api/create_vlans', {{ method: 'POST' }});
                const data = await response.json();
                alert(data.message);
            }}

            async function destroyVLANs() {{
                const response = await fetch('/api/destroy_vlans', {{ method: 'POST' }});
                const data = await response.json();
                alert(data.message);
            }}

            // Firewall functions
            async function configureFirewall() {{
                const config = {{
                    enabled: document.getElementById('firewallEnabled').checked,
                    default_policy: {{
                        input: document.getElementById('inputPolicy').value,
                        output: document.getElementById('outputPolicy').value,
                        forward: document.getElementById('forwardPolicy').value
                    }}
                }};
                const response = await fetch('/api/configure_firewall', {{
                    method: 'POST',
                    headers: {{'Content-Type': 'application/json'}},
                    body: JSON.stringify(config)
                }});
                const data = await response.json();
                alert(data.message);
            }}

            async function applyFirewallRules() {{
                const response = await fetch('/api/apply_firewall_rules', {{ method: 'POST' }});
                const data = await response.json();
                alert(data.message);
            }}

            async function flushFirewall() {{
                const response = await fetch('/api/flush_firewall', {{ method: 'POST' }});
                const data = await response.json();
                alert(data.message);
            }}

            // QoS functions
            async function configureQoS() {{
                const config = {{
                    enabled: document.getElementById('qosEnabled').checked,
                    upload_speed: document.getElementById('uploadSpeed').value,
                    download_speed: document.getElementById('downloadSpeed').value
                }};
                const response = await fetch('/api/configure_qos', {{
                    method: 'POST',
                    headers: {{'Content-Type': 'application/json'}},
                    body: JSON.stringify(config)
                }});
                const data = await response.json();
                alert(data.message);
            }}

            async function applyQoS() {{
                const response = await fetch('/api/apply_qos', {{ method: 'POST' }});
                const data = await response.json();
                alert(data.message);
            }}

            async function removeQoS() {{
                const response = await fetch('/api/remove_qos', {{ method: 'POST' }});
                const data = await response.json();
                alert(data.message);
            }}

            // DHCP functions
            async function configureDHCP() {{
                const config = {{
                    enabled: document.getElementById('dhcpEnabled').checked,
                    interface: document.getElementById('dhcpInterface').value,
                    range_start: document.getElementById('dhcpRangeStart').value,
                    range_end: document.getElementById('dhcpRangeEnd').value,
                    lease_time: document.getElementById('dhcpLeaseTime').value,
                    gateway: document.getElementById('dhcpGateway').value,
                    dns_servers: document.getElementById('dhcpDNS').value.split(',').map(s => s.trim())
                }};
                const response = await fetch('/api/configure_dhcp', {{
                    method: 'POST',
                    headers: {{'Content-Type': 'application/json'}},
                    body: JSON.stringify(config)
                }});
                const data = await response.json();
                alert(data.message);
            }}

            async function restartDHCP() {{
                const response = await fetch('/api/restart_dhcp', {{ method: 'POST' }});
                const data = await response.json();
                alert(data.message);
            }}

            async function stopDHCP() {{
                const response = await fetch('/api/stop_dhcp', {{ method: 'POST' }});
                const data = await response.json();
                alert(data.message);
            }}

            // Routing functions
            async function configureRouting() {{
                const config = {{
                    nat: {{
                        enabled: document.getElementById('natEnabled').checked,
                        masquerade_interfaces: document.getElementById('natInterfaces').value.split(',').map(s => s.trim())
                    }}
                }};
                const response = await fetch('/api/configure_routing', {{
                    method: 'POST',
                    headers: {{'Content-Type': 'application/json'}},
                    body: JSON.stringify(config)
                }});
                const data = await response.json();
                alert(data.message);
            }}

            async function applyNAT() {{
                const response = await fetch('/api/apply_nat', {{ method: 'POST' }});
                const data = await response.json();
                alert(data.message);
            }}

            async function removeNAT() {{
                const response = await fetch('/api/remove_nat', {{ method: 'POST' }});
                const data = await response.json();
                alert(data.message);
            }}

            async function refreshStatus() {{
                try {{
                    const response = await fetch('/api/network_status');
                    const data = await response.json();
                    let html = '';
                    for (const [key, value] of Object.entries(data)) {{
                        const statusClass = value ? 'status-online' : 'status-offline';
                        const statusText = value ? 'Ativo' : 'Inativo';
                        html += `<div><span class="status-indicator ${{statusClass}}"></span>${{key.replace('_', ' ').toUpperCase()}}: ${{statusText}}</div>`;
                    }}
                    document.getElementById('detailedStatus').innerHTML = html;
                }} catch (error) {{
                    console.error('Erro ao atualizar status:', error);
                }}
            }}
        </script>
    </body>
    </html>
    """

    return html

if __name__ == '__main__':
    app.run(debug=True)

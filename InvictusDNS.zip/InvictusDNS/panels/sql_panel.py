#!/usr/bin/env python3
"""
InvictusDNS - SQL Database Management Panel
Painel completo para gerenciamento do banco de dados SQLite.
Porta: 3010
"""

from flask import Flask, render_template_string, request, jsonify, session, redirect, url_for, send_file
import sqlite3
import os
import json
import hashlib
from datetime import datetime
import sys

# Adicionar caminho para imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

app = Flask(__name__)
app.secret_key = 'invictus-dns-sql-panel-secret-key-2024'

# Configurações do banco
DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data', 'dns_logs.db')

# Senha admin (hash do bcrypt para 'admin123')
ADMIN_PASSWORD_HASH = '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6fMmiP2Vy'

def get_db_connection():
    """Conecta ao banco de dados SQLite"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def get_table_info(table_name):
    """Obtém informações sobre uma tabela"""
    conn = get_db_connection()
    cursor = conn.cursor()

    # Obter estrutura da tabela
    cursor.execute(f"PRAGMA table_info({table_name})")
    columns = cursor.fetchall()

    # Obter contagem de registros
    cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
    count = cursor.fetchone()[0]

    # Obter índices da tabela
    cursor.execute(f"PRAGMA index_list({table_name})")
    indexes = cursor.fetchall()

    conn.close()

    return {
        'columns': [{'name': col[1], 'type': col[2], 'notnull': col[3], 'pk': col[5]} for col in columns],
        'count': count,
        'indexes': [idx[1] for idx in indexes]
    }

def get_table_data(table_name, limit=100, offset=0, order_by=None, filters=None):
    """Obtém dados de uma tabela com paginação e filtros"""
    conn = get_db_connection()
    cursor = conn.cursor()

    # Construir query base
    query = f"SELECT * FROM {table_name}"

    # Adicionar filtros
    params = []
    if filters:
        where_clauses = []
        for col, value in filters.items():
            if value:
                where_clauses.append(f"{col} LIKE ?")
                params.append(f"%{value}%")
        if where_clauses:
            query += " WHERE " + " AND ".join(where_clauses)

    # Adicionar ordenação
    if order_by:
        query += f" ORDER BY {order_by}"

    # Adicionar paginação
    query += " LIMIT ? OFFSET ?"
    params.extend([limit, offset])

    cursor.execute(query, params)
    rows = cursor.fetchall()

    # Obter total sem paginação para contagem
    count_query = f"SELECT COUNT(*) FROM {table_name}"
    if filters and any(filters.values()):
        count_query += " WHERE " + " AND ".join([f"{col} LIKE ?" for col, value in filters.items() if value])
        count_params = [f"%{value}%" for value in filters.values() if value]
        cursor.execute(count_query, count_params)
    else:
        cursor.execute(count_query)

    total_count = cursor.fetchone()[0]

    conn.close()

    return {
        'data': [dict(row) for row in rows],
        'total': total_count,
        'limit': limit,
        'offset': offset
    }

def execute_query(sql_query, params=None):
    """Executa uma query SQL personalizada"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        if params:
            cursor.execute(sql_query, params)
        else:
            cursor.execute(sql_query)

        # Se for SELECT, retornar resultados
        if sql_query.strip().upper().startswith('SELECT'):
            rows = cursor.fetchall()
            columns = [desc[0] for desc in cursor.description] if cursor.description else []
            result = {
                'type': 'SELECT',
                'columns': columns,
                'data': [dict(zip(columns, row)) for row in rows],
                'count': len(rows)
            }
        else:
            # Para outras operações, commit e retornar affected rows
            conn.commit()
            result = {
                'type': 'MODIFY',
                'affected_rows': cursor.rowcount,
                'message': f'Query executada com sucesso. {cursor.rowcount} linha(s) afetada(s).'
            }

        conn.close()
        return {'success': True, 'result': result}

    except Exception as e:
        return {'success': False, 'error': str(e)}

def get_database_stats():
    """Obtém estatísticas do banco de dados"""
    conn = get_db_connection()
    cursor = conn.cursor()

    # Obter todas as tabelas
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
    tables = cursor.fetchall()

    stats = {}
    total_records = 0

    for table_name, in tables:
        cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
        count = cursor.fetchone()[0]
        stats[table_name] = count
        total_records += count

    # Obter tamanho do arquivo
    db_size = os.path.getsize(DB_PATH) if os.path.exists(DB_PATH) else 0

    conn.close()

    return {
        'tables': stats,
        'total_records': total_records,
        'db_size': db_size,
        'db_size_mb': round(db_size / (1024 * 1024), 2)
    }

# Template HTML
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🗄️ InvictusDNS - SQL Database Panel</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #333;
            min-height: 100vh;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            min-height: 100vh;
            box-shadow: 0 0 30px rgba(0,0,0,0.1);
        }

        .header {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            color: white;
            padding: 20px;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .header h1 {
            font-size: 2.2em;
            margin-bottom: 10px;
        }

        .header p {
            opacity: 0.9;
        }

        .nav {
            background: #f8f9fa;
            padding: 15px;
            border-bottom: 1px solid #dee2e6;
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .nav-btn {
            background: #6c757d;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.3s;
            font-size: 14px;
        }

        .nav-btn:hover, .nav-btn.active {
            background: #4facfe;
        }

        .content {
            padding: 20px;
        }

        .section {
            margin-bottom: 30px;
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            border-left: 4px solid #4facfe;
        }

        .section h2 {
            color: #333;
            margin-bottom: 15px;
            font-size: 1.4em;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }

        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            text-align: center;
        }

        .stat-card h3 {
            color: #4facfe;
            font-size: 2em;
            margin-bottom: 5px;
        }

        .stat-card p {
            color: #666;
            font-size: 0.9em;
        }

        .table-container {
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }

        .table-header {
            background: #f8f9fa;
            padding: 15px;
            border-bottom: 1px solid #dee2e6;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .table-title {
            font-weight: bold;
            color: #333;
        }

        .table-info {
            color: #666;
            font-size: 0.9em;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #dee2e6;
        }

        th {
            background: #f8f9fa;
            font-weight: 600;
            color: #333;
        }

        tr:hover {
            background: #f8f9fa;
        }

        .btn {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s;
            margin-right: 5px;
        }

        .btn:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(79, 172, 254, 0.3);
        }

        .btn-danger {
            background: linear-gradient(135deg, #ff6b6b 0%, #ee5a52 100%);
        }

        .btn-success {
            background: linear-gradient(135deg, #51cf66 0%, #40c057 100%);
        }

        .btn-secondary {
            background: linear-gradient(135deg, #868e96 0%, #6c757d 100%);
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
            color: #333;
        }

        .form-group input, .form-group select, .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 2px solid #ddd;
            border-radius: 6px;
            font-size: 14px;
            transition: border-color 0.3s;
        }

        .form-group input:focus, .form-group select:focus, .form-group textarea:focus {
            outline: none;
            border-color: #4facfe;
        }

        .form-row {
            display: flex;
            gap: 15px;
        }

        .form-row .form-group {
            flex: 1;
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }

        .modal.show {
            display: flex;
        }

        .modal-content {
            background: white;
            border-radius: 10px;
            padding: 25px;
            max-width: 600px;
            width: 90%;
            max-height: 80vh;
            overflow-y: auto;
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid #dee2e6;
        }

        .modal-title {
            font-size: 1.4em;
            color: #333;
        }

        .close {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: #666;
        }

        .alert {
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 15px;
        }

        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
            margin-top: 20px;
        }

        .page-btn {
            padding: 8px 12px;
            border: 1px solid #dee2e6;
            background: white;
            color: #333;
            border-radius: 4px;
            cursor: pointer;
            transition: all 0.3s;
        }

        .page-btn:hover, .page-btn.active {
            background: #4facfe;
            color: white;
            border-color: #4facfe;
        }

        .filters {
            background: white;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 15px;
            border: 1px solid #dee2e6;
        }

        .filter-row {
            display: flex;
            gap: 10px;
            align-items: end;
            flex-wrap: wrap;
        }

        .query-editor {
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 6px;
            padding: 15px;
            margin-bottom: 15px;
        }

        .query-textarea {
            width: 100%;
            min-height: 100px;
            font-family: 'Courier New', monospace;
            font-size: 14px;
            border: 1px solid #ccc;
            border-radius: 4px;
            padding: 10px;
        }

        .query-result {
            background: white;
            border: 1px solid #dee2e6;
            border-radius: 6px;
            padding: 15px;
            margin-top: 15px;
            max-height: 400px;
            overflow-y: auto;
        }

        .result-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 12px;
        }

        .result-table th, .result-table td {
            padding: 8px;
            border: 1px solid #dee2e6;
            text-align: left;
        }

        .result-table th {
            background: #f8f9fa;
            font-weight: 600;
        }

        .loading {
            text-align: center;
            padding: 20px;
            color: #666;
        }

        .spinner {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #4facfe;
            border-radius: 50%;
            width: 30px;
            height: 30px;
            animation: spin 1s linear infinite;
            display: inline-block;
            margin-right: 10px;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .hidden {
            display: none !important;
        }

        @media (max-width: 768px) {
            .nav {
                flex-direction: column;
            }

            .table-container {
                overflow-x: auto;
            }

            table {
                min-width: 600px;
            }

            .form-row {
                flex-direction: column;
            }

            .filter-row {
                flex-direction: column;
                align-items: stretch;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🗄️ SQL Database Management Panel</h1>
            <p>Gerencie completamente o banco de dados do InvictusDNS</p>
        </div>

        <div class="nav" id="nav-buttons">
            <!-- Botões de navegação serão inseridos via JavaScript -->
        </div>

        <div class="content">
            <!-- Alertas -->
            <div id="alert-container"></div>

            <!-- Seção de Estatísticas -->
            <div class="section" id="stats-section">
                <h2>📊 Estatísticas do Banco</h2>
                <div class="stats-grid" id="stats-grid">
                    <!-- Estatísticas serão carregadas via JavaScript -->
                </div>
            </div>

            <!-- Seção de Tabelas -->
            <div class="section" id="tables-section">
                <h2>📋 Tabelas do Banco</h2>
                <div id="tables-list">
                    <!-- Lista de tabelas será carregada via JavaScript -->
                </div>
            </div>

            <!-- Seção de Dados da Tabela -->
            <div class="section hidden" id="table-data-section">
                <h2 id="table-data-title">📊 Dados da Tabela</h2>

                <!-- Filtros -->
                <div class="filters" id="filters-container">
                    <!-- Filtros serão inseridos dinamicamente -->
                </div>

                <!-- Ações da Tabela -->
                <div style="margin-bottom: 15px;">
                    <button class="btn btn-success" onclick="showAddRecordModal()">➕ Adicionar Registro</button>
                    <button class="btn btn-secondary" onclick="refreshTableData()">🔄 Atualizar</button>
                    <button class="btn" onclick="exportTableData()">📥 Exportar CSV</button>
                </div>

                <!-- Container da Tabela -->
                <div class="table-container">
                    <div class="table-header">
                        <div>
                            <span class="table-title" id="current-table-name"></span>
                            <span class="table-info" id="table-info"></span>
                        </div>
                        <div id="table-actions">
                            <!-- Ações serão inseridas dinamicamente -->
                        </div>
                    </div>
                    <div id="table-data-container">
                        <!-- Dados da tabela serão carregados via JavaScript -->
                    </div>
                </div>

                <!-- Paginação -->
                <div class="pagination" id="pagination-container">
                    <!-- Paginação será inserida via JavaScript -->
                </div>
            </div>

            <!-- Seção de Query SQL -->
            <div class="section hidden" id="query-section">
                <h2>🔍 Query SQL Personalizada</h2>

                <div class="query-editor">
                    <div class="form-group">
                        <label for="sql-query">Digite sua query SQL:</label>
                        <textarea id="sql-query" class="query-textarea" placeholder="SELECT * FROM users WHERE role = 'admin';"></textarea>
                    </div>
                    <button class="btn btn-success" onclick="executeCustomQuery()">▶️ Executar Query</button>
                    <button class="btn btn-secondary" onclick="clearQueryResult()">🗑️ Limpar</button>
                </div>

                <div id="query-result" class="query-result hidden">
                    <!-- Resultados da query serão exibidos aqui -->
                </div>
            </div>

            <!-- Seção de Backup -->
            <div class="section hidden" id="backup-section">
                <h2>💾 Backup e Restauração</h2>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div>
                        <h3>📤 Criar Backup</h3>
                        <p>Faça download de um backup completo do banco de dados.</p>
                        <button class="btn btn-success" onclick="createBackup()">📥 Download Backup</button>
                    </div>

                    <div>
                        <h3>📥 Restaurar Backup</h3>
                        <p>Restaure o banco a partir de um arquivo de backup.</p>
                        <input type="file" id="backup-file" accept=".db,.sql" style="margin-bottom: 10px;">
                        <br>
                        <button class="btn btn-danger" onclick="restoreBackup()">📤 Restaurar Backup</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal para Adicionar/Editar Registro -->
    <div class="modal" id="record-modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="record-modal-title">Adicionar Registro</h3>
                <button class="close" onclick="closeRecordModal()">&times;</button>
            </div>
            <div id="record-form-container">
                <!-- Formulário será inserido dinamicamente -->
            </div>
        </div>
    </div>

    <script>
        let currentTable = null;
        let currentPage = 0;
        let pageSize = 50;
        let currentFilters = {};
        let currentSort = null;

        // Estado da aplicação
        const sections = ['stats', 'tables', 'table-data', 'query', 'backup'];
        let currentSection = 'stats';

        // Inicialização
        document.addEventListener('DOMContentLoaded', function() {
            setupNavigation();
            loadStats();
            loadTables();
        });

        function setupNavigation() {
            const navButtons = document.getElementById('nav-buttons');

            const buttons = [
                { id: 'stats', label: '📊 Estatísticas', section: 'stats' },
                { id: 'tables', label: '📋 Tabelas', section: 'tables' },
                { id: 'query', label: '🔍 SQL Query', section: 'query' },
                { id: 'backup', label: '💾 Backup', section: 'backup' }
            ];

            buttons.forEach(btn => {
                const button = document.createElement('button');
                button.className = 'nav-btn';
                button.textContent = btn.label;
                button.onclick = () => showSection(btn.section);
                navButtons.appendChild(button);
            });

            // Botão de logout
            const logoutBtn = document.createElement('button');
            logoutBtn.className = 'nav-btn btn-danger';
            logoutBtn.textContent = '🚪 Logout';
            logoutBtn.style.marginLeft = 'auto';
            logoutBtn.onclick = () => window.location.href = '/logout';
            navButtons.appendChild(logoutBtn);
        }

        function showSection(sectionId) {
            // Esconder todas as seções
            sections.forEach(id => {
                const element = document.getElementById(id + '-section');
                if (element) element.classList.add('hidden');
            });

            // Mostrar seção selecionada
            const targetElement = document.getElementById(sectionId + '-section');
            if (targetElement) targetElement.classList.remove('hidden');

            // Atualizar botões de navegação
            document.querySelectorAll('.nav-btn').forEach(btn => {
                btn.classList.remove('active');
            });
            event.target.classList.add('active');

            currentSection = sectionId;

            // Carregar dados da seção se necessário
            if (sectionId === 'stats') loadStats();
            if (sectionId === 'tables') loadTables();
        }

        function showAlert(message, type = 'success') {
            const alertContainer = document.getElementById('alert-container');
            const alert = document.createElement('div');
            alert.className = `alert alert-${type}`;
            alert.textContent = message;

            alertContainer.appendChild(alert);

            // Remover automaticamente após 5 segundos
            setTimeout(() => {
                alert.remove();
            }, 5000);
        }

        // Funções de Estatísticas
        async function loadStats() {
            try {
                const response = await fetch('/api/stats');
                const data = await response.json();

                const statsGrid = document.getElementById('stats-grid');
                statsGrid.innerHTML = '';

                // Estatística de tabelas
                const tablesCard = document.createElement('div');
                tablesCard.className = 'stat-card';
                tablesCard.innerHTML = `
                    <h3>${Object.keys(data.tables).length}</h3>
                    <p>Tabelas</p>
                `;
                statsGrid.appendChild(tablesCard);

                // Estatística de registros totais
                const recordsCard = document.createElement('div');
                recordsCard.className = 'stat-card';
                recordsCard.innerHTML = `
                    <h3>${data.total_records.toLocaleString()}</h3>
                    <p>Registros Totais</p>
                `;
                statsGrid.appendChild(recordsCard);

                // Estatística de tamanho do banco
                const sizeCard = document.createElement('div');
                sizeCard.className = 'stat-card';
                sizeCard.innerHTML = `
                    <h3>${data.db_size_mb} MB</h3>
                    <p>Tamanho do Banco</p>
                `;
                statsGrid.appendChild(sizeCard);

                // Tabela com detalhes
                const detailsCard = document.createElement('div');
                detailsCard.className = 'stat-card';
                detailsCard.innerHTML = `
                    <h3>📋</h3>
                    <p>Detalhes por Tabela</p>
                `;
                detailsCard.onclick = () => showSection('tables');
                detailsCard.style.cursor = 'pointer';
                statsGrid.appendChild(detailsCard);

            } catch (error) {
                console.error('Erro ao carregar estatísticas:', error);
                showAlert('Erro ao carregar estatísticas', 'error');
            }
        }

        // Funções de Tabelas
        async function loadTables() {
            try {
                const response = await fetch('/api/tables');
                const tables = await response.json();

                const tablesList = document.getElementById('tables-list');
                tablesList.innerHTML = '';

                tables.forEach(table => {
                    const tableCard = document.createElement('div');
                    tableCard.className = 'table-container';
                    tableCard.innerHTML = `
                        <div class="table-header">
                            <div>
                                <span class="table-title">${table.name}</span>
                                <span class="table-info">${table.count.toLocaleString()} registros</span>
                            </div>
                            <div>
                                <button class="btn btn-success" onclick="viewTable('${table.name}')">👁️ Ver Dados</button>
                                <button class="btn btn-secondary" onclick="showTableInfo('${table.name}')">ℹ️ Info</button>
                            </div>
                        </div>
                    `;
                    tablesList.appendChild(tableCard);
                });

            } catch (error) {
                console.error('Erro ao carregar tabelas:', error);
                showAlert('Erro ao carregar tabelas', 'error');
            }
        }

        async function viewTable(tableName) {
            currentTable = tableName;
            currentPage = 0;
            currentFilters = {};
            currentSort = null;

            document.getElementById('current-table-name').textContent = tableName;
            await loadTableData();
            showSection('table-data');
        }

        async function loadTableData() {
            if (!currentTable) return;

            try {
                const params = new URLSearchParams({
                    table: currentTable,
                    limit: pageSize,
                    offset: currentPage * pageSize
                });

                if (currentSort) params.append('order_by', currentSort);
                Object.keys(currentFilters).forEach(key => {
                    if (currentFilters[key]) params.append(`filter_${key}`, currentFilters[key]);
                });

                const response = await fetch(`/api/table-data?${params}`);
                const data = await response.json();

                displayTableData(data);
                updatePagination(data.total, data.limit, data.offset);

            } catch (error) {
                console.error('Erro ao carregar dados da tabela:', error);
                showAlert('Erro ao carregar dados da tabela', 'error');
            }
        }

        function displayTableData(data) {
            const container = document.getElementById('table-data-container');
            const info = document.getElementById('table-info');

            info.textContent = `Mostrando ${data.data.length} de ${data.total} registros`;

            if (data.data.length === 0) {
                container.innerHTML = '<div class="loading">Nenhum registro encontrado</div>';
                return;
            }

            let html = '<table><thead><tr>';

            // Cabeçalhos
            Object.keys(data.data[0]).forEach(column => {
                html += `<th onclick="sortTable('${column}')">${column} ${currentSort === column ? '↑' : ''}</th>`;
            });
            html += '<th>Ações</th></tr></thead><tbody>';

            // Dados
            data.data.forEach((row, index) => {
                html += '<tr>';
                Object.values(row).forEach(value => {
                    html += `<td>${value !== null ? value : '<em>null</em>'}</td>`;
                });
                html += `
                    <td>
                        <button class="btn btn-secondary" onclick="editRecord(${index})">✏️</button>
                        <button class="btn btn-danger" onclick="deleteRecord(${index})">🗑️</button>
                    </td>
                `;
                html += '</tr>';
            });

            html += '</tbody></table>';
            container.innerHTML = html;

            // Armazenar dados para edição/exclusão
            container.dataset.tableData = JSON.stringify(data.data);
        }

        function updatePagination(total, limit, offset) {
            const container = document.getElementById('pagination-container');
            const totalPages = Math.ceil(total / limit);
            const currentPageNum = Math.floor(offset / limit);

            if (totalPages <= 1) {
                container.innerHTML = '';
                return;
            }

            let html = '';

            // Anterior
            if (currentPageNum > 0) {
                html += `<button class="page-btn" onclick="changePage(${currentPageNum - 1})">← Anterior</button>`;
            }

            // Páginas
            const startPage = Math.max(0, currentPageNum - 2);
            const endPage = Math.min(totalPages - 1, currentPageNum + 2);

            for (let i = startPage; i <= endPage; i++) {
                const activeClass = i === currentPageNum ? ' active' : '';
                html += `<button class="page-btn${activeClass}" onclick="changePage(${i})">${i + 1}</button>`;
            }

            // Próximo
            if (currentPageNum < totalPages - 1) {
                html += `<button class="page-btn" onclick="changePage(${currentPageNum + 1})">Próximo →</button>`;
            }

            container.innerHTML = html;
        }

        function changePage(page) {
            currentPage = page;
            loadTableData();
        }

        function sortTable(column) {
            currentSort = currentSort === column ? null : column;
            currentPage = 0;
            loadTableData();
        }

        async function showTableInfo(tableName) {
            try {
                const response = await fetch(`/api/table-info?table=${tableName}`);
                const info = await response.json();

                let message = `Tabela: ${tableName}\\n`;
                message += `Registros: ${info.count}\\n`;
                message += `Colunas: ${info.columns.length}\\n`;
                message += `Índices: ${info.indexes.length}\\n\\n`;

                message += 'Colunas:\\n';
                info.columns.forEach(col => {
                    message += `- ${col.name} (${col.type}) ${col.pk ? '[PK]' : ''} ${col.notnull ? '[NOT NULL]' : ''}\\n`;
                });

                alert(message);

            } catch (error) {
                console.error('Erro ao obter info da tabela:', error);
                showAlert('Erro ao obter informações da tabela', 'error');
            }
        }

        // Funções de CRUD
        function showAddRecordModal() {
            // Implementar modal para adicionar registro
            showAlert('Funcionalidade de adicionar registro em desenvolvimento', 'error');
        }

        function editRecord(index) {
            // Implementar edição de registro
            showAlert('Funcionalidade de editar registro em desenvolvimento', 'error');
        }

        function deleteRecord(index) {
            // Implementar exclusão de registro
            showAlert('Funcionalidade de excluir registro em desenvolvimento', 'error');
        }

        function refreshTableData() {
            loadTableData();
            showAlert('Dados atualizados com sucesso');
        }

        function exportTableData() {
            // Implementar export CSV
            showAlert('Funcionalidade de export em desenvolvimento', 'error');
        }

        function closeRecordModal() {
            document.getElementById('record-modal').classList.remove('show');
        }

        // Funções de Query SQL
        async function executeCustomQuery() {
            const query = document.getElementById('sql-query').value.trim();
            if (!query) {
                showAlert('Digite uma query SQL', 'error');
                return;
            }

            const resultDiv = document.getElementById('query-result');
            resultDiv.classList.remove('hidden');
            resultDiv.innerHTML = '<div class="loading"><div class="spinner"></div>Executando query...</div>';

            try {
                const response = await fetch('/api/execute-query', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ query: query })
                });

                const result = await response.json();

                if (result.success) {
                    displayQueryResult(result.result);
                } else {
                    resultDiv.innerHTML = `<div class="alert alert-error">Erro: ${result.error}</div>`;
                }

            } catch (error) {
                console.error('Erro ao executar query:', error);
                resultDiv.innerHTML = `<div class="alert alert-error">Erro ao executar query: ${error.message}</div>`;
            }
        }

        function displayQueryResult(result) {
            const resultDiv = document.getElementById('query-result');

            if (result.type === 'SELECT') {
                if (result.data.length === 0) {
                    resultDiv.innerHTML = '<div class="alert alert-success">Query executada com sucesso. Nenhum resultado retornado.</div>';
                    return;
                }

                let html = `<div class="alert alert-success">Query executada com sucesso. ${result.count} resultado(s) retornado(s).</div>`;
                html += '<table class="result-table"><thead><tr>';

                result.columns.forEach(col => {
                    html += `<th>${col}</th>`;
                });
                html += '</tr></thead><tbody>';

                result.data.forEach(row => {
                    html += '<tr>';
                    result.columns.forEach(col => {
                        const value = row[col];
                        html += `<td>${value !== null ? value : '<em>null</em>'}</td>`;
                    });
                    html += '</tr>';
                });

                html += '</tbody></table>';
                resultDiv.innerHTML = html;

            } else {
                resultDiv.innerHTML = `<div class="alert alert-success">${result.message}</div>`;
            }
        }

        function clearQueryResult() {
            document.getElementById('query-result').classList.add('hidden');
            document.getElementById('sql-query').value = '';
        }

        // Funções de Backup
        function createBackup() {
            // Implementar download de backup
            showAlert('Funcionalidade de backup em desenvolvimento', 'error');
        }

        function restoreBackup() {
            // Implementar restauração de backup
            showAlert('Funcionalidade de restauração em desenvolvimento', 'error');
        }

        // Logout
        function logout() {
            window.location.href = '/logout';
        }
    </script>
</body>
</html>
"""

@app.route('/')
def index():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    return render_template_string(HTML_TEMPLATE)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        password = request.form.get('password', '')
        if password == 'admin123':  # Senha simples para demo
            session['logged_in'] = True
            return redirect(url_for('index'))
        else:
            error = "Senha incorreta. Tente novamente."
    else:
        error = None

    return render_template_string("""
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Login - InvictusDNS SQL Panel</title>
        <style>
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: #333;
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                margin: 0;
            }

            .login-container {
                background: white;
                border-radius: 10px;
                padding: 40px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.2);
                max-width: 400px;
                width: 90%;
                text-align: center;
            }

            .login-container h1 {
                color: #4facfe;
                margin-bottom: 10px;
                font-size: 2em;
            }

            .login-container p {
                color: #666;
                margin-bottom: 30px;
            }

            .form-group {
                margin-bottom: 20px;
                text-align: left;
            }

            .form-group label {
                display: block;
                margin-bottom: 5px;
                font-weight: 500;
                color: #333;
            }

            .form-group input {
                width: 100%;
                padding: 12px;
                border: 2px solid #ddd;
                border-radius: 6px;
                font-size: 16px;
                transition: border-color 0.3s;
                box-sizing: border-box;
            }

            .form-group input:focus {
                outline: none;
                border-color: #4facfe;
            }

            .btn {
                background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
                color: white;
                border: none;
                padding: 12px 30px;
                border-radius: 6px;
                cursor: pointer;
                font-size: 16px;
                transition: all 0.3s;
                width: 100%;
            }

            .btn:hover {
                transform: translateY(-1px);
                box-shadow: 0 4px 8px rgba(79, 172, 254, 0.3);
            }

            .error {
                color: #dc3545;
                background: #f8d7da;
                border: 1px solid #f5c6cb;
                padding: 10px;
                border-radius: 4px;
                margin-bottom: 20px;
            }
        </style>
    </head>
    <body>
        <div class="login-container">
            <h1>🔐 SQL Database Panel</h1>
            <p>Entre com sua senha para acessar o painel</p>
            {% if error %}
            <div class="error">{{ error }}</div>
            {% endif %}
            <form method="POST">
                <div class="form-group">
                    <label for="password">Senha:</label>
                    <input type="password" id="password" name="password" required autofocus>
                </div>
                <button type="submit" class="btn">Entrar</button>
            </form>
        </div>
    </body>
    </html>
    """, error=error)

@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    return redirect(url_for('login'))

# API Routes
@app.route('/api/stats')
def api_stats():
    if not session.get('logged_in'):
        return jsonify({'error': 'Unauthorized'}), 401
    try:
        stats = get_database_stats()
        return jsonify(stats)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/tables')
def api_tables():
    if not session.get('logged_in'):
        return jsonify({'error': 'Unauthorized'}), 401
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = cursor.fetchall()
        conn.close()

        table_list = []
        for table_name, in tables:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
            count = cursor.fetchone()[0]
            conn.close()
            table_list.append({'name': table_name, 'count': count})

        return jsonify(table_list)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/table-data')
def api_table_data():
    if not session.get('logged_in'):
        return jsonify({'error': 'Unauthorized'}), 401
    try:
        table_name = request.args.get('table')
        limit = int(request.args.get('limit', 100))
        offset = int(request.args.get('offset', 0))
        order_by = request.args.get('order_by')
        filters = {}
        for key, value in request.args.items():
            if key.startswith('filter_'):
                filters[key[7:]] = value  # Remove 'filter_' prefix

        data = get_table_data(table_name, limit, offset, order_by, filters)
        return jsonify(data)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/table-info')
def api_table_info():
    if not session.get('logged_in'):
        return jsonify({'error': 'Unauthorized'}), 401
    try:
        table_name = request.args.get('table')
        info = get_table_info(table_name)
        return jsonify(info)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/execute-query', methods=['POST'])
def api_execute_query():
    if not session.get('logged_in'):
        return jsonify({'error': 'Unauthorized'}), 401
    try:
        data = request.get_json()
        query = data.get('query', '')
        result = execute_query(query)
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3010, debug=True)

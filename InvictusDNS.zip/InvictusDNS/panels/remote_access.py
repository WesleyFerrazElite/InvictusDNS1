from flask import Flask, render_template_string, request, jsonify, session, redirect, url_for, flash
import subprocess
import os
import platform
import psutil
import threading
import time
import logging
from functools import wraps
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
from datetime import datetime
import json
import base64
import secrets
import socket
import uuid

app = Flask(__name__)
app.secret_key = 'supersecretkey'

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

DB_FILE = 'data/dns_logs.db'
REMOTE_SESSIONS_FILE = 'remote_sessions.json'

# Remote access configuration
remote_config = {
    'enabled': True,
    'port': 3389,  # RDP default port
    'vnc_port': 5900,
    'anydesk_enabled': True,
    'teamviewer_enabled': True,
    'chrome_remote_desktop_enabled': True,
    'custom_rdp_enabled': True,
    'security': {
        'require_2fa': False,
        'session_timeout': 3600,  # 1 hour
        'max_concurrent_sessions': 5,
        'allowed_ips': [],  # Empty means allow all
        'encryption': 'AES-256'
    },
    'monitoring': {
        'log_sessions': True,
        'alert_on_new_connection': True,
        'record_sessions': False  # Screen recording
    }
}

# Active remote sessions
active_sessions = {}

def init_db():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY,
                    username TEXT UNIQUE,
                    password_hash TEXT,
                    role TEXT DEFAULT 'user',
                    ips TEXT
                )''')
    c.execute('''CREATE TABLE IF NOT EXISTS remote_sessions (
                    id TEXT PRIMARY KEY,
                    user_id INTEGER,
                    start_time TEXT,
                    end_time TEXT,
                    client_ip TEXT,
                    session_type TEXT,
                    status TEXT
                )''')
    # Insert admin if not exists
    c.execute("SELECT COUNT(*) FROM users WHERE username = 'admin'")
    if c.fetchone()[0] == 0:
        c.execute("INSERT INTO users (username, password_hash, role, ips) VALUES (?, ?, ?, ?)",
                  ('admin', generate_password_hash('senha123'), 'admin', ''))
    conn.commit()
    conn.close()

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

def load_remote_sessions():
    global active_sessions
    try:
        if os.path.exists(REMOTE_SESSIONS_FILE):
            with open(REMOTE_SESSIONS_FILE, 'r') as f:
                active_sessions = json.load(f)
    except Exception as e:
        logging.error(f"Error loading remote sessions: {e}")

def save_remote_sessions():
    try:
        with open(REMOTE_SESSIONS_FILE, 'w') as f:
            json.dump(active_sessions, f, indent=2)
    except Exception as e:
        logging.error(f"Error saving remote sessions: {e}")

def generate_session_id():
    return str(uuid.uuid4())

def get_system_info():
    return {
        'os': platform.system(),
        'version': platform.release(),
        'hostname': socket.gethostname(),
        'ip_address': socket.gethostbyname(socket.gethostname())
    }

def check_remote_tools():
    tools_status = {}

    # Check RDP
    try:
        if platform.system() == 'Windows':
            result = subprocess.run(['netstat', '-an'], capture_output=True, text=True)
            rdp_active = '3389' in result.stdout
        else:
            result = subprocess.run(['netstat', '-tlnp'], capture_output=True, text=True)
            rdp_active = '3389' in result.stdout
        tools_status['rdp'] = rdp_active
    except:
        tools_status['rdp'] = False

    # Check VNC
    try:
        result = subprocess.run(['netstat', '-tlnp'], capture_output=True, text=True)
        vnc_active = '5900' in result.stdout or '5901' in result.stdout
        tools_status['vnc'] = vnc_active
    except:
        tools_status['vnc'] = False

    # Check AnyDesk
    try:
        result = subprocess.run(['pgrep', '-f', 'anydesk'], capture_output=True, text=True)
        tools_status['anydesk'] = bool(result.stdout.strip())
    except:
        tools_status['anydesk'] = False

    # Check TeamViewer
    try:
        result = subprocess.run(['pgrep', '-f', 'teamviewer'], capture_output=True, text=True)
        tools_status['teamviewer'] = bool(result.stdout.strip())
    except:
        tools_status['teamviewer'] = False

    return tools_status

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        init_db()
        conn = sqlite3.connect(DB_FILE, timeout=30, check_same_thread=False)
        c = conn.cursor()
        c.execute("SELECT id, password_hash FROM users WHERE username = ?", (username,))
        user = c.fetchone()
        conn.close()
        if user and check_password_hash(user[1], password):
            session['user_id'] = user[0]
            return redirect(url_for('remote_panel'))
        flash('Credenciais inválidas')
    html = """
    <!DOCTYPE html>
    <html>
    <head><title>Login Acesso Remoto</title></head>
    <body>
        <h1>Login Painel de Acesso Remoto</h1>
        <form method="post">
            <input type="text" name="username" placeholder="Usuário" required><br>
            <input type="password" name="password" placeholder="Senha" required><br>
            <button type="submit">Login</button>
        </form>
    </body>
    </html>
    """
    return html

@app.route('/remote_panel')
@login_required
def remote_panel():
    html = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Painel de Acesso Remoto</title>
        <style>
            body {
                margin: 0;
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: #fff;
                overflow-x: hidden;
            }
            .container {
                background-color: rgba(0, 0, 0, 0.8);
                margin: 20px auto;
                padding: 20px;
                border-radius: 15px;
                max-width: 1200px;
                box-shadow: 0 0 20px rgba(102, 126, 234, 0.5);
            }
            h1 {
                text-align: center;
                font-weight: 700;
                font-size: 2.5em;
                margin-bottom: 20px;
                text-shadow: 0 0 10px #667eea;
            }
            .tabs {
                display: flex;
                justify-content: center;
                margin-bottom: 20px;
                flex-wrap: wrap;
            }
            .tab {
                padding: 10px 20px;
                background: rgba(102, 126, 234, 0.2);
                border: 1px solid #667eea;
                cursor: pointer;
                border-radius: 8px;
                margin: 5px;
                transition: background 0.3s;
            }
            .tab.active {
                background: #667eea;
                color: #000;
            }
            .tab-content {
                display: none;
            }
            .tab-content.active {
                display: block;
            }
            .grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                gap: 20px;
            }
            .card {
                background: rgba(255, 255, 255, 0.1);
                padding: 20px;
                border-radius: 10px;
                box-shadow: 0 0 10px rgba(102, 126, 234, 0.3);
                backdrop-filter: blur(10px);
            }
            .card h3 {
                margin-top: 0;
                color: #667eea;
            }
            button {
                background-color: #667eea;
                border: none;
                padding: 12px 25px;
                border-radius: 8px;
                color: #fff;
                font-weight: bold;
                cursor: pointer;
                transition: background-color 0.3s ease;
                margin: 5px;
            }
            button:hover {
                background-color: #5a67d8;
            }
            button.danger {
                background-color: #e53e3e;
            }
            button.danger:hover {
                background-color: #c53030;
            }
            button.success {
                background-color: #38a169;
            }
            button.success:hover {
                background-color: #2f855a;
            }
            input, select {
                width: 100%;
                padding: 10px;
                margin-bottom: 15px;
                border-radius: 8px;
                border: none;
                background: rgba(255, 255, 255, 0.9);
                color: #000;
                font-size: 1em;
            }
            .status-indicator {
                display: inline-block;
                width: 12px;
                height: 12px;
                border-radius: 50%;
                margin-right: 8px;
            }
            .status-online {
                background-color: #38a169;
            }
            .status-offline {
                background-color: #e53e3e;
            }
            .session-list {
                max-height: 300px;
                overflow-y: auto;
                background: rgba(0, 0, 0, 0.3);
                padding: 10px;
                border-radius: 8px;
            }
            .session-item {
                background: rgba(255, 255, 255, 0.1);
                padding: 10px;
                margin-bottom: 8px;
                border-radius: 5px;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Painel de Acesso Remoto</h1>
            <div class="tabs">
                <div class="tab" onclick="openTab(event, 'Overview')">Visão Geral</div>
                <div class="tab" onclick="openTab(event, 'RDP')">RDP</div>
                <div class="tab" onclick="openTab(event, 'VNC')">VNC</div>
                <div class="tab" onclick="openTab(event, 'AnyDesk')">AnyDesk</div>
                <div class="tab" onclick="openTab(event, 'TeamViewer')">TeamViewer</div>
                <div class="tab" onclick="openTab(event, 'ChromeRD')">Chrome Remote Desktop</div>
                <div class="tab" onclick="openTab(event, 'Sessions')">Sessões</div>
                <div class="tab" onclick="openTab(event, 'Security')">Segurança</div>
                <div class="tab" onclick="openTab(event, 'Settings')">Configurações</div>
            </div>

            <div id="Overview" class="tab-content">
                <div class="grid">
                    <div class="card">
                        <h3>Informações do Sistema</h3>
                        <div id="systemInfo"></div>
                    </div>
                    <div class="card">
                        <h3>Status das Ferramentas</h3>
                        <div id="toolsStatus"></div>
                    </div>
                    <div class="card">
                        <h3>Sessões Ativas</h3>
                        <div id="activeSessions"></div>
                    </div>
                    <div class="card">
                        <h3>Configuração Atual</h3>
                        <div id="currentConfig"></div>
                    </div>
                </div>
            </div>

            <div id="RDP" class="tab-content">
                <div class="card">
                    <h3>Controle RDP</h3>
                    <div id="rdpStatus"></div>
                    <button onclick="startRDP()">Iniciar RDP</button>
                    <button onclick="stopRDP()" class="danger">Parar RDP</button>
                    <button onclick="configureRDP()">Configurar RDP</button>
                    <div id="rdpConfig" style="margin-top: 20px;">
                        <h4>Configurações RDP</h4>
                        <input type="number" id="rdpPort" placeholder="Porta RDP (padrão: 3389)">
                        <button onclick="updateRDPPort()">Atualizar Porta</button>
                    </div>
                </div>
            </div>

            <div id="VNC" class="tab-content">
                <div class="card">
                    <h3>Controle VNC</h3>
                    <div id="vncStatus"></div>
                    <button onclick="startVNC()">Iniciar VNC</button>
                    <button onclick="stopVNC()" class="danger">Parar VNC</button>
                    <button onclick="configureVNC()">Configurar VNC</button>
                    <div id="vncConfig" style="margin-top: 20px;">
                        <h4>Configurações VNC</h4>
                        <input type="number" id="vncPort" placeholder="Porta VNC (padrão: 5900)">
                        <input type="password" id="vncPassword" placeholder="Senha VNC">
                        <button onclick="updateVNCPort()">Atualizar Configurações</button>
                    </div>
                </div>
            </div>

            <div id="AnyDesk" class="tab-content">
                <div class="card">
                    <h3>Controle AnyDesk</h3>
                    <div id="anydeskStatus"></div>
                    <button onclick="startAnyDesk()">Iniciar AnyDesk</button>
                    <button onclick="stopAnyDesk()" class="danger">Parar AnyDesk</button>
                    <button onclick="getAnyDeskID()">Obter ID AnyDesk</button>
                    <div id="anydeskInfo" style="margin-top: 20px;"></div>
                </div>
            </div>

            <div id="TeamViewer" class="tab-content">
                <div class="card">
                    <h3>Controle TeamViewer</h3>
                    <div id="teamviewerStatus"></div>
                    <button onclick="startTeamViewer()">Iniciar TeamViewer</button>
                    <button onclick="stopTeamViewer()" class="danger">Parar TeamViewer</button>
                    <button onclick="getTeamViewerID()">Obter ID TeamViewer</button>
                    <div id="teamviewerInfo" style="margin-top: 20px;"></div>
                </div>
            </div>

            <div id="ChromeRD" class="tab-content">
                <div class="card">
                    <h3>Chrome Remote Desktop</h3>
                    <div id="chromeStatus"></div>
                    <button onclick="setupChromeRD()">Configurar Chrome Remote Desktop</button>
                    <button onclick="startChromeRD()">Iniciar Sessão</button>
                    <button onclick="stopChromeRD()" class="danger">Parar Sessão</button>
                    <div id="chromeInfo" style="margin-top: 20px;"></div>
                </div>
            </div>

            <div id="Sessions" class="tab-content">
                <div class="card">
                    <h3>Sessões de Acesso Remoto</h3>
                    <div id="sessionList" class="session-list"></div>
                    <button onclick="refreshSessions()">Atualizar Lista</button>
                    <button onclick="clearOldSessions()" class="danger">Limpar Sessões Antigas</button>
                </div>
            </div>

            <div id="Security" class="tab-content">
                <div class="grid">
                    <div class="card">
                        <h3>Configurações de Segurança</h3>
                        <div id="securitySettings"></div>
                        <button onclick="updateSecuritySettings()">Atualizar Configurações</button>
                    </div>
                    <div class="card">
                        <h3>Monitoramento de Sessões</h3>
                        <div id="sessionMonitoring"></div>
                        <button onclick="enableSessionRecording()">Habilitar Gravação</button>
                        <button onclick="disableSessionRecording()" class="danger">Desabilitar Gravação</button>
                    </div>
                </div>
            </div>

            <div id="Settings" class="tab-content">
                <div class="card">
                    <h3>Configurações Gerais</h3>
                    <div id="generalSettings"></div>
                    <button onclick="saveSettings()">Salvar Configurações</button>
                    <button onclick="resetSettings()" class="danger">Restaurar Padrões</button>
                </div>
            </div>
        </div>

        <script>
            function openTab(evt, tabName) {
                var i, tabcontent, tablinks;
                tabcontent = document.getElementsByClassName("tab-content");
                for (i = 0; i < tabcontent.length; i++) {
                    tabcontent[i].style.display = "none";
                }
                tablinks = document.getElementsByClassName("tab");
                for (i = 0; i < tablinks.length; i++) {
                    tablinks[i].className = tablinks[i].className.replace(" active", "");
                }
                document.getElementById(tabName).style.display = "block";
                evt.currentTarget.className += " active";
            }

            // Initialize
            document.getElementsByClassName('tab')[0].click();

            // Load initial data
            setInterval(loadSystemInfo, 5000);
            setInterval(loadToolsStatus, 10000);
            setInterval(loadActiveSessions, 3000);
            setInterval(loadCurrentConfig, 10000);

            async function loadSystemInfo() {
                try {
                    const response = await fetch('/api/system_info');
                    const data = await response.json();
                    document.getElementById('systemInfo').innerHTML = `
                        <div><strong>Sistema:</strong> ${data.os}</div>
                        <div><strong>Versão:</strong> ${data.version}</div>
                        <div><strong>Hostname:</strong> ${data.hostname}</div>
                        <div><strong>IP:</strong> ${data.ip_address}</div>
                    `;
                } catch (error) {
                    console.error('Erro ao carregar informações do sistema:', error);
                }
            }

            async function loadToolsStatus() {
                try {
                    const response = await fetch('/api/tools_status');
                    const data = await response.json();
                    let html = '';
                    for (const [tool, status] of Object.entries(data)) {
                        const statusClass = status ? 'status-online' : 'status-offline';
                        const statusText = status ? 'Ativo' : 'Inativo';
                        html += `<div><span class="status-indicator ${statusClass}"></span>${tool.toUpperCase()}: ${statusText}</div>`;
                    }
                    document.getElementById('toolsStatus').innerHTML = html;
                } catch (error) {
                    console.error('Erro ao carregar status das ferramentas:', error);
                }
            }

            async function loadActiveSessions() {
                try {
                    const response = await fetch('/api/active_sessions');
                    const data = await response.json();
                    document.getElementById('activeSessions').innerHTML = `
                        <div><strong>Sessões Ativas:</strong> ${data.count}</div>
                        <div><strong>Última Atividade:</strong> ${data.last_activity || 'Nenhuma'}</div>
                    `;
                } catch (error) {
                    console.error('Erro ao carregar sessões ativas:', error);
                }
            }

            async function loadCurrentConfig() {
                try {
                    const response = await fetch('/api/remote_config');
                    const data = await response.json();
                    document.getElementById('currentConfig').innerHTML = `
                        <div><strong>Acesso Remoto:</strong> ${data.enabled ? 'Habilitado' : 'Desabilitado'}</div>
                        <div><strong>Porta RDP:</strong> ${data.port}</div>
                        <div><strong>Porta VNC:</strong> ${data.vnc_port}</div>
                        <div><strong>2FA:</strong> ${data.security.require_2fa ? 'Obrigatório' : 'Opcional'}</div>
                    `;
                } catch (error) {
                    console.error('Erro ao carregar configuração:', error);
                }
            }

            // RDP functions
            async function startRDP() {
                const response = await fetch('/api/rdp/start', { method: 'POST' });
                const data = await response.json();
                alert(data.message);
                loadToolsStatus();
            }

            async function stopRDP() {
                const response = await fetch('/api/rdp/stop', { method: 'POST' });
                const data = await response.json();
                alert(data.message);
                loadToolsStatus();
            }

            async function configureRDP() {
                const port = document.getElementById('rdpPort').value;
                const response = await fetch('/api/rdp/configure', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({port: port})
                });
                const data = await response.json();
                alert(data.message);
            }

            // VNC functions
            async function startVNC() {
                const response = await fetch('/api/vnc/start', { method: 'POST' });
                const data = await response.json();
                alert(data.message);
                loadToolsStatus();
            }

            async function stopVNC() {
                const response = await fetch('/api/vnc/stop', { method: 'POST' });
                const data = await response.json();
                alert(data.message);
                loadToolsStatus();
            }

            async function configureVNC() {
                const port = document.getElementById('vncPort').value;
                const password = document.getElementById('vncPassword').value;
                const response = await fetch('/api/vnc/configure', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({port: port, password: password})
                });
                const data = await response.json();
                alert(data.message);
            }

            // AnyDesk functions
            async function startAnyDesk() {
                const response = await fetch('/api/anydesk/start', { method: 'POST' });
                const data = await response.json();
                alert(data.message);
                loadToolsStatus();
            }

            async function stopAnyDesk() {
                const response = await fetch('/api/anydesk/stop', { method: 'POST' });
                const data = await response.json();
                alert(data.message);
                loadToolsStatus();
            }

            async function getAnyDeskID() {
                const response = await fetch('/api/anydesk/id');
                const data = await response.json();
                document.getElementById('anydeskInfo').innerHTML = `
                    <div><strong>ID AnyDesk:</strong> ${data.id}</div>
                    <div><strong>Status:</strong> ${data.status}</div>
                `;
            }

            // TeamViewer functions
            async function startTeamViewer() {
                const response = await fetch('/api/teamviewer/start', { method: 'POST' });
                const data = await response.json();
                alert(data.message);
                loadToolsStatus();
            }

            async function stopTeamViewer() {
                const response = await fetch('/api/teamviewer/stop', { method: 'POST' });
                const data = await response.json();
                alert(data.message);
                loadToolsStatus();
            }

            async function getTeamViewerID() {
                const response = await fetch('/api/teamviewer/id');
                const data = await response.json();
                document.getElementById('teamviewerInfo').innerHTML = `
                    <div><strong>ID TeamViewer:</strong> ${data.id}</div>
                    <div><strong>Status:</strong> ${data.status}</div>
                `;
            }

            // Chrome Remote Desktop functions
            async function setupChromeRD() {
                const response = await fetch('/api/chrome/setup', { method: 'POST' });
                const data = await response.json();
                alert(data.message);
            }

            async function startChromeRD() {
                const response = await fetch('/api/chrome/start', { method: 'POST' });
                const data = await response.json();
                alert(data.message);
                loadToolsStatus();
            }

            async function stopChromeRD() {
                const response = await fetch('/api/chrome/stop', { method: 'POST' });
                const data = await response.json();
                alert(data.message);
                loadToolsStatus();
            }

            // Session management
            async function refreshSessions() {
                const response = await fetch('/api/sessions');
                const data = await response.json();
                const sessionList = document.getElementById('sessionList');
                sessionList.innerHTML = data.map(session => `
                    <div class="session-item">
                        <div>
                            <strong>${session.session_type}</strong><br>
                            <small>Usuário: ${session.username} | IP: ${session.client_ip} | Início: ${session.start_time}</small>
                        </div>
                        <button onclick="terminateSession('${session.id}')" class="danger">Terminar</button>
                    </div>
                `).join('');
            }

            async function terminateSession(sessionId) {
                const response = await fetch('/api/sessions/terminate', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({session_id: sessionId})
                });
                const data = await response.json();
                alert(data.message);
                refreshSessions();
            }

            async function clearOldSessions() {
                const response = await fetch('/api/sessions/clear_old', { method: 'POST' });
                const data = await response.json();
                alert(data.message);
                refreshSessions();
            }

            // Security functions
            async function updateSecuritySettings() {
                const response = await fetch('/api/security/update', { method: 'POST' });
                const data = await response.json();
                alert(data.message);
            }

            async function enableSessionRecording() {
                const response = await fetch('/api/security/enable_recording', { method: 'POST' });
                const data = await response.json();
                alert(data.message);
            }

            async function disableSessionRecording() {
                const response = await fetch('/api/security/disable_recording', { method: 'POST' });
                const data = await response.json();
                alert(data.message);
            }

            // Settings functions
            async function saveSettings() {
                const response = await fetch('/api/settings/save', { method: 'POST' });
                const data = await response.json();
                alert(data.message);
            }

            async function resetSettings() {
                if (confirm('Tem certeza que deseja restaurar as configurações padrão?')) {
                    const response = await fetch('/api/settings/reset', { method: 'POST' });
                    const data = await response.json();
                    alert(data.message);
                }
            }

            // Load initial data
            loadSystemInfo();
            loadToolsStatus();
            loadActiveSessions();
            loadCurrentConfig();
            refreshSessions();
        </script>
    </body>
    </html>
    """
    return render_template_string(html)

# API endpoints for remote access functionality

@app.route('/api/system_info')
@login_required
def api_system_info():
    return jsonify(get_system_info())

@app.route('/api/tools_status')
@login_required
def api_tools_status():
    return jsonify(check_remote_tools())

@app.route('/api/active_sessions')
@login_required
def api_active_sessions():
    return jsonify({
        'count': len(active_sessions),
        'last_activity': max([s.get('start_time', '') for s in active_sessions.values()] or [''])
    })

@app.route('/api/remote_config')
@login_required
def api_remote_config():
    return jsonify(remote_config)

@app.route('/api/rdp/start', methods=['POST'])
@login_required
def api_rdp_start():
    try:
        if platform.system() == 'Windows':
            # Enable RDP on Windows
            subprocess.run(['reg', 'add', 'HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Terminal Server', '/v', 'fDenyTSConnections', '/t', 'REG_DWORD', '/d', '0', '/f'])
            subprocess.run(['net', 'start', 'termservice'])
        else:
            # Linux RDP setup (xrdp)
            subprocess.run(['sudo', 'systemctl', 'start', 'xrdp'])
        return jsonify({'message': 'RDP iniciado com sucesso'})
    except Exception as e:
        return jsonify({'message': f'Erro ao iniciar RDP: {str(e)}'})

@app.route('/api/rdp/stop', methods=['POST'])
@login_required
def api_rdp_stop():
    try:
        if platform.system() == 'Windows':
            subprocess.run(['net', 'stop', 'termservice'])
        else:
            subprocess.run(['sudo', 'systemctl', 'stop', 'xrdp'])
        return jsonify({'message': 'RDP parado com sucesso'})
    except Exception as e:
        return jsonify({'message': f'Erro ao parar RDP: {str(e)}'})

@app.route('/api/rdp/configure', methods=['POST'])
@login_required
def api_rdp_configure():
    data = request.get_json()
    port = data.get('port', 3389)
    remote_config['port'] = port
    # Save configuration logic here
    return jsonify({'message': f'Porta RDP configurada para {port}'})

@app.route('/api/vnc/start', methods=['POST'])
@login_required
def api_vnc_start():
    try:
        if platform.system() == 'Linux':
            subprocess.run(['sudo', 'systemctl', 'start', 'vncserver@:1.service'])
        # For other systems, implement appropriate VNC start logic
        return jsonify({'message': 'VNC iniciado com sucesso'})
    except Exception as e:
        return jsonify({'message': f'Erro ao iniciar VNC: {str(e)}'})

@app.route('/api/vnc/stop', methods=['POST'])
@login_required
def api_vnc_stop():
    try:
        if platform.system() == 'Linux':
            subprocess.run(['sudo', 'systemctl', 'stop', 'vncserver@:1.service'])
        return jsonify({'message': 'VNC parado com sucesso'})
    except Exception as e:
        return jsonify({'message': f'Erro ao parar VNC: {str(e)}'})

@app.route('/api/vnc/configure', methods=['POST'])
@login_required
def api_vnc_configure():
    data = request.get_json()
    port = data.get('port', 5900)
    password = data.get('password', '')
    remote_config['vnc_port'] = port
    # Save VNC password configuration
    return jsonify({'message': 'Configurações VNC atualizadas'})

@app.route('/api/anydesk/start', methods=['POST'])
@login_required
def api_anydesk_start():
    try:
        subprocess.run(['anydesk'], check=True)
        return jsonify({'message': 'AnyDesk iniciado com sucesso'})
    except Exception as e:
        return jsonify({'message': f'Erro ao iniciar AnyDesk: {str(e)}'})

@app.route('/api/anydesk/stop', methods=['POST'])
@login_required
def api_anydesk_stop():
    try:
        subprocess.run(['pkill', '-f', 'anydesk'], check=True)
        return jsonify({'message': 'AnyDesk parado com sucesso'})
    except Exception as e:
        return jsonify({'message': f'Erro ao parar AnyDesk: {str(e)}'})

@app.route('/api/anydesk/id')
@login_required
def api_anydesk_id():
    try:
        # This is a simplified implementation - in reality, you'd need to query AnyDesk
        result = subprocess.run(['anydesk', '--get-id'], capture_output=True, text=True)
        anydesk_id = result.stdout.strip()
        return jsonify({'id': anydesk_id, 'status': 'success'})
    except Exception as e:
        return jsonify({'id': 'Não disponível', 'status': 'error', 'message': str(e)})

@app.route('/api/teamviewer/start', methods=['POST'])
@login_required
def api_teamviewer_start():
    try:
        subprocess.run(['teamviewer'], check=True)
        return jsonify({'message': 'TeamViewer iniciado com sucesso'})
    except Exception as e:
        return jsonify({'message': f'Erro ao iniciar TeamViewer: {str(e)}'})

@app.route('/api/teamviewer/stop', methods=['POST'])
@login_required
def api_teamviewer_stop():
    try:
        subprocess.run(['pkill', '-f', 'teamviewer'], check=True)
        return jsonify({'message': 'TeamViewer parado com sucesso'})
    except Exception as e:
        return jsonify({'message': f'Erro ao parar TeamViewer: {str(e)}'})

@app.route('/api/teamviewer/id')
@login_required
def api_teamviewer_id():
    try:
        # Simplified TeamViewer ID retrieval
        result = subprocess.run(['teamviewer', '--info'], capture_output=True, text=True)
        # Parse TeamViewer ID from output
        teamviewer_id = '123456789'  # Placeholder - implement actual parsing
        return jsonify({'id': teamviewer_id, 'status': 'success'})
    except Exception as e:
        return jsonify({'id': 'Não disponível', 'status': 'error', 'message': str(e)})

@app.route('/api/chrome/setup', methods=['POST'])
@login_required
def api_chrome_setup():
    try:
        # Chrome Remote Desktop setup commands
        if platform.system() == 'Linux':
            subprocess.run(['wget', 'https://dl.google.com/linux/direct/chrome-remote-desktop_current_amd64.deb'])
            subprocess.run(['sudo', 'dpkg', '-i', 'chrome-remote-desktop_current_amd64.deb'])
        return jsonify({'message': 'Chrome Remote Desktop configurado com sucesso'})
    except Exception as e:
        return jsonify({'message': f'Erro ao configurar Chrome Remote Desktop: {str(e)}'})

@app.route('/api/chrome/start', methods=['POST'])
@login_required
def api_chrome_start():
    try:
        subprocess.run(['sudo', 'systemctl', 'start', 'chrome-remote-desktop@USER.service'])
        return jsonify({'message': 'Chrome Remote Desktop iniciado'})
    except Exception as e:
        return jsonify({'message': f'Erro ao iniciar Chrome Remote Desktop: {str(e)}'})

@app.route('/api/chrome/stop', methods=['POST'])
@login_required
def api_chrome_stop():
    try:
        subprocess.run(['sudo', 'systemctl', 'stop', 'chrome-remote-desktop@USER.service'])
        return jsonify({'message': 'Chrome Remote Desktop parado'})
    except Exception as e:
        return jsonify({'message': f'Erro ao parar Chrome Remote Desktop: {str(e)}'})

@app.route('/api/sessions')
@login_required
def api_sessions():
    try:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT rs.id, u.username, rs.start_time, rs.client_ip, rs.session_type, rs.status
            FROM remote_sessions rs
            JOIN users u ON rs.user_id = u.id
            WHERE rs.end_time IS NULL
            ORDER BY rs.start_time DESC
        """)
        sessions = []
        for row in cursor.fetchall():
            sessions.append({
                'id': row[0],
                'username': row[1],
                'start_time': row[2],
                'client_ip': row[3],
                'session_type': row[4],
                'status': row[5]
            })
        conn.close()
        return jsonify(sessions)
    except Exception as e:
        return jsonify({'error': str(e)})

@app.route('/api/sessions/terminate', methods=['POST'])
@login_required
def api_terminate_session():
    data = request.get_json()
    session_id = data.get('session_id')
    try:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        cursor.execute("UPDATE remote_sessions SET end_time = ?, status = 'terminated' WHERE id = ?",
                      (datetime.now().isoformat(), session_id))
        conn.commit()
        conn.close()
        if session_id in active_sessions:
            del active_sessions[session_id]
            save_remote_sessions()
        return jsonify({'message': 'Sessão terminada com sucesso'})
    except Exception as e:
        return jsonify({'message': f'Erro ao terminar sessão: {str(e)}'})

@app.route('/api/sessions/clear_old', methods=['POST'])
@login_required
def api_clear_old_sessions():
    try:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        # Clear sessions older than 24 hours
        cutoff_time = datetime.now().isoformat()
        cursor.execute("UPDATE remote_sessions SET status = 'expired' WHERE start_time < datetime('now', '-1 day') AND end_time IS NULL")
        conn.commit()
        conn.close()
        return jsonify({'message': 'Sessões antigas limpas com sucesso'})
    except Exception as e:
        return jsonify({'message': f'Erro ao limpar sessões antigas: {str(e)}'})

@app.route('/api/security/update', methods=['POST'])
@login_required
def api_security_update():
    # Update security settings
    return jsonify({'message': 'Configurações de segurança atualizadas'})

@app.route('/api/security/enable_recording', methods=['POST'])
@login

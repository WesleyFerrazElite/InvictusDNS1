"""
================================================================================
                    INVICTUSDNS - SISTEMA COMPLETO DE GERENCIAMENTO
================================================================================

SISTEMA DE PAINÉIS E PORTAS ORGANIZADO:

🔥 FIREWALL & CONTROLE DE REDE (Porta 3000 - Este arquivo)
================================================================================
- Controle de Portas TCP/UDP (iptables)
- Firewall avançado com regras dinâmicas
- Monitoramento de portas abertas/fechadas
- Bloqueio de IPs e domínios
- Sistema de ofuscação visual de IPs
- Dashboard principal com métricas em tempo real

🤖 INTELIGÊNCIA ARTIFICIAL (Porta 3002)
================================================================================
- Painel de IA completo (/ai_panel)
- Detecção de anomalias ML
- Categorização automática de ameaças
- Análise comportamental de tráfego
- Previsão de ataques
- Relatórios inteligentes

☁️ NUVEM & BACKUP (Porta 3003)
================================================================================
- InvictusCloud - Sistema de backup na nuvem
- Gerenciamento de usuários e quotas
- Criptografia AES para dados
- Sincronização automática
- Recuperação de desastres

🌐 CONFIGURAÇÃO DE REDE AVANÇADA (Porta 3004)
================================================================================
- VPN (OpenVPN, WireGuard)
- PPPoE/Bridge/VLAN
- DHCP Server avançado
- DNS Server com cache inteligente
- QoS e controle de banda
- Firewall de rede completo

📱 APLICATIVOS MÓVEIS (Portas 3005-3006)
================================================================================
- API REST completa para mobile
- Autenticação avançada
- Apps Flutter/Kotlin
- Notificações push
- Controle parental móvel

🔒 SEGURANÇA AVANÇADA (Portas 3007-3008)
================================================================================
- Criptografia quântica
- Autenticação biométrica
- Detecção de root/jailbreak
- Honeypots inteligentes
- Análise forense

📊 MONITORAMENTO & METRICS (Porta 3009)
================================================================================
- Dashboard de métricas em tempo real
- Detecção de anomalias
- Alertas inteligentes
- Relatórios automatizados
- Analytics de performance

🎯 OUTROS SERVIÇOS (Portas 3010+)
================================================================================
- API de comunicação interna
- Serviços de cache Redis
- Message queues
- Load balancers
- Microserviços especializados

================================================================================
ESTRUTURA DE DIRETÓRIOS:
================================================================================
InvictusDNS/
├── agents/           # Sistema de agentes IA
├── monitoring/       # Dashboards e métricas
├── security/         # Módulos de segurança
├── utils/            # Utilitários (ip_obfuscator.py)
├── panels/           # Painéis web (este arquivo)
├── data/             # Bancos de dados e logs
├── logs/             # Arquivos de log
└── data_backup/      # Backups automáticos

================================================================================
BANCO DE DADOS PRINCIPAL: data/dns_logs.db
================================================================================
- dns_logs: Logs de consultas DNS
- blocked_domains: Domínios bloqueados
- blocked_ips: IPs bloqueados
- users: Sistema de usuários
- traffic_logs: Logs de tráfego
- data_usage: Controle de uso de dados
"""

from flask import Flask, render_template_string, request, Response, jsonify, session, redirect, url_for, flash
import sqlite3
from functools import wraps
import psutil
import threading
import time
import os
import subprocess
import socket
from werkzeug.security import generate_password_hash, check_password_hash

# Importar sistema de ofuscação de IP (FIREWALL - Porta 3000)
try:
    from utils.ip_obfuscator import obfuscate_ip, deobfuscate_ip
except ImportError:
    def obfuscate_ip(ip): return ip
    def deobfuscate_ip(symbols): return symbols

app = Flask(__name__)
app.secret_key = 'supersecretkey'

DESKTOP_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data')
DB_FILE = os.path.join(DESKTOP_DIR, 'dns_logs.db')
LOG_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'logs')
DATA_BACKUP_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data_backup')
USERS_DB_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data', 'users')

def init_db():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS dns_logs (
                    id INTEGER PRIMARY KEY,
                    timestamp TEXT,
                    client_ip TEXT,
                    domain TEXT,
                    response_ip TEXT,
                    category TEXT
                )''')
    # Add response_time if not exists
    try:
        c.execute("ALTER TABLE dns_logs ADD COLUMN response_time REAL")
    except sqlite3.OperationalError:
        pass
    c.execute('''CREATE TABLE IF NOT EXISTS blocked_domains (
                    id INTEGER PRIMARY KEY,
                    domain TEXT,
                    user_id INTEGER
                )''')
    c.execute('''CREATE TABLE IF NOT EXISTS blocked_ips (
                    id INTEGER PRIMARY KEY,
                    ip TEXT,
                    user_id INTEGER
                )''')
    c.execute('''CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY,
                    username TEXT UNIQUE,
                    password_hash TEXT,
                    role TEXT DEFAULT 'user',
                    ips TEXT
                )''')
    c.execute('''CREATE TABLE IF NOT EXISTS traffic_logs (
                    id INTEGER PRIMARY KEY,
                    timestamp TEXT,
                    src_ip TEXT,
                    dst_ip TEXT,
                    src_port INTEGER,
                    dst_port INTEGER,
                    protocol TEXT,
                    length INTEGER,
                    info TEXT
                )''')
    # Insert admin if not exists
    c.execute("SELECT COUNT(*) FROM users WHERE username = 'admin'")
    if c.fetchone()[0] == 0:
        c.execute("INSERT INTO users (username, password_hash, role, ips) VALUES (?, ?, ?, ?)",
                  ('admin', generate_password_hash('senha123'), 'admin', ''))
    conn.commit()
    conn.close()

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

def get_current_user():
    if 'user_id' in session:
        conn = sqlite3.connect(DB_FILE)
        c = conn.cursor()
        c.execute("SELECT id, username, role, ips FROM users WHERE id = ?", (session['user_id'],))
        user = c.fetchone()
        conn.close()
        return user
    return None

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = sqlite3.connect(DB_FILE, timeout=30, check_same_thread=False)
        c = conn.cursor()
        c.execute("SELECT id, password_hash FROM users WHERE username = ?", (username,))
        user = c.fetchone()
        conn.close()
        if user and check_password_hash(user[1], password):
            session['user_id'] = user[0]
            return redirect(url_for('dashboard'))
        flash('Credenciais inválidas')
    html = """
    <!DOCTYPE html>
    <html>
    <head><title>Login</title></head>
    <body>
        <h1>Login InvictusDNS</h1>
        <form method="post">
            <input type="text" name="username" placeholder="Usuário" required><br>
            <input type="password" name="password" placeholder="Senha" required><br>
            <button type="submit">Login</button>
        </form>
    </body>
    </html>
    """
    return html

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    return redirect(url_for('login'))

# Get server usage info
import time

# Cache simples para uso do servidor para evitar consultas frequentes ao banco
_server_usage_cache = None
_server_usage_cache_time = 0
_cache_duration = 5  # segundos

def get_server_usage():
    global _server_usage_cache, _server_usage_cache_time
    now = time.time()
    if _server_usage_cache and (now - _server_usage_cache_time) < _cache_duration:
        return _server_usage_cache
    cpu = psutil.cpu_percent(interval=1)
    mem = psutil.virtual_memory()
    mem_percent = mem.percent
    net = psutil.net_io_counters()
    net_sent = net.bytes_sent / (1024**2)  # MB
    net_recv = net.bytes_recv / (1024**2)  # MB
    usage = {'cpu': cpu, 'memory': mem_percent, 'net_sent': net_sent, 'net_recv': net_recv}
    _server_usage_cache = usage
    _server_usage_cache_time = now
    return usage

@app.route('/api/server_usage')
@login_required
def api_server_usage():
    usage = get_server_usage()
    init_db()
    conn = sqlite3.connect(DB_FILE, timeout=30, check_same_thread=False)
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM dns_logs")
    total_queries = c.fetchone()[0]
    c.execute("SELECT AVG(response_time) FROM dns_logs WHERE response_time IS NOT NULL")
    avg_response = c.fetchone()[0] or 0
    c.execute("SELECT COUNT(*) FROM dns_logs WHERE category = 'threat'")
    total_blocked = c.fetchone()[0]
    conn.close()
    usage['total_queries'] = total_queries
    usage['avg_response'] = avg_response
    usage['total_blocked'] = total_blocked
    return jsonify(usage)

@app.route('/api/ai_activities')
@login_required
def api_ai_activities():
    init_db()
    conn = sqlite3.connect(DB_FILE, timeout=30, check_same_thread=False)
    c = conn.cursor()
    c.execute("SELECT timestamp, client_ip, domain, category FROM dns_logs ORDER BY id DESC LIMIT 10")
    activities = c.fetchall()
    conn.close()
    ai_activities = []
    for act in activities:
        category = act[3] or 'unknown'
        if category == 'threat':
            action = f"IA bloqueou ameaça: {act[2]} de {act[1]}"
        else:
            action = f"IA resolveu consulta para {act[2]} de {act[1]}, categorizou como '{category}'"
        ai_activities.append({
            'timestamp': act[0],
            'client_ip': act[1],
            'domain': act[2],
            'category': category,
            'action': action
        })
    return jsonify(ai_activities)

@app.route('/api/logs')
@login_required
def api_logs():
    user = get_current_user()
    init_db()
    conn = sqlite3.connect(DB_FILE, timeout=30, check_same_thread=False)
    c = conn.cursor()
    if user[2] == 'admin':
        # Limitar logs para performance - últimos 500 registros
        c.execute("SELECT timestamp, client_ip, domain, response_ip, category, response_time FROM dns_logs ORDER BY id DESC LIMIT 500")
    else:
        ips = user[3] if len(user) > 3 else ''
        if ips:
            ip_list = [ip.strip() for ip in ips.split(',')]
            placeholders = ','.join('?' * len(ip_list))
            c.execute(f"SELECT timestamp, client_ip, domain, response_ip, category, response_time FROM dns_logs WHERE client_ip IN ({placeholders}) ORDER BY id DESC LIMIT 500", ip_list)
        else:
            c.execute("SELECT timestamp, client_ip, domain, response_ip, category, response_time FROM dns_logs WHERE 1=0")
    logs = c.fetchall()
    conn.close()
    return jsonify(logs)

@app.route('/api/data_usage')
@login_required
def api_data_usage():
    user = get_current_user()
    init_db()
    conn = sqlite3.connect(DB_FILE, timeout=30, check_same_thread=False)
    c = conn.cursor()
    if user[2] == 'admin':
        c.execute("SELECT ip, SUM(data_mb) FROM data_usage GROUP BY ip ORDER BY SUM(data_mb) DESC")
    else:
        ips = user[3] if len(user) > 3 else ''
        if ips:
            ip_list = [ip.strip() for ip in ips.split(',')]
            placeholders = ','.join('?' * len(ip_list))
            c.execute(f"SELECT ip, SUM(data_mb) FROM data_usage WHERE ip IN ({placeholders}) GROUP BY ip ORDER BY SUM(data_mb) DESC", ip_list)
        else:
            c.execute("SELECT ip, SUM(data_mb) FROM data_usage WHERE 1=0")
    usage = dict(c.fetchall())
    conn.close()
    return jsonify(usage)

@app.route('/api/traffic_logs')
@login_required
def api_traffic_logs():
    user = get_current_user()
    if user[2] != 'admin':
        return jsonify([]), 403
    init_db()
    conn = sqlite3.connect(DB_FILE, timeout=30, check_same_thread=False)
    c = conn.cursor()
    # Limitar logs de tráfego para performance - últimos 200 registros
    c.execute("SELECT timestamp, src_ip, dst_ip, src_port, dst_port, protocol, length, info FROM traffic_logs ORDER BY id DESC LIMIT 200")
    logs = c.fetchall()
    conn.close()
    return jsonify(logs)

@app.route('/api/connected_devices')
@login_required
def api_connected_devices():
    user = get_current_user()
    if user[2] != 'admin':
        return jsonify({'total': 0, 'devices': []}), 403
    init_db()
    conn = sqlite3.connect(DB_FILE, timeout=30, check_same_thread=False)
    c = conn.cursor()
    # Pegar IPs únicos que fizeram consultas nas últimas 24 horas
    c.execute("SELECT DISTINCT client_ip, MAX(timestamp) as last_seen, COUNT(*) as queries FROM dns_logs WHERE timestamp > datetime('now', '-1 day') GROUP BY client_ip ORDER BY last_seen DESC")
    devices = c.fetchall()
    conn.close()

    # Estimar tipo de dispositivo baseado em domínios consultados
    device_list = []
    for ip, last_seen, queries in devices:
        device_type = 'Desconhecido'
        # Verificar se consultou domínios típicos de mobile
        conn = sqlite3.connect(DB_FILE, timeout=30, check_same_thread=False)
        c = conn.cursor()
        c.execute("SELECT domain FROM dns_logs WHERE client_ip = ? AND timestamp > datetime('now', '-1 day')", (ip,))
        domains = [row[0] for row in c.fetchall()]
        conn.close()

        mobile_domains = ['play.google.com', 'itunes.apple.com', 'appstore', 'mobile', 'android', 'ios', 'whatsapp', 'telegram', 'instagram', 'facebook']
        if any(any(md in d.lower() for md in mobile_domains) for d in domains):
            device_type = 'Celular/Mobile'
        elif any('steam' in d.lower() or 'epic' in d.lower() for d in domains):
            device_type = 'Computador/Gaming'
        else:
            device_type = 'Computador'

        device_list.append({
            'ip': ip,
            'last_seen': last_seen,
            'queries': queries,
            'type': device_type
        })

    return jsonify({
        'total': len(device_list),
        'devices': device_list
    })

@app.route('/api/ai_command', methods=['POST'])
@login_required
def ai_command():
    user = get_current_user()
    if user[2] != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403
    data = request.get_json()
    command = data.get('command')
    target = data.get('target')
    init_db()
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    if command == 'block_domain':
        c.execute("INSERT OR IGNORE INTO blocked_domains (domain, user_id) VALUES (?, ?)", (target, user[0]))
    elif command == 'unblock_domain':
        c.execute("DELETE FROM blocked_domains WHERE domain = ?", (target,))
    elif command == 'block_ip':
        c.execute("INSERT OR IGNORE INTO blocked_ips (ip, user_id) VALUES (?, ?)", (target, user[0]))
    elif command == 'unblock_ip':
        c.execute("DELETE FROM blocked_ips WHERE ip = ?", (target,))
    conn.commit()
    conn.close()
    return jsonify({'status': 'success'})

# ================================================================================
# 🔥 FIREWALL - CONTROLE DE PORTAS TCP/UDP (Porta 3000)
# ================================================================================
@app.route('/api/port_control', methods=['GET', 'POST'])
@login_required
def api_port_control():
    """
    API para controle de portas TCP/UDP via iptables
    - GET: Lista portas abertas no sistema
    - POST: Abre/fecha portas no firewall
    """
    user = get_current_user()
    if user[2] != 'admin':
        return jsonify({'error': 'Unauthorized - Apenas admin pode controlar portas'}), 403

    if request.method == 'GET':
        # Listar portas abertas usando netstat
        try:
            result = subprocess.run(['netstat', '-tuln'], capture_output=True, text=True, timeout=10)
            lines = result.stdout.split('\n')
            ports = []
            for line in lines[2:]:  # Skip headers
                if line.strip():
                    parts = line.split()
                    if len(parts) >= 4:
                        proto = parts[0]
                        local_addr = parts[3]
                        if ':' in local_addr:
                            port = local_addr.split(':')[-1]
                            if port.isdigit():
                                ports.append({
                                    'protocol': proto,
                                    'port': int(port),
                                    'status': 'LISTEN' if 'LISTEN' in line else 'OPEN'
                                })
            return jsonify({'ports': ports})
        except Exception as e:
            return jsonify({'error': f'Erro ao listar portas: {str(e)}'}), 500

    elif request.method == 'POST':
        data = request.get_json()
        action = data.get('action')  # 'open' ou 'close'
        port = data.get('port')
        protocol = data.get('protocol', 'tcp')

        if not port or not action:
            return jsonify({'error': 'Porta e ação são obrigatórias'}), 400

        try:
            if action == 'open':
                # Abrir porta no firewall iptables
                if protocol.lower() == 'tcp':
                    subprocess.run(['iptables', '-I', 'INPUT', '-p', 'tcp', '--dport', str(port), '-j', 'ACCEPT'], check=True)
                elif protocol.lower() == 'udp':
                    subprocess.run(['iptables', '-I', 'INPUT', '-p', 'udp', '--dport', str(port), '-j', 'ACCEPT'], check=True)
                else:
                    return jsonify({'error': 'Protocolo deve ser TCP ou UDP'}), 400
                return jsonify({'message': f'✅ Porta {port}/{protocol} ABERTA no firewall'})

            elif action == 'close':
                # Fechar porta no firewall iptables
                if protocol.lower() == 'tcp':
                    subprocess.run(['iptables', '-D', 'INPUT', '-p', 'tcp', '--dport', str(port), '-j', 'ACCEPT'], check=True)
                elif protocol.lower() == 'udp':
                    subprocess.run(['iptables', '-D', 'INPUT', '-p', 'udp', '--dport', str(port), '-j', 'ACCEPT'], check=True)
                else:
                    return jsonify({'error': 'Protocolo deve ser TCP ou UDP'}), 400
                return jsonify({'message': f'❌ Porta {port}/{protocol} FECHADA no firewall'})

            else:
                return jsonify({'error': 'Ação deve ser "open" ou "close"'}), 400

        except subprocess.CalledProcessError as e:
            return jsonify({'error': f'Erro no iptables: {str(e)}'}), 500

    return jsonify({'error': 'Método não suportado'}), 405

# ================================================================================
# 🔥 FIREWALL - SISTEMA DE OFUSCAÇÃO DE IP (Porta 3000)
# ================================================================================
@app.route('/api/obfuscate_ip', methods=['POST'])
@login_required
def api_obfuscate_ip():
    """
    API para ofuscar IP em símbolos visuais únicos
    Converte IP normal em representação simbólica para privacidade visual
    """
    data = request.get_json()
    ip = data.get('ip')
    if not ip:
        return jsonify({'error': 'IP é obrigatório para ofuscação'}), 400

    try:
        obfuscated = obfuscate_ip(ip)
        if obfuscated == '❌':
            return jsonify({'error': 'Formato de IP inválido'}), 400
        return jsonify({
            'obfuscated': obfuscated,
            'original': ip,
            'message': f'IP {ip} ofuscado com sucesso'
        })
    except Exception as e:
        return jsonify({'error': f'Erro na ofuscação: {str(e)}'}), 500

@app.route('/api/deobfuscate_ip', methods=['POST'])
@login_required
def api_deobfuscate_ip():
    """
    API para desofuscar símbolos de volta para IP
    Converte representação simbólica de volta para IP normal
    """
    data = request.get_json()
    symbols = data.get('symbols')
    if not symbols:
        return jsonify({'error': 'Símbolos são obrigatórios para desofuscação'}), 400

    try:
        ip = deobfuscate_ip(symbols)
        if not ip:
            return jsonify({'error': 'Símbolos inválidos ou IP não encontrado'}), 400
        return jsonify({
            'ip': ip,
            'symbols': symbols,
            'message': f'Símbolos desofuscados para IP {ip}'
        })
    except Exception as e:
        return jsonify({'error': f'Erro na desofuscação: {str(e)}'}), 500

@app.route('/dashboard')
@login_required
def dashboard():
    user = get_current_user()
    init_db()
    conn = sqlite3.connect(DB_FILE, timeout=30, check_same_thread=False)
    c = conn.cursor()
    if user[2] == 'admin':
        c.execute("SELECT timestamp, client_ip, domain, response_ip, category, response_time FROM dns_logs ORDER BY id DESC LIMIT 100")
    else:
        # For user, show logs from their IPs
        ips = user[3] if len(user) > 3 else ''
        if ips:
            ip_list = [ip.strip() for ip in ips.split(',')]
            placeholders = ','.join('?' * len(ip_list))
            c.execute(f"SELECT timestamp, client_ip, domain, response_ip, category, response_time FROM dns_logs WHERE client_ip IN ({placeholders}) ORDER BY id DESC LIMIT 100", ip_list)
        else:
            c.execute("SELECT timestamp, client_ip, domain, response_ip, category, response_time FROM dns_logs WHERE 1=0")  # No logs
    logs = c.fetchall()
    conn.close()

    if user[2] == 'admin':
            # Full dashboard for admin
            tabs = """
                <div class="tab" onclick="openTab(event, 'Dashboard')">Dashboard</div>
                <div class="tab" onclick="openTab(event, 'Logs')">Logs</div>
                <div class="tab" onclick="openTab(event, 'DataUsage')">Uso de Dados</div>
                <div class="tab" onclick="openTab(event, 'Traffic')">Monitor de Tráfego</div>
                <div class="tab" onclick="openTab(event, 'Devices')">Dispositivos Conectados</div>
                <div class="tab" onclick="openTab(event, 'Network')">Rede</div>
                <div class="tab" onclick="openTab(event, 'PortControl')">Controle de Portas</div>
                <div class="tab" onclick="openTab(event, 'IPObfuscator')">Ofuscador de IP</div>
                <div class="tab" onclick="openTab(event, 'Settings')">Configurações</div>
                <div class="tab" onclick="openTab(event, 'AI')">Inteligência Artificial</div>
                <div class='tab' onclick="openTab(event, 'Users')">Usuários</div>
            """
            dashboard_content = """
            <div id="Dashboard" class="tab-content">
                <div id="dashboard">
                    <h2>📊 Dashboard - Monitoramento em Tempo Real</h2>
                    <div id="clock" style="font-size: 24px; text-align: center; margin-bottom: 20px; color: #e8eaf6;"></div>

                    <div class="grid-container">
                        <div class="metric-card">
                            <div class="metric-value" id="cpuUsage">0%</div>
                            <div class="metric-label">CPU Usage</div>
                            <div class="usage-container"><div id="cpuUsageBar" class="usage-bar"></div></div>
                        </div>
                        <div class="metric-card">
                            <div class="metric-value" id="memUsage">0%</div>
                            <div class="metric-label">Memory Usage</div>
                            <div class="usage-container"><div id="memUsageBar" class="usage-bar"></div></div>
                        </div>
                        <div class="metric-card">
                            <div class="metric-value" id="totalQueries">0</div>
                            <div class="metric-label">DNS Queries</div>
                        </div>
                        <div class="metric-card">
                            <div class="metric-value" id="connectedDevices">0</div>
                            <div class="metric-label">Devices Online</div>
                        </div>
                    </div>

                    <h3>🌐 Rede</h3>
                    <div class="grid-container">
                        <div class="metric-card">
                            <div class="metric-value" id="netSent">0 MB</div>
                            <div class="metric-label">Data Sent</div>
                        </div>
                        <div class="metric-card">
                            <div class="metric-value" id="netRecv">0 MB</div>
                            <div class="metric-label">Data Received</div>
                        </div>
                        <div class="metric-card">
                            <div class="metric-value" id="avgResponse">0s</div>
                            <div class="metric-label">Avg Response Time</div>
                        </div>
                        <div class="metric-card">
                            <div class="metric-value" id="totalBlocked">0</div>
                            <div class="metric-label">Threats Blocked</div>
                        </div>
                    </div>
                </div>
            </div>
            """
            users_tab = "<div id='Users' class='tab-content'><h2>Gerenciar Usuários</h2><a href='/users'>Gerenciar</a></div>"
            script_extra = """
            function fetchServerUsage() {
                    fetch('/api/server_usage')
                    .then(response => response.json())
                    .then(data => {
                        document.getElementById('cpuUsage').textContent = data.cpu + '%';
                        document.getElementById('cpuUsageBar').style.width = data.cpu + '%';
                        document.getElementById('memUsage').textContent = data.memory + '%';
                        document.getElementById('memUsageBar').style.width = data.memory + '%';
                        document.getElementById('netSent').textContent = data.net_sent.toFixed(2) + ' MB';
                        document.getElementById('netRecv').textContent = data.net_recv.toFixed(2) + ' MB';
                        document.getElementById('totalQueries').textContent = data.total_queries;
                        document.getElementById('avgResponse').textContent = data.avg_response.toFixed(2) + 's';
                        document.getElementById('totalBlocked').textContent = data.total_blocked;
                        // Atualizar dispositivos conectados
                        fetch('/api/connected_devices')
                        .then(response => response.json())
                        .then(deviceData => {
                            document.getElementById('connectedDevices').textContent = deviceData.total;
                        });
                    });
                }
                function updateClock() {
                    const now = new Date();
                    const timeString = now.toLocaleTimeString('pt-BR', {
                        hour12: false,
                        hour: '2-digit',
                        minute: '2-digit',
                        second: '2-digit'
                    });
                    document.getElementById('clock').textContent = timeString;
                }
                function toggleSecurity(module) {
                    const toggle = event.target;
                    toggle.classList.toggle('active');
                    const label = toggle.nextElementSibling;
                    label.textContent = toggle.classList.contains('active') ? 'Ativo' : 'Inativo';

                    // Aqui você pode adicionar lógica para realmente ativar/desativar módulos
                    console.log(`${module} ${toggle.classList.contains('active') ? 'ativado' : 'desativado'}`);
                }
                function toggleAI(module) {
                    const toggle = event.target;
                    toggle.classList.toggle('active');
                    const label = toggle.nextElementSibling;
                    label.textContent = toggle.classList.contains('active') ? 'Ativo' : 'Inativo';

                    // Lógica para controlar módulos de IA
                    console.log(`IA ${module} ${toggle.classList.contains('active') ? 'ativado' : 'desativado'}`);
                }
                function connectVPN() {
                    alert('🔗 Conectando VPN... (Funcionalidade em desenvolvimento)');
                    // Lógica para conectar VPN
                }
                function connectPPPoE() {
                    alert('🌐 Iniciando PPPoE... (Funcionalidade em desenvolvimento)');
                    // Lógica para conectar PPPoE
                }
                function openVPNPanel() {
                    alert('🔗 Abrindo painel VPN... (Funcionalidade em desenvolvimento)');
                }
                function openPPPoEPanel() {
                    alert('🌐 Abrindo painel PPPoE... (Funcionalidade em desenvolvimento)');
                }
                function openDHCPPanel() {
                    alert('📡 Abrindo painel DHCP... (Funcionalidade em desenvolvimento)');
                }
                function openSatelliteMap() {
                    const container = document.getElementById('satelliteMapContainer');
                    container.style.display = container.style.display === 'none' ? 'block' : 'none';
                }
                function searchLocation() {
                    const location = document.getElementById('searchLocation').value;
                    if (!location) {
                        alert('Por favor, digite um endereço ou coordenadas.');
                        return;
                    }
                    alert(`🔍 Buscando: ${location} (Funcionalidade em desenvolvimento)`);
                }
                function locateDevice() {
                    alert('📍 Localizando dispositivo... (Funcionalidade em desenvolvimento)');
                }
                function toggleSatelliteView() {
                    alert('🛰️ Alternando vista satélite... (Funcionalidade em desenvolvimento)');
                }
                function toggleAdvancedNetwork() {
                    window.open('http://localhost:3004', '_blank');
                }
                function fetchAIActivities() {
                    fetch('/api/ai_activities')
                    .then(response => response.json())
                    .then(data => {
                        let activities = data.map(act => `<div>${act.timestamp}: ${act.action}</div>`).join('');
                        document.getElementById('ai-activities').innerHTML = activities;
                    });
                }
                function fetchTrafficLogs() {
                    if (document.getElementById('Traffic').style.display === 'block') {
                        fetch('/api/traffic_logs')
                        .then(response => response.json())
                        .then(data => {
                            let tbody = document.querySelector('#trafficTable tbody');
                            tbody.innerHTML = '';
                            data.forEach(log => {
                                let row = `<tr>
                                    <td>${log[0]}</td>
                                    <td>${log[1]}</td>
                                    <td>${log[2]}</td>
                                    <td>${log[3]}</td>
                                    <td>${log[4]}</td>
                                    <td>${log[5]}</td>
                                    <td>${log[6]}</td>
                                    <td>${log[7]}</td>
                                </tr>`;
                                tbody.innerHTML += row;
                            });
                        });
                    }
                }
                function fetchConnectedDevices() {
                    if (document.getElementById('Devices').style.display === 'block') {
                        fetch('/api/connected_devices')
                        .then(response => response.json())
                        .then(data => {
                            document.getElementById('totalDevices').textContent = data.total;
                            let tbody = document.querySelector('#devicesTable tbody');
                            tbody.innerHTML = '';
                            data.devices.forEach(device => {
                                let row = `<tr>
                                    <td>${device.ip}</td>
                                    <td>${device.type}</td>
                                    <td>${device.last_seen}</td>
                                    <td>${device.queries}</td>
                                </tr>`;
                                tbody.innerHTML += row;
                            });
                        });
                    }
                }
                setInterval(fetchServerUsage, 5000);
                setInterval(fetchAIActivities, 1000);
                setInterval(fetchTrafficLogs, 1000);
                setInterval(fetchConnectedDevices, 5000);
                setInterval(updateClock, 1000);
                updateClock(); // Inicializar relógio
                setInterval(fetchOpenPorts, 10000);
            """
    else:
        # Simplified dashboard for users
        tabs = """
            <div class="tab" onclick="openTab(event, 'Logs')">Logs</div>
            <div class="tab" onclick="openTab(event, 'DataUsage')">Uso de Dados</div>
            <div class="tab" onclick="openTab(event, 'Settings')">Configurações</div>
        """
        dashboard_content = ""
        users_tab = ""
        script_extra = ""

    html = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>InvictusDNS - Painel de """ + user[1] + """</title>
        <style>
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                margin: 0;
                padding: 20px;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: #333;
                min-height: 100vh;
            }
            .container {
                max-width: 1400px;
                margin: 0 auto;
                background: rgba(255,255,255,0.95);
                border-radius: 20px;
                padding: 30px;
                box-shadow: 0 20px 40px rgba(0,0,0,0.1);
                backdrop-filter: blur(10px);
            }
            h1 {
                color: #2c3e50;
                text-align: center;
                margin-bottom: 30px;
                font-size: 2.5em;
                text-shadow: 2px 2px 4px rgba(0,0,0,0.1);
                background: linear-gradient(45deg, #667eea, #764ba2);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                background-clip: text;
            }
            .header-actions {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 30px;
                padding: 20px;
                background: linear-gradient(135deg, #667eea, #764ba2);
                border-radius: 15px;
                color: white;
            }
            .tabs {
                display: flex;
                margin-bottom: 30px;
                background: rgba(255,255,255,0.1);
                border-radius: 15px;
                padding: 10px;
                overflow-x: auto;
            }
            .tab {
                padding: 15px 25px;
                background: rgba(255,255,255,0.2);
                border: none;
                border-radius: 10px;
                cursor: pointer;
                margin: 0 5px;
                transition: all 0.3s ease;
                font-weight: 600;
                color: white;
                white-space: nowrap;
            }
            .tab:hover {
                background: rgba(255,255,255,0.3);
                transform: translateY(-2px);
            }
            .tab.active {
                background: white;
                color: #667eea;
                box-shadow: 0 4px 15px rgba(0,0,0,0.2);
            }
            .tab-content {
                display: none;
                background: white;
                border-radius: 15px;
                padding: 30px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.1);
                margin-top: 20px;
            }
            .tab-content.active { display: block; }
            table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 20px;
                border-radius: 10px;
                overflow: hidden;
                box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            }
            th, td {
                border: 1px solid #e1e8ed;
                padding: 15px;
                text-align: left;
                transition: all 0.3s ease;
            }
            th {
                background: linear-gradient(135deg, #667eea, #764ba2);
                color: white;
                font-weight: 600;
                text-transform: uppercase;
                letter-spacing: 1px;
            }
            tr:nth-child(even) { background-color: #f8f9fa; }
            tr:hover {
                background-color: #e3f2fd;
                transform: scale(1.01);
                box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            }
            .porn { background-color: #ffebee !important; }
            .game { background-color: #e8f5e8 !important; }
            .malware { background-color: #fff3e0 !important; }
            .threat { background-color: #ffebee !important; }
            #dashboard {
                background: linear-gradient(135deg, #667eea, #764ba2);
                color: white;
                padding: 30px;
                border-radius: 15px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.2);
                margin-bottom: 30px;
            }
            #dashboard h2 {
                margin-top: 0;
                color: white;
                text-align: center;
                font-size: 2em;
            }
            #dashboard h3 {
                color: #e8eaf6;
                border-bottom: 2px solid rgba(255,255,255,0.3);
                padding-bottom: 10px;
            }
            .usage-bar {
                height: 25px;
                background: linear-gradient(90deg, #4caf50, #45a049);
                border-radius: 12px;
                transition: width 0.5s ease;
                box-shadow: 0 2px 5px rgba(0,0,0,0.2);
            }
            .usage-container {
                background: rgba(255,255,255,0.2);
                border-radius: 12px;
                width: 100%;
                margin-bottom: 15px;
                height: 25px;
                overflow: hidden;
            }
            .metric-card {
                background: rgba(255,255,255,0.9);
                border-radius: 10px;
                padding: 20px;
                margin: 10px;
                text-align: center;
                box-shadow: 0 5px 15px rgba(0,0,0,0.1);
                transition: transform 0.3s ease;
            }
            .metric-card:hover {
                transform: translateY(-5px);
            }
            .metric-value {
                font-size: 2em;
                font-weight: bold;
                color: #667eea;
            }
            .metric-label {
                color: #666;
                font-size: 0.9em;
            }
            .status-indicator {
                display: inline-block;
                width: 12px;
                height: 12px;
                border-radius: 50%;
                margin-right: 8px;
            }
            .status-online { background: #4caf50; }
            .status-offline { background: #f44336; }
            .logout-btn {
                background: linear-gradient(135deg, #ff6b6b, #ee5a52);
                color: white;
                padding: 12px 25px;
                border: none;
                border-radius: 25px;
                cursor: pointer;
                font-weight: 600;
                text-decoration: none;
                transition: all 0.3s ease;
                box-shadow: 0 4px 15px rgba(255,107,107,0.3);
            }
            .logout-btn:hover {
                transform: translateY(-2px);
                box-shadow: 0 6px 20px rgba(255,107,107,0.4);
            }
            .action-btn {
                background: linear-gradient(135deg, #667eea, #764ba2);
                color: white;
                padding: 12px 25px;
                border: none;
                border-radius: 25px;
                cursor: pointer;
                font-weight: 600;
                text-decoration: none;
                margin: 10px;
                display: inline-block;
                transition: all 0.3s ease;
                box-shadow: 0 4px 15px rgba(102,126,234,0.3);
            }
            .action-btn:hover {
                transform: translateY(-2px);
                box-shadow: 0 6px 20px rgba(102,126,234,0.4);
            }
            .danger-btn {
                background: linear-gradient(135deg, #ff6b6b, #ee5a52);
            }
            .success-btn {
                background: linear-gradient(135deg, #4caf50, #45a049);
            }
            .info-btn {
                background: linear-gradient(135deg, #2196f3, #1976d2);
            }
            .warning-btn {
                background: linear-gradient(135deg, #ff9800, #f57c00);
            }
            .ip-obfuscated {
                font-family: 'Courier New', monospace;
                background: rgba(155,89,182,0.1);
                padding: 5px 10px;
                border-radius: 5px;
                border: 1px solid #9b59b6;
            }
            .map-container {
                height: 400px;
                border-radius: 10px;
                overflow: hidden;
                box-shadow: 0 5px 15px rgba(0,0,0,0.2);
                margin: 20px 0;
            }
            .satellite-controls {
                background: rgba(255,255,255,0.9);
                padding: 20px;
                border-radius: 10px;
                margin: 20px 0;
                display: flex;
                gap: 15px;
                align-items: center;
                flex-wrap: wrap;
            }
            .satellite-btn {
                background: linear-gradient(135deg, #667eea, #764ba2);
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 25px;
                cursor: pointer;
                font-weight: 600;
                transition: all 0.3s ease;
            }
            .satellite-btn:hover {
                transform: translateY(-2px);
                box-shadow: 0 4px 15px rgba(102,126,234,0.4);
            }
            .satellite-input {
                padding: 10px;
                border: 2px solid #667eea;
                border-radius: 25px;
                outline: none;
                font-size: 14px;
                transition: border-color 0.3s ease;
            }
            .satellite-input:focus {
                border-color: #764ba2;
            }
            .vpn-status {
                background: linear-gradient(135deg, #4caf50, #45a049);
                color: white;
                padding: 20px;
                border-radius: 10px;
                margin: 20px 0;
                text-align: center;
            }
            .ppoe-status {
                background: linear-gradient(135deg, #2196f3, #1976d2);
                color: white;
                padding: 20px;
                border-radius: 10px;
                margin: 20px 0;
                text-align: center;
            }
            .security-panel {
                background: linear-gradient(135deg, #ff6b6b, #ee5a52);
                color: white;
                padding: 20px;
                border-radius: 10px;
                margin: 20px 0;
            }
            .security-toggle {
                display: flex;
                align-items: center;
                margin: 10px 0;
                padding: 10px;
                background: rgba(255,255,255,0.1);
                border-radius: 8px;
            }
            .security-toggle label {
                margin-left: 10px;
                font-weight: 600;
            }
            .toggle-switch {
                position: relative;
                width: 50px;
                height: 24px;
                background: #ccc;
                border-radius: 12px;
                cursor: pointer;
                transition: background 0.3s ease;
            }
            .toggle-switch.active {
                background: #4caf50;
            }
            .toggle-switch::after {
                content: '';
                position: absolute;
                top: 2px;
                left: 2px;
                width: 20px;
                height: 20px;
                background: white;
                border-radius: 50%;
                transition: transform 0.3s ease;
            }
            .toggle-switch.active::after {
                transform: translateX(26px);
            }
            @keyframes pulse {
                0% { transform: scale(1); }
                50% { transform: scale(1.05); }
                100% { transform: scale(1); }
            }
            .pulse {
                animation: pulse 2s infinite;
            }
            @keyframes fadeIn {
                from { opacity: 0; transform: translateY(20px); }
                to { opacity: 1; transform: translateY(0); }
            }
            .fade-in {
                animation: fadeIn 0.5s ease-out;
            }
            .grid-container {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                gap: 20px;
                margin: 20px 0;
            }
            .card {
                background: white;
                border-radius: 15px;
                padding: 25px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.1);
                transition: all 0.3s ease;
            }
            .card:hover {
                transform: translateY(-5px);
                box-shadow: 0 15px 40px rgba(0,0,0,0.2);
            }
            .card-header {
                font-size: 1.2em;
                font-weight: bold;
                margin-bottom: 15px;
                color: #667eea;
            }
            .alert {
                padding: 15px;
                border-radius: 8px;
                margin: 10px 0;
                display: flex;
                align-items: center;
            }
            .alert-success {
                background: #d4edda;
                color: #155724;
                border: 1px solid #c3e6cb;
            }
            .alert-danger {
                background: #f8d7da;
                color: #721c24;
                border: 1px solid #f5c6cb;
            }
            .alert-info {
                background: #d1ecf1;
                color: #0c5460;
                border: 1px solid #bee5eb;
            }
            .alert-warning {
                background: #fff3cd;
                color: #856404;
                border: 1px solid #ffeaa7;
            }
        </style>
        <script>
            function openTab(evt, tabName) {
                var i, tabcontent, tablinks;
                tabcontent = document.getElementsByClassName("tab-content");
                for (i = 0; i < tabcontent.length; i++) {
                    tabcontent[i].style.display = "none";
                }
                tablinks = document.getElementsByClassName("tab");
                for (i = 0; i < tablinks.length; i++) {
                    tablinks[i].className = tablinks[i].className.replace(" active", "");
                }
                document.getElementById(tabName).style.display = "block";
                evt.currentTarget.className += " active";
            }
            function fetchLogs() {
                if (document.getElementById('Logs').style.display === 'block') {
                    fetch('/api/logs')
                    .then(response => response.json())
                    .then(data => {
                        let tbody = document.querySelector('#logsTable tbody');
                        tbody.innerHTML = '';
                        data.forEach(log => {
                            let row = `<tr class="${log[4] || ''}">
                                <td>${log[0]}</td>
                                <td>${log[1]}</td>
                                <td>${log[2]}</td>
                                <td>${log[3] || ''}</td>
                                <td>${log[4] || ''}</td>
                                <td>${log[5] ? log[5].toFixed(2) + 's' : ''}</td>
                            </tr>`;
                            tbody.innerHTML += row;
                        });
                    });
                }
            }
            setInterval(fetchLogs, 1000); // Update logs every 1 second

            function fetchDataUsage() {
                if (document.getElementById('DataUsage').style.display === 'block') {
                    fetch('/api/data_usage')
                    .then(response => response.json())
                    .then(data => {
                        let tbody = document.querySelector('#dataUsageTable tbody');
                        tbody.innerHTML = '';
                        for (let ip in data) {
                            let row = `<tr>
                                <td>${ip}</td>
                                <td>${data[ip].toFixed(3)}</td>
                            </tr>`;
                            tbody.innerHTML += row;
                        }
                    });
                }
            }
            """ + script_extra + """
            function fetchOpenPorts() {
                if (document.getElementById('PortControl').style.display === 'block') {
                    fetch('/api/port_control')
                    .then(response => response.json())
                    .then(data => {
                        if (data.ports) {
                            let html = '<table style="width: 100%; border-collapse: collapse;"><tr><th style="border: 1px solid #ddd; padding: 8px;">Protocolo</th><th style="border: 1px solid #ddd; padding: 8px;">Porta</th><th style="border: 1px solid #ddd; padding: 8px;">Status</th></tr>';
                            data.ports.forEach(port => {
                                html += `<tr><td style="border: 1px solid #ddd; padding: 8px;">${port.protocol}</td><td style="border: 1px solid #ddd; padding: 8px;">${port.port}</td><td style="border: 1px solid #ddd; padding: 8px;">${port.status}</td></tr>`;
                            });
                            html += '</table>';
                            document.getElementById('portsTableContainer').innerHTML = html;
                        }
                    });
                }
            }
            function refreshPorts() {
                fetchOpenPorts();
            }
            function openPort() {
                const port = document.getElementById('portNumber').value;
                const protocol = document.getElementById('portProtocol').value;
                if (!port) {
                    showPortMessage('Por favor, digite um número de porta válido.', 'error');
                    return;
                }
                fetch('/api/port_control', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({action: 'open', port: parseInt(port), protocol: protocol})
                })
                .then(response => response.json())
                .then(data => {
                    if (data.message) {
                        showPortMessage(data.message, 'success');
                        fetchOpenPorts();
                    } else if (data.error) {
                        showPortMessage(data.error, 'error');
                    }
                });
            }
            function closePort() {
                const port = document.getElementById('portNumber').value;
                const protocol = document.getElementById('portProtocol').value;
                if (!port) {
                    showPortMessage('Por favor, digite um número de porta válido.', 'error');
                    return;
                }
                fetch('/api/port_control', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({action: 'close', port: parseInt(port), protocol: protocol})
                })
                .then(response => response.json())
                .then(data => {
                    if (data.message) {
                        showPortMessage(data.message, 'success');
                        fetchOpenPorts();
                    } else if (data.error) {
                        showPortMessage(data.error, 'error');
                    }
                });
            }
            function showPortMessage(message, type) {
                const msgDiv = document.getElementById('portControlMessage');
                msgDiv.textContent = message;
                msgDiv.style.display = 'block';
                msgDiv.style.backgroundColor = type === 'success' ? '#d4edda' : '#f8d7da';
                msgDiv.style.color = type === 'success' ? '#155724' : '#721c24';
                msgDiv.style.border = `1px solid ${type === 'success' ? '#c3e6cb' : '#f5c6cb'}`;
                setTimeout(() => { msgDiv.style.display = 'none'; }, 5000);
            }
            function obfuscateIP() {
                const ip = document.getElementById('inputIP').value;
                if (!ip) {
                    alert('Por favor, digite um IP válido.');
                    return;
                }
                fetch('/api/obfuscate_ip', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({ip: ip})
                })
                .then(response => response.json())
                .then(data => {
                    if (data.obfuscated) {
                        document.getElementById('obfuscatedResult').textContent = data.obfuscated;
                        document.getElementById('obfuscatedResult').style.display = 'block';
                    } else if (data.error) {
                        alert(data.error);
                    }
                });
            }
            function deobfuscateIP() {
                const symbols = document.getElementById('inputSymbols').value;
                if (!symbols) {
                    alert('Por favor, cole os símbolos ofuscados.');
                    return;
                }
                fetch('/api/deobfuscate_ip', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({symbols: symbols})
                })
                .then(response => response.json())
                .then(data => {
                    if (data.ip) {
                        document.getElementById('deobfuscatedResult').textContent = data.ip;
                        document.getElementById('deobfuscatedResult').style.display = 'block';
                    } else if (data.error) {
                        alert(data.error);
                    }
                });
            }
            setInterval(fetchLogs, 1000);
            setInterval(fetchDataUsage, 1000);
            window.onload = function() {
                """ + ("fetchServerUsage(); fetchAIActivities();" if user[2] == 'admin' else "") + """
                document.getElementsByClassName('tab')[0].click();
            };
        </script>
    </head>
    <body>
        <div class="container fade-in">
            <h1>🚀 InvictusDNS - Sistema Completo</h1>
            <div class="header-actions">
                <div>
                    <span class="status-indicator status-online"></span>
                    <strong>""" + user[1] + """</strong> - Online
                </div>
                <a href="/logout" class="logout-btn">🚪 Logout</a>
            </div>
            <div class="tabs">
                """ + tabs + """
            </div>
        """ + dashboard_content + """
        <div id="Logs" class="tab-content">
            <h2>📋 Logs de Consultas DNS</h2>
            <div class="alert alert-success">
                <span>🔍</span>
                <div>
                    <strong>Histórico Completo</strong><br>
                    Todas as consultas DNS registradas com categorização automática por IA.
                </div>
            </div>
            <table id="logsTable">
                <tr>
                <th>🕒 Calendário/Hora</th>
                <th>🌐 IP do Cliente</th>
                <th>🔗 Domínio</th>
                <th>📍 IP Resolvido</th>
                <th>🏷️ Categoria</th>
                <th>⚡ Tempo de Resposta</th>
                </tr>
                <tbody>
                {% for log in logs %}
                <tr class="{{ log[4] }}">
                    <td>{{ log[0] }}</td>
                <td>
                    <span class="ip-obfuscated" title="{{ log[1] }}">{{ log[1] }}</span>
                </td>
                    <td>{{ log[2] }}</td>
                    <td>{{ log[3] }}</td>
                    <td>{{ log[4] }}</td>
                    <td>{{ "%.2f"|format(log[5] or 0) }}s</td>
                </tr>
                {% endfor %}
                </tbody>
            </table>
        </div>

        <div id="ServerActivity" class="tab-content" style="display:none;">
            <h2>Atividade do Servidor DNS (Interna e Externa)</h2>
            <div id="serverActivityLog" style="height: 300px; overflow-y: scroll; background: #f0f0f0; padding: 10px; border: 1px solid #ccc; font-family: monospace; font-size: 12px;"></div>
        </div>
        <div id="DataUsage" class="tab-content">
            <h2>📊 Uso de Dados por IP (em MB)</h2>
            <div class="alert alert-info">
                <span>💾</span>
                <div>
                    <strong>Controle de Banda Ativo</strong><br>
                    Monitoramento detalhado do consumo de dados por dispositivo.
                </div>
            </div>
            <table id="dataUsageTable">
                <tr>
                    <th>🌐 IP</th>
                    <th>📈 Uso Total (MB)</th>
                </tr>
                <tbody>
                </tbody>
            </table>
        </div>
        <div id="Traffic" class="tab-content">
            <h2>🌐 Monitor de Tráfego em Tempo Real</h2>
            <div class="alert alert-warning">
                <span>⚡</span>
                <div>
                    <strong>Análise de Rede Ativa</strong><br>
                    Monitoramento contínuo de pacotes TCP/UDP e conexões ativas.
                </div>
            </div>
            <table id="trafficTable">
                <tr>
                    <th>🕒 Timestamp</th>
                    <th>📤 Src IP</th>
                    <th>📥 Dst IP</th>
                    <th>🔌 Src Port</th>
                    <th>🔌 Dst Port</th>
                    <th>📋 Protocol</th>
                    <th>📏 Length</th>
                    <th>ℹ️ Info</th>
                </tr>
                <tbody>
                </tbody>
            </table>
        </div>
        <div id="Devices" class="tab-content">
            <h2>📱 Dispositivos Conectados</h2>
            <div class="alert alert-success">
                <span>📊</span>
                <div>
                    <strong>Monitoramento Ativo</strong><br>
                    Total de Dispositivos: <span id="totalDevices" style="font-weight: bold; font-size: 1.2em;">0</span>
                </div>
            </div>
            <table id="devicesTable">
                <tr>
                    <th>📱 IP do Dispositivo</th>
                    <th>🔍 Tipo</th>
                    <th>🕒 Última Atividade</th>
                    <th>📈 Consultas DNS</th>
                </tr>
                <tbody>
                </tbody>
            </table>
        </div>
        <!-- 🌐 CONFIGURAÇÃO DE REDE AVANÇADA (Porta 3004) -->
        <div id="Network" class="tab-content">
            <h2>🌐 Rede Avançada - Configuração de Rede Completa</h2>
            <div class="alert alert-success">
                <span>🔧</span>
                <div>
                    <strong>CONFIGURAÇÃO DE REDE AVANÇADA</strong><br>
                    VPN, PPPoE, Bridge, VLAN, DHCP, DNS, QoS, Firewall de rede completo.
                </div>
            </div>

            <div class="grid-container">
                <div class="card">
                    <div class="card-header">🔗 VPN Server</div>
                    <p>OpenVPN e WireGuard configuráveis</p>
                    <button class="action-btn" onclick="openVPNPanel()">Configurar VPN</button>
                </div>
                <div class="card">
                    <div class="card-header">🌐 PPPoE</div>
                    <p>Conexão PPPoE automática</p>
                    <button class="action-btn info-btn" onclick="openPPPoEPanel()">Configurar PPPoE</button>
                </div>
                <div class="card">
                    <div class="card-header">📡 DHCP Server</div>
                    <p>Servidor DHCP avançado</p>
                    <button class="action-btn warning-btn" onclick="openDHCPPanel()">Configurar DHCP</button>
                </div>
                <div class="card">
                    <div class="card-header">🛰️ Satélite Map</div>
                    <p>Localização geográfica</p>
                    <button class="action-btn" onclick="openSatelliteMap()">Abrir Mapa</button>
                </div>
            </div>

            <div id="satelliteMapContainer" style="display: none; margin-top: 30px;">
                <h3>🛰️ Mapa de Satélite - Localização de Dispositivos</h3>
                <div class="satellite-controls">
                    <input type="text" class="satellite-input" id="searchLocation" placeholder="Digite um endereço ou coordenadas">
                    <button class="satellite-btn" onclick="searchLocation()">🔍 Buscar</button>
                    <button class="satellite-btn" onclick="locateDevice()">📍 Localizar Dispositivo</button>
                    <button class="satellite-btn" onclick="toggleSatelliteView()">🛰️ Vista Satélite</button>
                </div>
                <div class="map-container" id="satelliteMap">
                    <!-- Mapa será carregado aqui -->
                    <div style="display: flex; align-items: center; justify-content: center; height: 100%; background: rgba(0,0,0,0.1); border-radius: 10px;">
                        <div style="text-align: center; color: #666;">
                            <div style="font-size: 3em; margin-bottom: 10px;">🛰️</div>
                            <div>Mapa de Satélite</div>
                            <div style="font-size: 0.9em; margin-top: 10px;">Funcionalidade em desenvolvimento</div>
                        </div>
                    </div>
                </div>
            </div>

            <div style="margin-top: 30px; text-align: center;">
                <button class="action-btn success-btn" onclick="toggleAdvancedNetwork()">🔧 Abrir Configurações Avançadas (Porta 3004)</button>
            </div>
        </div>
        <!-- 🔥 FIREWALL - CONTROLE DE PORTAS TCP/UDP -->
        <div id="PortControl" class="tab-content">
            <h2>🔥 Firewall - Controle de Portas TCP/UDP</h2>
            <div style="background: rgba(255,0,0,0.1); border: 1px solid #ff4444; padding: 15px; border-radius: 10px; margin-bottom: 20px;">
                <h3 style="color: #ff4444; margin: 0;">⚠️ ATENÇÃO - FIREWALL ATIVO</h3>
                <p style="margin: 5px 0 0 0;">Apenas administradores podem modificar regras de firewall. Todas as ações são logadas.</p>
            </div>
            <div style="margin-bottom: 20px;">
                <button onclick="refreshPorts()" style="padding: 10px 20px; background: #3498db; color: white; border: none; border-radius: 5px; cursor: pointer;">🔄 Atualizar Portas</button>
            </div>
            <div id="portsList" style="margin-bottom: 20px;">
                <h3>📋 Portas Abertas/Ativas no Sistema</h3>
                <div id="portsTableContainer"></div>
            </div>
            <div style="background: rgba(255,255,255,0.1); padding: 20px; border-radius: 10px;">
                <h3>🎛️ Controle Manual de Firewall</h3>
                <div style="display: flex; gap: 10px; align-items: center; margin-bottom: 10px;">
                    <select id="portProtocol" style="padding: 8px; border-radius: 5px; border: 1px solid #ddd;">
                        <option value="tcp">🔌 TCP</option>
                        <option value="udp">📡 UDP</option>
                    </select>
                    <input type="number" id="portNumber" placeholder="Número da Porta (1-65535)" min="1" max="65535" style="padding: 8px; border-radius: 5px; border: 1px solid #ddd;">
                    <button onclick="openPort()" style="padding: 8px 15px; background: #27ae60; color: white; border: none; border-radius: 5px; cursor: pointer;">✅ Abrir Porta</button>
                    <button onclick="closePort()" style="padding: 8px 15px; background: #e74c3c; color: white; border: none; border-radius: 5px; cursor: pointer;">❌ Fechar Porta</button>
                </div>
                <div id="portControlMessage" style="margin-top: 10px; padding: 10px; border-radius: 5px; display: none;"></div>
                <div style="margin-top: 15px; font-size: 12px; color: #888;">
                    <strong>Portas Comuns:</strong> 22(SSH), 80(HTTP), 443(HTTPS), 53(DNS), 25(SMTP), 110(POP3), 143(IMAP)
                </div>
            </div>
        </div>
        <!-- 🔥 FIREWALL - OFUSCADOR DE IP -->
        <div id="IPObfuscator" class="tab-content">
            <h2>🔥 Firewall - Sistema de Ofuscação de IP</h2>
            <div style="background: rgba(155,89,182,0.1); border: 1px solid #9b59b6; padding: 15px; border-radius: 10px; margin-bottom: 20px;">
                <h3 style="color: #9b59b6; margin: 0;">🔒 PRIVACIDADE VISUAL</h3>
                <p style="margin: 5px 0 0 0;">Converta IPs em símbolos únicos para proteger informações sensíveis em logs e interfaces.</p>
            </div>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                <div style="background: rgba(255,255,255,0.1); padding: 20px; border-radius: 10px;">
                    <h3>🔄 Ofuscar IP → Símbolos</h3>
                    <input type="text" id="inputIP" placeholder="Digite um IP (ex: 192.168.1.1)" style="width: 100%; padding: 10px; margin-bottom: 10px; border-radius: 5px; border: 1px solid #ddd;">
                    <button onclick="obfuscateIP()" style="padding: 10px 20px; background: #9b59b6; color: white; border: none; border-radius: 5px; cursor: pointer; width: 100%;">🎭 Ofuscar IP</button>
                    <div id="obfuscatedResult" style="margin-top: 10px; padding: 10px; background: rgba(0,0,0,0.2); border-radius: 5px; font-family: monospace; font-size: 16px; display: none;"></div>
                </div>
                <div style="background: rgba(255,255,255,0.1); padding: 20px; border-radius: 10px;">
                    <h3>🔄 Desofuscar Símbolos → IP</h3>
                    <input type="text" id="inputSymbols" placeholder="Cole os símbolos ofuscados" style="width: 100%; padding: 10px; margin-bottom: 10px; border-radius: 5px; border: 1px solid #ddd;">
                    <button onclick="deobfuscateIP()" style="padding: 10px 20px; background: #e67e22; color: white; border: none; border-radius: 5px; cursor: pointer; width: 100%;">🔍 Desofuscar</button>
                    <div id="deobfuscatedResult" style="margin-top: 10px; padding: 10px; background: rgba(0,0,0,0.2); border-radius: 5px; font-family: monospace; display: none;"></div>
                </div>
            </div>
            <div style="margin-top: 20px; background: rgba(255,255,255,0.1); padding: 20px; border-radius: 10px;">
                <h3>📚 Como Funciona o Sistema de Ofuscação</h3>
                <p>Cada dígito do IP é convertido em um símbolo único e memorável:</p>
                <div style="display: grid; grid-template-columns: repeat(5, 1fr); gap: 10px; font-family: monospace; background: rgba(0,0,0,0.1); padding: 15px; border-radius: 5px;">
                    <div>0 → 🌀 (Redemoinho)</div>
                    <div>1 → 🌟 (Estrela)</div>
                    <div>2 → 🔥 (Fogo)</div>
                    <div>3 → ⚡ (Raio)</div>
                    <div>4 → 💎 (Diamante)</div>
                    <div>5 → 🎯 (Alvo)</div>
                    <div>6 → 🚀 (Foguete)</div>
                    <div>7 → 🌙 (Lua)</div>
                    <div>8 → 💫 (Cometa)</div>
                    <div>9 → 🌈 (Arco-íris)</div>
                </div>
                <p style="margin-top: 10px; font-weight: bold;">Exemplo prático:</p>
                <div style="background: rgba(0,0,0,0.1); padding: 10px; border-radius: 5px; font-family: monospace;">
                    IP: 192.168.1.1 → Símbolos: 🔥🌟🌈✨🚀⚡🌟🌟✨🌟
                </div>
                <p style="margin-top: 10px; font-size: 12px; color: #888;">
                    💡 <strong>Dica:</strong> Use este sistema para proteger IPs em logs públicos, apresentações ou compartilhamento de dados sensíveis.
                </p>
            </div>
        </div>
        <!-- ☁️ NUVEM & BACKUP - INVICTUSCLOUD (Porta 3003) -->
        <div id="Settings" class="tab-content">
            <h2>🔥 Firewall - Configurações de Bloqueio</h2>
            <div class="alert alert-danger">
                <span>🛡️</span>
                <div>
                    <strong>SISTEMA DE BLOQUEIO ATIVO</strong><br>
                    Gerencie domínios e IPs bloqueados no firewall.
                </div>
            </div>
            <a href="/block" class="action-btn danger-btn">🚫 Gerenciar Bloqueios</a>

            <h2>☁️ InvictusCloud - Sistema de Backup na Nuvem</h2>
            <div class="alert alert-info">
                <span>☁️</span>
                <div>
                    <strong>BACKUP NA NUVEM ATIVO</strong><br>
                    Criptografia AES, gerenciamento de usuários e quotas, recuperação de desastres.
                </div>
            </div>
            <a href="http://localhost:3003" target="_blank" class="action-btn info-btn">☁️ Acessar Painel de Nuvem (Porta 3003)</a>

            <h2>🔒 Segurança Avançada</h2>
            <div class="security-panel">
                <h3>🛡️ Módulos de Segurança Ativos</h3>
                <div class="security-toggle">
                    <div class="toggle-switch active" onclick="toggleSecurity('firewall')"></div>
                    <label>Firewall Inteligente</label>
                </div>
                <div class="security-toggle">
                    <div class="toggle-switch active" onclick="toggleSecurity('ai')"></div>
                    <label>Detecção IA de Ameaças</label>
                </div>
                <div class="security-toggle">
                    <div class="toggle-switch active" onclick="toggleSecurity('encryption')"></div>
                    <label>Criptografia AES-256</label>
                </div>
                <div class="security-toggle">
                    <div class="toggle-switch" onclick="toggleSecurity('vpn')"></div>
                    <label>VPN Automática</label>
                </div>
                <div class="security-toggle">
                    <div class="toggle-switch" onclick="toggleSecurity('ppoe')"></div>
                    <label>PPPoE Seguro</label>
                </div>
            </div>

            <h2>🌐 VPN & PPPoE</h2>
            <div class="vpn-status">
                <h3>🔗 VPN Status</h3>
                <p>Status: <strong>DESCONECTADO</strong> | Última conexão: Nunca</p>
                <button class="action-btn success-btn" onclick="connectVPN()">🔗 Conectar VPN</button>
            </div>

            <div class="ppoe-status">
                <h3>🌐 PPPoE Status</h3>
                <p>Status: <strong>INATIVO</strong> | Última sessão: Nunca</p>
                <button class="action-btn info-btn" onclick="connectPPPoE()">🌐 Iniciar PPPoE</button>
            </div>
        </div>
        """ + users_tab + """
        <!-- 🤖 INTELIGÊNCIA ARTIFICIAL - PAINEL IA (Porta 3002) -->
        <div id="AI" class="tab-content">
            <h2>🤖 IA - Sistema de Inteligência Artificial Completo</h2>
            <div class="alert alert-info">
                <span>🧠</span>
                <div>
                    <strong>SISTEMA DE IA ATIVO</strong><br>
                    Monitoramento inteligente, detecção de anomalias e categorização automática de ameaças.
                </div>
            </div>

            <div class="grid-container">
                <div class="card">
                    <div class="card-header">🎯 Detecção de Ameaças</div>
                    <p>IA analisa logs em tempo real para identificar padrões suspeitos.</p>
                    <div class="security-toggle">
                        <div class="toggle-switch active" onclick="toggleAI('threat_detection')"></div>
                        <label>Ativo</label>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header">📊 Análise de Anomalias</div>
                    <p>Machine Learning detecta comportamentos anômalos na rede.</p>
                    <div class="security-toggle">
                        <div class="toggle-switch active" onclick="toggleAI('anomaly_detection')"></div>
                        <label>Ativo</label>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header">🤖 Respostas Automáticas</div>
                    <p>IA toma ações preventivas contra ameaças detectadas.</p>
                    <div class="security-toggle">
                        <div class="toggle-switch active" onclick="toggleAI('auto_response')"></div>
                        <label>Ativo</label>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header">📈 Previsão de Ataques</div>
                    <p>Análise preditiva de possíveis vulnerabilidades.</p>
                    <div class="security-toggle">
                        <div class="toggle-switch" onclick="toggleAI('attack_prediction')"></div>
                        <label>Inativo</label>
                    </div>
                </div>
            </div>

            <h3>📋 Atividades da IA em Tempo Real</h3>
            <div id="ai-activities" style="height: 300px; overflow-y: scroll; background: rgba(0,0,0,0.05); padding: 15px; border-radius: 10px; font-family: monospace; font-size: 12px; border: 1px solid #e1e8ed;"></div>

            <div style="margin-top: 30px; text-align: center;">
                <a href="http://localhost:3002" target="_blank" class="action-btn">🚀 Abrir Painel de IA Completo (Porta 3002)</a>
            </div>
        </div>
    </body>
    </html>
    """
    return render_template_string(html, logs=logs)

@app.route('/block', methods=['GET', 'POST'])
@login_required
def block():
    user = get_current_user()
    init_db()
    if request.method == 'POST':
        action = request.form.get('action')
        domain = request.form.get('domain')
        ip = request.form.get('ip')
        conn = sqlite3.connect(DB_FILE)
        c = conn.cursor()
        if user[2] == 'admin':
            if action == 'block_domain' and domain:
                c.execute("INSERT OR IGNORE INTO blocked_domains (domain, user_id) VALUES (?, ?)", (domain, user[0]))
            elif action == 'unblock_domain' and domain:
                c.execute("DELETE FROM blocked_domains WHERE domain = ?", (domain,))
            elif action == 'block_ip' and ip:
                c.execute("INSERT OR IGNORE INTO blocked_ips (ip, user_id) VALUES (?, ?)", (ip, user[0]))
            elif action == 'unblock_ip' and ip:
                c.execute("DELETE FROM blocked_ips WHERE ip = ?", (ip,))
        else:
            # Normal user can only block/unblock their own domains and ips
            if action == 'block_domain' and domain:
                c.execute("INSERT OR IGNORE INTO blocked_domains (domain, user_id) VALUES (?, ?)", (domain, user[0]))
            elif action == 'unblock_domain' and domain:
                c.execute("DELETE FROM blocked_domains WHERE domain = ? AND user_id = ?", (domain, user[0]))
            elif action == 'block_ip' and ip:
                c.execute("INSERT OR IGNORE INTO blocked_ips (ip, user_id) VALUES (?, ?)", (ip, user[0]))
            elif action == 'unblock_ip' and ip:
                c.execute("DELETE FROM blocked_ips WHERE ip = ? AND user_id = ?", (ip, user[0]))
        conn.commit()
        conn.close()
        return '', 204

    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    if user[2] == 'admin':
        c.execute("SELECT domain FROM blocked_domains")
        blocked_domains = [row[0] for row in c.fetchall()]
        c.execute("SELECT ip FROM blocked_ips")
        blocked_ips = [row[0] for row in c.fetchall()]
    else:
        c.execute("SELECT domain FROM blocked_domains WHERE user_id = ?", (user[0],))
        blocked_domains = [row[0] for row in c.fetchall()]
        c.execute("SELECT ip FROM blocked_ips WHERE user_id = ?", (user[0],))
        blocked_ips = [row[0] for row in c.fetchall()]
    conn.close()

    html = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>InvictusDNS - Gerenciar Bloqueios</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 20px; background: #f4f7f9; color: #333; }
            h1 { color: #2c3e50; }
            form { margin-bottom: 20px; }
            input[type=text] { padding: 8px; width: 300px; }
            button { padding: 8px 15px; background: #3498db; color: white; border: none; cursor: pointer; border-radius: 4px; }
            ul { list-style-type: none; padding-left: 0; }
            li { background: #ecf0f1; margin: 5px 0; padding: 8px; border-radius: 4px; }
        </style>
        <script>
            function postAction(action, value) {
                let formData = new FormData();
                if(action.includes('domain')) {
                    formData.append('domain', value);
                } else {
                    formData.append('ip', value);
                }
                formData.append('action', action);
                fetch('/block', {
                    method: 'POST',
                    body: formData
                }).then(() => location.reload());
            }
        </script>
    </head>
    <body>
        <h1>InvictusDNS - Gerenciar Bloqueios</h1>
        <a href="/dashboard">Voltar</a>
        <h2>Bloquear Domínio</h2>
        <form onsubmit="event.preventDefault(); postAction('block_domain', this.domain.value); this.domain.value='';">
            <input type="text" name="domain" placeholder="Domínio" required>
            <button type="submit">Bloquear</button>
        </form>
        <h2>Desbloquear Domínio</h2>
        <form onsubmit="event.preventDefault(); postAction('unblock_domain', this.domain.value); this.domain.value='';">
            <input type="text" name="domain" placeholder="Domínio" required>
            <button type="submit">Desbloquear</button>
        </form>
        <h2>Bloquear IP</h2>
        <form onsubmit="event.preventDefault(); postAction('block_ip', this.ip.value); this.ip.value='';">
            <input type="text" name="ip" placeholder="IP" required>
            <button type="submit">Bloquear</button>
        </form>
        <h2>Desbloquear IP</h2>
        <form onsubmit="event.preventDefault(); postAction('unblock_ip', this.ip.value); this.ip.value='';">
            <input type="text" name="ip" placeholder="IP" required>
            <button type="submit">Desbloquear</button>
        </form>
        <h2>Domínios Bloqueados</h2>
        <ul>
        {% for d in blocked_domains %}
        <li>{{ d }}</li>
        {% endfor %}
        </ul>
        <h2>IPs Bloqueados</h2>
        <ul>
        {% for i in blocked_ips %}
        <li>{{ i }}</li>
        {% endfor %}
        </ul>
    </body>
    </html>
    """
    return render_template_string(html, blocked_domains=blocked_domains, blocked_ips=blocked_ips)

@app.route('/stats')
@login_required
def stats():
    user = get_current_user()
    init_db()
    conn = sqlite3.connect(DB_FILE, timeout=30, check_same_thread=False)
    c = conn.cursor()
    if user[2] == 'admin':
        c.execute("SELECT category, COUNT(*) FROM dns_logs GROUP BY category")
        category_stats = c.fetchall()
        c.execute("SELECT client_ip, COUNT(*) FROM dns_logs GROUP BY client_ip ORDER BY COUNT(*) DESC LIMIT 10")
        top_ips = c.fetchall()
        c.execute("SELECT domain, COUNT(*) FROM dns_logs GROUP BY domain ORDER BY COUNT(*) DESC LIMIT 10")
        top_domains = c.fetchall()
    else:
        # For user, show stats only for their IPs
        ips = user[3] if len(user) > 3 else ''
        if ips:
            ip_list = [ip.strip() for ip in ips.split(',')]
            placeholders = ','.join('?' * len(ip_list))
            c.execute(f"SELECT category, COUNT(*) FROM dns_logs WHERE client_ip IN ({placeholders}) GROUP BY category", ip_list)
            category_stats = c.fetchall()
            c.execute(f"SELECT client_ip, COUNT(*) FROM dns_logs WHERE client_ip IN ({placeholders}) GROUP BY client_ip ORDER BY COUNT(*) DESC LIMIT 10", ip_list)
            top_ips = c.fetchall()
            c.execute(f"SELECT domain, COUNT(*) FROM dns_logs WHERE client_ip IN ({placeholders}) GROUP BY domain ORDER BY COUNT(*) DESC LIMIT 10", ip_list)
            top_domains = c.fetchall()
        else:
            category_stats = []
            top_ips = []
            top_domains = []
    conn.close()

    html = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>InvictusDNS - Estatísticas de """ + user[1] + """</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 20px; background: #f4f7f9; color: #333; }
            h1 { color: #2c3e50; }
            ul { list-style-type: none; padding-left: 0; }
            li { background: #ecf0f1; margin: 5px 0; padding: 8px; border-radius: 4px; }
        </style>
    </head>
    <body>
        <h1>InvictusDNS - Estatísticas de """ + user[1] + """</h1>
        <a href="/dashboard">Voltar</a>
        <h2>Estatísticas por Categoria</h2>
        <ul>
        {% for cat, count in category_stats %}
        <li>{{ cat }}: {{ count }}</li>
        {% endfor %}
        </ul>
        <h2>Top IPs</h2>
        <ul>
        {% for ip, count in top_ips %}
        <li>{{ ip }}: {{ count }}</li>
        {% endfor %}
        </ul>
        <h2>Top Domínios</h2>
        <ul>
        {% for dom, count in top_domains %}
        <li>{{ dom }}: {{ count }}</li>
        {% endfor %}
        </ul>
    </body>
    </html>
    """
    return render_template_string(html, category_stats=category_stats, top_ips=top_ips, top_domains=top_domains)

# ================================================================================
# ☁️ NUVEM & BACKUP - GERENCIAMENTO DE USUÁRIOS (Porta 3000)
# ================================================================================
@app.route('/users', methods=['GET', 'POST'])
@login_required
def users():
    """
    Sistema de gerenciamento de usuários do InvictusCloud
    - Adicionar/remover usuários
    - Controle de acesso por IPs
    - Gerenciamento de roles (admin/user)
    """
    user = get_current_user()
    if user[2] != 'admin':
        return redirect(url_for('dashboard'))
    init_db()
    if request.method == 'POST':
        action = request.form.get('action')
        username = request.form.get('username')
        password = request.form.get('password')
        ips = request.form.get('ips', '')
        conn = sqlite3.connect(DB_FILE)
        c = conn.cursor()
        if action == 'add_user' and username and password:
            c.execute("INSERT INTO users (username, password_hash, role, ips) VALUES (?, ?, 'user', ?)",
                      (username, generate_password_hash(password), ips))
        elif action == 'delete_user' and username:
            c.execute("DELETE FROM users WHERE username = ?", (username,))
        conn.commit()
        conn.close()
        return redirect(url_for('users'))

    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("SELECT id, username, role, ips FROM users")
    users_list = c.fetchall()
    conn.close()

    html = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>☁️ InvictusCloud - Gerenciar Usuários</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 20px; background: #f4f7f9; color: #333; }
            h1 { color: #2c3e50; }
            form { margin-bottom: 20px; }
            input[type=text], input[type=password] { padding: 8px; width: 300px; }
            button { padding: 8px 15px; background: #3498db; color: white; border: none; cursor: pointer; border-radius: 4px; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #34495e; color: white; }
            tr:nth-child(even) { background-color: #ecf0f1; }
        </style>
    </head>
    <body>
        <h1>☁️ InvictusCloud - Gerenciar Usuários</h1>
        <a href="/dashboard">Voltar ao Dashboard</a>
        <h2>👤 Adicionar Novo Usuário</h2>
        <form method="post">
            <input type="hidden" name="action" value="add_user">
            <input type="text" name="username" placeholder="Nome de usuário" required><br>
            <input type="password" name="password" placeholder="Senha" required><br>
            <input type="text" name="ips" placeholder="IPs permitidos (separados por vírgula)"><br>
            <button type="submit">➕ Adicionar Usuário</button>
        </form>
        <h2>📋 Lista de Usuários</h2>
        <table>
            <tr>
                <th>ID</th>
                <th>👤 Usuário</th>
                <th>🔰 Role</th>
                <th>🌐 IPs Permitidos</th>
                <th>⚙️ Ações</th>
            </tr>
            {% for u in users_list %}
            <tr>
                <td>{{ u[0] }}</td>
                <td>{{ u[1] }}</td>
                <td>{{ u[2] }}</td>
                <td>{{ u[3] }}</td>
                <td>
                    <form method="post" style="display:inline;">
                        <input type="hidden" name="action" value="delete_user">
                        <input type="hidden" name="username" value="{{ u[1] }}">
                        <button type="submit" onclick="return confirm('Deletar usuário?')" style="background: #e74c3c;">🗑️ Deletar</button>
                    </form>
                </td>
            </tr>
            {% endfor %}
        </table>
    </body>
    </html>
    """
    return render_template_string(html, users_list=users_list)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3000, debug=False)

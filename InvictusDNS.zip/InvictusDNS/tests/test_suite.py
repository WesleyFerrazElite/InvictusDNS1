import unittest
import sys
import os
import tempfile
import shutil
import json
from unittest.mock import Mock, patch, MagicMock
import sqlite3
from datetime import datetime, timedelta

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import modules to test
from server.dns_server import DNSServer
from panels.web_panel import WebPanel
from api.rest_api import app as api_app
from notifications.alert_system import NotificationManager
from monitoring.metrics_collector import MetricsCollector
from auth.advanced_auth import app as auth_app
from cluster.cluster_manager import ClusterManager

class TestDNSServer(unittest.TestCase):
    def setUp(self):
        self.dns_server = DNSServer()
        self.test_db = tempfile.NamedTemporaryFile(delete=False)
        self.test_db.close()

    def tearDown(self):
        if os.path.exists(self.test_db.name):
            os.unlink(self.test_db.name)

    def test_dns_resolution(self):
        """Test basic DNS resolution"""
        # Mock DNS query
        with patch('socket.socket') as mock_socket:
            mock_sock = MagicMock()
            mock_socket.return_value = mock_sock
            mock_sock.recvfrom.return_value = (b'test query', ('127.0.0.1', 12345))

            # This would need more detailed mocking for full test
            # For now, just test that the class can be instantiated
            self.assertIsInstance(self.dns_server, DNSServer)

    def test_cache_operations(self):
        """Test DNS cache operations"""
        # Test cache set/get
        self.dns_server.dns_cache['test.com'] = ('1.2.3.4', datetime.now().timestamp())

        cached_result = self.dns_server.dns_cache.get('test.com')
        self.assertIsNotNone(cached_result)
        self.assertEqual(cached_result[0], '1.2.3.4')

class TestWebPanel(unittest.TestCase):
    def setUp(self):
        self.app = WebPanel().app
        self.client = self.app.test_client()

    def test_homepage(self):
        """Test web panel homepage"""
        response = self.client.get('/')
        self.assertEqual(response.status_code, 200)

    def test_login_page(self):
        """Test login page access"""
        response = self.client.get('/login')
        self.assertEqual(response.status_code, 200)

    @patch('panels.web_panel.get_local_ip')
    def test_dashboard_data(self, mock_ip):
        """Test dashboard data endpoint"""
        mock_ip.return_value = '192.168.1.100'

        response = self.client.get('/api/dashboard-data')
        self.assertEqual(response.status_code, 200)

        data = json.loads(response.data)
        self.assertIn('local_ip', data)
        self.assertIn('public_ip', data)

class TestAPI(unittest.TestCase):
    def setUp(self):
        self.app = api_app.test_client()

    def test_health_endpoint(self):
        """Test API health endpoint"""
        response = self.app.get('/api/health')
        self.assertEqual(response.status_code, 200)

        data = json.loads(response.data)
        self.assertEqual(data['status'], 'healthy')
        self.assertIn('version', data)

    @patch('api.rest_api.get_db_connection')
    def test_statistics_endpoint(self, mock_db):
        """Test statistics endpoint"""
        # Mock database connection
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_conn.execute.return_value = mock_cursor
        mock_cursor.fetchone.return_value = [100, 50.0, 100.0, 10.0]  # Mock stats
        mock_db.return_value = mock_conn

        response = self.app.get('/api/statistics')
        self.assertEqual(response.status_code, 200)

        data = json.loads(response.data)
        self.assertIn('dns', data)
        self.assertIn('traffic', data)

class TestNotifications(unittest.TestCase):
    def setUp(self):
        self.notification_manager = NotificationManager()

    def test_config_loading(self):
        """Test notification configuration loading"""
        config = self.notification_manager.config
        self.assertIsInstance(config, dict)
        self.assertIn('email', config)
        self.assertIn('alerts', config)

    def test_alert_sending(self):
        """Test alert sending functionality"""
        with patch.object(self.notification_manager, 'send_email_alert') as mock_email:
            self.notification_manager.send_alert(
                'Test Alert',
                'This is a test message'
            )
            mock_email.assert_called_once()

class TestMetrics(unittest.TestCase):
    def setUp(self):
        self.metrics_collector = MetricsCollector()

    def test_system_metrics_collection(self):
        """Test system metrics collection"""
        with patch('monitoring.metrics_collector.psutil') as mock_psutil:
            mock_psutil.cpu_percent.return_value = 45.5
            mock_psutil.virtual_memory.return_value.percent = 60.0

            metrics = self.metrics_collector.collect_system_metrics()

            self.assertIn('cpu_percent', metrics)
            self.assertIn('memory_percent', metrics)
            self.assertEqual(metrics['cpu_percent'], 45.5)

    def test_metrics_history(self):
        """Test metrics history storage"""
        initial_length = len(self.metrics_collector.metrics_history['system'])

        self.metrics_collector.collect_all_metrics()

        new_length = len(self.metrics_collector.metrics_history['system'])
        self.assertEqual(new_length, initial_length + 1)

class TestAuthentication(unittest.TestCase):
    def setUp(self):
        self.app = auth_app.test_client()

    def test_login_page(self):
        """Test login page rendering"""
        response = self.app.get('/auth/login')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'InvictusDNS Login', response.data)

    @patch('auth.advanced_auth.verify_password')
    @patch('auth.advanced_auth.get_db_connection')
    def test_login_attempt(self, mock_db, mock_verify):
        """Test login attempt"""
        mock_verify.return_value = True

        mock_conn = MagicMock()
        mock_user = MagicMock()
        mock_user.__getitem__.side_effect = lambda x: {
            'id': 1, 'username': 'testuser', 'password_hash': 'hash',
            'role': 'user', 'two_factor_secret': None, 'two_factor_enabled': False,
            'created_at': '2024-01-01', 'last_login': None, 'login_attempts': 0,
            'locked_until': None, 'active': True
        }[x]
        mock_conn.execute.return_value.fetchone.return_value = mock_user
        mock_db.return_value = mock_conn

        response = self.app.post('/auth/login',
                               json={'username': 'testuser', 'password': 'password'})

        self.assertEqual(response.status_code, 200)

class TestCluster(unittest.TestCase):
    def setUp(self):
        self.cluster_manager = ClusterManager()

    def test_node_registration(self):
        """Test node registration"""
        from cluster.cluster_manager import ClusterNode

        node = ClusterNode('test-node', '127.0.0.1', 5001, 'worker')
        self.cluster_manager.register_node(node)

        self.assertIn('test-node', self.cluster_manager.nodes)
        self.assertEqual(self.cluster_manager.nodes['test-node'].ip, '127.0.0.1')

    def test_node_unregistration(self):
        """Test node unregistration"""
        from cluster.cluster_manager import ClusterNode

        node = ClusterNode('test-node-2', '127.0.0.1', 5002, 'worker')
        self.cluster_manager.register_node(node)

        self.assertIn('test-node-2', self.cluster_manager.nodes)

        self.cluster_manager.unregister_node('test-node-2')

        self.assertNotIn('test-node-2', self.cluster_manager.nodes)

class TestIntegration(unittest.TestCase):
    """Integration tests for multiple components"""

    def setUp(self):
        # Create temporary directory for integration tests
        self.temp_dir = tempfile.mkdtemp()
        self.original_cwd = os.getcwd()

        # Change to temp directory
        os.chdir(self.temp_dir)

        # Create mock data directory
        os.makedirs('InvictusDNS_Data/dados', exist_ok=True)

    def tearDown(self):
        # Restore original directory
        os.chdir(self.original_cwd)

        # Clean up temp directory
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_full_system_initialization(self):
        """Test full system initialization"""
        # This would test the integration of multiple components
        # For now, just test that we can import and instantiate main components

        try:
            from server.dns_server import DNSServer
            from panels.web_panel import WebPanel
            from api.rest_api import app as api_app

            dns_server = DNSServer()
            web_panel = WebPanel()

            self.assertIsInstance(dns_server, DNSServer)
            self.assertIsInstance(web_panel, WebPanel)
            self.assertIsNotNone(api_app)

        except ImportError as e:
            self.skipTest(f"Import error: {e}")

class TestPerformance(unittest.TestCase):
    """Performance tests"""

    def setUp(self):
        self.metrics_collector = MetricsCollector()

    def test_metrics_collection_performance(self):
        """Test that metrics collection is fast enough"""
        import time

        start_time = time.time()
        self.metrics_collector.collect_all_metrics()
        end_time = time.time()

        duration = end_time - start_time

        # Should complete in less than 1 second
        self.assertLess(duration, 1.0, "Metrics collection took too long")

def run_tests():
    """Run all tests with coverage"""
    # Create test suite
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()

    # Add test classes
    test_classes = [
        TestDNSServer,
        TestWebPanel,
        TestAPI,
        TestNotifications,
        TestMetrics,
        TestAuthentication,
        TestCluster,
        TestIntegration,
        TestPerformance
    ]

    for test_class in test_classes:
        suite.addTests(loader.loadTestsFromTestCase(test_class))

    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

    # Print summary
    print(f"\n{'='*50}")
    print("TEST SUMMARY")
    print(f"{'='*50}")
    print(f"Tests run: {result.testsRun}")
    print(f"Failures: {len(result.failures)}")
    print(f"Errors: {len(result.errors)}")
    print(f"Skipped: {len(result.skipped)}")

    if result.wasSuccessful():
        print("✅ All tests passed!")
        return 0
    else:
        print("❌ Some tests failed!")
        return 1

if __name__ == '__main__':
    exit_code = run_tests()
    sys.exit(exit_code)

"""
Network Agent for InvictusDNS AI System

This agent specializes in network optimization, traffic analysis, and
infrastructure monitoring. It monitors network performance, optimizes
traffic routing, and ensures network reliability.

Features:
- Real-time network monitoring and analysis
- Traffic optimization and load balancing
- Network performance metrics
- Bandwidth management
- Connection quality assessment
- Network topology discovery
- Routing optimization
- QoS (Quality of Service) management

Author: BLACKBOXAI
"""

import time
import json
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import threading
import psutil
import socket
import subprocess
from collections import defaultdict, deque

from .base_agent import BaseAgent, AgentPriority, Message

class NetworkMetrics:
    """Network performance metrics"""
    def __init__(self):
        self.bytes_sent = 0
        self.bytes_recv = 0
        self.packets_sent = 0
        self.packets_recv = 0
        self.errors_in = 0
        self.errors_out = 0
        self.drops_in = 0
        self.drops_out = 0
        self.latency = 0.0
        self.jitter = 0.0
        self.bandwidth_usage = 0.0

class ConnectionInfo:
    """Network connection information"""
    def __init__(self, local_addr: str, remote_addr: str, status: str,
                 protocol: str = 'tcp', pid: int = None):
        self.local_addr = local_addr
        self.remote_addr = remote_addr
        self.status = status
        self.protocol = protocol
        self.pid = pid
        self.start_time = datetime.now()
        self.bytes_sent = 0
        self.bytes_recv = 0

class NetworkAgent(BaseAgent):
    """
    Specialized network agent for monitoring and optimization.

    Monitors network traffic, analyzes performance, optimizes routing,
    and ensures network reliability for the InvictusDNS system.
    """

    def __init__(self, coordinator=None, config: Dict[str, Any] = None):
        super().__init__(
            agent_id="network_agent",
            name="Network Agent",
            coordinator=coordinator,
            config=config or {},
            log_level="INFO"
        )

        # Network-specific configuration
        self.monitoring_interval = self.config.get('monitoring_interval', 30)  # seconds
        self.bandwidth_limits = self.config.get('bandwidth_limits', {})
        self.qos_rules = self.config.get('qos_rules', [])

        # Network state
        self.network_interfaces = {}
        self.active_connections = {}
        self.routing_table = {}
        self.network_topology = {}

        # Performance data
        self.metrics_history = deque(maxlen=100)  # Keep last 100 measurements
        self.connection_history = deque(maxlen=1000)  # Keep last 1000 connections

        # Optimization settings
        self.load_balancing_enabled = self.config.get('load_balancing', True)
        self.auto_optimization = self.config.get('auto_optimization', True)
        self.traffic_shaping = self.config.get('traffic_shaping', False)

        self.logger.info("Network Agent initialized")

    def _initialize(self):
        """Initialize network-specific components"""
        # Discover network interfaces
        self._discover_network_interfaces()

        # Load network configuration
        self._load_network_config()

        # Register network-specific message handlers
        self.register_handler('network_scan', self._handle_network_scan)
        self.register_handler('traffic_analysis', self._handle_traffic_analysis)
        self.register_handler('optimize_routing', self._handle_optimize_routing)
        self.register_handler('qos_update', self._handle_qos_update)
        self.register_handler('ip_blocked', self._handle_ip_blocked)

        # Start network monitoring threads
        self.monitoring_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
        self.optimization_thread = threading.Thread(target=self._optimization_loop, daemon=True)

        self.monitoring_thread.start()
        self.optimization_thread.start()

        self.logger.info("Network Agent components initialized")

    def _perform_work(self):
        """Perform network monitoring and optimization work"""
        try:
            # Update network metrics
            self._update_network_metrics()

            # Monitor connection health
            self._monitor_connection_health()

            # Analyze traffic patterns
            self._analyze_traffic_patterns()

            # Check network performance
            self._check_network_performance()

        except Exception as e:
            self.logger.error(f"Error in network work loop: {e}")
            self.error_count += 1

    def _cleanup(self):
        """Cleanup network-specific resources"""
        self._save_network_config()
        self.logger.info("Network Agent cleaned up")

    def get_capabilities(self) -> List[str]:
        """Return network agent capabilities"""
        return [
            "network_monitoring",
            "traffic_analysis",
            "routing_optimization",
            "load_balancing",
            "qos_management",
            "bandwidth_control",
            "connection_monitoring",
            "network_discovery"
        ]

    def _monitoring_loop(self):
        """Continuous network monitoring loop"""
        while self.running and self.state.value == "running":
            try:
                # Collect network statistics
                self._collect_network_stats()

                # Monitor active connections
                self._monitor_active_connections()

                # Check network interfaces status
                self._check_interface_status()

                # Update routing information
                self._update_routing_info()

                time.sleep(self.monitoring_interval)

            except Exception as e:
                self.logger.error(f"Error in monitoring loop: {e}")
                time.sleep(60)  # Back off on errors

    def _optimization_loop(self):
        """Network optimization loop"""
        while self.running and self.state.value == "running":
            try:
                if self.auto_optimization:
                    # Perform automatic optimizations
                    self._perform_auto_optimization()

                # Check for optimization opportunities
                self._check_optimization_opportunities()

                time.sleep(300)  # Check every 5 minutes

            except Exception as e:
                self.logger.error(f"Error in optimization loop: {e}")
                time.sleep(300)

    def _discover_network_interfaces(self):
        """Discover available network interfaces"""
        try:
            interfaces = psutil.net_if_addrs()
            for interface_name, addresses in interfaces.items():
                interface_info = {
                    'name': interface_name,
                    'addresses': [],
                    'status': 'unknown',
                    'stats': {}
                }

                for addr in addresses:
                    if addr.family == socket.AF_INET:
                        interface_info['addresses'].append({
                            'ip': addr.address,
                            'netmask': addr.netmask,
                            'broadcast': addr.broadcast
                        })
                    elif addr.family == socket.AF_INET6:
                        interface_info['addresses'].append({
                            'ip': addr.address,
                            'netmask': addr.netmask
                        })

                self.network_interfaces[interface_name] = interface_info

            self.logger.info(f"Discovered {len(self.network_interfaces)} network interfaces")

        except Exception as e:
            self.logger.error(f"Error discovering network interfaces: {e}")

    def _collect_network_stats(self):
        """Collect network statistics"""
        try:
            current_time = datetime.now()
            metrics = NetworkMetrics()

            # Get network I/O statistics
            net_stats = psutil.net_io_counters()
            metrics.bytes_sent = net_stats.bytes_sent
            metrics.bytes_recv = net_stats.bytes_recv
            metrics.packets_sent = net_stats.packets_sent
            metrics.packets_recv = net_stats.packets_recv
            metrics.errors_in = net_stats.errin
            metrics.errors_out = net_stats.errout
            metrics.drops_in = net_stats.dropin
            metrics.drops_out = net_stats.dropout

            # Calculate bandwidth usage
            if self.metrics_history:
                prev_metrics = self.metrics_history[-1]
                time_diff = (current_time - prev_metrics['timestamp']).total_seconds()
                if time_diff > 0:
                    metrics.bandwidth_usage = (metrics.bytes_sent - prev_metrics['bytes_sent']) / time_diff

            # Measure latency (ping to gateway)
            metrics.latency = self._measure_latency()

            # Store metrics
            self.metrics_history.append({
                'timestamp': current_time,
                'metrics': metrics
            })

        except Exception as e:
            self.logger.error(f"Error collecting network stats: {e}")

    def _monitor_active_connections(self):
        """Monitor active network connections"""
        try:
            connections = psutil.net_connections(kind='inet')

            current_connections = {}
            for conn in connections:
                if conn.status == 'ESTABLISHED':
                    key = f"{conn.laddr.ip}:{conn.laddr.port}-{conn.raddr.ip}:{conn.raddr.port}"
                    connection_info = ConnectionInfo(
                        local_addr=f"{conn.laddr.ip}:{conn.laddr.port}",
                        remote_addr=f"{conn.raddr.ip}:{conn.raddr.port}",
                        status=conn.status,
                        protocol='tcp',
                        pid=conn.pid
                    )
                    current_connections[key] = connection_info

            # Update connection tracking
            for key, conn_info in current_connections.items():
                if key not in self.active_connections:
                    self.active_connections[key] = conn_info
                    self.connection_history.append({
                        'timestamp': datetime.now(),
                        'type': 'new_connection',
                        'connection': key,
                        'info': conn_info.__dict__
                    })

            # Remove closed connections
            closed_connections = []
            for key in self.active_connections:
                if key not in current_connections:
                    closed_connections.append(key)
                    self.connection_history.append({
                        'timestamp': datetime.now(),
                        'type': 'closed_connection',
                        'connection': key
                    })

            for key in closed_connections:
                del self.active_connections[key]

        except Exception as e:
            self.logger.error(f"Error monitoring connections: {e}")

    def _update_network_metrics(self):
        """Update network performance metrics"""
        if self.metrics_history:
            latest = self.metrics_history[-1]['metrics']
            self.metrics['bytes_sent'] = latest.bytes_sent
            self.metrics['bytes_recv'] = latest.bytes_recv
            self.metrics['packets_sent'] = latest.packets_sent
            self.metrics['packets_recv'] = latest.packets_recv
            self.metrics['network_errors'] = latest.errors_in + latest.errors_out
            self.metrics['latency'] = latest.latency
            self.metrics['bandwidth_usage'] = latest.bandwidth_usage
            self.metrics['active_connections'] = len(self.active_connections)

    def _monitor_connection_health(self):
        """Monitor health of network connections"""
        try:
            unhealthy_connections = []

            for key, conn_info in self.active_connections.items():
                # Check connection age
                age = (datetime.now() - conn_info.start_time).total_seconds()
                if age > 3600:  # 1 hour
                    unhealthy_connections.append({
                        'connection': key,
                        'issue': 'long_running',
                        'age': age
                    })

            # Report unhealthy connections
            if unhealthy_connections:
                self.send_message(
                    "communication_agent",
                    "network_alert",
                    {
                        'type': 'unhealthy_connections',
                        'connections': unhealthy_connections
                    },
                    AgentPriority.NORMAL
                )

        except Exception as e:
            self.logger.error(f"Error monitoring connection health: {e}")

    def _analyze_traffic_patterns(self):
        """Analyze network traffic patterns"""
        try:
            if len(self.connection_history) < 10:
                return

            # Analyze connection patterns
            recent_connections = [c for c in self.connection_history
                                if (datetime.now() - c['timestamp']).total_seconds() < 3600]

            # Detect potential DDoS patterns
            ip_counts = defaultdict(int)
            for conn in recent_connections:
                if conn['type'] == 'new_connection':
                    # Extract IP from connection string
                    remote_ip = conn['connection'].split('-')[1].split(':')[0]
                    ip_counts[remote_ip] += 1

            # Check for suspicious activity
            for ip, count in ip_counts.items():
                if count > 50:  # Threshold for suspicious activity
                    self.send_message(
                        "security_agent",
                        "suspicious_traffic",
                        {
                            'ip': ip,
                            'connection_count': count,
                            'time_window': '1_hour'
                        },
                        AgentPriority.HIGH
                    )

        except Exception as e:
            self.logger.error(f"Error analyzing traffic patterns: {e}")

    def _check_network_performance(self):
        """Check overall network performance"""
        try:
            if not self.metrics_history:
                return

            latest = self.metrics_history[-1]['metrics']

            # Check latency
            if latest.latency > 100:  # High latency threshold
                self.logger.warning(f"High network latency detected: {latest.latency}ms")

            # Check error rates
            total_packets = latest.packets_sent + latest.packets_recv
            if total_packets > 0:
                error_rate = (latest.errors_in + latest.errors_out) / total_packets
                if error_rate > 0.01:  # 1% error rate threshold
                    self.logger.warning(f"High network error rate: {error_rate:.2%}")

            # Check bandwidth usage
            if latest.bandwidth_usage > 1000000:  # 1MB/s threshold
                self.logger.info(f"High bandwidth usage: {latest.bandwidth_usage / 1000000:.2f} MB/s")

        except Exception as e:
            self.logger.error(f"Error checking network performance: {e}")

    def _perform_auto_optimization(self):
        """Perform automatic network optimizations"""
        try:
            # Optimize routing table
            self._optimize_routing_table()

            # Adjust QoS settings
            self._adjust_qos_settings()

            # Balance network load
            if self.load_balancing_enabled:
                self._balance_network_load()

        except Exception as e:
            self.logger.error(f"Error in auto optimization: {e}")

    def _check_optimization_opportunities(self):
        """Check for network optimization opportunities"""
        try:
            # Check for unused bandwidth
            if self.metrics_history:
                avg_bandwidth = sum(m['metrics'].bandwidth_usage for m in self.metrics_history) / len(self.metrics_history)
                if avg_bandwidth < 100000:  # Low utilization
                    self.logger.info("Network underutilized - optimization opportunity detected")

            # Check for bottleneck interfaces
            self._check_interface_bottlenecks()

        except Exception as e:
            self.logger.error(f"Error checking optimization opportunities: {e}")

    def _measure_latency(self) -> float:
        """Measure network latency"""
        try:
            # Ping default gateway
            result = subprocess.run(
                ['ping', '-c', '1', '-W', '1', '8.8.8.8'],
                capture_output=True,
                text=True,
                timeout=5
            )

            if result.returncode == 0:
                # Extract latency from ping output
                lines = result.stdout.split('\n')
                for line in lines:
                    if 'time=' in line:
                        time_str = line.split('time=')[1].split()[0]
                        return float(time_str)

            return 999.0  # High latency if ping fails

        except Exception:
            return 999.0

    def _optimize_routing_table(self):
        """Optimize network routing table"""
        # Implementation would analyze and optimize routing
        self.logger.debug("Routing table optimization completed")

    def _adjust_qos_settings(self):
        """Adjust Quality of Service settings"""
        # Implementation would adjust QoS based on traffic analysis
        self.logger.debug("QoS settings adjusted")

    def _balance_network_load(self):
        """Balance network load across interfaces"""
        # Implementation would distribute traffic across available interfaces
        self.logger.debug("Network load balanced")

    def _check_interface_bottlenecks(self):
        """Check for network interface bottlenecks"""
        try:
            for interface_name, interface_info in self.network_interfaces.items():
                stats = psutil.net_if_stats().get(interface_name)
                if stats and not stats.isup:
                    self.logger.warning(f"Network interface {interface_name} is down")
        except Exception as e:
            self.logger.error(f"Error checking interface bottlenecks: {e}")

    def _check_interface_status(self):
        """Check status of network interfaces"""
        try:
            interface_stats = psutil.net_if_stats()
            for interface_name, stats in interface_stats.items():
                if interface_name in self.network_interfaces:
                    self.network_interfaces[interface_name]['status'] = 'up' if stats.isup else 'down'
                    self.network_interfaces[interface_name]['stats'] = {
                        'mtu': stats.mtu,
                        'speed': stats.speed,
                        'duplex': str(stats.duplex)
                    }
        except Exception as e:
            self.logger.error(f"Error checking interface status: {e}")

    def _update_routing_info(self):
        """Update routing table information"""
        try:
            # Get routing table (Unix-like systems)
            result = subprocess.run(['route', '-n'], capture_output=True, text=True)
            if result.returncode == 0:
                # Parse routing table
                lines = result.stdout.split('\n')
                for line in lines[2:]:  # Skip header
                    parts = line.split()
                    if len(parts) >= 8:
                        destination = parts[0]
                        gateway = parts[1]
                        self.routing_table[destination] = {
                            'gateway': gateway,
                            'interface': parts[7],
                            'flags': parts[3]
                        }
        except Exception as e:
            self.logger.error(f"Error updating routing info: {e}")

    def _load_network_config(self):
        """Load network configuration from file"""
        try:
            with open('data/network_agent_config.json', 'r') as f:
                config = json.load(f)
                self.bandwidth_limits.update(config.get('bandwidth_limits', {}))
                self.qos_rules.extend(config.get('qos_rules', []))
        except FileNotFoundError:
            pass
        except Exception as e:
            self.logger.error(f"Error loading network config: {e}")

    def _save_network_config(self):
        """Save network configuration to file"""
        try:
            config = {
                'bandwidth_limits': self.bandwidth_limits,
                'qos_rules': self.qos_rules,
                'last_save': datetime.now().isoformat()
            }
            with open('data/network_agent_config.json', 'w') as f:
                json.dump(config, f, indent=2)
        except Exception as e:
            self.logger.error(f"Error saving network config: {e}")

    # Message handlers
    def _handle_network_scan(self, message: Message) -> Dict[str, Any]:
        """Handle network scan request"""
        return {
            'interfaces': self.network_interfaces,
            'active_connections': len(self.active_connections),
            'routing_table_size': len(self.routing_table),
            'metrics': self.metrics.copy()
        }

    def _handle_traffic_analysis(self, message: Message) -> Dict[str, Any]:
        """Handle traffic analysis request"""
        analysis = {
            'total_connections': len(self.connection_history),
            'active_connections': len(self.active_connections),
            'recent_traffic': list(self.connection_history)[-10:],
            'performance_metrics': self.metrics.copy()
        }
        return analysis

    def _handle_optimize_routing(self, message: Message) -> Dict[str, Any]:
        """Handle routing optimization request"""
        self._optimize_routing_table()
        return {'status': 'routing_optimized'}

    def _handle_qos_update(self, message: Message) -> Dict[str, Any]:
        """Handle QoS update request"""
        new_rules = message.payload.get('rules', [])
        self.qos_rules = new_rules
        self._adjust_qos_settings()
        return {'status': 'qos_updated', 'rules_count': len(new_rules)}

    def _handle_ip_blocked(self, message: Message) -> Dict[str, Any]:
        """Handle IP blocked notification"""
        ip = message.payload.get('ip')
        reason = message.payload.get('reason', 'Unknown')

        # Update routing to avoid blocked IP
        self.logger.info(f"IP blocked notification received: {ip} - {reason}")

        # Could implement traffic rerouting here
        return {'status': 'acknowledged', 'ip': ip}

"""
Learning Agent for InvictusDNS AI System

This agent specializes in continuous learning, adaptation, and knowledge
management. It analyzes system behavior, learns from patterns, and
improves system performance over time.

Features:
- Continuous learning from system data
- Pattern recognition and analysis
- Predictive modeling
- Knowledge base management
- Model training and optimization
- Adaptation to changing conditions
- Performance analytics
- Learning from user interactions

Author: BLACKBOXAI
"""

import time
import json
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import threading
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, IsolationForest
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
import joblib
from collections import defaultdict, deque

from .base_agent import BaseAgent, AgentPriority, Message

class LearningModel:
    """Container for machine learning models"""
    def __init__(self, model_type: str, model=None, scaler=None):
        self.model_type = model_type
        self.model = model
        self.scaler = scaler
        self.created_at = datetime.now()
        self.last_trained = None
        self.accuracy = 0.0
        self.training_samples = 0

class LearningAgent(BaseAgent):
    """
    Specialized learning agent for continuous adaptation and improvement.

    Learns from system behavior, user interactions, and environmental data
    to improve system performance and provide intelligent insights.
    """

    def __init__(self, coordinator=None, config: Dict[str, Any] = None):
        super().__init__(
            agent_id="learning_agent",
            name="Learning Agent",
            coordinator=coordinator,
            config=config or {},
            log_level="INFO"
        )

        # Learning-specific configuration
        self.learning_rate = self.config.get('learning_rate', 0.01)
        self.retrain_interval = self.config.get('retrain_interval', 3600)  # 1 hour
        self.min_training_samples = self.config.get('min_training_samples', 100)
        self.model_save_path = self.config.get('model_save_path', 'data/models/')

        # Learning models
        self.models = {}
        self.training_data = defaultdict(list)
        self.knowledge_base = {}

        # Learning state
        self.learning_cycles = 0
        self.last_retrain = datetime.now()
        self.performance_history = deque(maxlen=1000)

        # Adaptation settings
        self.adaptive_learning = self.config.get('adaptive_learning', True)
        self.online_learning = self.config.get('online_learning', True)
        self.knowledge_sharing = self.config.get('knowledge_sharing', True)

        # Initialize default models
        self._initialize_models()

        self.logger.info("Learning Agent initialized")

    def _initialize(self):
        """Initialize learning-specific components"""
        # Load existing models and knowledge
        self._load_models()
        self._load_knowledge_base()

        # Register learning-specific message handlers
        self.register_handler('learn_pattern', self._handle_learn_pattern)
        self.register_handler('predict_outcome', self._handle_predict_outcome)
        self.register_handler('update_knowledge', self._handle_update_knowledge)
        self.register_handler('analyze_performance', self._handle_analyze_performance)
        self.register_handler('share_knowledge', self._handle_share_knowledge)

        # Start learning threads
        self.learning_thread = threading.Thread(target=self._learning_loop, daemon=True)
        self.adaptation_thread = threading.Thread(target=self._adaptation_loop, daemon=True)

        self.learning_thread.start()
        self.adaptation_thread.start()

        self.logger.info("Learning Agent components initialized")

    def _perform_work(self):
        """Perform learning and adaptation work"""
        try:
            # Collect learning data
            self._collect_learning_data()

            # Update performance metrics
            self._update_performance_metrics()

            # Check for retraining opportunities
            self._check_retraining_needs()

            # Analyze system behavior
            self._analyze_system_behavior()

        except Exception as e:
            self.logger.error(f"Error in learning work loop: {e}")
            self.error_count += 1

    def _cleanup(self):
        """Cleanup learning-specific resources"""
        self._save_models()
        self._save_knowledge_base()
        self.logger.info("Learning Agent cleaned up")

    def get_capabilities(self) -> List[str]:
        """Return learning agent capabilities"""
        return [
            "pattern_learning",
            "predictive_modeling",
            "knowledge_management",
            "performance_analysis",
            "adaptive_learning",
            "behavior_analysis",
            "model_training",
            "knowledge_sharing"
        ]

    def _initialize_models(self):
        """Initialize default machine learning models"""
        try:
            # Anomaly detection model
            anomaly_model = IsolationForest(contamination=0.1, random_state=42)
            self.models['anomaly_detector'] = LearningModel('anomaly_detection', anomaly_model)

            # Pattern classification model
            pattern_model = RandomForestClassifier(n_estimators=100, random_state=42)
            self.models['pattern_classifier'] = LearningModel('classification', pattern_model)

            # Performance prediction model
            perf_model = RandomForestClassifier(n_estimators=50, random_state=42)
            self.models['performance_predictor'] = LearningModel('classification', perf_model)

            self.logger.info("Default models initialized")

        except Exception as e:
            self.logger.error(f"Error initializing models: {e}")

    def _learning_loop(self):
        """Continuous learning loop"""
        while self.running and self.state.value == "running":
            try:
                # Process new learning data
                self._process_learning_data()

                # Update models with new data
                if self.online_learning:
                    self._online_model_update()

                # Share knowledge with other agents
                if self.knowledge_sharing:
                    self._share_knowledge()

                time.sleep(300)  # Learn every 5 minutes

            except Exception as e:
                self.logger.error(f"Error in learning loop: {e}")
                time.sleep(300)

    def _adaptation_loop(self):
        """Continuous adaptation loop"""
        while self.running and self.state.value == "running":
            try:
                # Analyze current system performance
                self._analyze_current_performance()

                # Generate adaptation recommendations
                self._generate_adaptation_recommendations()

                # Apply adaptive changes
                self._apply_adaptive_changes()

                time.sleep(600)  # Adapt every 10 minutes

            except Exception as e:
                self.logger.error(f"Error in adaptation loop: {e}")
                time.sleep(600)

    def _collect_learning_data(self):
        """Collect data for learning"""
        try:
            # Get data from other agents
            self.send_message(
                "communication_agent",
                "request_data",
                {"data_types": ["performance", "behavior", "interactions"]},
                AgentPriority.NORMAL
            )

            # Collect system metrics
            system_data = self._collect_system_metrics()
            self.training_data['system_performance'].append(system_data)

            # Collect user interaction data
            interaction_data = self._collect_interaction_data()
            self.training_data['user_interactions'].append(interaction_data)

        except Exception as e:
            self.logger.error(f"Error collecting learning data: {e}")

    def _process_learning_data(self):
        """Process collected learning data"""
        try:
            for data_type, data_list in self.training_data.items():
                if len(data_list) >= self.min_training_samples:
                    # Prepare data for model training
                    processed_data = self._preprocess_data(data_list)

                    # Update relevant models
                    self._update_model(data_type, processed_data)

                    # Clear processed data to save memory
                    self.training_data[data_type] = data_list[-100:]  # Keep last 100 samples

        except Exception as e:
            self.logger.error(f"Error processing learning data: {e}")

    def _update_model(self, data_type: str, data: pd.DataFrame):
        """Update a specific model with new data"""
        try:
            if data_type == 'system_performance':
                model_key = 'performance_predictor'
            elif data_type == 'user_interactions':
                model_key = 'pattern_classifier'
            else:
                return

            if model_key in self.models:
                model_container = self.models[model_key]

                # Prepare features and labels
                if len(data) > 1:
                    X = data.drop('target', axis=1) if 'target' in data.columns else data
                    y = data['target'] if 'target' in data.columns else None

                    # Scale features
                    if model_container.scaler:
                        X_scaled = model_container.scaler.transform(X)
                    else:
                        model_container.scaler = StandardScaler()
                        X_scaled = model_container.scaler.fit_transform(X)

                    # Train or update model
                    if y is not None:
                        model_container.model.fit(X_scaled, y)
                        model_container.accuracy = self._evaluate_model(model_container.model, X_scaled, y)
                    else:
                        # Unsupervised learning
                        model_container.model.fit(X_scaled)

                    model_container.last_trained = datetime.now()
                    model_container.training_samples = len(data)

                    self.logger.info(f"Updated model {model_key}: accuracy={model_container.accuracy:.3f}")

        except Exception as e:
            self.logger.error(f"Error updating model {data_type}: {e}")

    def _online_model_update(self):
        """Perform online model updates with streaming data"""
        try:
            # Implement online learning algorithms
            # This would use techniques like incremental learning
            pass

        except Exception as e:
            self.logger.error(f"Error in online model update: {e}")

    def _analyze_system_behavior(self):
        """Analyze system behavior patterns"""
        try:
            if len(self.performance_history) < 10:
                return

            # Detect performance trends
            recent_performance = list(self.performance_history)[-10:]
            avg_performance = sum(p['score'] for p in recent_performance) / len(recent_performance)

            # Identify performance degradation
            if avg_performance < 0.7:  # Below 70% performance
                self.send_message(
                    "automation_agent",
                    "performance_alert",
                    {
                        'alert_type': 'performance_degradation',
                        'current_score': avg_performance,
                        'recommendations': self._generate_performance_recommendations()
                    },
                    AgentPriority.HIGH
                )

            # Detect unusual patterns
            anomalies = self._detect_behavior_anomalies(recent_performance)
            if anomalies:
                self.send_message(
                    "security_agent",
                    "behavior_anomaly",
                    {'anomalies': anomalies},
                    AgentPriority.NORMAL
                )

        except Exception as e:
            self.logger.error(f"Error analyzing system behavior: {e}")

    def _check_retraining_needs(self):
        """Check if models need retraining"""
        try:
            current_time = datetime.now()

            for model_key, model_container in self.models.items():
                if model_container.last_trained:
                    time_since_train = (current_time - model_container.last_trained).total_seconds()

                    if time_since_train > self.retrain_interval:
                        self.logger.info(f"Model {model_key} needs retraining")
                        # Trigger retraining
                        self._retrain_model(model_key)

        except Exception as e:
            self.logger.error(f"Error checking retraining needs: {e}")

    def _retrain_model(self, model_key: str):
        """Retrain a specific model"""
        try:
            if model_key not in self.models:
                return

            # Collect fresh training data
            training_data = self._collect_fresh_training_data(model_key)

            if training_data and len(training_data) >= self.min_training_samples:
                self._update_model(model_key, pd.DataFrame(training_data))
                self.logger.info(f"Retrained model {model_key}")

        except Exception as e:
            self.logger.error(f"Error retraining model {model_key}: {e}")

    def _share_knowledge(self):
        """Share learned knowledge with other agents"""
        try:
            knowledge_summary = {
                'learned_patterns': list(self.knowledge_base.keys())[:10],  # Top 10 patterns
                'model_performance': {k: v.accuracy for k, v in self.models.items()},
                'insights': self._generate_current_insights()
            }

            self.send_message(
                "communication_agent",
                "knowledge_update",
                knowledge_summary,
                AgentPriority.NORMAL
            )

        except Exception as e:
            self.logger.error(f"Error sharing knowledge: {e}")

    def _analyze_current_performance(self):
        """Analyze current system performance"""
        try:
            # Get performance data from other agents
            performance_data = self._get_performance_data()

            # Calculate performance score
            score = self._calculate_performance_score(performance_data)

            # Store in history
            self.performance_history.append({
                'timestamp': datetime.now(),
                'score': score,
                'metrics': performance_data
            })

        except Exception as e:
            self.logger.error(f"Error analyzing current performance: {e}")

    def _generate_adaptation_recommendations(self):
        """Generate recommendations for system adaptation"""
        try:
            if len(self.performance_history) < 5:
                return []

            # Analyze performance trends
            recent_scores = [p['score'] for p in list(self.performance_history)[-5:]]

            recommendations = []

            # Check for declining performance
            if recent_scores[-1] < recent_scores[0] * 0.9:  # 10% decline
                recommendations.append({
                    'type': 'performance_optimization',
                    'description': 'Performance declining - consider resource optimization',
                    'actions': ['increase_resources', 'optimize_queries', 'cache_more_data']
                })

            # Check for high resource usage
            avg_cpu = sum(p['metrics'].get('cpu_usage', 0) for p in self.performance_history) / len(self.performance_history)
            if avg_cpu > 80:
                recommendations.append({
                    'type': 'resource_optimization',
                    'description': 'High CPU usage detected',
                    'actions': ['optimize_cpu_intensive_tasks', 'implement_load_balancing']
                })

            return recommendations

        except Exception as e:
            self.logger.error(f"Error generating adaptation recommendations: {e}")
            return []

    def _apply_adaptive_changes(self):
        """Apply adaptive changes to the system"""
        try:
            recommendations = self._generate_adaptation_recommendations()

            for rec in recommendations:
                # Send adaptation recommendations to automation agent
                self.send_message(
                    "automation_agent",
                    "adaptation_recommendation",
                    rec,
                    AgentPriority.NORMAL
                )

        except Exception as e:
            self.logger.error(f"Error applying adaptive changes: {e}")

    def _preprocess_data(self, data_list: List[Dict]) -> pd.DataFrame:
        """Preprocess learning data for model training"""
        try:
            df = pd.DataFrame(data_list)

            # Handle missing values
            df = df.fillna(df.mean())

            # Convert categorical variables
            categorical_cols = df.select_dtypes(include=['object']).columns
            for col in categorical_cols:
                df[col] = pd.Categorical(df[col]).codes

            return df

        except Exception as e:
            self.logger.error(f"Error preprocessing data: {e}")
            return pd.DataFrame()

    def _evaluate_model(self, model, X, y) -> float:
        """Evaluate model performance"""
        try:
            predictions = model.predict(X)
            return accuracy_score(y, predictions)
        except Exception:
            return 0.0

    def _collect_system_metrics(self) -> Dict[str, Any]:
        """Collect system performance metrics"""
        # Implementation would collect actual system metrics
        return {
            'cpu_usage': 45.2,
            'memory_usage': 67.8,
            'disk_usage': 34.1,
            'network_usage': 12.3,
            'timestamp': datetime.now().isoformat()
        }

    def _collect_interaction_data(self) -> Dict[str, Any]:
        """Collect user interaction data"""
        # Implementation would collect actual interaction data
        return {
            'user_actions': ['login', 'query', 'update'],
            'response_times': [0.5, 1.2, 0.8],
            'success_rate': 0.95,
            'timestamp': datetime.now().isoformat()
        }

    def _detect_behavior_anomalies(self, performance_data: List[Dict]) -> List[Dict]:
        """Detect anomalies in behavior data"""
        # Simple anomaly detection
        anomalies = []
        scores = [p['score'] for p in performance_data]

        if len(scores) > 3:
            mean_score = sum(scores) / len(scores)
            std_score = np.std(scores)

            for i, score in enumerate(scores):
                if abs(score - mean_score) > 2 * std_score:  # 2 standard deviations
                    anomalies.append({
                        'index': i,
                        'score': score,
                        'deviation': abs(score - mean_score),
                        'timestamp': performance_data[i]['timestamp']
                    })

        return anomalies

    def _get_performance_data(self) -> Dict[str, Any]:
        """Get current performance data"""
        # Implementation would get actual performance data
        return {
            'cpu_usage': 45.2,
            'memory_usage': 67.8,
            'response_time': 0.8,
            'error_rate': 0.02
        }

    def _calculate_performance_score(self, data: Dict[str, Any]) -> float:
        """Calculate overall performance score"""
        try:
            # Simple weighted scoring
            cpu_weight = 0.3
            memory_weight = 0.2
            response_weight = 0.3
            error_weight = 0.2

            cpu_score = max(0, 1 - data.get('cpu_usage', 0) / 100)
            memory_score = max(0, 1 - data.get('memory_usage', 0) / 100)
            response_score = max(0, 1 - data.get('response_time', 0) / 5)  # Max 5 seconds
            error_score = max(0, 1 - data.get('error_rate', 0) * 10)  # Scale error rate

            total_score = (cpu_score * cpu_weight +
                          memory_score * memory_weight +
                          response_score * response_weight +
                          error_score * error_weight)

            return total_score

        except Exception:
            return 0.5  # Default neutral score

    def _generate_performance_recommendations(self) -> List[str]:
        """Generate performance improvement recommendations"""
        return [
            "Optimize database queries",
            "Implement caching for frequently accessed data",
            "Scale up server resources",
            "Review and optimize algorithms"
        ]

    def _collect_fresh_training_data(self, model_key: str) -> List[Dict]:
        """Collect fresh training data for a specific model"""
        # Implementation would collect fresh data based on model type
        return []

    def _generate_current_insights(self) -> List[str]:
        """Generate current system insights"""
        return [
            "System performance is stable",
            "User engagement patterns detected",
            "Potential optimization opportunities identified"
        ]

    def _load_models(self):
        """Load saved models from disk"""
        try:
            import os
            if os.path.exists(self.model_save_path):
                for filename in os.listdir(self.model_save_path):
                    if filename.endswith('.pkl'):
                        model_name = filename[:-4]  # Remove .pkl extension
                        model_path = os.path.join(self.model_save_path, filename)
                        model = joblib.load(model_path)
                        self.models[model_name] = LearningModel(model_name, model)
                        self.logger.info(f"Loaded model: {model_name}")
        except Exception as e:
            self.logger.error(f"Error loading models: {e}")

    def _save_models(self):
        """Save models to disk"""
        try:
            import os
            os.makedirs(self.model_save_path, exist_ok=True)

            for model_name, model_container in self.models.items():
                if model_container.model:
                    model_path = os.path.join(self.model_save_path, f"{model_name}.pkl")
                    joblib.dump(model_container.model, model_path)
                    self.logger.info(f"Saved model: {model_name}")
        except Exception as e:
            self.logger.error(f"Error saving models: {e}")

    def _load_knowledge_base(self):
        """Load knowledge base from file"""
        try:
            with open('data/knowledge_base.json', 'r') as f:
                self.knowledge_base = json.load(f)
        except FileNotFoundError:
            self.knowledge_base = {}
        except Exception as e:
            self.logger.error(f"Error loading knowledge base: {e}")

    def _save_knowledge_base(self):
        """Save knowledge base to file"""
        try:
            with open('data/knowledge_base.json', 'w') as f:
                json.dump(self.knowledge_base, f, indent=2)
        except Exception as e:
            self.logger.error(f"Error saving knowledge base: {e}")

    def _update_performance_metrics(self):
        """Update learning-specific performance metrics"""
        self.metrics['learning_cycles'] = self.learning_cycles
        self.metrics['models_trained'] = len([m for m in self.models.values() if m.last_trained])
        self.metrics['knowledge_base_size'] = len(self.knowledge_base)
        self.metrics['training_samples'] = sum(len(data) for data in self.training_data.values())

    # Message handlers
    def _handle_learn_pattern(self, message: Message) -> Dict[str, Any]:
        """Handle pattern learning request"""
        pattern_data = message.payload.get('pattern_data', {})
        pattern_type = message.payload.get('pattern_type', 'unknown')

        # Add to training data
        self.training_data[pattern_type].append(pattern_data)

        return {'status': 'pattern_learned', 'samples': len(self.training_data[pattern_type])}

    def _handle_predict_outcome(self, message: Message) -> Dict[str, Any]:
        """Handle outcome prediction request"""
        features = message.payload.get('features', {})
        model_type = message.payload.get('model_type', 'pattern_classifier')

        if model_type in self.models:
            model_container = self.models[model_type]
            if model_container.model and model_container.scaler:
                # Prepare features
                feature_df = pd.DataFrame([features])
                scaled_features = model_container.scaler.transform(feature_df)

                # Make prediction
                prediction = model_container.model.predict(scaled_features)[0]
                confidence = max(model_container.model.predict_proba(scaled_features)[0])

                return {
                    'prediction': prediction,
                    'confidence': float(confidence),
                    'model_accuracy': model_container.accuracy
                }

        return {'error': 'Model not available or not trained'}

    def _handle_update_knowledge(self, message: Message) -> Dict[str, Any]:
        """Handle knowledge update request"""
        key = message.payload.get('key')
        value = message.payload.get('value')

        if key:
            self.knowledge_base[key] = {
                'value': value,
                'updated_at': datetime.now().isoformat(),
                'source': message.sender
            }
            return {'status': 'knowledge_updated'}

        return {'error': 'No key provided'}

    def _handle_analyze_performance(self, message: Message) -> Dict[str, Any]:
        """Handle performance analysis request"""
        analysis = {
            'current_score': self.performance_history[-1]['score'] if self.performance_history else 0,
            'trend': self._calculate_performance_trend(),
            'recommendations': self._generate_performance_recommendations(),
            'metrics': self.metrics.copy()
        }
        return analysis

    def _handle_share_knowledge(self, message: Message) -> Dict[str, Any]:
        """Handle knowledge sharing request"""
        recipient = message.payload.get('recipient')

        knowledge_packet = {
            'knowledge_base': self.knowledge_base,
            'learned_patterns': list(self.training_data.keys()),
            'model_insights': {k: v.accuracy for k, v in self.models.items()}
        }

        if recipient:
            self.send_message(
                recipient,
                "knowledge_packet",
                knowledge_packet,
                AgentPriority.NORMAL
            )

        return {'status': 'knowledge_shared', 'recipient': recipient}

    def _calculate_performance_trend(self) -> str:
        """Calculate performance trend"""
        if len(self.performance_history) < 2:
            return "insufficient_data"

        recent_scores = [p['score'] for p in list(self.performance_history)[-5:]]
        if len(recent_scores) < 2:
            return "stable"

        trend = recent_scores[-1] - recent_scores[0]
        if trend > 0.1:
            return "improving"
        elif trend < -0.1:
            return "declining"
        else:
            return "stable"

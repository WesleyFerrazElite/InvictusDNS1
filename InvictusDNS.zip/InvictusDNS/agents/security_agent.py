"""
Security Agent for InvictusDNS AI System

This agent specializes in cybersecurity, threat detection, and protection.
It monitors network traffic, analyzes security events, detects anomalies,
and responds to security threats automatically.

Features:
- Real-time threat detection and analysis
- Anomaly detection in network traffic
- Automated security response actions
- Integration with existing security monitoring
- Threat intelligence gathering
- Security policy enforcement
- Incident response coordination
- Vulnerability assessment

Author: BLACKBOXAI
"""

import time
import json
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import threading
import re
import hashlib
from collections import defaultdict, deque

from .base_agent import BaseAgent, AgentPriority, Message
from ..ai_core import ai_core

class ThreatLevel:
    """Threat level enumeration"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class SecurityEvent:
    """Security event class"""
    def __init__(self, event_type: str, severity: str, source_ip: str,
                 description: str, details: Dict[str, Any] = None):
        self.id = hashlib.md5(f"{event_type}{source_ip}{datetime.now().isoformat()}".encode()).hexdigest()
        self.timestamp = datetime.now()
        self.event_type = event_type
        self.severity = severity
        self.source_ip = source_ip
        self.description = description
        self.details = details or {}
        self.resolved = False
        self.response_actions = []

    def to_dict(self) -> Dict[str, Any]:
        return {
            'id': self.id,
            'timestamp': self.timestamp.isoformat(),
            'event_type': self.event_type,
            'severity': self.severity,
            'source_ip': self.source_ip,
            'description': self.description,
            'details': self.details,
            'resolved': self.resolved,
            'response_actions': self.response_actions
        }

class SecurityAgent(BaseAgent):
    """
    Specialized security agent for threat detection and response.

    Monitors network traffic, analyzes security events, and provides
    automated security responses to protect the InvictusDNS system.
    """

    def __init__(self, coordinator=None, config: Dict[str, Any] = None):
        super().__init__(
            agent_id="security_agent",
            name="Security Agent",
            coordinator=coordinator,
            config=config or {},
            log_level="INFO"
        )

        # Security-specific configuration
        self.threat_thresholds = self.config.get('threat_thresholds', {
            'suspicious_connections': 10,
            'failed_logins': 5,
            'unusual_traffic': 1000
        })

        self.blocked_ips = set()
        self.suspicious_ips = set()
        self.threat_patterns = self._load_threat_patterns()
        self.security_events = deque(maxlen=1000)  # Keep last 1000 events
        self.active_incidents = {}

        # Monitoring data
        self.connection_attempts = defaultdict(int)
        self.failed_logins = defaultdict(int)
        self.traffic_anomalies = []

        # AI integration
        self.ai_core = ai_core

        # Response actions
        self.auto_response_enabled = self.config.get('auto_response', True)
        self.response_actions = []

        self.logger.info("Security Agent initialized")

    def _initialize(self):
        """Initialize security-specific components"""
        # Load existing security data
        self._load_security_data()

        # Register security-specific message handlers
        self.register_handler('security_scan', self._handle_security_scan)
        self.register_handler('threat_analysis', self._handle_threat_analysis)
        self.register_handler('block_ip', self._handle_block_ip)
        self.register_handler('unblock_ip', self._handle_unblock_ip)
        self.register_handler('incident_report', self._handle_incident_report)

        # Start security monitoring threads
        self.monitoring_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
        self.monitoring_thread.start()

        self.logger.info("Security Agent components initialized")

    def _perform_work(self):
        """Perform security monitoring and analysis work"""
        try:
            # Analyze recent traffic patterns
            self._analyze_traffic_patterns()

            # Check for suspicious activities
            self._check_suspicious_activities()

            # Update threat intelligence
            self._update_threat_intelligence()

            # Process active incidents
            self._process_incidents()

            # Clean up old data
            self._cleanup_old_data()

        except Exception as e:
            self.logger.error(f"Error in security work loop: {e}")
            self.error_count += 1

    def _cleanup(self):
        """Cleanup security-specific resources"""
        self._save_security_data()
        self.logger.info("Security Agent cleaned up")

    def get_capabilities(self) -> List[str]:
        """Return security agent capabilities"""
        return [
            "threat_detection",
            "anomaly_analysis",
            "security_monitoring",
            "incident_response",
            "ip_blocking",
            "traffic_analysis",
            "vulnerability_scanning",
            "threat_intelligence"
        ]

    def _monitoring_loop(self):
        """Continuous security monitoring loop"""
        while self.running and self.state.value == "running":
            try:
                # Monitor system logs for security events
                self._monitor_system_logs()

                # Check firewall status
                self._check_firewall_status()

                # Monitor for brute force attempts
                self._monitor_brute_force()

                # Update security metrics
                self._update_security_metrics()

                time.sleep(10)  # Check every 10 seconds

            except Exception as e:
                self.logger.error(f"Error in monitoring loop: {e}")
                time.sleep(30)  # Back off on errors

    def _analyze_traffic_patterns(self):
        """Analyze network traffic for anomalies"""
        try:
            # Get recent traffic data from coordinator or database
            recent_traffic = self._get_recent_traffic()

            # Detect unusual patterns
            anomalies = self._detect_traffic_anomalies(recent_traffic)

            for anomaly in anomalies:
                self._create_security_event(
                    event_type="traffic_anomaly",
                    severity=anomaly.get('severity', 'medium'),
                    source_ip=anomaly.get('source_ip', 'unknown'),
                    description=f"Traffic anomaly detected: {anomaly.get('description', 'Unknown')}",
                    details=anomaly
                )

        except Exception as e:
            self.logger.error(f"Error analyzing traffic patterns: {e}")

    def _check_suspicious_activities(self):
        """Check for suspicious activities"""
        try:
            # Check for repeated connection attempts
            for ip, attempts in self.connection_attempts.items():
                if attempts > self.threat_thresholds['suspicious_connections']:
                    self._create_security_event(
                        event_type="suspicious_connections",
                        severity="medium",
                        source_ip=ip,
                        description=f"Multiple connection attempts from {ip}: {attempts}",
                        details={'attempts': attempts}
                    )

            # Check for failed login attempts
            for ip, failures in self.failed_logins.items():
                if failures > self.threat_thresholds['failed_logins']:
                    self._create_security_event(
                        event_type="brute_force_attempt",
                        severity="high",
                        source_ip=ip,
                        description=f"Brute force login attempts from {ip}: {failures}",
                        details={'failures': failures}
                    )

            # Reset counters periodically
            self._reset_activity_counters()

        except Exception as e:
            self.logger.error(f"Error checking suspicious activities: {e}")

    def _update_threat_intelligence(self):
        """Update threat intelligence from various sources"""
        try:
            # Get threat intelligence from AI
            threat_data = self.ai_core.analyze_threat_intelligence()

            # Update local threat patterns
            if threat_data.get('new_patterns'):
                self.threat_patterns.extend(threat_data['new_patterns'])
                self._save_threat_patterns()

            # Check for known malicious IPs
            malicious_ips = threat_data.get('malicious_ips', [])
            for ip in malicious_ips:
                if ip not in self.blocked_ips:
                    self._block_ip(ip, "Known malicious IP from threat intelligence")

        except Exception as e:
            self.logger.error(f"Error updating threat intelligence: {e}")

    def _process_incidents(self):
        """Process active security incidents"""
        try:
            for incident_id, incident in list(self.active_incidents.items()):
                # Check if incident should be escalated
                if self._should_escalate_incident(incident):
                    self._escalate_incident(incident)

                # Check if incident is resolved
                if self._is_incident_resolved(incident):
                    self._resolve_incident(incident_id)

        except Exception as e:
            self.logger.error(f"Error processing incidents: {e}")

    def _create_security_event(self, event_type: str, severity: str,
                              source_ip: str, description: str,
                              details: Dict[str, Any] = None):
        """Create a new security event"""
        event = SecurityEvent(event_type, severity, source_ip, description, details)
        self.security_events.append(event)

        # Log the event
        self.logger.warning(f"Security Event: {event_type} - {description}")

        # Send notification if high severity
        if severity in ['high', 'critical']:
            self._notify_security_event(event)

        # Trigger automated response if enabled
        if self.auto_response_enabled:
            self._trigger_automated_response(event)

        return event

    def _block_ip(self, ip: str, reason: str):
        """Block an IP address"""
        if ip not in self.blocked_ips:
            self.blocked_ips.add(ip)
            self.logger.warning(f"Blocked IP {ip}: {reason}")

            # Add firewall rule (implementation depends on system)
            self._add_firewall_rule(ip, "block", reason)

            # Notify other agents
            self.send_message(
                "network_agent",
                "ip_blocked",
                {"ip": ip, "reason": reason},
                AgentPriority.HIGH
            )

    def _unblock_ip(self, ip: str):
        """Unblock an IP address"""
        if ip in self.blocked_ips:
            self.blocked_ips.remove(ip)
            self.logger.info(f"Unblocked IP {ip}")

            # Remove firewall rule
            self._remove_firewall_rule(ip)

    def _trigger_automated_response(self, event: SecurityEvent):
        """Trigger automated response to security event"""
        try:
            # Use AI to determine appropriate response
            response_plan = self.ai_core.generate_security_response(event.to_dict())

            for action in response_plan.get('actions', []):
                self._execute_security_action(action, event)

        except Exception as e:
            self.logger.error(f"Error triggering automated response: {e}")

    def _execute_security_action(self, action: Dict[str, Any], event: SecurityEvent):
        """Execute a security response action"""
        action_type = action.get('type')

        if action_type == 'block_ip':
            self._block_ip(event.source_ip, action.get('reason', 'Automated response'))
        elif action_type == 'log_event':
            self.logger.warning(f"Security action logged: {action.get('message', 'Unknown')}")
        elif action_type == 'notify_admin':
            self._send_admin_notification(action.get('message', 'Security alert'))
        elif action_type == 'isolate_system':
            self._isolate_system(action.get('duration', 300))

        # Record the action
        event.response_actions.append(action)

    def _detect_traffic_anomalies(self, traffic_data: List[Dict]) -> List[Dict]:
        """Detect anomalies in traffic data"""
        anomalies = []

        try:
            # Simple anomaly detection based on statistical analysis
            if len(traffic_data) < 10:
                return anomalies

            # Calculate baseline statistics
            packet_sizes = [t.get('length', 0) for t in traffic_data]
            avg_size = sum(packet_sizes) / len(packet_sizes)

            # Check for anomalies
            for traffic in traffic_data[-50:]:  # Check last 50 packets
                size = traffic.get('length', 0)
                if abs(size - avg_size) > avg_size * 2:  # 200% deviation
                    anomalies.append({
                        'type': 'size_anomaly',
                        'severity': 'low',
                        'source_ip': traffic.get('src_ip', 'unknown'),
                        'description': f'Unusual packet size: {size} bytes',
                        'details': traffic
                    })

        except Exception as e:
            self.logger.error(f"Error detecting traffic anomalies: {e}")

        return anomalies

    def _load_threat_patterns(self) -> List[Dict]:
        """Load threat patterns from file"""
        try:
            with open('data/threat_patterns.json', 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            # Return default patterns
            return [
                {'pattern': r'admin.*login', 'type': 'brute_force', 'severity': 'high'},
                {'pattern': r'select.*from', 'type': 'sql_injection', 'severity': 'critical'},
                {'pattern': r'<script>', 'type': 'xss', 'severity': 'high'}
            ]
        except Exception as e:
            self.logger.error(f"Error loading threat patterns: {e}")
            return []

    def _save_threat_patterns(self):
        """Save threat patterns to file"""
        try:
            with open('data/threat_patterns.json', 'w') as f:
                json.dump(self.threat_patterns, f, indent=2)
        except Exception as e:
            self.logger.error(f"Error saving threat patterns: {e}")

    def _load_security_data(self):
        """Load security data from file"""
        try:
            with open('data/security_agent_data.json', 'r') as f:
                data = json.load(f)
                self.blocked_ips = set(data.get('blocked_ips', []))
                self.suspicious_ips = set(data.get('suspicious_ips', []))
        except FileNotFoundError:
            pass
        except Exception as e:
            self.logger.error(f"Error loading security data: {e}")

    def _save_security_data(self):
        """Save security data to file"""
        try:
            data = {
                'blocked_ips': list(self.blocked_ips),
                'suspicious_ips': list(self.suspicious_ips),
                'last_save': datetime.now().isoformat()
            }
            with open('data/security_agent_data.json', 'w') as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            self.logger.error(f"Error saving security data: {e}")

    def _reset_activity_counters(self):
        """Reset activity counters periodically"""
        # Reset every hour
        current_hour = datetime.now().hour
        if not hasattr(self, '_last_reset_hour'):
            self._last_reset_hour = current_hour

        if current_hour != self._last_reset_hour:
            self.connection_attempts.clear()
            self.failed_logins.clear()
            self._last_reset_hour = current_hour

    def _get_recent_traffic(self) -> List[Dict]:
        """Get recent traffic data"""
        # This would integrate with the network monitoring system
        # For now, return mock data
        return [
            {'src_ip': '192.168.1.100', 'length': 100, 'timestamp': datetime.now().isoformat()},
            {'src_ip': '192.168.1.101', 'length': 200, 'timestamp': datetime.now().isoformat()},
        ]

    def _monitor_system_logs(self):
        """Monitor system logs for security events"""
        # Implementation would depend on the system logging setup
        pass

    def _check_firewall_status(self):
        """Check firewall status"""
        # Implementation would check actual firewall status
        pass

    def _monitor_brute_force(self):
        """Monitor for brute force attempts"""
        # Implementation would check authentication logs
        pass

    def _update_security_metrics(self):
        """Update security-related metrics"""
        self.metrics['blocked_ips'] = len(self.blocked_ips)
        self.metrics['active_incidents'] = len(self.active_incidents)
        self.metrics['security_events'] = len(self.security_events)

    def _should_escalate_incident(self, incident) -> bool:
        """Check if incident should be escalated"""
        # Simple escalation logic
        return (datetime.now() - incident['created']) > timedelta(minutes=30)

    def _escalate_incident(self, incident):
        """Escalate a security incident"""
        self.logger.warning(f"Escalating incident: {incident['id']}")
        # Send escalation notification
        self._send_admin_notification(f"Incident escalated: {incident['description']}")

    def _is_incident_resolved(self, incident) -> bool:
        """Check if incident is resolved"""
        return incident.get('resolved', False)

    def _resolve_incident(self, incident_id: str):
        """Resolve a security incident"""
        if incident_id in self.active_incidents:
            self.active_incidents[incident_id]['resolved'] = True
            self.logger.info(f"Incident resolved: {incident_id}")

    def _notify_security_event(self, event: SecurityEvent):
        """Send notification about security event"""
        self.send_message(
            "communication_agent",
            "security_alert",
            {
                'event': event.to_dict(),
                'message': f"Security Alert: {event.description}"
            },
            AgentPriority.HIGH
        )

    def _send_admin_notification(self, message: str):
        """Send notification to administrators"""
        # This would integrate with notification system
        self.logger.warning(f"Admin Notification: {message}")

    def _isolate_system(self, duration: int):
        """Isolate system for security"""
        self.logger.warning(f"Isolating system for {duration} seconds")
        # Implementation would temporarily isolate the system
        time.sleep(duration)

    def _add_firewall_rule(self, ip: str, action: str, reason: str):
        """Add firewall rule"""
        # Implementation would add actual firewall rule
        self.logger.info(f"Firewall rule added: {action} {ip} - {reason}")

    def _remove_firewall_rule(self, ip: str):
        """Remove firewall rule"""
        # Implementation would remove actual firewall rule
        self.logger.info(f"Firewall rule removed: {ip}")

    # Message handlers
    def _handle_security_scan(self, message: Message) -> Dict[str, Any]:
        """Handle security scan request"""
        scan_results = {
            'blocked_ips': len(self.blocked_ips),
            'suspicious_ips': len(self.suspicious_ips),
            'active_incidents': len(self.active_incidents),
            'recent_events': len([e for e in self.security_events if not e.resolved])
        }
        return scan_results

    def _handle_threat_analysis(self, message: Message) -> Dict[str, Any]:
        """Handle threat analysis request"""
        target = message.payload.get('target', 'system')
        analysis = self.ai_core.analyze_threats(target)
        return analysis

    def _handle_block_ip(self, message: Message) -> Dict[str, Any]:
        """Handle IP blocking request"""
        ip = message.payload.get('ip')
        reason = message.payload.get('reason', 'Manual block')
        if ip:
            self._block_ip(ip, reason)
            return {'status': 'blocked', 'ip': ip}
        return {'status': 'error', 'message': 'No IP provided'}

    def _handle_unblock_ip(self, message: Message) -> Dict[str, Any]:
        """Handle IP unblocking request"""
        ip = message.payload.get('ip')
        if ip:
            self._unblock_ip(ip)
            return {'status': 'unblocked', 'ip': ip}
        return {'status': 'error', 'message': 'No IP provided'}

    def _handle_incident_report(self, message: Message) -> Dict[str, Any]:
        """Handle incident report request"""
        return {
            'active_incidents': list(self.active_incidents.values()),
            'recent_events': [e.to_dict() for e in list(self.security_events)[-10:]]
        }

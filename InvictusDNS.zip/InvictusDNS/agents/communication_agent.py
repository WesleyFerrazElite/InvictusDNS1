"""
Communication Agent for InvictusDNS AI System

This agent specializes in inter-agent communication, external integrations,
and message routing. It manages communication protocols, handles external
APIs, and coordinates information flow between all system components.

Features:
- Inter-agent message routing and coordination
- External API integrations (Telegram, webhooks, etc.)
- Notification management and delivery
- Message queuing and prioritization
- Communication protocol management
- External service integrations
- Real-time communication streaming
- Message encryption and security

Author: BLACKBOXAI
"""

import time
import json
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import threading
import requests
import asyncio
import websockets
from collections import defaultdict, deque
import hashlib
import hmac
import base64

from .base_agent import BaseAgent, AgentPriority, Message

class CommunicationChannel:
    """Communication channel configuration"""
    def __init__(self, channel_id: str, channel_type: str, config: Dict[str, Any]):
        self.id = channel_id
        self.type = channel_type  # telegram, webhook, email, sms, etc.
        self.config = config
        self.enabled = True
        self.created_at = datetime.now()
        self.last_used = None
        self.message_count = 0
        self.error_count = 0

class NotificationRule:
    """Notification rule configuration"""
    def __init__(self, rule_id: str, name: str, conditions: List[Dict],
                 channels: List[str], template: str, enabled: bool = True):
        self.id = rule_id
        self.name = name
        self.conditions = conditions
        self.channels = channels
        self.template = template
        self.enabled = enabled
        self.created_at = datetime.now()
        self.last_triggered = None
        self.trigger_count = 0

class CommunicationAgent(BaseAgent):
    """
    Specialized communication agent for managing all system communications.

    Handles inter-agent messaging, external integrations, notifications,
    and ensures reliable communication across the entire InvictusDNS system.
    """

    def __init__(self, coordinator=None, config: Dict[str, Any] = None):
        super().__init__(
            agent_id="communication_agent",
            name="Communication Agent",
            coordinator=coordinator,
            config=config or {},
            log_level="INFO"
        )

        # Communication-specific configuration
        self.message_queue_size = self.config.get('message_queue_size', 1000)
        self.retry_attempts = self.config.get('retry_attempts', 3)
        self.message_timeout = self.config.get('message_timeout', 300)  # 5 minutes

        # Communication state
        self.channels = {}
        self.notification_rules = {}
        self.message_queue = deque(maxlen=self.message_queue_size)
        self.pending_responses = {}
        self.active_streams = {}

        # External integrations
        self.telegram_config = self.config.get('telegram', {})
        self.webhook_config = self.config.get('webhooks', {})
        self.email_config = self.config.get('email', {})

        # Message routing
        self.route_table = {}
        self.message_history = deque(maxlen=5000)

        # Real-time communication
        self.websocket_clients = set()
        self.stream_subscribers = defaultdict(set)

        self.logger.info("Communication Agent initialized")

    def _initialize(self):
        """Initialize communication-specific components"""
        # Load existing channels and rules
        self._load_channels()
        self._load_notification_rules()

        # Register communication-specific message handlers
        self.register_handler('send_notification', self._handle_send_notification)
        self.register_handler('create_channel', self._handle_create_channel)
        self.register_handler('route_message', self._handle_route_message)
        self.register_handler('broadcast_message', self._handle_broadcast_message)
        self.register_handler('request_analytics_data', self._handle_request_analytics_data)
        self.register_handler('analytics_insights', self._handle_analytics_insights)
        self.register_handler('analytics_alert', self._handle_analytics_alert)
        self.register_handler('network_alert', self._handle_network_alert)
        self.register_handler('security_alert', self._handle_security_alert)
        self.register_handler('analytics_stream', self._handle_analytics_stream)

        # Start communication threads
        self.message_processor = threading.Thread(target=self._message_processing_loop, daemon=True)
        self.notification_processor = threading.Thread(target=self._notification_loop, daemon=True)
        self.websocket_server = threading.Thread(target=self._websocket_server_loop, daemon=True)

        self.message_processor.start()
        self.notification_processor.start()
        self.websocket_server.start()

        # Set up external integrations
        self._setup_external_integrations()

        self.logger.info("Communication Agent components initialized")

    def _perform_work(self):
        """Perform communication management and routing work"""
        try:
            # Process queued messages
            self._process_message_queue()

            # Check for pending responses
            self._check_pending_responses()

            # Update communication metrics
            self._update_communication_metrics()

            # Maintain external connections
            self._maintain_external_connections()

        except Exception as e:
            self.logger.error(f"Error in communication work loop: {e}")
            self.error_count += 1

    def _cleanup(self):
        """Cleanup communication-specific resources"""
        self._save_channels()
        self._save_notification_rules()
        self.logger.info("Communication Agent cleaned up")

    def get_capabilities(self) -> List[str]:
        """Return communication agent capabilities"""
        return [
            "message_routing",
            "notification_delivery",
            "external_integrations",
            "real_time_communication",
            "channel_management",
            "message_encryption",
            "webhook_handling",
            "api_integrations"
        ]

    def _message_processing_loop(self):
        """Message processing and routing loop"""
        while self.running and self.state.value == "running":
            try:
                # Process incoming messages
                self._process_incoming_messages()

                # Route pending messages
                self._route_pending_messages()

                # Clean up old messages
                self._cleanup_old_messages()

                time.sleep(1)  # Process every second

            except Exception as e:
                self.logger.error(f"Error in message processing loop: {e}")
                time.sleep(5)

    def _notification_loop(self):
        """Notification processing loop"""
        while self.running and self.state.value == "running":
            try:
                # Process notification rules
                self._process_notification_rules()

                # Send queued notifications
                self._send_queued_notifications()

                # Update notification status
                self._update_notification_status()

                time.sleep(10)  # Process every 10 seconds

            except Exception as e:
                self.logger.error(f"Error in notification loop: {e}")
                time.sleep(30)

    def _websocket_server_loop(self):
        """WebSocket server for real-time communication"""
        # WebSocket server implementation would go here
        # For now, just keep the thread alive
        while self.running and self.state.value == "running":
            time.sleep(60)

    def _process_message_queue(self):
        """Process messages in the queue"""
        try:
            while self.message_queue:
                message = self.message_queue.popleft()
                self._route_message(message)

        except Exception as e:
            self.logger.error(f"Error processing message queue: {e}")

    def _route_message(self, message: Message):
        """Route a message to its destination"""
        try:
            if not self.coordinator:
                self.logger.warning("No coordinator available for message routing")
                return

            # Find target agent
            target_agent = self.coordinator.get_agent(message.receiver)

            if target_agent:
                # Deliver message
                target_agent.receive_message(message)
                message.delivered = True
                self.logger.debug(f"Message {message.id} routed to {message.receiver}")
            else:
                self.logger.warning(f"Agent {message.receiver} not found for message routing")

            # Record message
            self.message_history.append({
                'message': message.to_dict(),
                'routed_at': datetime.now().isoformat(),
                'delivered': message.delivered
            })

        except Exception as e:
            self.logger.error(f"Error routing message: {e}")

    def _process_incoming_messages(self):
        """Process incoming messages from external sources"""
        try:
            # Check for webhook messages
            self._process_webhook_messages()

            # Check for external API messages
            self._process_external_api_messages()

            # Check for stream messages
            self._process_stream_messages()

        except Exception as e:
            self.logger.error(f"Error processing incoming messages: {e}")

    def _route_pending_messages(self):
        """Route messages that are pending delivery"""
        try:
            current_time = datetime.now()

            for message_data in list(self.message_history):
                message_dict = message_data['message']
                message = Message.from_dict(message_dict)

                if not message.delivered:
                    time_since_creation = (current_time - message.timestamp).total_seconds()

                    if time_since_creation < self.message_timeout:
                        # Try to route again
                        self._route_message(message)
                    else:
                        self.logger.warning(f"Message {message.id} timed out")

        except Exception as e:
            self.logger.error(f"Error routing pending messages: {e}")

    def _cleanup_old_messages(self):
        """Clean up old messages from history"""
        try:
            cutoff_time = datetime.now() - timedelta(hours=24)

            # Remove old messages
            self.message_history[:] = [
                msg for msg in self.message_history
                if datetime.fromisoformat(msg['routed_at']) > cutoff_time
            ]

        except Exception as e:
            self.logger.error(f"Error cleaning up old messages: {e}")

    def _process_notification_rules(self):
        """Process notification rules and trigger notifications"""
        try:
            for rule_id, rule in self.notification_rules.items():
                if not rule.enabled:
                    continue

                # Check if rule conditions are met
                if self._evaluate_notification_conditions(rule):
                    # Trigger notification
                    self._trigger_notification(rule)
                    rule.last_triggered = datetime.now()
                    rule.trigger_count += 1

        except Exception as e:
            self.logger.error(f"Error processing notification rules: {e}")

    def _evaluate_notification_conditions(self, rule: NotificationRule) -> bool:
        """Evaluate conditions for a notification rule"""
        try:
            for condition in rule.conditions:
                condition_type = condition.get('type')

                if condition_type == 'message_type':
                    # Check for specific message types
                    message_type = condition.get('message_type')
                    recent_messages = [msg for msg in self.message_history
                                     if msg['message']['message_type'] == message_type]
                    if not recent_messages:
                        return False

                elif condition_type == 'metric_threshold':
                    # Check metric thresholds
                    metric = condition.get('metric')
                    threshold = condition.get('threshold')
                    operator = condition.get('operator', 'greater_than')

                    # Get current metric value (simplified)
                    current_value = self._get_current_metric_value(metric)
                    if not self._compare_values(current_value, operator, threshold):
                        return False

                elif condition_type == 'time_based':
                    # Time-based conditions
                    current_time = datetime.now()
                    start_time = condition.get('start_time')
                    end_time = condition.get('end_time')

                    if start_time and current_time < datetime.fromisoformat(start_time):
                        return False
                    if end_time and current_time > datetime.fromisoformat(end_time):
                        return False

                else:
                    return False

            return True

        except Exception as e:
            self.logger.error(f"Error evaluating notification conditions: {e}")
            return False

    def _trigger_notification(self, rule: NotificationRule):
        """Trigger a notification based on rule"""
        try:
            # Format notification message
            message = self._format_notification_message(rule)

            # Send to all specified channels
            for channel_id in rule.channels:
                if channel_id in self.channels:
                    channel = self.channels[channel_id]
                    self._send_to_channel(channel, message)

            self.logger.info(f"Triggered notification: {rule.name}")

        except Exception as e:
            self.logger.error(f"Error triggering notification: {e}")

    def _send_to_channel(self, channel: CommunicationChannel, message: str):
        """Send message to a communication channel"""
        try:
            if channel.type == 'telegram':
                self._send_telegram_message(channel, message)
            elif channel.type == 'webhook':
                self._send_webhook_message(channel, message)
            elif channel.type == 'email':
                self._send_email_message(channel, message)
            else:
                self.logger.warning(f"Unknown channel type: {channel.type}")

            channel.last_used = datetime.now()
            channel.message_count += 1

        except Exception as e:
            self.logger.error(f"Error sending to channel {channel.id}: {e}")
            channel.error_count += 1

    def _send_telegram_message(self, channel: CommunicationChannel, message: str):
        """Send message via Telegram"""
        try:
            bot_token = channel.config.get('bot_token')
            chat_id = channel.config.get('chat_id')

            if bot_token and chat_id:
                url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
                data = {
                    'chat_id': chat_id,
                    'text': message,
                    'parse_mode': 'HTML'
                }

                response = requests.post(url, data=data, timeout=10)
                response.raise_for_status()

                self.logger.debug(f"Telegram message sent to {chat_id}")

        except Exception as e:
            self.logger.error(f"Error sending Telegram message: {e}")
            raise

    def _send_webhook_message(self, channel: CommunicationChannel, message: str):
        """Send message via webhook"""
        try:
            webhook_url = channel.config.get('url')
            headers = channel.config.get('headers', {})
            method = channel.config.get('method', 'POST')

            if webhook_url:
                payload = {
                    'message': message,
                    'timestamp': datetime.now().isoformat(),
                    'channel': channel.id
                }

                response = requests.request(
                    method=method,
                    url=webhook_url,
                    json=payload,
                    headers=headers,
                    timeout=10
                )
                response.raise_for_status()

                self.logger.debug(f"Webhook message sent to {webhook_url}")

        except Exception as e:
            self.logger.error(f"Error sending webhook message: {e}")
            raise

    def _send_email_message(self, channel: CommunicationChannel, message: str):
        """Send message via email"""
        # Email implementation would go here
        # Requires SMTP configuration
        self.logger.debug(f"Email message would be sent: {message}")

    def _format_notification_message(self, rule: NotificationRule) -> str:
        """Format notification message using template"""
        try:
            template = rule.template

            # Replace template variables
            template = template.replace('{{timestamp}}', datetime.now().isoformat())
            template = template.replace('{{rule_name}}', rule.name)

            # Add more template variables as needed

            return template

        except Exception as e:
            self.logger.error(f"Error formatting notification message: {e}")
            return f"Notification: {rule.name}"

    def _send_queued_notifications(self):
        """Send any queued notifications"""
        # Implementation for queued notifications
        pass

    def _update_notification_status(self):
        """Update notification delivery status"""
        # Implementation for status updates
        pass

    def _check_pending_responses(self):
        """Check for pending message responses"""
        try:
            current_time = datetime.now()

            for message_id, response_data in list(self.pending_responses.items()):
                sent_time = response_data['sent_time']
                timeout = response_data.get('timeout', self.message_timeout)

                if (current_time - sent_time).total_seconds() > timeout:
                    self.logger.warning(f"Response timeout for message {message_id}")
                    del self.pending_responses[message_id]

        except Exception as e:
            self.logger.error(f"Error checking pending responses: {e}")

    def _update_communication_metrics(self):
        """Update communication-related metrics"""
        self.metrics['messages_routed'] = len(self.message_history)
        self.metrics['active_channels'] = len([c for c in self.channels.values() if c.enabled])
        self.metrics['notification_rules'] = len(self.notification_rules)
        self.metrics['websocket_clients'] = len(self.websocket_clients)

    def _maintain_external_connections(self):
        """Maintain connections to external services"""
        try:
            # Test external service connections
            self._test_external_connections()

            # Reconnect failed connections
            self._reconnect_failed_connections()

        except Exception as e:
            self.logger.error(f"Error maintaining external connections: {e}")

    def _setup_external_integrations(self):
        """Set up external service integrations"""
        try:
            # Set up Telegram integration
            if self.telegram_config:
                self._setup_telegram_integration()

            # Set up webhook endpoints
            if self.webhook_config:
                self._setup_webhook_endpoints()

        except Exception as e:
            self.logger.error(f"Error setting up external integrations: {e}")

    def _setup_telegram_integration(self):
        """Set up Telegram bot integration"""
        # Implementation for Telegram bot setup
        pass

    def _setup_webhook_endpoints(self):
        """Set up webhook endpoints"""
        # Implementation for webhook endpoints
        pass

    def _process_webhook_messages(self):
        """Process incoming webhook messages"""
        # Implementation for webhook message processing
        pass

    def _process_external_api_messages(self):
        """Process messages from external APIs"""
        # Implementation for external API message processing
        pass

    def _process_stream_messages(self):
        """Process streaming messages"""
        # Implementation for stream message processing
        pass

    def _test_external_connections(self):
        """Test connections to external services"""
        # Implementation for connection testing
        pass

    def _reconnect_failed_connections(self):
        """Reconnect failed external connections"""
        # Implementation for reconnection logic
        pass

    def _get_current_metric_value(self, metric: str) -> Any:
        """Get current value of a metric"""
        # Simplified metric retrieval
        if metric == 'message_queue_size':
            return len(self.message_queue)
        elif metric == 'active_channels':
            return len([c for c in self.channels.values() if c.enabled])
        else:
            return 0

    def _compare_values(self, value: Any, operator: str, threshold: Any) -> bool:
        """Compare values using operators"""
        try:
            if operator == 'equals':
                return value == threshold
            elif operator == 'greater_than':
                return float(value) > float(threshold)
            elif operator == 'less_than':
                return float(value) < float(threshold)
            else:
                return False
        except:
            return False

    def _load_channels(self):
        """Load communication channels from file"""
        try:
            with open('data/communication_channels.json', 'r') as f:
                channels_data = json.load(f)
                for ch_data in channels_data:
                    channel = CommunicationChannel(
                        ch_data['id'],
                        ch_data['type'],
                        ch_data['config']
                    )
                    channel.enabled = ch_data.get('enabled', True)
                    channel.created_at = datetime.fromisoformat(ch_data['created_at'])
                    if ch_data.get('last_used'):
                        channel.last_used = datetime.fromisoformat(ch_data['last_used'])
                    channel.message_count = ch_data.get('message_count', 0)
                    channel.error_count = ch_data.get('error_count', 0)
                    self.channels[channel.id] = channel
        except FileNotFoundError:
            self.channels = {}
        except Exception as e:
            self.logger.error(f"Error loading channels: {e}")

    def _save_channels(self):
        """Save communication channels to file"""
        try:
            channels_data = []
            for channel in self.channels.values():
                ch_data = {
                    'id': channel.id,
                    'type': channel.type,
                    'config': channel.config,
                    'enabled': channel.enabled,
                    'created_at': channel.created_at.isoformat(),
                    'last_used': channel.last_used.isoformat() if channel.last_used else None,
                    'message_count': channel.message_count,
                    'error_count': channel.error_count
                }
                channels_data.append(ch_data)

            with open('data/communication_channels.json', 'w') as f:
                json.dump(channels_data, f, indent=2)
        except Exception as e:
            self.logger.error(f"Error saving channels: {e}")

    def _load_notification_rules(self):
        """Load notification rules from file"""
        try:
            with open('data/notification_rules.json', 'r') as f:
                rules_data = json.load(f)
                for rule_data in rules_data:
                    rule = NotificationRule(
                        rule_data['id'],
                        rule_data['name'],
                        rule_data['conditions'],
                        rule_data['channels'],
                        rule_data['template'],
                        rule_data.get('enabled', True)
                    )
                    rule.created_at = datetime.fromisoformat(rule_data['created_at'])
                    if rule_data.get('last_triggered'):
                        rule.last_triggered = datetime.fromisoformat(rule_data['last_triggered'])
                    rule.trigger_count = rule_data.get('trigger_count', 0)
                    self.notification_rules[rule.id] = rule
        except FileNotFoundError:
            self.notification_rules = {}
        except Exception as e:
            self.logger.error(f"Error loading notification rules: {e}")

    def _save_notification_rules(self):
        """Save notification rules to file"""
        try:
            rules_data = []
            for rule in self.notification_rules.values():
                rule_data = {
                    'id': rule.id,
                    'name': rule.name,
                    'conditions': rule.conditions,
                    'channels': rule.channels,
                    'template': rule.template,
                    'enabled': rule.enabled,
                    'created_at': rule.created_at.isoformat(),
                    'last_triggered': rule.last_triggered.isoformat() if rule.last_triggered else None,
                    'trigger_count': rule.trigger_count
                }
                rules_data.append(rule_data)

            with open('data/notification_rules.json', 'w') as f:
                json.dump(rules_data, f, indent=2)
        except Exception as e:
            self.logger.error(f"Error saving notification rules: {e}")

    # Message handlers
    def _handle_send_notification(self, message: Message) -> Dict[str, Any]:
        """Handle notification sending request"""
        notification_data = message.payload.get('notification')

        if notification_data:
            channels = notification_data.get('channels', [])
            message_text = notification_data.get('message', '')

            sent_count = 0
            for channel_id in channels:
                if channel_id in self.channels:
                    channel = self.channels[channel_id]
                    try:
                        self._send_to_channel(channel, message_text)
                        sent_count += 1
                    except Exception as e:
                        self.logger.error(f"Failed to send to channel {channel_id}: {e}")

            return {'status': 'sent', 'channels_attempted': len(channels), 'channels_successful': sent_count}
        else:
            return {'error': 'No notification data provided'}

    def _handle_create_channel(self, message: Message) -> Dict[str, Any]:
        """Handle channel creation request"""
        channel_data = message.payload.get('channel')

        if channel_data:
            channel_id = channel_data.get('id') or f"channel_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            channel = CommunicationChannel(
                channel_id=channel_id,
                channel_type=channel_data['type'],
                config=channel_data['config']
            )
            self.channels[channel_id] = channel
            self._save_channels()

            return {'status': 'created', 'channel_id': channel_id}
        else:
            return {'error': 'No channel data provided'}

    def _handle_route_message(self, message: Message) -> Dict[str, Any]:
        """Handle message routing request"""
        target_message = message.payload.get('message')

        if target_message:
            # Create Message object from payload
            route_message = Message(
                sender=target_message.get('sender', 'system'),
                receiver=target_message['receiver'],
                message_type=target_message['message_type'],
                payload=target_message['payload'],
                priority=AgentPriority(target_message.get('priority', 2)),
                correlation_id=target_message.get('correlation_id')
            )

            # Add to queue for routing
            self.message_queue.append(route_message)

            return {'status': 'queued', 'message_id': route_message.id}
        else:
            return {'error': 'No message data provided'}

    def _handle_broadcast_message(self, message: Message) -> Dict[str, Any]:
        """Handle broadcast message request"""
        broadcast_data = message.payload.get('broadcast')

        if broadcast_data:
            message_type = broadcast_data.get('message_type')
            payload = broadcast_data.get('payload', {})
            target_agents = broadcast_data.get('target_agents', [])

            sent_count = 0
            if target_agents:
                # Send to specific agents
                for agent_id in target_agents:
                    try:
                        msg_id = self.send_message(agent_id, message_type, payload)
                        sent_count += 1
                    except Exception as e:
                        self.logger.error(f"Failed to broadcast to {agent_id}: {e}")
            else:
                # Broadcast to all agents
                if self.coordinator:
                    for agent in self.coordinator.agents.values():
                        try:
                            msg_id = self.send_message(agent.agent_id, message_type, payload)
                            sent_count += 1
                        except Exception as e:
                            self.logger.error(f"Failed to broadcast to {agent.agent_id}: {e}")

            return {'status': 'broadcast', 'messages_sent': sent_count}
        else:
            return {'error': 'No broadcast data provided'}

    def _handle_request_analytics_data(self, message: Message) -> Dict[str, Any]:
        """Handle analytics data request"""
        # This would collect data from various agents and return it
        # For now, return mock data
        return {
            'performance': {'cpu': 45.2, 'memory': 67.8},
            'security': {'threats': 2, 'blocks': 15},
            'network': {'connections': 150, 'traffic': 1024}
        }

    def _handle_analytics_insights(self, message: Message) -> Dict[str, Any]:
        """Handle analytics insights"""
        insights = message.payload.get('insights', [])

        # Log insights and potentially forward to other systems
        for insight in insights:
            self.logger.info(f"Analytics Insight: {insight.get('description', 'Unknown')}")

        # Could store insights or trigger notifications based on them
        return {'status': 'processed', 'insights_count': len(insights)}

    def _handle_analytics_alert(self, message: Message) -> Dict[str, Any]:
        """Handle analytics alert"""
        alert_data = message.payload

        # Create notification for alert
        alert_message = f"Analytics Alert: {alert_data.get('message', 'Unknown alert')}"

        # Send to configured channels
        self._send_alert_notification(alert_message, alert_data)

        return {'status': 'alert_processed'}

    def _handle_network_alert(self, message: Message) -> Dict[str, Any]:
        """Handle network alert"""
        alert_data = message.payload

        alert_message = f"Network Alert: {alert_data.get('type', 'Unknown')} - {alert_data.get('message', '')}"

        self._send_alert_notification(alert_message, alert_data)

        return {'status': 'alert_processed'}

    def _handle_security_alert(self, message: Message) -> Dict[str, Any]:
        """Handle security alert"""
        alert_data = message.payload

        alert_message = f"Security Alert: {alert_data.get('event_type', 'Unknown')} - {alert_data.get('description', '')}"

        self._send_alert_notification(alert_message, alert_data)

        return {'status': 'alert_processed'}

    def _handle_analytics_stream(self, message: Message) -> Dict[str, Any]:
        """Handle analytics stream data"""
        stream_data = message.payload.get('data', {})

        # Forward to WebSocket clients or stream subscribers
        self._broadcast_stream_data(stream_data)

        return {'status': 'streamed'}

    def _send_alert_notification(self, message: str, alert_data: Dict[str, Any]):
        """Send alert notification to configured channels"""
        try:
            # Find alert notification channels
            alert_channels = [ch for ch in self.channels.values()
                            if ch.config.get('alert_channel', False)]

            for channel in alert_channels:
                try:
                    self._send_to_channel(channel, message)
                except Exception as e:
                    self.logger.error(f"Failed to send alert to channel {channel.id}: {e}")

        except Exception as e:
            self.logger.error(f"Error sending alert notification: {e}")

    def _broadcast_stream_data(self, data: Dict[str, Any]):
        """Broadcast data to stream subscribers"""
        # Implementation for broadcasting to WebSocket clients
        pass

"""
Agent Coordinator for InvictusDNS AI System

This module provides the AgentCoordinator class that manages all AI agents,
coordinates their activities, handles inter-agent communication, and ensures
system-wide coherence and optimization.

Features:
- Agent lifecycle management (start, stop, monitor)
- Inter-agent communication routing
- Load balancing and resource allocation
- Conflict resolution and priority management
- System health monitoring and optimization
- Agent coordination and orchestration
- Performance monitoring and analytics
- Automatic agent scaling and deployment

Author: BLACKBOXAI
"""

import time
import json
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import threading
import psutil
from collections import defaultdict, deque

from .base_agent import BaseAgent, AgentPriority, Message
from .security_agent import SecurityAgent
from .network_agent import NetworkAgent
from .learning_agent import LearningAgent
from .automation_agent import AutomationAgent
from .analytics_agent import AnalyticsAgent
from .communication_agent import CommunicationAgent

class AgentCoordinator:
    """
    Central coordinator for managing all AI agents in the InvictusDNS system.

    Provides centralized control, monitoring, and coordination of all agents,
    ensuring optimal system performance and coherent operation.
    """

    def __init__(self, config: Dict[str, Any] = None):
        """
        Initialize the agent coordinator.

        Args:
            config: Configuration dictionary for the coordinator
        """
        self.config = config or {}
        self.logger = logging.getLogger("InvictusDNS.AgentCoordinator")

        # Agent management
        self.agents = {}
        self.agent_configs = {}
        self.agent_dependencies = {}
        self.agent_priorities = {}

        # System state
        self.system_status = "initializing"
        self.start_time = None
        self.coordination_cycles = 0

        # Performance monitoring
        self.performance_history = deque(maxlen=1000)
        self.system_metrics = {}

        # Coordination settings
        self.coordination_interval = self.config.get('coordination_interval', 30)  # seconds
        self.max_agents = self.config.get('max_agents', 20)
        self.auto_scaling = self.config.get('auto_scaling', True)

        # Communication
        self.message_queue = deque(maxlen=10000)
        self.pending_responses = {}

        # Health monitoring
        self.agent_health = {}
        self.system_health = "healthy"

        # Load balancing
        self.agent_load = {}
        self.load_thresholds = {
            'cpu': 80,
            'memory': 85,
            'message_queue': 1000
        }

        self.logger.info("Agent Coordinator initialized")

    def initialize_system(self):
        """Initialize the entire agent system"""
        try:
            self.logger.info("Initializing InvictusDNS AI Agent System")
            self.start_time = datetime.now()
            self.system_status = "initializing"

            # Load agent configurations
            self._load_agent_configs()

            # Create and initialize agents
            self._create_agents()

            # Establish agent dependencies
            self._establish_dependencies()

            # Start agents in dependency order
            self._start_agents()

            # Start coordination loop
            self.coordination_thread = threading.Thread(target=self._coordination_loop, daemon=True)
            self.coordination_thread.start()

            self.system_status = "running"
            self.logger.info("InvictusDNS AI Agent System initialized successfully")

        except Exception as e:
            self.logger.error(f"Failed to initialize agent system: {e}")
            self.system_status = "error"
            raise

    def shutdown_system(self):
        """Shutdown the entire agent system"""
        try:
            self.logger.info("Shutting down InvictusDNS AI Agent System")
            self.system_status = "shutting_down"

            # Stop coordination
            self.system_status = "stopped"

            # Stop agents in reverse dependency order
            self._stop_agents()

            self.logger.info("InvictusDNS AI Agent System shutdown complete")

        except Exception as e:
            self.logger.error(f"Error during system shutdown: {e}")

    def get_agent(self, agent_id: str) -> Optional[BaseAgent]:
        """Get an agent by ID"""
        return self.agents.get(agent_id)

    def get_all_agents(self) -> Dict[str, BaseAgent]:
        """Get all registered agents"""
        return self.agents.copy()

    def get_system_status(self) -> Dict[str, Any]:
        """Get overall system status"""
        return {
            'status': self.system_status,
            'start_time': self.start_time.isoformat() if self.start_time else None,
            'uptime': self._get_uptime(),
            'agent_count': len(self.agents),
            'active_agents': len([a for a in self.agents.values() if a.state.value == "running"]),
            'system_health': self.system_health,
            'coordination_cycles': self.coordination_cycles,
            'system_metrics': self.system_metrics.copy()
        }

    def send_message(self, sender: str, receiver: str, message_type: str,
                    payload: Dict[str, Any], priority: AgentPriority = AgentPriority.NORMAL,
                    correlation_id: str = None) -> str:
        """
        Send a message between agents through the coordinator

        Args:
            sender: Sending agent ID
            receiver: Receiving agent ID
            message_type: Type of message
            payload: Message payload
            priority: Message priority
            correlation_id: Correlation ID for request-response

        Returns:
            Message ID
        """
        message = Message(sender, receiver, message_type, payload, priority, correlation_id)

        # Add to message queue for routing
        self.message_queue.append(message)

        self.logger.debug(f"Message queued: {sender} -> {receiver}: {message_type}")

        return message.id

    def broadcast_message(self, sender: str, message_type: str, payload: Dict[str, Any],
                         target_agents: List[str] = None,
                         priority: AgentPriority = AgentPriority.NORMAL):
        """
        Broadcast a message to multiple agents

        Args:
            sender: Sending agent ID
            message_type: Type of message
            payload: Message payload
            target_agents: List of target agent IDs (None for all agents)
            priority: Message priority
        """
        if target_agents is None:
            target_agents = list(self.agents.keys())

        sent_count = 0
        for agent_id in target_agents:
            if agent_id != sender:  # Don't send to self
                try:
                    self.send_message(sender, agent_id, message_type, payload, priority)
                    sent_count += 1
                except Exception as e:
                    self.logger.error(f"Failed to broadcast to {agent_id}: {e}")

        self.logger.debug(f"Broadcast {message_type} sent to {sent_count} agents")

    def add_agent(self, agent: BaseAgent, config: Dict[str, Any] = None,
                  dependencies: List[str] = None, priority: int = 1):
        """
        Add a new agent to the system

        Args:
            agent: Agent instance
            config: Agent configuration
            dependencies: List of agent IDs this agent depends on
            priority: Agent priority (higher numbers = higher priority)
        """
        if len(self.agents) >= self.max_agents:
            raise ValueError(f"Maximum number of agents ({self.max_agents}) reached")

        agent_id = agent.agent_id

        if agent_id in self.agents:
            self.logger.warning(f"Agent {agent_id} already exists, replacing")

        # Set coordinator reference
        agent.coordinator = self

        # Store agent information
        self.agents[agent_id] = agent
        self.agent_configs[agent_id] = config or {}
        self.agent_dependencies[agent_id] = dependencies or []
        self.agent_priorities[agent_id] = priority

        self.logger.info(f"Agent {agent_id} added to system")

    def remove_agent(self, agent_id: str):
        """Remove an agent from the system"""
        if agent_id in self.agents:
            agent = self.agents[agent_id]

            # Stop agent if running
            if agent.state.value == "running":
                agent.stop()

            # Remove from all data structures
            del self.agents[agent_id]
            del self.agent_configs[agent_id]
            del self.agent_dependencies[agent_id]
            del self.agent_priorities[agent_id]

            # Remove from dependencies
            for deps in self.agent_dependencies.values():
                if agent_id in deps:
                    deps.remove(agent_id)

            self.logger.info(f"Agent {agent_id} removed from system")

    def get_agent_status(self, agent_id: str) -> Optional[Dict[str, Any]]:
        """Get status of a specific agent"""
        agent = self.get_agent(agent_id)
        if agent:
            return agent.get_status()
        return None

    def get_agent_health(self) -> Dict[str, Dict[str, Any]]:
        """Get health status of all agents"""
        health_status = {}

        for agent_id, agent in self.agents.items():
            status = agent.get_status()
            health_status[agent_id] = {
                'state': status['state'],
                'health': status['health'],
                'last_activity': status['last_activity'],
                'error_count': status['error_count'],
                'uptime': status['uptime']
            }

        return health_status

    def optimize_system(self):
        """Perform system-wide optimization"""
        try:
            self.logger.info("Starting system optimization")

            # Analyze agent performance
            self._analyze_agent_performance()

            # Balance agent load
            self._balance_agent_load()

            # Optimize resource allocation
            self._optimize_resource_allocation()

            # Update agent configurations
            self._update_agent_configs()

            self.logger.info("System optimization completed")

        except Exception as e:
            self.logger.error(f"Error during system optimization: {e}")

    def _coordination_loop(self):
        """Main coordination loop"""
        while self.system_status == "running":
            try:
                self.coordination_cycles += 1

                # Route messages
                self._route_messages()

                # Monitor agent health
                self._monitor_agent_health()

                # Update system metrics
                self._update_system_metrics()

                # Perform coordination tasks
                self._perform_coordination_tasks()

                time.sleep(self.coordination_interval)

            except Exception as e:
                self.logger.error(f"Error in coordination loop: {e}")
                time.sleep(30)

    def _route_messages(self):
        """Route queued messages to their destinations"""
        try:
            routed_count = 0

            while self.message_queue and routed_count < 100:  # Limit per cycle
                message = self.message_queue.popleft()

                target_agent = self.get_agent(message.receiver)
                if target_agent:
                    target_agent.receive_message(message)
                    message.delivered = True
                    routed_count += 1
                else:
                    self.logger.warning(f"Message routing failed: agent {message.receiver} not found")
                    # Could implement dead letter queue here

        except Exception as e:
            self.logger.error(f"Error routing messages: {e}")

    def _monitor_agent_health(self):
        """Monitor health of all agents"""
        try:
            unhealthy_agents = []

            for agent_id, agent in self.agents.items():
                status = agent.get_status()

                # Check for unhealthy conditions
                if status['state'] == 'error':
                    unhealthy_agents.append(agent_id)
                elif status['error_count'] > 10:
                    unhealthy_agents.append(agent_id)
                elif status.get('health') == 'unhealthy':
                    unhealthy_agents.append(agent_id)

                # Update health tracking
                self.agent_health[agent_id] = {
                    'status': status['health'],
                    'last_check': datetime.now(),
                    'error_count': status['error_count']
                }

            # Handle unhealthy agents
            for agent_id in unhealthy_agents:
                self._handle_unhealthy_agent(agent_id)

            # Update system health
            if unhealthy_agents:
                self.system_health = "degraded"
            else:
                self.system_health = "healthy"

        except Exception as e:
            self.logger.error(f"Error monitoring agent health: {e}")

    def _update_system_metrics(self):
        """Update overall system metrics"""
        try:
            current_time = datetime.now()

            # Collect system-wide metrics
            total_messages = sum(len(agent.message_queue) for agent in self.agents.values())
            total_errors = sum(agent.error_count for agent in self.agents.values())
            active_agents = len([a for a in self.agents.values() if a.state.value == "running"])

            # System resource usage
            system_cpu = psutil.cpu_percent()
            system_memory = psutil.virtual_memory().percent

            self.system_metrics = {
                'timestamp': current_time.isoformat(),
                'active_agents': active_agents,
                'total_messages_queued': total_messages,
                'total_agent_errors': total_errors,
                'system_cpu_usage': system_cpu,
                'system_memory_usage': system_memory,
                'coordination_cycles': self.coordination_cycles
            }

            # Store in performance history
            self.performance_history.append(self.system_metrics.copy())

        except Exception as e:
            self.logger.error(f"Error updating system metrics: {e}")

    def _perform_coordination_tasks(self):
        """Perform periodic coordination tasks"""
        try:
            # Check for agent scaling needs
            if self.auto_scaling:
                self._check_scaling_needs()

            # Optimize message routing
            self._optimize_message_routing()

            # Update agent priorities
            self._update_agent_priorities()

        except Exception as e:
            self.logger.error(f"Error performing coordination tasks: {e}")

    def _create_agents(self):
        """Create and configure all agents"""
        try:
            # Create core agents
            agents_to_create = [
                (SecurityAgent, "security_agent", "Security monitoring and threat detection"),
                (NetworkAgent, "network_agent", "Network optimization and monitoring"),
                (LearningAgent, "learning_agent", "Continuous learning and adaptation"),
                (AutomationAgent, "automation_agent", "Rule-based automation and workflows"),
                (AnalyticsAgent, "analytics_agent", "Data analysis and business intelligence"),
                (CommunicationAgent, "communication_agent", "Inter-agent communication and external integrations")
            ]

            for agent_class, agent_id, description in agents_to_create:
                try:
                    config = self.agent_configs.get(agent_id, {})
                    agent = agent_class(coordinator=self, config=config)
                    self.add_agent(agent, config)
                    self.logger.info(f"Created agent: {agent_id} - {description}")
                except Exception as e:
                    self.logger.error(f"Failed to create agent {agent_id}: {e}")

        except Exception as e:
            self.logger.error(f"Error creating agents: {e}")
            raise

    def _establish_dependencies(self):
        """Establish agent dependencies"""
        # Define dependency relationships
        self.agent_dependencies = {
            'security_agent': [],
            'network_agent': [],
            'communication_agent': [],
            'analytics_agent': ['communication_agent'],
            'learning_agent': ['analytics_agent', 'communication_agent'],
            'automation_agent': ['communication_agent', 'analytics_agent']
        }

        self.logger.info("Agent dependencies established")

    def _start_agents(self):
        """Start all agents in dependency order"""
        try:
            # Topological sort for dependency ordering
            started_agents = set()
            max_iterations = len(self.agents) * 2

            for _ in range(max_iterations):
                if len(started_agents) == len(self.agents):
                    break

                for agent_id, agent in self.agents.items():
                    if agent_id in started_agents:
                        continue

                    # Check if all dependencies are started
                    dependencies = self.agent_dependencies.get(agent_id, [])
                    if all(dep in started_agents for dep in dependencies):
                        try:
                            agent.start()
                            started_agents.add(agent_id)
                            self.logger.info(f"Started agent: {agent_id}")
                        except Exception as e:
                            self.logger.error(f"Failed to start agent {agent_id}: {e}")

            if len(started_agents) != len(self.agents):
                raise RuntimeError("Circular dependency detected in agent startup")

        except Exception as e:
            self.logger.error(f"Error starting agents: {e}")
            raise

    def _stop_agents(self):
        """Stop all agents"""
        try:
            for agent_id, agent in self.agents.items():
                try:
                    agent.stop()
                    self.logger.info(f"Stopped agent: {agent_id}")
                except Exception as e:
                    self.logger.error(f"Error stopping agent {agent_id}: {e}")

        except Exception as e:
            self.logger.error(f"Error stopping agents: {e}")

    def _handle_unhealthy_agent(self, agent_id: str):
        """Handle an unhealthy agent"""
        try:
            agent = self.get_agent(agent_id)
            if not agent:
                return

            status = agent.get_status()

            # Attempt to restart the agent
            if status['state'] == 'error':
                self.logger.warning(f"Attempting to restart unhealthy agent: {agent_id}")
                try:
                    agent.stop()
                    time.sleep(2)
                    agent.start()
                    self.logger.info(f"Successfully restarted agent: {agent_id}")
                except Exception as e:
                    self.logger.error(f"Failed to restart agent {agent_id}: {e}")

            # If agent has too many errors, consider removing it
            if status['error_count'] > 50:
                self.logger.warning(f"Agent {agent_id} has excessive errors, considering removal")
                # Could implement agent removal logic here

        except Exception as e:
            self.logger.error(f"Error handling unhealthy agent {agent_id}: {e}")

    def _analyze_agent_performance(self):
        """Analyze performance of all agents"""
        try:
            performance_data = {}

            for agent_id, agent in self.agents.items():
                status = agent.get_status()
                performance_data[agent_id] = {
                    'uptime': status['uptime'],
                    'messages_processed': status['metrics'].get('messages_processed', 0),
                    'error_rate': status['error_count'] / max(status['uptime'], 1),
                    'cpu_usage': status['metrics'].get('cpu_usage', 0),
                    'memory_usage': status['metrics'].get('memory_usage', 0)
                }

            # Identify underperforming agents
            for agent_id, perf in performance_data.items():
                if perf['error_rate'] > 0.1:  # 10% error rate
                    self.logger.warning(f"Agent {agent_id} has high error rate: {perf['error_rate']:.2%}")

                if perf['cpu_usage'] > 90:
                    self.logger.warning(f"Agent {agent_id} has high CPU usage: {perf['cpu_usage']}%")

        except Exception as e:
            self.logger.error(f"Error analyzing agent performance: {e}")

    def _balance_agent_load(self):
        """Balance load across agents"""
        try:
            # Calculate current load distribution
            agent_loads = {}
            for agent_id, agent in self.agents.items():
                status = agent.get_status()
                agent_loads[agent_id] = {
                    'message_queue': len(agent.message_queue),
                    'cpu_usage': status['metrics'].get('cpu_usage', 0),
                    'memory_usage': status['metrics'].get('memory_usage', 0)
                }

            # Identify overloaded agents
            overloaded = []
            underloaded = []

            for agent_id, load in agent_loads.items():
                if (load['cpu_usage'] > self.load_thresholds['cpu'] or
                    load['memory_usage'] > self.load_thresholds['memory'] or
                    load['message_queue'] > self.load_thresholds['message_queue']):
                    overloaded.append(agent_id)
                elif (load['cpu_usage'] < 30 and
                      load['memory_usage'] < 50 and
                      load['message_queue'] < 100):
                    underloaded.append(agent_id)

            # Implement load balancing (simplified)
            if overloaded and underloaded:
                self.logger.info(f"Load balancing: {len(overloaded)} overloaded, {len(underloaded)} underloaded")
                # Could implement message redistribution here

        except Exception as e:
            self.logger.error(f"Error balancing agent load: {e}")

    def _optimize_resource_allocation(self):
        """Optimize resource allocation across agents"""
        try:
            # Analyze resource usage patterns
            total_cpu = sum(psutil.cpu_percent(percpu=True))
            total_memory = psutil.virtual_memory().available

            # Adjust agent resource limits based on usage
            for agent_id, agent in self.agents.items():
                # Implementation would adjust agent resource allocations
                pass

        except Exception as e:
            self.logger.error(f"Error optimizing resource allocation: {e}")

    def _update_agent_configs(self):
        """Update agent configurations based on performance"""
        try:
            # Analyze performance and suggest config changes
            for agent_id, agent in self.agents.items():
                status = agent.get_status()

                # Example: Adjust monitoring intervals based on load
                if status['metrics'].get('cpu_usage', 0) > 80:
                    # Reduce monitoring frequency to save resources
                    new_config = agent.config.copy()
                    new_config['monitoring_interval'] = max(
                        new_config.get('monitoring_interval', 30) * 1.5, 60
                    )
                    agent.update_config(new_config)

        except Exception as e:
            self.logger.error(f"Error updating agent configs: {e}")

    def _check_scaling_needs(self):
        """Check if system needs scaling"""
        try:
            system_load = self.system_metrics.get('system_cpu_usage', 0)

            if system_load > 90 and len(self.agents) < self.max_agents:
                self.logger.info("High system load detected, considering agent scaling")
                # Could implement agent scaling logic here

            elif system_load < 30 and len(self.agents) > 6:  # Minimum agents
                self.logger.info("Low system load detected, considering agent reduction")
                # Could implement agent reduction logic here

        except Exception as e:
            self.logger.error(f"Error checking scaling needs: {e}")

    def _optimize_message_routing(self):
        """Optimize message routing efficiency"""
        try:
            # Analyze message routing patterns
            routing_stats = defaultdict(int)

            # Count messages by type and destination
            for message_data in list(self.message_queue)[-1000:]:  # Last 1000 messages
                routing_stats[f"{message_data.message_type}->{message_data.receiver}"] += 1

            # Identify high-traffic routes for optimization
            high_traffic_routes = [
                route for route, count in routing_stats.items()
                if count > 100  # Threshold for high traffic
            ]

            if high_traffic_routes:
                self.logger.info(f"Identified {len(high_traffic_routes)} high-traffic routes for optimization")

        except Exception as e:
            self.logger.error(f"Error optimizing message routing: {e}")

    def _update_agent_priorities(self):
        """Update agent priorities based on system needs"""
        try:
            # Adjust priorities based on current system state
            for agent_id, agent in self.agents.items():
                status = agent.get_status()

                # Increase priority for agents with high error rates
                if status['error_count'] > 5:
                    current_priority = self.agent_priorities.get(agent_id, 1)
                    self.agent_priorities[agent_id] = min(current_priority + 1, 5)

                # Increase priority for security agent during threats
                if agent_id == 'security_agent' and status['metrics'].get('active_incidents', 0) > 0:
                    self.agent_priorities[agent_id] = 5

        except Exception as e:
            self.logger.error(f"Error updating agent priorities: {e}")

    def _get_uptime(self) -> float:
        """Get system uptime in seconds"""
        if self.start_time:
            return (datetime.now() - self.start_time).total_seconds()
        return 0

    def _load_agent_configs(self):
        """Load agent configurations from file"""
        try:
            with open('data/agent_configs.json', 'r') as f:
                self.agent_configs = json.load(f)
            self.logger.info("Agent configurations loaded")
        except FileNotFoundError:
            # Use default configurations
            self.agent_configs = {
                'security_agent': {'auto_response': True, 'threat_thresholds': {'suspicious_connections': 10}},
                'network_agent': {'load_balancing': True, 'monitoring_interval': 30},
                'learning_agent': {'adaptive_learning': True, 'retrain_interval': 3600},
                'automation_agent': {'max_concurrent_rules': 10, 'auto_response': True},
                'analytics_agent': {'data_retention_days': 90, 'analysis_interval': 300},
                'communication_agent': {'message_queue_size': 1000, 'retry_attempts': 3}
            }
        except Exception as e:
            self.logger.error(f"Error loading agent configs: {e}")

# Global coordinator instance
coordinator = AgentCoordinator()

def get_coordinator() -> AgentCoordinator:
    """Get the global agent coordinator instance"""
    return coordinator

def initialize_agent_system(config: Dict[str, Any] = None):
    """Initialize the entire agent system"""
    global coordinator
    coordinator = AgentCoordinator(config)
    coordinator.initialize_system()

def shutdown_agent_system():
    """Shutdown the entire agent system"""
    global coordinator
    coordinator.shutdown_system()

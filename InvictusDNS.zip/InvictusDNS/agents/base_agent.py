"""
Base Agent Class for InvictusDNS AI System

This module provides the foundational BaseAgent class that all specialized
agents inherit from. It includes common functionality for agent lifecycle,
communication, state management, and coordination.

Features:
- Agent lifecycle management (init, start, stop, pause, resume)
- Message passing system for inter-agent communication
- State persistence and recovery
- Health monitoring and self-diagnostics
- Configuration management
- Logging and telemetry
- Error handling and recovery

Author: BLACKBOXAI
"""

import threading
import time
import json
import logging
import uuid
from datetime import datetime
from typing import Dict, List, Any, Optional, Callable
from abc import ABC, abstractmethod
import os
import psutil
from enum import Enum

class AgentState(Enum):
    """Enumeration of possible agent states"""
    INITIALIZING = "initializing"
    RUNNING = "running"
    PAUSED = "paused"
    STOPPED = "stopped"
    ERROR = "error"
    MAINTENANCE = "maintenance"

class AgentPriority(Enum):
    """Agent execution priority levels"""
    LOW = 1
    NORMAL = 2
    HIGH = 3
    CRITICAL = 4

class Message:
    """Message class for inter-agent communication"""
    def __init__(self, sender: str, receiver: str, message_type: str,
                 payload: Dict[str, Any], priority: AgentPriority = AgentPriority.NORMAL,
                 correlation_id: str = None):
        self.id = str(uuid.uuid4())
        self.timestamp = datetime.now().isoformat()
        self.sender = sender
        self.receiver = receiver
        self.message_type = message_type
        self.payload = payload
        self.priority = priority
        self.correlation_id = correlation_id or self.id
        self.delivered = False
        self.processed = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            'id': self.id,
            'timestamp': self.timestamp,
            'sender': self.sender,
            'receiver': self.receiver,
            'message_type': self.message_type,
            'payload': self.payload,
            'priority': self.priority.value,
            'correlation_id': self.correlation_id,
            'delivered': self.delivered,
            'processed': self.processed
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Message':
        msg = cls(
            sender=data['sender'],
            receiver=data['receiver'],
            message_type=data['message_type'],
            payload=data['payload'],
            priority=AgentPriority(data['priority']),
            correlation_id=data.get('correlation_id')
        )
        msg.id = data['id']
        msg.timestamp = data['timestamp']
        msg.delivered = data.get('delivered', False)
        msg.processed = data.get('processed', False)
        return msg

class BaseAgent(ABC):
    """
    Base class for all AI agents in the InvictusDNS system.

    Provides common functionality for:
    - Agent lifecycle management
    - Inter-agent communication
    - State persistence
    - Health monitoring
    - Configuration management
    - Error handling
    """

    def __init__(self, agent_id: str, name: str, coordinator=None,
                 config: Dict[str, Any] = None, log_level: str = 'INFO'):
        """
        Initialize the base agent.

        Args:
            agent_id: Unique identifier for the agent
            name: Human-readable name for the agent
            coordinator: AgentCoordinator instance for inter-agent communication
            config: Configuration dictionary
            log_level: Logging level (DEBUG, INFO, WARNING, ERROR)
        """
        self.agent_id = agent_id
        self.name = name
        self.coordinator = coordinator
        self.config = config or {}
        self.state = AgentState.INITIALIZING
        self.priority = AgentPriority.NORMAL

        # Logging setup
        self.logger = logging.getLogger(f"InvictusDNS.Agent.{self.name}")
        self.logger.setLevel(getattr(logging, log_level.upper()))

        # State management
        self.start_time = None
        self.last_activity = None
        self.health_status = "healthy"
        self.error_count = 0
        self.message_count = 0

        # Message handling
        self.message_queue = []
        self.message_handlers = {}
        self.pending_responses = {}

        # Threading
        self.running = False
        self.worker_thread = None
        self.message_thread = None

        # Persistence
        self.state_file = f"data/agent_states/{self.agent_id}_state.json"
        os.makedirs(os.path.dirname(self.state_file), exist_ok=True)

        # Performance metrics
        self.metrics = {
            'messages_processed': 0,
            'messages_sent': 0,
            'errors': 0,
            'uptime': 0,
            'cpu_usage': 0,
            'memory_usage': 0
        }

        # Register default message handlers
        self._register_default_handlers()

        self.logger.info(f"Agent {self.name} initialized")

    def _register_default_handlers(self):
        """Register default message handlers"""
        self.register_handler('ping', self._handle_ping)
        self.register_handler('status', self._handle_status_request)
        self.register_handler('config_update', self._handle_config_update)
        self.register_handler('shutdown', self._handle_shutdown)
        self.register_handler('pause', self._handle_pause)
        self.register_handler('resume', self._handle_resume)

    def register_handler(self, message_type: str, handler: Callable):
        """Register a message handler for a specific message type"""
        self.message_handlers[message_type] = handler
        self.logger.debug(f"Registered handler for message type: {message_type}")

    def start(self):
        """Start the agent"""
        if self.state != AgentState.INITIALIZING:
            self.logger.warning(f"Agent {self.name} already started")
            return

        try:
            self.logger.info(f"Starting agent {self.name}")
            self.running = True
            self.start_time = datetime.now()
            self.last_activity = self.start_time

            # Load previous state if exists
            self._load_state()

            # Initialize agent-specific components
            self._initialize()

            # Start worker threads
            self.worker_thread = threading.Thread(target=self._worker_loop, daemon=True)
            self.message_thread = threading.Thread(target=self._message_loop, daemon=True)

            self.worker_thread.start()
            self.message_thread.start()

            self.state = AgentState.RUNNING
            self._save_state()

            self.logger.info(f"Agent {self.name} started successfully")

        except Exception as e:
            self.logger.error(f"Failed to start agent {self.name}: {e}")
            self.state = AgentState.ERROR
            raise

    def stop(self):
        """Stop the agent"""
        if not self.running:
            return

        self.logger.info(f"Stopping agent {self.name}")
        self.running = False
        self.state = AgentState.STOPPED

        # Wait for threads to finish
        if self.worker_thread and self.worker_thread.is_alive():
            self.worker_thread.join(timeout=5)
        if self.message_thread and self.message_thread.is_alive():
            self.message_thread.join(timeout=5)

        # Cleanup
        self._cleanup()
        self._save_state()

        self.logger.info(f"Agent {self.name} stopped")

    def pause(self):
        """Pause the agent"""
        if self.state != AgentState.RUNNING:
            return

        self.logger.info(f"Pausing agent {self.name}")
        self.state = AgentState.PAUSED
        self._save_state()

    def resume(self):
        """Resume the agent"""
        if self.state != AgentState.PAUSED:
            return

        self.logger.info(f"Resuming agent {self.name}")
        self.state = AgentState.RUNNING
        self.last_activity = datetime.now()
        self._save_state()

    def send_message(self, receiver: str, message_type: str, payload: Dict[str, Any],
                    priority: AgentPriority = AgentPriority.NORMAL,
                    correlation_id: str = None) -> str:
        """
        Send a message to another agent

        Args:
            receiver: Target agent ID
            message_type: Type of message
            payload: Message payload
            priority: Message priority
            correlation_id: Correlation ID for request-response patterns

        Returns:
            Message ID
        """
        message = Message(self.agent_id, receiver, message_type, payload, priority, correlation_id)

        if self.coordinator:
            self.coordinator.route_message(message)
        else:
            # Direct message if no coordinator
            self._deliver_message(message)

        self.metrics['messages_sent'] += 1
        self.logger.debug(f"Sent message {message.id} to {receiver}: {message_type}")

        return message.id

    def receive_message(self, message: Message):
        """Receive a message from another agent"""
        self.message_queue.append(message)
        self.message_count += 1
        self.last_activity = datetime.now()

    def get_status(self) -> Dict[str, Any]:
        """Get current agent status"""
        return {
            'agent_id': self.agent_id,
            'name': self.name,
            'state': self.state.value,
            'priority': self.priority.value,
            'health': self.health_status,
            'start_time': self.start_time.isoformat() if self.start_time else None,
            'last_activity': self.last_activity.isoformat() if self.last_activity else None,
            'uptime': self._get_uptime(),
            'metrics': self.metrics.copy(),
            'config': self.config,
            'error_count': self.error_count,
            'message_queue_size': len(self.message_queue)
        }

    def update_config(self, new_config: Dict[str, Any]):
        """Update agent configuration"""
        self.config.update(new_config)
        self._save_state()
        self.logger.info(f"Configuration updated for agent {self.name}")

    def _worker_loop(self):
        """Main worker loop - to be overridden by subclasses"""
        while self.running and self.state == AgentState.RUNNING:
            try:
                self._update_metrics()
                self._perform_work()
                time.sleep(1)  # Prevent busy waiting
            except Exception as e:
                self.logger.error(f"Error in worker loop: {e}")
                self.error_count += 1
                self.metrics['errors'] += 1
                time.sleep(5)  # Back off on errors

    def _message_loop(self):
        """Message processing loop"""
        while self.running:
            try:
                if self.message_queue:
                    message = self.message_queue.pop(0)
                    self._process_message(message)
                else:
                    time.sleep(0.1)  # Prevent busy waiting
            except Exception as e:
                self.logger.error(f"Error in message loop: {e}")
                self.error_count += 1
                time.sleep(1)

    def _process_message(self, message: Message):
        """Process a received message"""
        try:
            message.delivered = True

            handler = self.message_handlers.get(message.message_type)
            if handler:
                response = handler(message)
                message.processed = True
                self.metrics['messages_processed'] += 1

                # Send response if handler returned one
                if response and message.correlation_id:
                    self.send_message(
                        message.sender,
                        'response',
                        {'result': response},
                        correlation_id=message.correlation_id
                    )
            else:
                self.logger.warning(f"No handler for message type: {message.message_type}")

        except Exception as e:
            self.logger.error(f"Error processing message {message.id}: {e}")
            self.error_count += 1

    def _update_metrics(self):
        """Update performance metrics"""
        try:
            process = psutil.Process()
            self.metrics['cpu_usage'] = process.cpu_percent()
            self.metrics['memory_usage'] = process.memory_percent()
            self.metrics['uptime'] = self._get_uptime()
        except:
            pass  # Ignore metric update errors

    def _get_uptime(self) -> float:
        """Get agent uptime in seconds"""
        if self.start_time:
            return (datetime.now() - self.start_time).total_seconds()
        return 0

    def _load_state(self):
        """Load agent state from file"""
        try:
            if os.path.exists(self.state_file):
                with open(self.state_file, 'r') as f:
                    state_data = json.load(f)
                    self.state = AgentState(state_data.get('state', 'stopped'))
                    self.config.update(state_data.get('config', {}))
                    self.metrics.update(state_data.get('metrics', {}))
                    self.logger.info(f"State loaded for agent {self.name}")
        except Exception as e:
            self.logger.error(f"Failed to load state: {e}")

    def _save_state(self):
        """Save agent state to file"""
        try:
            state_data = {
                'agent_id': self.agent_id,
                'name': self.name,
                'state': self.state.value,
                'config': self.config,
                'metrics': self.metrics,
                'last_save': datetime.now().isoformat()
            }
            with open(self.state_file, 'w') as f:
                json.dump(state_data, f, indent=2)
        except Exception as e:
            self.logger.error(f"Failed to save state: {e}")

    # Default message handlers
    def _handle_ping(self, message: Message) -> Dict[str, Any]:
        """Handle ping messages"""
        return {'status': 'pong', 'timestamp': datetime.now().isoformat()}

    def _handle_status_request(self, message: Message) -> Dict[str, Any]:
        """Handle status request messages"""
        return self.get_status()

    def _handle_config_update(self, message: Message) -> Dict[str, Any]:
        """Handle configuration update messages"""
        new_config = message.payload.get('config', {})
        self.update_config(new_config)
        return {'status': 'updated'}

    def _handle_shutdown(self, message: Message) -> Dict[str, Any]:
        """Handle shutdown messages"""
        self.stop()
        return {'status': 'shutdown'}

    def _handle_pause(self, message: Message) -> Dict[str, Any]:
        """Handle pause messages"""
        self.pause()
        return {'status': 'paused'}

    def _handle_resume(self, message: Message) -> Dict[str, Any]:
        """Handle resume messages"""
        self.resume()
        return {'status': 'resumed'}

    # Abstract methods to be implemented by subclasses
    @abstractmethod
    def _initialize(self):
        """Initialize agent-specific components"""
        pass

    @abstractmethod
    def _perform_work(self):
        """Perform agent-specific work"""
        pass

    @abstractmethod
    def _cleanup(self):
        """Cleanup agent-specific resources"""
        pass

    @abstractmethod
    def get_capabilities(self) -> List[str]:
        """Return list of agent capabilities"""
        pass

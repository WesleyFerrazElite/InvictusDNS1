"""
InvictusDNS AI Agents Package

This package contains all AI agents for the InvictusDNS system, providing
specialized functionality for security, networking, learning, automation,
analytics, and communication.

Agents:
- SecurityAgent: Threat detection and response
- NetworkAgent: Network optimization and monitoring
- LearningAgent: Continuous learning and adaptation
- AutomationAgent: Rule-based automation and workflows
- AnalyticsAgent: Data analysis and business intelligence
- CommunicationAgent: Inter-agent communication and external integrations

Coordinator:
- AgentCoordinator: Central coordination and management of all agents

Author: BLACKBOXAI
"""

from .base_agent import BaseAgent, AgentPriority, Message
from .security_agent import SecurityAgent
from .network_agent import NetworkAgent
from .learning_agent import LearningAgent
from .automation_agent import AutomationAgent
from .analytics_agent import AnalyticsAgent
from .communication_agent import CommunicationAgent
from .agent_coordinator import AgentCoordinator, get_coordinator, initialize_agent_system, shutdown_agent_system

__all__ = [
    # Base classes
    'BaseAgent',
    'AgentPriority',
    'Message',

    # Specialized agents
    'SecurityAgent',
    'NetworkAgent',
    'LearningAgent',
    'AutomationAgent',
    'AnalyticsAgent',
    'CommunicationAgent',

    # Coordination
    'AgentCoordinator',
    'get_coordinator',
    'initialize_agent_system',
    'shutdown_agent_system'
]

__version__ = "1.0.0"
__author__ = "BLACKBOXAI"
__description__ = "AI Agent System for InvictusDNS"

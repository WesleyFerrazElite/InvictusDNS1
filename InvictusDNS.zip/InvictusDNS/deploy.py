#!/usr/bin/env python3
"""
InvictusDNS Deployment Script
Creates portable version, installer, and deployment package
"""

import os
import sys
import shutil
import zipfile
from pathlib import Path

def create_portable_zip():
    """Create portable ZIP for distribution"""
    print("Creating portable ZIP...")

    zip_name = 'InvictusDNS_Portable.zip'
    with zipfile.ZipFile(zip_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk('.'):
            # Skip unwanted directories
            dirs[:] = [d for d in dirs if d not in ['__pycache__', '.git', 'dist', 'build', '.pytest_cache']]

            for file in files:
                # Skip unwanted files
                if file.endswith(('.pyc', '.pyo', '.log')) or file.startswith('.'):
                    continue

                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, '.')
                zipf.write(file_path, arcname)

    print(f"Created: {zip_name}")
    return zip_name

def create_installer_zip():
    """Create installer ZIP"""
    print("Creating installer ZIP...")

    zip_name = 'InvictusDNS_Installer.zip'
    with zipfile.ZipFile(zip_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
        # Add installer and required files
        files_to_include = [
            'installer.py',
            'launcher.py',
            'requirements_portable.txt',
            'README_Portable.md',
            'create_icon.py',
            'build_exe.py',
            'build_exe_with_icon.py'
        ]

        for file in files_to_include:
            if os.path.exists(file):
                zipf.write(file)

        # Add directories
        dirs_to_include = ['data', 'panels', 'server', 'scripts']
        for dir_name in dirs_to_include:
            if os.path.exists(dir_name):
                for root, dirs, files in os.walk(dir_name):
                    for file in files:
                        if not file.endswith(('.pyc', '.pyo', '.log')) and not file.startswith('.'):
                            file_path = os.path.join(root, file)
                            arcname = os.path.relpath(file_path, '.')
                            zipf.write(file_path, arcname)

    print(f"Created: {zip_name}")
    return zip_name

def create_desktop_shortcut_script():
    """Create script to copy to desktop"""
    print("Creating desktop deployment script...")

    script_content = '''#!/usr/bin/env python3
"""
Copy InvictusDNS to Desktop
"""

import os
import shutil
import platform
from pathlib import Path

def deploy_to_desktop():
    """Deploy InvictusDNS to desktop"""
    desktop = Path.home() / 'Desktop'
    source = Path(__file__).parent
    target = desktop / 'InvictusDNS'

    print(f"Deploying to: {target}")

    # Copy all files
    if target.exists():
        shutil.rmtree(target)
    shutil.copytree(source, target)

    # Create shortcut
    if platform.system() == 'Windows':
        # Create batch file
        batch_file = target / 'Run_InvictusDNS.bat'
        with open(batch_file, 'w') as f:
            f.write('@echo off\\npython launcher.py\\n')
        print(f"Created: {batch_file}")
    else:
        # Make launcher executable
        launcher = target / 'launcher.py'
        os.chmod(launcher, 0o755)
        print(f"Made executable: {launcher}")

    print("Deployment complete!")
    print(f"Run from: {target}")

if __name__ == '__main__':
    deploy_to_desktop()
'''

    with open('deploy_to_desktop.py', 'w') as f:
        f.write(script_content)

    print("Created: deploy_to_desktop.py")

def main():
    """Main deployment function"""
    print("InvictusDNS Deployment Tool")
    print("=" * 40)

    # Create portable ZIP
    portable_zip = create_portable_zip()

    # Create installer ZIP
    installer_zip = create_installer_zip()

    # Create desktop deployment script
    create_desktop_shortcut_script()

    print("\nDeployment files created:")
    print(f"- {portable_zip} (extract and run launcher.py)")
    print(f"- {installer_zip} (run installer.py to install system-wide)")
    print("- deploy_to_desktop.py (run to copy to desktop)")

    print("\nTo build executable:")
    print("1. Install PyInstaller: pip install PyInstaller")
    print("2. Run: python build_exe_with_icon.py")
    print("3. Executable will be in dist/InvictusDNS.exe")

if __name__ == '__main__':
    main()

"""
InvictusDNS API Documentation
Generated automatically - DO NOT EDIT MANUALLY
"""

API_DOCUMENTATION = """
# InvictusDNS REST API Documentation

## Overview
InvictusDNS provides a comprehensive REST API for programmatic access to DNS server functionality, monitoring, and management.

## Authentication
All API endpoints require JWT authentication. Include the token in the Authorization header:
```
Authorization: Bearer <your-jwt-token>
```

## Base URL
```
http://localhost:5000/api
```

## Endpoints

### Health Check
- **GET** `/api/health`
- **Description**: Check API health status
- **Response**:
```json
{
  "status": "healthy",
  "version": "1.0.0",
  "uptime": "1h 30m",
  "timestamp": "2024-01-01T12:00:00Z"
}
```

### DNS Statistics
- **GET** `/api/statistics`
- **Description**: Get DNS server statistics
- **Response**:
```json
{
  "dns": {
    "total_queries": 1250,
    "avg_response_time": 45.2,
    "max_response_time": 120.5,
    "min_response_time": 12.3,
    "categories": {
      "porn": 150,
      "game": 300,
      "malware": 25,
      "other": 775
    },
    "top_domains": [
      {"domain": "google.com", "count": 45},
      {"domain": "facebook.com", "count": 32}
    ],
    "top_clients": [
      {"ip": "192.168.1.100", "count": 89},
      {"ip": "192.168.1.101", "count": 67}
    ]
  },
  "traffic": {
    "total_packets": 5000,
    "total_bytes": 2500000,
    "avg_packet_size": 500,
    "unique_sources": 25,
    "unique_destinations": 15,
    "protocols": [
      {"protocol": "TCP", "count": 3000, "bytes": 1800000},
      {"protocol": "UDP", "count": 2000, "bytes": 700000}
    ],
    "hourly_traffic": [
      {"hour": "14", "packets": 450, "bytes": 225000}
    ]
  }
}
```

### DNS Logs
- **GET** `/api/dns-logs`
- **Parameters**:
  - `limit` (int, optional): Number of logs to return (default: 100, max: 1000)
  - `offset` (int, optional): Offset for pagination (default: 0)
  - `start_date` (string, optional): Start date in ISO format
  - `end_date` (string, optional): End date in ISO format
  - `domain` (string, optional): Filter by domain
  - `client_ip` (string, optional): Filter by client IP
  - `category` (string, optional): Filter by category
- **Response**:
```json
{
  "logs": [
    {
      "id": 1,
      "timestamp": "2024-01-01T12:00:00Z",
      "client_ip": "192.168.1.100",
      "domain": "example.com",
      "response_ip": "93.184.216.34",
      "category": "other",
      "response_time": 23.5
    }
  ],
  "total": 1250,
  "limit": 100,
  "offset": 0
}
```

### Traffic Logs
- **GET** `/api/traffic-logs`
- **Parameters**: Same as DNS logs
- **Response**:
```json
{
  "logs": [
    {
      "id": 1,
      "timestamp": "2024-01-01T12:00:00Z",
      "src_ip": "192.168.1.100",
      "dst_ip": "8.8.8.8",
      "src_port": 54321,
      "dst_port": 53,
      "protocol": "UDP",
      "length": 512,
      "info": "DNS Query"
    }
  ],
  "total": 5000,
  "limit": 100,
  "offset": 0
}
```

### Blocked Domains
- **GET** `/api/blocked-domains`
- **POST** `/api/blocked-domains`
- **DELETE** `/api/blocked-domains/{domain}`

**GET Response**:
```json
{
  "domains": [
    {
      "id": 1,
      "domain": "malicious-site.com",
      "user_id": 1,
      "blocked_at": "2024-01-01T12:00:00Z"
    }
  ]
}
```

**POST Body**:
```json
{
  "domain": "malicious-site.com"
}
```

### Blocked IPs
- **GET** `/api/blocked-ips`
- **POST** `/api/blocked-ips`
- **DELETE** `/api/blocked-ips/{ip}`

**GET Response**:
```json
{
  "ips": [
    {
      "id": 1,
      "ip": "192.168.1.200",
      "user_id": 1,
      "blocked_at": "2024-01-01T12:00:00Z"
    }
  ]
}
```

**POST Body**:
```json
{
  "ip": "192.168.1.200"
}
```

### User Management
- **GET** `/api/users`
- **POST** `/api/users`
- **PUT** `/api/users/{user_id}`
- **DELETE** `/api/users/{user_id}`

**Requires admin role**

**GET Response**:
```json
{
  "users": [
    {
      "id": 1,
      "username": "admin",
      "email": "admin@example.com",
      "role": "admin",
      "active": true,
      "created_at": "2024-01-01T12:00:00Z",
      "last_login": "2024-01-01T15:30:00Z"
    }
  ]
}
```

**POST Body**:
```json
{
  "username": "newuser",
  "email": "user@example.com",
  "password": "securepassword",
  "role": "user"
}
```

### System Metrics
- **GET** `/api/metrics`
- **Description**: Get real-time system metrics
- **Response**:
```json
{
  "system": {
    "cpu_percent": 45.2,
    "memory_percent": 67.8,
    "memory_used": 3456789,
    "memory_total": 8589934592,
    "disk_usage": 23.4,
    "network_connections": 45,
    "load_average": [1.2, 1.1, 1.0],
    "timestamp": "2024-01-01T12:00:00Z"
  },
  "dns": {
    "total_queries": 1250,
    "avg_response_time": 45.2,
    "categories": {"porn": 150, "game": 300}
  },
  "traffic": {
    "total_packets": 5000,
    "total_bytes": 2500000,
    "protocols": [{"protocol": "TCP", "count": 3000}]
  }
}
```

### Alert Management
- **GET** `/api/alerts`
- **POST** `/api/alerts`
- **PUT** `/api/alerts/{alert_id}`
- **DELETE** `/api/alerts/{alert_id}`

**GET Response**:
```json
{
  "alerts": [
    {
      "id": 1,
      "name": "High CPU Usage",
      "type": "system",
      "condition": "cpu_percent > 80",
      "enabled": true,
      "created_at": "2024-01-01T12:00:00Z"
    }
  ]
}
```

**POST Body**:
```json
{
  "name": "High Memory Usage",
  "type": "system",
  "condition": "memory_percent > 90",
  "actions": ["email", "webhook"],
  "enabled": true
}
```

### Backup Management
- **GET** `/api/backups`
- **POST** `/api/backups`
- **GET** `/api/backups/{backup_id}/download`
- **DELETE** `/api/backups/{backup_id}`

**GET Response**:
```json
{
  "backups": [
    {
      "id": 1,
      "name": "daily_backup_2024_01_01",
      "size": 1048576,
      "created_at": "2024-01-01T03:00:00Z",
      "type": "full"
    }
  ]
}
```

**POST Body**:
```json
{
  "type": "full",
  "name": "manual_backup"
}
```

## Error Responses
All endpoints return errors in the following format:
```json
{
  "error": "Error description",
  "code": "ERROR_CODE",
  "timestamp": "2024-01-01T12:00:00Z"
}
```

Common HTTP status codes:
- `200`: Success
- `201`: Created
- `400`: Bad Request
- `401`: Unauthorized
- `403`: Forbidden
- `404`: Not Found
- `500`: Internal Server Error

## Rate Limiting
API requests are limited to 1000 requests per hour per IP address.

## WebSocket Support
Real-time updates are available via WebSocket at `/api/ws`:
```javascript
const ws = new WebSocket('ws://localhost:5000/api/ws');
ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  console.log('Real-time update:', data);
};
```

## SDKs and Libraries
- **Python**: `pip install invictus-dns-sdk`
- **JavaScript**: `npm install invictus-dns-client`
- **Go**: `go get github.com/invictus-dns/go-client`

## Changelog
### v1.0.0
- Initial API release
- Basic DNS and traffic monitoring
- User management
- Alert system

## Support
For API support, visit our documentation at https://docs.invictus-dns.com or contact support@invictus-dns.com.
"""

SWAGGER_CONFIG = """
{
  "openapi": "3.0.3",
  "info": {
    "title": "InvictusDNS API",
    "description": "REST API for InvictusDNS server management and monitoring",
    "version": "1.0.0",
    "contact": {
      "email": "support@invictus-dns.com"
    }
  },
  "servers": [
    {
      "url": "http://localhost:5000/api",
      "description": "Local development server"
    }
  ],
  "security": [
    {
      "bearerAuth": []
    }
  ],
  "components": {
    "securitySchemes": {
      "bearerAuth": {
        "type": "http",
        "scheme": "bearer",
        "bearerFormat": "JWT"
      }
    },
    "schemas": {
      "Error": {
        "type": "object",
        "properties": {
          "error": {
            "type": "string"
          },
          "code": {
            "type": "string"
          },
          "timestamp": {
            "type": "string",
            "format": "date-time"
          }
        }
      },
      "Health": {
        "type": "object",
        "properties": {
          "status": {
            "type": "string",
            "enum": ["healthy", "unhealthy"]
          },
          "version": {
            "type": "string"
          },
          "uptime": {
            "type": "string"
          },
          "timestamp": {
            "type": "string",
            "format": "date-time"
          }
        }
      }
    }
  }
}
"""

def generate_api_docs():
    """Generate API documentation files"""
    import os

    docs_dir = os.path.dirname(os.path.abspath(__file__))

    # Write API documentation
    with open(os.path.join(docs_dir, 'api.md'), 'w', encoding='utf-8') as f:
        f.write(API_DOCUMENTATION)

    # Write Swagger configuration
    with open(os.path.join(docs_dir, 'swagger.json'), 'w', encoding='utf-8') as f:
        f.write(SWAGGER_CONFIG)

    print("API documentation generated successfully!")

if __name__ == "__main__":
    generate_api_docs()

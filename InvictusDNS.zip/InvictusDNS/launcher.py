#!/usr/bin/env python3
"""
InvictusDNS Portable Launcher
Auto-detects IP, starts DNS server and all panels.
Cross-platform compatible.
"""

import os
import sys
import socket
import subprocess
import threading
import time
import signal
import platform
from pathlib import Path

# Detect OS
IS_WINDOWS = platform.system() == 'Windows'
IS_LINUX = platform.system() == 'Linux'

# Project root
PROJECT_ROOT = Path(__file__).parent

# Services
SERVICES = {
    'dns_server': ('server/dns_server.py', 53),
    'web_panel': ('panels/web_panel.py', 3000),
    'marketing_panel': ('panels/marketing_panel.py', 3001),
    'ai_panel': ('panels/ai_panel.py', 3002),
    'cloud_panel': ('panels/cloud_panel.py', 3003),
}

processes = []

def get_local_ip():
    """Auto-detect local IP"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return "127.0.0.1"

def start_service(name, script_path, port):
    """Start a service"""
    try:
        cmd = [sys.executable, str(PROJECT_ROOT / script_path)]
        if IS_WINDOWS:
            process = subprocess.Popen(cmd, creationflags=subprocess.CREATE_NEW_CONSOLE)
        else:
            process = subprocess.Popen(cmd)
        processes.append((name, process, port))
        print(f"Started {name} on port {port}")
        time.sleep(1)  # Wait for startup
    except Exception as e:
        print(f"Failed to start {name}: {e}")

def stop_services():
    """Stop all services"""
    for name, process, port in processes:
        try:
            if IS_WINDOWS:
                process.terminate()
            else:
                process.send_signal(signal.SIGTERM)
            process.wait(timeout=5)
            print(f"Stopped {name}")
        except:
            process.kill()
            print(f"Force killed {name}")

def main():
    print("InvictusDNS Portable Launcher")
    print("=" * 40)

    # Detect IP
    local_ip = get_local_ip()
    print(f"Detected local IP: {local_ip}")

    # Start services
    print("Starting services...")
    for name, (script, port) in SERVICES.items():
        start_service(name, script, port)

    print("\nServices running:")
    print(f"DNS Server: {local_ip}:53")
    print(f"Web Panel: http://{local_ip}:3000 (login: admin/admin)")
    print(f"Marketing Panel: http://{local_ip}:3001")
    print(f"AI Panel: http://{local_ip}:3002")
    print(f"Cloud Panel: http://{local_ip}:3003")

    print("\nPress Ctrl+C to stop all services")

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nStopping services...")
        stop_services()
        print("All services stopped. Goodbye!")

if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == '--test':
        print("Test mode: Checking dependencies...")
        try:
            import flask, sqlite3, dnslib, scapy, werkzeug, cryptography, psutil
            print("All dependencies OK")
        except ImportError as e:
            print(f"Missing dependency: {e}")
            sys.exit(1)
        print("IP detection:", get_local_ip())
        print("Test passed!")
    else:
        main()

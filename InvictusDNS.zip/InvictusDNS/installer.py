#!/usr/bin/env python3
"""
InvictusDNS AI Panel Setup Installer
Instalador completo do sistema InvictusDNS com IA integrada
Compatível com Windows e Linux
"""

import os
import sys
import shutil
import platform
import subprocess
import urllib.request
import zipfile
import tempfile
from pathlib import Path

IS_WINDOWS = platform.system() == 'Windows'
IS_LINUX = platform.system() == 'Linux'
IS_MAC = platform.system() == 'Darwin'

def print_banner():
    """Exibe banner do instalador"""
    print("""
    ╔══════════════════════════════════════════════════════════════╗
    ║                    INVICTUS DNS - SETUP                      ║
    ║              Instalador Completo com IA Integrada           ║
    ╚══════════════════════════════════════════════════════════════╝
    """)

def check_python_version():
    """Verifica versão do Python"""
    if sys.version_info < (3, 8):
        print("❌ ERRO: Python 3.8 ou superior é necessário!")
        print(f"Versão atual: {sys.version}")
        print("Baixe Python 3.8+ de: https://python.org")
        sys.exit(1)
    print(f"✅ Python {sys.version.split()[0]} - OK")

def check_admin_privileges():
    """Verifica privilégios de administrador"""
    try:
        if IS_WINDOWS:
            import ctypes
            return ctypes.windll.shell32.IsUserAnAdmin()
        else:
            return os.geteuid() == 0
    except:
        return False

def install_python_dependencies():
    """Instala dependências Python"""
    print("\n📦 Instalando dependências Python...")

    requirements_files = ['requirements_portable.txt', 'requirements.txt']

    for req_file in requirements_files:
        if os.path.exists(req_file):
            print(f"Instalando {req_file}...")
            try:
                subprocess.check_call([sys.executable, '-m', 'pip', 'install', '-r', req_file])
                print(f"✅ {req_file} instalado com sucesso!")
            except subprocess.CalledProcessError as e:
                print(f"❌ Erro ao instalar {req_file}: {e}")
                return False
        else:
            print(f"⚠️  Arquivo {req_file} não encontrado, pulando...")

    return True

def configure_firewall():
    """Configura firewall para as portas necessárias"""
    print("\n🔥 Configurando firewall...")

    ports = [53, 3000, 3001, 3002, 3003]  # DNS + Web Panels

    if IS_WINDOWS:
        try:
            for port in ports:
                if port == 53:
                    # DNS (UDP)
                    cmd = f'netsh advfirewall firewall add rule name="InvictusDNS DNS" dir=in action=allow protocol=UDP localport={port}'
                else:
                    # HTTP (TCP)
                    cmd = f'netsh advfirewall firewall add rule name="InvictusDNS Port {port}" dir=in action=allow protocol=TCP localport={port}'
                subprocess.run(cmd, shell=True, capture_output=True)
            print("✅ Firewall configurado no Windows!")
        except Exception as e:
            print(f"⚠️  Erro ao configurar firewall: {e}")
            print("Configure manualmente as portas: 53, 3000-3003")

    elif IS_LINUX:
        try:
            # Verifica se ufw está instalado
            subprocess.run(['which', 'ufw'], check=True, capture_output=True)

            for port in ports:
                if port == 53:
                    subprocess.run(['sudo', 'ufw', 'allow', str(port)], check=True)
                else:
                    subprocess.run(['sudo', 'ufw', 'allow', f'{port}/tcp'], check=True)

            subprocess.run(['sudo', 'ufw', '--force', 'enable'], check=True)
            print("✅ Firewall configurado no Linux!")
        except (subprocess.CalledProcessError, FileNotFoundError):
            print("⚠️  UFW não encontrado ou erro na configuração")
            print("Configure manualmente as portas: 53, 3000-3003")

def create_env_file():
    """Cria arquivo .env com template das APIs"""
    print("\n🔑 Criando arquivo de configuração das APIs...")

    env_content = """# InvictusDNS - Chaves de API para IA
# Obtenha suas chaves nos sites oficiais dos provedores

# OpenAI (https://platform.openai.com/api-keys)
OPENAI_API_KEY=sk-your-openai-api-key-here

# Groq (https://console.groq.com/keys)
GROQ_API_KEY=gsk-your-groq-api-key-here

# Google Gemini (https://makersuite.google.com/app/apikey)
GOOGLE_API_KEY=your-google-gemini-api-key-here

# Anthropic Claude (https://console.anthropic.com/)
ANTHROPIC_API_KEY=sk-ant-your-anthropic-api-key-here

# Blackbox AI (https://www.blackbox.ai/)
BLACKBOX_API_KEY=your-blackbox-api-key-here

# GLM (ZhipuAI) (https://open.bigmodel.cn/)
GLM_API_KEY=your-glm-api-key-here

# DeepInfra (https://deepinfra.com/)
DEEPINFRA_API_KEY=your-deepinfra-api-key-here

# ===========================================
# INSTRUÇÕES:
# 1. Preencha APENAS as chaves dos provedores que você quer usar
# 2. Deixe as outras em branco ou comente com #
# 3. Reinicie o InvictusDNS após alterar
# 4. Mantenha este arquivo SEGURO e não compartilhe!
# ===========================================
"""

    env_file = Path('.env')
    if not env_file.exists():
        with open(env_file, 'w', encoding='utf-8') as f:
            f.write(env_content)
        print("✅ Arquivo .env criado!")
        print("📝 Edite o arquivo .env com suas chaves de API")
    else:
        print("ℹ️  Arquivo .env já existe")

def get_install_path():
    """Obtém caminho de instalação do sistema"""
    if IS_WINDOWS:
        return Path(os.environ.get('PROGRAMFILES', 'C:\\Program Files')) / 'InvictusDNS'
    else:
        return Path('/opt/InvictusDNS')

def create_desktop_shortcut(target_path, name):
    """Cria atalho na área de trabalho"""
    desktop = Path.home() / 'Desktop'

    if IS_WINDOWS:
        # Cria arquivo .lnk simplificado
        shortcut_path = desktop / f'{name}.lnk'
        try:
            with open(shortcut_path, 'w') as f:
                f.write(f'[InternetShortcut]\nURL=file:///{target_path}\n')
            print(f"✅ Atalho criado: {shortcut_path}")
        except Exception as e:
            print(f"⚠️  Erro ao criar atalho: {e}")

    else:
        # Cria arquivo .desktop
        shortcut_path = desktop / f'{name}.desktop'
        try:
            with open(shortcut_path, 'w') as f:
                f.write(f'''[Desktop Entry]
Name={name}
Exec={target_path}
Type=Application
Terminal=false
Icon=dns
Comment=InvictusDNS com IA integrada
''')
            os.chmod(shortcut_path, 0o755)
            print(f"✅ Atalho criado: {shortcut_path}")
        except Exception as e:
            print(f"⚠️  Erro ao criar atalho: {e}")

def create_startup_scripts():
    """Cria scripts de inicialização"""
    print("\n📜 Criando scripts de inicialização...")

    # Script para iniciar tudo
    start_all_content = '''#!/bin/bash
# InvictusDNS - Iniciar Todos os Serviços
echo "Iniciando InvictusDNS com IA..."

# Iniciar em background
python start_all.py &

echo "Serviços iniciados!"
echo "Acesse:"
echo "- Painel Web: http://localhost:3000 (admin/senha123)"
echo "- Painel IA: http://localhost:3002"
echo "- Painel Marketing: http://localhost:3001"
echo "- Painel Cloud: http://localhost:3003"
'''

    # Script para parar tudo
    stop_all_content = '''#!/bin/bash
# InvictusDNS - Parar Todos os Serviços
echo "Parando InvictusDNS..."

# Matar processos Python relacionados
pkill -f "python.*dns_server.py" || true
pkill -f "python.*web_panel.py" || true
pkill -f "python.*ai_panel.py" || true
pkill -f "python.*marketing_panel.py" || true
pkill -f "python.*cloud_panel.py" || true

echo "Serviços parados!"
'''

    try:
        with open('start_invictus.sh', 'w') as f:
            f.write(start_all_content)
        os.chmod('start_invictus.sh', 0o755)

        with open('stop_invictus.sh', 'w') as f:
            f.write(stop_all_content)
        os.chmod('stop_invictus.sh', 0o755)

        print("✅ Scripts criados: start_invictus.sh, stop_invictus.sh")
    except Exception as e:
        print(f"⚠️  Erro ao criar scripts: {e}")

def install_system():
    """Instala o sistema no computador"""
    print("\n💾 Instalando InvictusDNS no sistema...")

    install_path = get_install_path()
    source_path = Path(__file__).parent

    print(f"Instalando em: {install_path}")

    # Criar diretório de instalação
    install_path.mkdir(parents=True, exist_ok=True)

    # Copiar TODAS as pastas e arquivos
    print("Copiando TODOS os arquivos do projeto...")
    exclude_dirs = ['__pycache__', '.git', 'dist', 'build', 'node_modules']

    # Pastas específicas do projeto
    folders_to_copy = [
        'agents', 'api', 'app', 'auth', 'backup', 'cluster', 'config',
        'core-services', 'dados', 'data', 'docker', 'docs', 'InvictusDNS_Data',
        'k8s', 'logs', 'mobile_app', 'monitoring', 'notifications', 'panels',
        'scripts', 'security', 'server', 'sql', 'tests', 'ui', 'user_data', 'utils'
    ]

    # Copiar pastas específicas
    for folder in folders_to_copy:
        src = source_path / folder
        dst = install_path / folder
        if src.exists():
            try:
                if dst.exists():
                    shutil.rmtree(dst)
                shutil.copytree(src, dst, dirs_exist_ok=True)
                print(f"✅ Pasta copiada: {folder}")
            except Exception as e:
                print(f"⚠️  Erro ao copiar pasta {folder}: {e}")
        else:
            print(f"⚠️  Pasta não encontrada: {folder}")

    # Copiar arquivos raiz
    print("Copiando arquivos raiz...")
    root_files_to_copy = [
        '.env', '.env.example', 'ai_config.json', 'ai_core.py', 'AI_PANEL_CONFIGURATION_DOCUMENTATION.md',
        'ai_panel_service.py', 'ai_panel.service', 'AI_SECURITY_COMMANDS_GUIDE.md', 'ALL_PANELS_GUIDE.md',
        'architecture.md', 'build_exe_with_icon.py', 'build_exe.py', 'cleanup.py', 'cloud_panel.service',
        'cookies.txt', 'cookies1.txt', 'create_icon.py', 'deploy.py', 'dns_logs.db', 'dns_server.log',
        'docker-compose.core.yml', 'docker-compose.yml', 'INICIAR_TUDO.bat', 'INICIAR_TUDO.py',
        'install_ai_panel_service.bat', 'INSTALL_GUIA_RAPIDO.md', 'INSTALL.md', 'installer.py',
        'invictusdns_integrated.py', 'InvictusDNS.exe', 'invictusdns.exe.spec', 'invictusdns.service',
        'launcher.py', 'main.py', 'marketing_panel.service', 'monitor_services.py', 'network_config.json',
        'nohup.out', 'README_AI_PANEL.md', 'README_CORE_SERVICES.md', 'README_INICIAR.md',
        'README_Portable.md', 'README.md', 'requirements_portable.txt', 'requirements.txt',
        'run_linux.py', 'run_windows.py', 'setup_ai_panel.bat', 'setup.bat', 'setup.sh',
        'start_ai_panel_service.bat', 'start_ai_panel.bat', 'start_all.bat', 'start_all.py',
        'start_dns_server.py', 'start_services.sh', 'start_web_panel.py', 'stop_all.py',
        'stop_services.sh', 'test_db.py', 'TODO_AI_CONFIG.md', 'TODO_ISP_INTEGRATION.md',
        'TODO.md', 'TODO1.md', 'TUTORIAL_INSTALACAO.txt', 'web_panel.service'
    ]

    for file in root_files_to_copy:
        src = source_path / file
        dst = install_path / file
        if src.exists():
            try:
                shutil.copy2(src, dst)
                print(f"✅ Arquivo copiado: {file}")
            except Exception as e:
                print(f"⚠️  Erro ao copiar arquivo {file}: {e}")
        else:
            print(f"⚠️  Arquivo não encontrado: {file}")

    # Copiar outros arquivos que possam existir
    for item in source_path.iterdir():
        if item.name not in exclude_dirs and item.name not in folders_to_copy and item.name not in root_files_to_copy:
            try:
                if item.is_file():
                    shutil.copy2(item, install_path / item.name)
                    print(f"✅ Arquivo adicional copiado: {item.name}")
                elif item.is_dir():
                    shutil.copytree(item, install_path / item.name, dirs_exist_ok=True)
                    print(f"✅ Pasta adicional copiada: {item.name}")
            except Exception as e:
                print(f"⚠️  Erro ao copiar {item.name}: {e}")

    # Criar executável
    launcher_exe = install_path / 'InvictusDNS.exe' if IS_WINDOWS else install_path / 'InvictusDNS'
    launcher_py = install_path / 'launcher.py'

    if IS_WINDOWS:
        # Criar arquivo batch
        batch_file = install_path / 'InvictusDNS.bat'
        with open(batch_file, 'w') as f:
            f.write(f'@echo off\ncd /d "{install_path}"\npython launcher.py\n')
        launcher_exe = batch_file
    else:
        # Tornar script executável
        os.chmod(launcher_py, 0o755)
        launcher_exe = launcher_py

    # Criar atalho na área de trabalho
    print("Criando atalho na área de trabalho...")
    create_desktop_shortcut(launcher_exe, 'InvictusDNS')

    print("✅ Instalação concluída!")
    print(f"Executável: {launcher_exe}")
    print("Atalho criado na área de trabalho")

def test_installation():
    """Testa se a instalação funcionou"""
    print("\n🧪 Testando instalação...")

    try:
        # Testar importações básicas
        import flask
        import sqlite3
        import psutil
        print("✅ Dependências básicas OK")

        # Testar se scripts existem
        scripts = ['launcher.py', 'start_all.py', 'panels/ai_panel.py']
        for script in scripts:
            if os.path.exists(script):
                print(f"✅ {script} encontrado")
            else:
                print(f"❌ {script} não encontrado")

        # Testar portas (básico)
        import socket
        ports = [3000, 3001, 3002, 3003]
        for port in ports:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            result = sock.connect_ex(('127.0.0.1', port))
            sock.close()
            if result == 0:
                print(f"⚠️  Porta {port} já em uso")
            else:
                print(f"✅ Porta {port} livre")

        print("✅ Teste concluído!")

    except ImportError as e:
        print(f"❌ Erro de dependências: {e}")
        return False
    except Exception as e:
        print(f"⚠️  Erro no teste: {e}")

    return True

def show_post_install_info():
    """Exibe informações pós-instalação"""
    print("""
╔══════════════════════════════════════════════════════════════╗
║                  INSTALAÇÃO CONCLUÍDA!                       ║
╚══════════════════════════════════════════════════════════════╝

🎯 PRÓXIMOS PASSOS:

1️⃣ CONFIGURAR APIs:
   - Edite o arquivo .env com suas chaves de API
   - Mínimo necessário: OpenAI ou Groq

2️⃣ INICIAR SISTEMA:
   - Use o atalho na área de trabalho
   - Ou execute: python launcher.py

3️⃣ ACESSAR PAINÉIS:
   - Painel Web: http://localhost:3000 (admin/senha123)
   - Painel IA: http://localhost:3002 (admin/senha123)
   - Painel Marketing: http://localhost:3001
   - Painel Cloud: http://localhost:3003

4️⃣ CONFIGURAR DNS:
   - No seu dispositivo: DNS = IP do servidor
   - Teste acessando sites

📚 DOCUMENTAÇÃO:
   - README_AI_PANEL.md - Guia completo da IA
   - TUTORIAL_INSTALACAO.txt - Instalação detalhada

🔧 SCRIPTS ÚTEIS:
   - start_invictus.sh - Iniciar tudo
   - stop_invictus.sh - Parar tudo

⚠️  IMPORTANTE:
   - Mantenha as chaves API seguras
   - Faça backup regular das configurações
   - Monitore os logs em logs/

🎉 BEM-VINDO AO INVICTUS DNS COM IA!
    """)

def main():
    """Função principal do instalador"""
    print_banner()

    # Verificações iniciais
    check_python_version()

    if not check_admin_privileges():
        print("⚠️  Recomenda-se executar como administrador/root para configuração completa")
        input("Pressione Enter para continuar ou Ctrl+C para cancelar...")

    # Menu de instalação
    print("\nSelecione o tipo de instalação:")
    print("1. Instalação Completa (recomendado)")
    print("2. Apenas dependências (para desenvolvimento)")
    print("3. Desinstalar")

    choice = input("Escolha (1-3): ").strip()

    if choice == '1':
        # Instalação completa
        print("\n🚀 Iniciando instalação completa...")

        # Instalar dependências
        if not install_python_dependencies():
            print("❌ Falha na instalação das dependências!")
            sys.exit(1)

        # Configurar firewall
        configure_firewall()

        # Criar arquivo .env
        create_env_file()

        # Criar scripts de inicialização
        create_startup_scripts()

        # Instalar no sistema
        install_system()

        # Testar instalação
        test_installation()

        # Informações finais
        show_post_install_info()

    elif choice == '2':
        # Apenas dependências
        print("\n📦 Instalando apenas dependências...")
        if install_python_dependencies():
            print("✅ Dependências instaladas!")
            print("Para instalar completamente, execute novamente e escolha opção 1")
        else:
            print("❌ Falha na instalação!")

    elif choice == '3':
        # Desinstalar
        print("\n🗑️  Desinstalando InvictusDNS...")
        install_path = get_install_path()
        if install_path.exists():
            shutil.rmtree(install_path)
            print(f"✅ Removido: {install_path}")

        # Remover atalhos
        desktop = Path.home() / 'Desktop'
        for ext in ['.lnk', '.desktop', '.bat']:
            shortcut = desktop / f'InvictusDNS{ext}'
            if shortcut.exists():
                shortcut.unlink()
                print(f"✅ Removido: {shortcut}")

        print("✅ Desinstalação concluída!")

    else:
        print("❌ Opção inválida!")

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nInstalação cancelada pelo usuário.")
    except Exception as e:
        print(f"\n❌ Erro durante instalação: {e}")
        import traceback
        traceback.print_exc()

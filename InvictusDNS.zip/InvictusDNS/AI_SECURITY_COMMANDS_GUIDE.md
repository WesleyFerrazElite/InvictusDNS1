# 🛡️ GUIA COMPLETO DE COMANDOS DE SEGURANÇA - IA INVICTUSDNS

## Visão Geral
O painel de IA do InvictusDNS possui controle total sobre todas as funções de segurança. A IA pode executar qualquer comando de segurança automaticamente através do chat conversacional.

## 📋 Como Usar os Comandos
1. Acesse: `http://localhost:3002`
2. Login: `admin` / `senha123`
3. Vá para a aba "Chat com IA"
4. Digite os comandos em linguagem natural (português brasileiro)

---

## 🚫 BLOQUEIO DE DOMÍNIOS

### Comando Básico
```
"Bloquear domínio example.com"
"Bloquear o domínio suspicious-site.com"
```

### Comando Avançado
```
"Bloquear domínio malware-domain.ru por 24 horas"
"Bloquear permanentemente o domínio phishing-bank.com"
```

### Exemplos Práticos
- ✅ `"Bloquear domínio porn-site.xxx"`
- ✅ `"Bloquear domínio virus-download.net"`
- ✅ `"Bloquear domínio fake-login-bank.com"`

---

## ✅ DESBLOQUEIO DE DOMÍNIOS

### Comando Básico
```
"Desbloquear domínio example.com"
"Remover bloqueio do domínio safe-site.com"
```

### Comando Avançado
```
"Desbloquear domínio temporarily-blocked.com"
"Remover bloqueio permanente do domínio legitimate-site.org"
```

### Exemplos Práticos
- ✅ `"Desbloquear domínio google.com"`
- ✅ `"Remover bloqueio do domínio youtube.com"`
- ✅ `"Desbloquear domínio github.com"`

---

## 🚫 BLOQUEIO DE IPS

### Comando Básico
```
"Bloquear IP 192.168.1.100"
"Bloquear o IP 10.0.0.50"
```

### Comando Avançado
```
"Bloquear IP 203.0.113.1 por ataque DDoS"
"Isolar IP 198.51.100.25 por comportamento suspeito"
```

### Exemplos Práticos
- ✅ `"Bloquear IP 185.220.101.1"` (Tor exit node)
- ✅ `"Bloquear IP 45.227.253.15"` (IP malicioso conhecido)
- ✅ `"Isolar IP 104.236.192.100"` (Servidor suspeito)

---

## ✅ DESBLOQUEIO DE IPS

### Comando Básico
```
"Desbloquear IP 192.168.1.100"
"Remover bloqueio do IP 10.0.0.50"
```

### Comando Avançado
```
"Desbloquear IP 203.0.113.1 após investigação"
"Remover isolamento do IP 198.51.100.25"
```

### Exemplos Práticos
- ✅ `"Desbloquear IP 8.8.8.8"` (Google DNS)
- ✅ `"Remover bloqueio do IP 1.1.1.1"` (Cloudflare DNS)
- ✅ `"Desbloquear IP 192.168.1.10"` (IP da rede local)

---

## 🔍 ANÁLISE DE DOMÍNIOS

### Comando Básico
```
"Analisar domínio example.com"
"Verificar domínio suspicious-site.net"
```

### Comando Avançado
```
"Analisar domínio malware-site.ru em profundidade"
"Fazer análise completa de segurança do domínio phishing-bank.com"
```

### Exemplos Práticos
- ✅ `"Analisar domínio google.com"`
- ✅ `"Verificar domínio microsoft.com"`
- ✅ `"Analisar domínio suspeito.ru"`

---

## 📊 STATUS DO SISTEMA

### Comando Básico
```
"Status do sistema"
"Como está o servidor"
"Verificar saúde do sistema"
```

### Comando Avançado
```
"Status detalhado do sistema"
"Verificar performance do servidor"
"Análise completa da saúde do sistema"
```

### Exemplos Práticos
- ✅ `"Status do sistema"`
- ✅ `"Como está o servidor"`
- ✅ `"Verificar performance"`

---

## 📈 RELATÓRIOS DE SEGURANÇA

### Comando Básico
```
"Relatório de segurança"
"Status de segurança"
"Verificar ameaças"
```

### Comando Avançado
```
"Relatório completo de segurança das últimas 24 horas"
"Status detalhado de ameaças e incidentes"
"Análise de vulnerabilidades do sistema"
```

### Exemplos Práticos
- ✅ `"Relatório de segurança"`
- ✅ `"Status de ameaças"`
- ✅ `"Verificar incidentes"`

---

## 🤖 MACHINE LEARNING

### Comando Básico
```
"Treinar o modelo"
"Atualizar ML"
"Treinar detecção de anomalias"
```

### Comando Avançado
```
"Treinar modelo de ML com dados das últimas 24 horas"
"Atualizar algoritmos de detecção de anomalias"
"Re-treinar modelo com novos padrões de ameaça"
```

### Exemplos Práticos
- ✅ `"Treinar o modelo"`
- ✅ `"Atualizar ML"`
- ✅ `"Treinar detecção"`

---

## 🧹 LIMPEZA DE CACHE

### Comando Básico
```
"Limpar cache"
"Esvaziar cache"
"Limpar memória cache"
```

### Comando Avançado
```
"Limpar cache DNS completamente"
"Esvaziar todos os caches do sistema"
"Limpar cache de ameaças e limpar memória"
```

### Exemplos Práticos
- ✅ `"Limpar cache"`
- ✅ `"Esvaziar cache DNS"`
- ✅ `"Limpar memória cache"`

---

## 🔄 REINICIALIZAÇÃO DE SERVIÇOS

### Comando Básico
```
"Reiniciar serviço"
"Restart do servidor"
"Reinicializar DNS"
```

### Comando Avançado
```
"Reiniciar serviço DNS suavemente"
"Fazer restart completo do servidor InvictusDNS"
"Reinicializar todos os serviços de segurança"
```

### Exemplos Práticos
- ✅ `"Reiniciar DNS"`
- ✅ `"Restart servidor"`
- ✅ `"Reinicializar serviços"`

---

## ⚙️ COMANDOS AVANÇADOS DE AUTOMAÇÃO

### Monitoramento Contínuo
```
"Ativar monitoramento contínuo de ameaças"
"Iniciar análise automática de logs"
"Ativar detecção automática de malware"
```

### Respostas Automáticas
```
"Ativar bloqueio automático de IPs suspeitos"
"Configurar resposta automática para DDoS"
"Ativar isolamento automático de ameaças"
```

### Manutenção
```
"Executar manutenção completa do sistema"
"Atualizar todas as bases de ameaças"
"Fazer backup automático de configurações"
```

---

## 📝 EXEMPLOS DE CONVERSAÇÃO COMPLETA

### Cenário 1: Detecção de Ameaça
```
Você: "Analisar domínio suspicious-malware.ru"
IA: ✅ Comando executado: analisar domínio suspicious-malware.ru
     Análise completa: Score de ameaça 85.2% - MALWARE DETECTADO
     Recomendação: Bloquear imediatamente

Você: "Bloquear domínio suspicious-malware.ru"
IA: ✅ Comando executado: bloquear domínio suspicious-malware.ru
     Domínio bloqueado com sucesso. Isolado da rede.
```

### Cenário 2: Ataque DDoS
```
Você: "Bloquear IP 203.0.113.195 por ataque DDoS"
IA: ✅ Comando executado: bloquear IP 203.0.113.195
     IP bloqueado. Ataque DDoS mitigado.
     Status: Firewall atualizado, tráfego malicioso interrompido.
```

### Cenário 3: Verificação de Sistema
```
Você: "Status do sistema"
IA: ✅ Comando executado: status do sistema
     CPU: 15.2% | Memória: 45.8% | Disco: 32.1%
     Status: Sistema saudável, todos os serviços ativos.

Você: "Relatório de segurança"
IA: ✅ Comando executado: relatório de segurança
     Domínios em quarentena: 12
     Incidentes hoje: 3 (todos mitigados)
     Ameaças ativas: 0
```

---

## 🔐 SEGURANÇA E AUTENTICAÇÃO

### Acesso ao Painel
- **URL**: `http://localhost:3002`
- **Usuário**: `admin`
- **Senha**: `senha123`
- **Porta**: 3002 (configurável)

### Níveis de Permissão
- **Admin**: Controle total sobre IA e segurança
- **User**: Acesso limitado a consultas

### Logs de Auditoria
- Todas as ações da IA são registradas
- Histórico completo de comandos executados
- Rastreamento de quem executou cada ação

---

## 🚨 RESPOSTAS AUTOMÁTICAS DA IA

A IA responde automaticamente a:
- Tentativas de acesso não autorizado
- Padrões suspeitos de tráfego
- Domínios conhecidos por malware
- IPs com comportamento anômalo
- Tentativas de exploração de vulnerabilidades

---

## 📞 SUPORTE E MONITORAMENTO

### Monitoramento em Tempo Real
- Dashboard atualizado a cada 5 segundos
- Alertas automáticos por email/SMS
- Logs centralizados de segurança

### Suporte Técnico
- IA responde 24/7 a comandos de segurança
- Diagnóstico automático de problemas
- Sugestões proativas de melhorias

---

**💡 DICA**: A IA entende comandos em linguagem natural. Você pode dizer "Bloqueie aquele domínio suspeito que está no log" ou "Proteja o servidor contra ataques" e a IA executará as ações apropriadas automaticamente.

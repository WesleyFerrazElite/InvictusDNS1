# InvictusDNS - Como Iniciar Tudo

## 🚀 INICIAR SISTEMA COMPLETO

### Opção 1: Arquivo Batch (Windows)
**Clique duplo no arquivo `INICIAR_TUDO.bat`**

Este arquivo irá:
- ✅ Verificar se Python está instalado
- ✅ Iniciar o sistema integrado completo
- ✅ Mostrar status de todos os componentes

### Opção 2: Arquivo Python (Windows/Linux/Mac)
**Execute: `python INICIAR_TUDO.py`**

Compatível com todos os sistemas operacionais.

---

## 📋 O QUE SERÁ INICIADO

### Servidores
- 🖥️ **DNS Server** (porta 53)
- 🌐 **API Gateway** (porta 8080)
- 📱 **Mobile API** (porta 8081)

### Painéis Web
- 👨‍💼 **Painel Admin** (porta 3000)
- 🤖 **Painel IA** (porta 3002)
- 📈 **Painel Marketing** (porta 3001)
- ☁️ **Painel Cloud** (porta 3003)

### Sistemas de IA
- 🧠 **AI Core** - Núcleo de inteligência artificial
- 👥 **Agents System** - Sistema de agentes inteligentes
- 🔒 **Security System** - Segurança avançada
- 📊 **ML Anomaly Detector** - Detecção de anomalias por ML
- ⚙️ **Automation Engine** - Motor de automação

### Infraestrutura
- ☁️ **Cluster Manager** - Gerenciamento de cluster
- 💾 **Cloud Backup** - Backup na nuvem
- 🌐 **PPOE Manager** - Gerenciamento PPOE
- ⚙️ **Configuration Manager** - Gerenciamento de configurações
- 📢 **Notification System** - Sistema de notificações
- 📊 **Analytics Dashboard** - Dashboard de analytics
- 👁️ **Watchdog Service** - Serviço de monitoramento
- ⚖️ **Load Balancer** - Balanceamento de carga

---

## 🎯 COMO USAR

1. **Certifique-se de estar na pasta raiz do InvictusDNS**
2. **Clique duplo em `INICIAR_TUDO.bat`** (Windows)
   ou execute `python INICIAR_TUDO.py` (qualquer OS)
3. **Aguarde a inicialização completa**
4. **Acesse os painéis via navegador**

---

## 📊 STATUS DOS COMPONENTES

O sistema mostra em tempo real:
- ✅ Componentes iniciados com sucesso
- ❌ Componentes com erro
- ⚠️ Avisos e alertas
- 📊 Status de portas e processos

---

## 🛑 COMO PARAR

- **Pressione `Ctrl+C`** no terminal
- Todos os componentes serão parados graciosamente
- O sistema salva logs em `logs/iniciar_tudo.log`

---

## 🔧 DEPENDÊNCIAS

Certifique-se de ter:
- Python 3.8+
- Módulos: flask, psutil, sqlite3
- Permissões para abrir portas (53, 3000-3003, 8080-8081)

---

## 📁 ESTRUTURA ESPERADA

```
InvictusDNS/
├── INICIAR_TUDO.bat     ← Clique aqui (Windows)
├── INICIAR_TUDO.py      ← Execute aqui (qualquer OS)
├── server/
│   └── dns_server.py
├── panels/
│   ├── web_panel.py
│   ├── ai_panel.py
│   ├── marketing_panel.py
│   └── cloud_panel.py
├── ai_core/
├── agents/
├── security/
├── monitoring/
├── cluster/
├── backup/
├── ppoe/
├── config/
├── notifications/
├── automation/
├── analytics/
├── api/
├── mobile/
├── services/
├── network/
└── logs/
```

---

## 🚨 SUPORTE

Se houver problemas:
1. Verifique se está na pasta correta
2. Verifique se Python está instalado
3. Verifique logs em `logs/iniciar_tudo.log`
4. Certifique-se de que as portas não estão ocupadas

---

**🎉 Agora é só clicar e deixar a IA trabalhar por você!**

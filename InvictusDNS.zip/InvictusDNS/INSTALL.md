# Guia de Instalação Completo - InvictusDNS

Este guia explica como instalar e configurar todos os componentes do InvictusDNS, incluindo os painéis web, nuvem e IA, com todas as dependências de criptografia, segurança e monitoramento.

## Pré-requisitos do Sistema

### Sistema Operacional
- Windows 11 (recomendado)
- Python 3.11+ instalado
- Pelo menos 4GB RAM
- Espaço em disco: 2GB mínimo

### Verificações Iniciais
1. Verifique se Python está instalado:
   ```cmd
   py --version
   ```
   Deve mostrar Python 3.11.x ou superior.

2. Verifique se pip está instalado:
   ```cmd
   py -m pip --version
   ```

## Instalação Passo a Passo

### Método 1: Instalação Automática (Recomendado)
```cmd
# Execute o instalador automático
setup.bat
```
Este script irá:
- Verificar Python
- Instalar todas as dependências
- Criar diretórios necessários
- Configurar firewall
- Preparar arquivo .env

### Método 2: Instalação Manual

#### 1. Clonar/Download do Projeto
```cmd
# Navegue até o diretório desejado
cd C:\Users\InvictusOS\Desktop

# Se clonando do git (assumindo que está versionado)
git clone <repository-url> InvictusDNS
cd InvictusDNS
```

#### 2. Instalar Dependências Python
```cmd
# Instalar todas as dependências necessárias
py -m pip install -r requirements.txt

# Verificar instalação
py -c "import flask, cryptography, psutil, openai, groq; print('Dependências básicas OK')"
```

### 3. Configurar Variáveis de Ambiente
Crie um arquivo `.env` na raiz do projeto:

```env
# Chaves de API para o painel IA (opcional - sem elas, alguns provedores não funcionarão)
OPENAI_API_KEY=sua-chave-openai-aqui
GROQ_API_KEY=sua-chave-groq-aqui
GOOGLE_API_KEY=sua-chave-google-aqui
ANTHROPIC_API_KEY=sua-chave-anthropic-aqui
BLACKBOX_API_KEY=sua-chave-blackbox-aqui
GLM_API_KEY=sua-chave-glm-aqui
DEEPINFRA_API_KEY=sua-chave-deepinfra-aqui
```

### 4. Criar Estrutura de Diretórios
```cmd
# Criar diretórios necessários
mkdir data
mkdir user_data
mkdir security
mkdir monitoring
mkdir utils
```

### 5. Configurar Firewall (Windows)
Abra PowerShell como administrador e execute:
```powershell
# Permitir portas necessárias
New-NetFirewallRule -DisplayName "InvictusDNS Web Panel" -Direction Inbound -Protocol TCP -LocalPort 3000 -Action Allow
New-NetFirewallRule -DisplayName "InvictusDNS AI Panel" -Direction Inbound -Protocol TCP -LocalPort 3002 -Action Allow
New-NetFirewallRule -DisplayName "InvictusDNS Cloud Panel" -Direction Inbound -Protocol TCP -LocalPort 3003 -Action Allow
```

## Configuração dos Painéis

### Painel Web (porta 3000)
Arquivo: `panels/web_panel.py`

**Funções principais:**
- Interface de administração DNS
- Gerenciamento de bloqueios
- Estatísticas do sistema
- Link para painel de nuvem

**Dependências específicas:**
- Flask (para web server)
- sqlite3 (banco de dados integrado)
- psutil (monitoramento sistema)

### Painel de Nuvem (porta 3003)
Arquivo: `panels/cloud_panel.py`

**Funções principais:**
- Sistema de backup na nuvem
- Gerenciamento de arquivos
- Controle de usuários e quotas
- Criptografia AES para arquivos

**Dependências específicas:**
- cryptography (para criptografia AES)
- Flask (web server)
- sqlite3 (banco de dados)
- os, time (operações de arquivo)

**Configuração adicional:**
- Arquivo `cloud_config.json` é criado automaticamente
- Diretório `user_data/` para armazenar arquivos criptografados

### Painel de IA (porta 3002)
Arquivo: `panels/ai_panel.py`

**Funções principais:**
- Chat com IA multi-provedor
- Detecção de anomalias ML
- Monitoramento de segurança
- Automação inteligente

**Dependências específicas:**
- openai, groq, google-generativeai, anthropic (APIs de IA)
- cryptography (criptografia de chaves API)
- psutil (monitoramento sistema)
- sqlite3 (banco de dados)
- requests (chamadas HTTP)

**Módulos externos necessários:**
- `monitoring/ml_anomaly_detector.py` - Detector de anomalias
- `utils/ip_obfuscator.py` - Ofuscação de IPs
- `security/advanced_security.py` - Segurança avançada

## Executando os Painéis

### Método 1: Iniciar Todos os Painéis Automaticamente
```cmd
# Execute o script de inicialização automática
start_all.bat
```
Este script irá abrir três janelas do console, uma para cada painel.

### Método 2: Iniciar Individualmente

#### 1. Painel Web
```cmd
cd InvictusDNS/panels
py web_panel.py
```
Acesse: http://localhost:3000
Login: admin / senha123

#### 2. Painel de Nuvem
```cmd
cd InvictusDNS/panels
py cloud_panel.py
```
Acesse: http://localhost:3003
Login: admin / senha123

#### 3. Painel de IA
```cmd
cd InvictusDNS/panels
py ai_panel.py
```
Acesse: http://localhost:3002
Login: admin / senha123

## Configuração de Segurança

### Criptografia
- **AES-256**: Usado para criptografar arquivos no painel de nuvem
- **Chaves API**: Criptografadas no banco de dados usando Fernet
- **Ofuscação de IP**: IPs são ofuscados antes do armazenamento

### Monitoramento
- **Sistema**: CPU, memória, disco monitorados em tempo real
- **Segurança**: Detecção de malware, phishing, DDoS
- **Logs**: Todos os acessos e ações são registrados

### Banco de Dados
- **SQLite**: Usado para armazenar usuários, logs DNS, tarefas IA
- **Localização**: `data/dns_logs.db`
- **Backup**: Recomendado backup regular do diretório `data/`

## Solução de Problemas

### Erro: "ModuleNotFoundError"
```cmd
# Reinstalar dependências
py -m pip install --upgrade flask cryptography psutil openai groq google-generativeai anthropic python-dotenv requests
```

### Erro: "Porta já em uso"
```cmd
# Verificar processos usando a porta
netstat -ano | findstr :3000
# Matar processo se necessário
taskkill /PID <PID> /F
```

### Erro: "Permission denied"
- Execute comandos como administrador
- Verifique permissões dos diretórios

### Painel não carrega
- Verifique se todos os arquivos estão presentes
- Confirme que as dependências estão instaladas
- Verifique logs no console para erros

## Funcionalidades Avançadas

### Backup Automático
- Configurado no painel de nuvem
- Arquivos criptografados automaticamente
- Controle de versão de arquivos

### IA Integrada
- Respostas automáticas a comandos
- Análise de ameaças em tempo real
- Detecção de anomalias comportamentais

### Monitoramento 24/7
- Alertas automáticos
- Relatórios diários
- Dashboard em tempo real

## Manutenção

### Atualizações
```cmd
# Atualizar dependências
py -m pip install --upgrade -r requirements.txt

# Backup de dados
copy data\* backup\
```

### Logs
- Logs do sistema: Ver console durante execução
- Logs de segurança: `data/dns_logs.db`
- Logs de IA: Console do painel IA

### Performance
- Monitore uso de CPU/memória
- Ajuste limites de taxa nas configurações
- Considere upgrade de hardware se necessário

## Suporte

Para problemas específicos:
1. Verifique este guia
2. Confirme instalação das dependências
3. Verifique logs de erro
4. Teste cada painel individualmente

Todos os painéis estão agora prontos para uso completo do InvictusDNS!

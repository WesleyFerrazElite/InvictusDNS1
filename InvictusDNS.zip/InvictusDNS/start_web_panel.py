#!/usr/bin/env python3
"""
InvictusDNS - Painel Web
Executa o painel web em background e mantém o processo ativo.
Compatível com Windows e Linux.
"""

import subprocess
import sys
import os
import time
import signal
import platform

def main():
    print("InvictusDNS - Iniciando Painel Web...")
    print(f"Sistema Operacional: {platform.system()}")

    # Caminho para o script do painel web
    web_script = os.path.join(os.path.dirname(__file__), 'panels', 'web_panel.py')

    if not os.path.exists(web_script):
        print(f"Erro: Arquivo {web_script} não encontrado!")
        sys.exit(1)

    try:
        # Executar o painel web
        if platform.system() == 'Windows':
            cmd = [sys.executable, web_script]
        else:
            cmd = ['python3', web_script]

        print(f"Executando: {' '.join(cmd)}")
        process = subprocess.Popen(cmd)

        print("Painel Web iniciado. PID:", process.pid)
        print("Acesse: http://localhost:3000")
        print("Login: admin / senha123")
        print("Pressione Ctrl+C para parar...")

        # Manter o processo ativo
        while True:
            time.sleep(1)
            if process.poll() is not None:
                print("Painel Web parou inesperadamente.")
                break

    except KeyboardInterrupt:
        print("\nParando painel web...")
        if 'process' in locals():
            process.terminate()
            process.wait()
        print("Painel Web parado.")
    except Exception as e:
        print(f"Erro ao iniciar painel web: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()

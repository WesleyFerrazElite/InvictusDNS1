#!/usr/bin/env python3
"""
Build InvictusDNS Portable Executable
"""

import PyInstaller.__main__
import os
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent

def build_exe():
    """Build portable executable"""
    spec = [
        '--onefile',  # Single executable
        '--windowed',  # No console window
        '--name=InvictusDNS',
        '--icon=icon.ico',  # Icon file
        '--add-data=data;data',  # Include data folder
        '--add-data=panels;panels',
        '--add-data=server;server',
        '--add-data=scripts;scripts',
        '--hidden-import=flask',
        '--hidden-import=sqlite3',
        '--hidden-import=dnslib',
        '--hidden-import=scapy',
        '--hidden-import=werkzeug',
        '--hidden-import=cryptography',
        '--hidden-import=psutil',
        '--hidden-import=hashlib',
        '--hidden-import=base64',
        '--hidden-import=threading',
        '--hidden-import=time',
        '--hidden-import=os',
        '--hidden-import=sys',
        '--hidden-import=socket',
        '--hidden-import=subprocess',
        '--hidden-import=signal',
        '--hidden-import=platform',
        '--hidden-import=pathlib',
        'launcher.py'
    ]

    PyInstaller.__main__.run(spec)

if __name__ == '__main__':
    build_exe()

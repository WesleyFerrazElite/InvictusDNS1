# 🖥️ GUIA COMPLETO DE TODOS OS PAINÉIS - INVICTUSDNS

## Visão Geral dos Painéis
O InvictusDNS possui 4 painéis web administrativos principais, cada um rodando em portas diferentes com funcionalidades específicas.

---

## 🌐 **WEB PANEL** (Painel Principal)
### **Porta**: 3000
### **URL**: `http://localhost:3000` ou `http://[IP_DO_SERVIDOR]:3000`
### **Usuário Padrão**: `admin`
### **Senha Padrão**: `senha123`

### **Funcionalidades**:
- ✅ **Dashboard Principal**: Estatísticas em tempo real (CPU, memória, rede, consultas DNS)
- ✅ **Gerenciamento de Usuários**: Adicionar/remover usuários, configurar IPs permitidos
- ✅ **Logs DNS**: Visualização de consultas, respostas, categorias (porn, game, malware)
- ✅ **Bloqueios**: Gerenciar domínios e IPs bloqueados
- ✅ **Monitoramento de Tráfego**: Análise de pacotes TCP/UDP, dados de uso
- ✅ **Configurações do Sistema**: Status de serviços, processos ativos
- ✅ **APIs REST**: Endpoints para integração externa

### **Como Acessar**:
1. Abrir navegador
2. Ir para: `http://localhost:3000`
3. Login: `admin` / `senha123`
4. Navegar pelas abas: Dashboard, Usuários, Logs, Bloqueios, etc.

---

## 📢 **MARKETING PANEL** (Painel de Marketing)
### **Porta**: 3001
### **URL**: `http://localhost:3001` ou `http://[IP_DO_SERVIDOR]:3001`
### **Usuário Padrão**: `admin`
### **Senha Padrão**: `senha123`

### **Funcionalidades**:
- ✅ **Página Promocional**: Site público editável com informações do InvictusDNS
- ✅ **Links de Redes Sociais**: Meta, Instagram, YouTube, Twitter, LinkedIn, TikTok, Kwai, Shopee, Mercado Livre
- ✅ **Conteúdo Personalizável**: Títulos, descrições, imagens
- ✅ **SEO Otimizado**: Meta tags, Open Graph para compartilhamento
- ✅ **Responsivo**: Funciona em desktop e mobile
- ✅ **Analytics**: Contadores de visitas (futuro)

### **Como Acessar**:
1. Abrir navegador
2. Ir para: `http://localhost:3001`
3. Login: `admin` / `senha123`
4. Editar conteúdo através da interface

---

## 🤖 **AI PANEL** (Painel de Inteligência Artificial)
### **Porta**: 3002
### **URL**: `http://localhost:3002` ou `http://[IP_DO_SERVIDOR]:3002`
### **Usuário Padrão**: `admin`
### **Senha Padrão**: `senha123`

### **Funcionalidades**:
- ✅ **Chat com IA**: Conversação natural em português brasileiro
- ✅ **Controle Total da IA**: Ativar/desativar IA globalmente e por provedor
- ✅ **7 Provedores Configurados**: OpenAI, Groq, Google, Anthropic, Blackbox, GLM, DeepInfra
- ✅ **Comandos de Segurança**: Bloquear/desbloquear domínios/IPs via chat
- ✅ **Machine Learning**: Detecção de anomalias e treinamento de modelos
- ✅ **Automação**: Regras automáticas de segurança e monitoramento
- ✅ **APIs de Gerenciamento**: Controle de chaves API, status de provedores
- ✅ **Monitoramento em Tempo Real**: CPU, memória, disco, processos
- ✅ **Tarefas Automáticas**: IA executa comandos atribuídos

### **Como Acessar**:
1. Abrir navegador
2. Ir para: `http://localhost:3002`
3. Login: `admin` / `senha123`
4. Usar o chat para comandos como:
   - "Bloquear domínio example.com"
   - "Status do sistema"
   - "Relatório de segurança"

---

## ☁️ **CLOUD PANEL** (Painel de Backup na Nuvem)
### **Porta**: 3003
### **URL**: `http://localhost:3003` ou `http://[IP_DO_SERVIDOR]:3003`
### **Usuário Padrão**: `admin`
### **Senha Padrão**: `senha123`

### **Funcionalidades**:
- ✅ **Sistema de Backup Seguro**: Upload de arquivos e pastas com criptografia AES
- ✅ **Registro de Usuários**: Sistema de contas para backup pessoal
- ✅ **Criptografia End-to-End**: Arquivos criptografados com chaves únicas
- ✅ **Quotas por Usuário**: Controle de espaço de armazenamento
- ✅ **Admin Dashboard**: Visão geral de todos os usuários, arquivos e uso
- ✅ **Delete/Restore**: Remover e restaurar arquivos
- ✅ **Suporte a ZIP**: Backup de pastas completas
- ✅ **Monitoramento**: Logs de upload/download, estatísticas de uso

### **Como Acessar**:
1. Abrir navegador
2. Ir para: `http://localhost:3003`
3. Login: `admin` / `senha123`
4. Registrar usuários e gerenciar backups

---

## 🔐 **SEGURANÇA E AUTENTICAÇÃO**

### **Credenciais Padrão** (Todos os Painéis):
- **Usuário**: `admin`
- **Senha**: `senha123`

### **Níveis de Acesso**:
- **Admin**: Controle total sobre todas as funcionalidades
- **User**: Acesso limitado (depende do painel)

### **Recomendações de Segurança**:
- ✅ Alterar senhas padrão após primeira configuração
- ✅ Usar HTTPS em produção (configurar certificado SSL)
- ✅ Configurar firewall para permitir apenas portas necessárias
- ✅ Ativar logs de auditoria
- ✅ Usar VPN para acesso remoto

---

## 🚀 **COMO INICIAR TODOS OS PAINÉIS**

### **Método 1: Script Automático**
```bash
# No diretório InvictusDNS
python launcher.py
# ou
./start_services.sh
```

### **Método 2: Manual Individual**
```bash
# Web Panel (Porta 3000)
cd panels
python web_panel.py &

# Marketing Panel (Porta 3001)
python marketing_panel.py &

# AI Panel (Porta 3002)
python ai_panel.py &

# Cloud Panel (Porta 3003)
python cloud_panel.py &
```

### **Método 3: Serviços Systemd (Linux)**
```bash
# Instalar serviços
sudo cp scripts/invictusdns-web.service /etc/systemd/system/
sudo cp scripts/invictusdns-marketing.service /etc/systemd/system/
sudo cp scripts/invictusdns-ai.service /etc/systemd/system/
sudo cp scripts/invictusdns-cloud.service /etc/systemd/system/

# Iniciar serviços
sudo systemctl start invictusdns-web
sudo systemctl start invictusdns-marketing
sudo systemctl start invictusdns-ai
sudo systemctl start invictusdns-cloud

# Habilitar auto-início
sudo systemctl enable invictusdns-web
sudo systemctl enable invictusdns-marketing
sudo systemctl enable invictusdns-ai
sudo systemctl enable invictusdns-cloud
```

---

## 📊 **MONITORAMENTO DE STATUS**

### **Verificar se os Painéis Estão Rodando**:
```bash
# Linux/Mac
netstat -tlnp | grep :300

# Windows
netstat -ano | findstr :300
```

### **Logs de Cada Painel**:
- **Web Panel**: `logs/web_panel.log`
- **Marketing Panel**: `logs/marketing_panel.log`
- **AI Panel**: `logs/ai_panel.log`
- **Cloud Panel**: `logs/cloud_panel.log`

---

## 🌐 **ACESSO REMOTO**

### **Configuração Básica**:
1. **Firewall**: Abrir portas 3000-3003
   ```bash
   # Ubuntu/Debian
   sudo ufw allow 3000/tcp
   sudo ufw allow 3001/tcp
   sudo ufw allow 3002/tcp
   sudo ufw allow 3003/tcp
   ```

2. **VPN Recomendada**: Para acesso seguro remoto
3. **HTTPS**: Configurar certificado SSL para produção

### **URLs de Acesso**:
- **Local**: `http://localhost:PORTA`
- **Rede Local**: `http://[IP_LOCAL]:PORTA`
- **Internet**: `http://[IP_PUBLICO]:PORTA` (com firewall configurado)

---

## ⚙️ **CONFIGURAÇÕES AVANÇADAS**

### **Personalização de Portas**:
Editar os arquivos `.py` dos painéis e alterar:
```python
app.run(host='0.0.0.0', port=NOVA_PORTA, debug=False)
```

### **Mudar Credenciais Padrão**:
1. Acessar painel como admin
2. Ir para configurações de usuário
3. Alterar senha do admin
4. Criar novos usuários com permissões específicas

### **Backup de Configurações**:
- Configurações salvas em: `data/` e `user_data/`
- Fazer backup regular desses diretórios

---

## 📞 **SUPORTE E DIAGNÓSTICO**

### **Verificar Dependências**:
```bash
pip install -r requirements.txt
```

### **Testar Conectividade**:
```bash
# Testar portas
curl http://localhost:3000
curl http://localhost:3001
curl http://localhost:3002
curl http://localhost:3003
```

### **Logs de Erro**:
- Verificar arquivos `.log` na pasta `logs/`
- Executar em modo debug: `python painel.py` (sem `&`)

---

## 🎯 **RESUMO RÁPIDO**

| Painel | Porta | Usuário | Senha | Função Principal |
|--------|-------|---------|-------|------------------|
| **Web** | 3000 | admin | senha123 | Dashboard principal, usuários, logs |
| **Marketing** | 3001 | admin | senha123 | Página promocional, redes sociais |
| **AI** | 3002 | admin | senha123 | IA conversacional, automação, segurança |
| **Cloud** | 3003 | admin | senha123 | Backup na nuvem, usuários, criptografia |

**💡 DICA**: Use o `launcher.py` para iniciar todos os painéis automaticamente, ou acesse cada um individualmente pelas portas especificadas.

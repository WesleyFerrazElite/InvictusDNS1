import base64
import hashlib
import random
import string

class IPObfuscator:
    def __init__(self):
        # Mapeamento de símbolos para cada dígito 0-9
        self.digit_symbols = {
            '0': '🌀', '1': '🌟', '2': '🔥', '3': '⚡', '4': '💎',
            '5': '🎯', '6': '🚀', '7': '🌙', '8': '💫', '9': '🌈'
        }

        # Símbolos separadores para octetos
        self.separators = ['✨', '💫', '🌟', '🔥', '⚡', '🎯', '🚀', '🌙']

        # Chave para criptografia (pode ser configurada)
        self.secret_key = b'InvictusDNS_IP_Obfuscation_Key_2024!'

    def ip_to_symbols(self, ip_str):
        """Converte IP para representação simbólica"""
        try:
            if not ip_str or ip_str == 'None':
                return '❓'

            # Dividir em octetos
            octets = ip_str.split('.')
            if len(octets) != 4:
                return '❌'

            obfuscated_parts = []
            for i, octet in enumerate(octets):
                # Converter cada dígito para símbolo
                symbol_octet = ''.join(self.digit_symbols.get(d, '❓') for d in octet)
                obfuscated_parts.append(symbol_octet)

                # Adicionar separador (exceto no último)
                if i < 3:
                    obfuscated_parts.append(random.choice(self.separators))

            return ''.join(obfuscated_parts)

        except Exception as e:
            print(f"Erro na ofuscação de IP: {e}")
            return '❌'

    def symbols_to_ip(self, symbol_str):
        """Converte representação simbólica de volta para IP"""
        try:
            if not symbol_str or symbol_str in ['❓', '❌']:
                return None

            # Criar mapeamento reverso
            symbol_to_digit = {v: k for k, v in self.digit_symbols.items()}

            # Remover separadores e converter símbolos para dígitos
            clean_str = ''
            for char in symbol_str:
                if char in symbol_to_digit:
                    clean_str += symbol_to_digit[char]

            # Tentar reconstruir IP (assumindo formato XXX.XXX.XXX.XXX)
            if len(clean_str) >= 4:
                # Tentar diferentes divisões possíveis
                for i in range(1, min(4, len(clean_str))):
                    for j in range(i+1, min(i+4, len(clean_str))):
                        for k in range(j+1, min(j+4, len(clean_str))):
                            try:
                                ip_parts = [
                                    clean_str[:i],
                                    clean_str[i:j],
                                    clean_str[j:k],
                                    clean_str[k:]
                                ]

                                # Validar que cada parte é um número válido
                                ip_nums = []
                                for part in ip_parts:
                                    if not part:
                                        continue
                                    num = int(part)
                                    if 0 <= num <= 255:
                                        ip_nums.append(str(num))

                                if len(ip_nums) == 4:
                                    return '.'.join(ip_nums)
                            except ValueError:
                                continue

            return None

        except Exception as e:
            print(f"Erro na desofuscação de IP: {e}")
            return None

    def hash_ip(self, ip_str, salt="InvictusDNS"):
        """Cria hash consistente do IP para analytics sem reversão"""
        try:
            if not ip_str:
                return None
            salted = f"{ip_str}{salt}"
            return hashlib.sha256(salted.encode()).hexdigest()[:16]
        except Exception as e:
            return None

    def encrypt_ip(self, ip_str):
        """Criptografa IP para armazenamento seguro"""
        try:
            if not ip_str:
                return None
            from cryptography.fernet import Fernet
            cipher = Fernet(self.secret_key)
            return cipher.encrypt(ip_str.encode()).decode()
        except Exception as e:
            return None

    def decrypt_ip(self, encrypted_ip):
        """Descriptografa IP"""
        try:
            if not encrypted_ip:
                return None
            from cryptography.fernet import Fernet
            cipher = Fernet(self.secret_key)
            return cipher.decrypt(encrypted_ip.encode()).decode()
        except Exception as e:
            return None

# Instância global
ip_obfuscator = IPObfuscator()

# Funções de conveniência
def obfuscate_ip(ip):
    return ip_obfuscator.ip_to_symbols(ip)

def deobfuscate_ip(symbols):
    return ip_obfuscator.symbols_to_ip(symbols)

def hash_ip(ip):
    return ip_obfuscator.hash_ip(ip)

if __name__ == '__main__':
    # Testes
    test_ips = ['192.168.1.1', '10.0.0.1', '172.16.0.1', '8.8.8.8']

    print("Teste de Ofuscação de IPs:")
    for ip in test_ips:
        obfuscated = obfuscate_ip(ip)
        print(f"{ip} -> {obfuscated}")

    print("\nTeste de Desofuscação:")
    for ip in test_ips:
        obfuscated = obfuscate_ip(ip)
        deobfuscated = deobfuscate_ip(obfuscated)
        print(f"{obfuscated} -> {deobfuscated}")

#!/usr/bin/env python3
"""
Build InvictusDNS Portable Executable with Icon
"""

import PyInstaller.__main__
import os
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent

def build_exe_with_icon():
    """Build portable executable with custom icon"""
    # First create icon if it doesn't exist
    if not os.path.exists('icon.ico'):
        print("Creating icon...")
        os.system('python create_icon.py')

    spec = [
        '--onefile',  # Single executable
        '--windowed',  # No console window
        '--name=InvictusDNS',
        '--icon=icon.ico',  # Custom icon
        '--add-data=data;data',  # Include data folder
        '--add-data=panels;panels',
        '--add-data=server;server',
        '--add-data=scripts;scripts',
        '--hidden-import=flask',
        '--hidden-import=sqlite3',
        '--hidden-import=dnslib',
        '--hidden-import=scapy',
        '--hidden-import=werkzeug',
        '--hidden-import=cryptography',
        '--hidden-import=psutil',
        '--hidden-import=hashlib',
        '--hidden-import=base64',
        '--hidden-import=threading',
        '--hidden-import=time',
        '--hidden-import=os',
        '--hidden-import=sys',
        '--hidden-import=socket',
        '--hidden-import=subprocess',
        '--hidden-import=signal',
        '--hidden-import=platform',
        '--hidden-import=pathlib',
        '--hidden-import=PIL',
        '--hidden-import=PIL.Image',
        '--hidden-import=PIL.ImageDraw',
        '--hidden-import=PIL.ImageFont',
        'launcher.py'
    ]

    print("Building executable...")
    PyInstaller.__main__.run(spec)
    print("Build complete! Executable: dist/InvictusDNS.exe")

if __name__ == '__main__':
    build_exe_with_icon()

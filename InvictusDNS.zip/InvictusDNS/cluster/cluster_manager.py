import socket
import threading
import time
import json
import os
import requests
from datetime import datetime, timedelta
import sqlite3
import hashlib
import secrets

DESKTOP_DIR = os.path.expanduser('~/Desktop')
CLUSTER_CONFIG_FILE = os.path.join(DESKTOP_DIR, 'InvictusDNS_Data', 'dados', 'cluster_config.json')
CLUSTER_DB_FILE = os.path.join(DESKTOP_DIR, 'InvictusDNS_Data', 'dados', 'cluster.db')

class ClusterNode:
    def __init__(self, node_id, ip, port, role='worker'):
        self.node_id = node_id
        self.ip = ip
        self.port = port
        self.role = role  # 'master' or 'worker'
        self.status = 'offline'
        self.last_heartbeat = None
        self.metrics = {}
        self.services = []

    def to_dict(self):
        return {
            'node_id': self.node_id,
            'ip': self.ip,
            'port': self.port,
            'role': self.role,
            'status': self.status,
            'last_heartbeat': self.last_heartbeat.isoformat() if self.last_heartbeat else None,
            'metrics': self.metrics,
            'services': self.services
        }

    @classmethod
    def from_dict(cls, data):
        node = cls(data['node_id'], data['ip'], data['port'], data['role'])
        node.status = data.get('status', 'offline')
        node.last_heartbeat = datetime.fromisoformat(data['last_heartbeat']) if data.get('last_heartbeat') else None
        node.metrics = data.get('metrics', {})
        node.services = data.get('services', [])
        return node

class ClusterManager:
    def __init__(self):
        self.nodes = {}
        self.local_node_id = self.generate_node_id()
        self.is_master = False
        self.master_node = None
        self.heartbeat_interval = 30  # seconds
        self.election_timeout = 60  # seconds
        self.running = False

        # Load configuration
        self.config = self.load_cluster_config()
        self.init_cluster_db()

    def generate_node_id(self):
        """Generate unique node ID"""
        hostname = socket.gethostname()
        ip = self.get_local_ip()
        unique_string = f"{hostname}:{ip}:{os.getpid()}"
        return hashlib.sha256(unique_string.encode()).hexdigest()[:16]

    def get_local_ip(self):
        """Get local IP address"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except:
            return "127.0.0.1"

    def load_cluster_config(self):
        """Load cluster configuration"""
        default_config = {
            'enabled': False,
            'cluster_name': 'InvictusDNS-Cluster',
            'discovery_method': 'static',  # 'static', 'multicast', 'consul'
            'static_nodes': [
                {'ip': '127.0.0.1', 'port': 5001},
                {'ip': '127.0.0.1', 'port': 5002}
            ],
            'multicast_group': '224.0.0.1',
            'multicast_port': 5000,
            'api_port': 5001,
            'replication_enabled': True,
            'load_balancing': True,
            'auto_failover': True
        }

        if os.path.exists(CLUSTER_CONFIG_FILE):
            with open(CLUSTER_CONFIG_FILE, 'r') as f:
                loaded_config = json.load(f)
                # Merge with defaults
                for key, value in default_config.items():
                    if key not in loaded_config:
                        loaded_config[key] = value
                return loaded_config
        else:
            self.save_cluster_config(default_config)
            return default_config

    def save_cluster_config(self, config):
        """Save cluster configuration"""
        os.makedirs(os.path.dirname(CLUSTER_CONFIG_FILE), exist_ok=True)
        with open(CLUSTER_CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=4)

    def init_cluster_db(self):
        """Initialize cluster database"""
        conn = sqlite3.connect(CLUSTER_DB_FILE)
        c = conn.cursor()

        # Cluster state table
        c.execute('''
            CREATE TABLE IF NOT EXISTS cluster_state (
                key TEXT PRIMARY KEY,
                value TEXT,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        # Node registry
        c.execute('''
            CREATE TABLE IF NOT EXISTS nodes (
                node_id TEXT PRIMARY KEY,
                ip TEXT,
                port INTEGER,
                role TEXT,
                status TEXT,
                last_seen TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        # Service registry
        c.execute('''
            CREATE TABLE IF NOT EXISTS services (
                service_id TEXT PRIMARY KEY,
                node_id TEXT,
                service_type TEXT,
                status TEXT,
                port INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (node_id) REFERENCES nodes (node_id)
            )
        ''')

        # Data replication log
        c.execute('''
            CREATE TABLE IF NOT EXISTS replication_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                operation TEXT,
                table_name TEXT,
                record_id TEXT,
                data TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                replicated BOOLEAN DEFAULT FALSE
            )
        ''')

        conn.commit()
        conn.close()

    def register_node(self, node):
        """Register a node in the cluster"""
        conn = sqlite3.connect(CLUSTER_DB_FILE)
        c = conn.cursor()

        c.execute('''
            INSERT OR REPLACE INTO nodes (node_id, ip, port, role, status, last_seen)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (node.node_id, node.ip, node.port, node.role, node.status, datetime.now().isoformat()))

        conn.commit()
        conn.close()

        self.nodes[node.node_id] = node

    def unregister_node(self, node_id):
        """Unregister a node from the cluster"""
        conn = sqlite3.connect(CLUSTER_DB_FILE)
        c = conn.cursor()

        c.execute('DELETE FROM nodes WHERE node_id = ?', (node_id,))
        c.execute('DELETE FROM services WHERE node_id = ?', (node_id,))

        conn.commit()
        conn.close()

        if node_id in self.nodes:
            del self.nodes[node_id]

    def discover_nodes(self):
        """Discover other nodes in the cluster"""
        if self.config['discovery_method'] == 'static':
            for node_config in self.config['static_nodes']:
                try:
                    # Try to connect to node
                    response = requests.get(f"http://{node_config['ip']}:{node_config['port']}/cluster/ping",
                                          timeout=5)
                    if response.status_code == 200:
                        node_data = response.json()
                        node = ClusterNode.from_dict(node_data)
                        self.register_node(node)
                except:
                    # Node is offline
                    pass

    def start_election(self):
        """Start leader election process"""
        if not self.config['enabled']:
            return

        # Simple leader election based on node ID
        # In a real implementation, you'd use Raft, Paxos, or similar
        candidates = [node for node in self.nodes.values() if node.status == 'online']

        if candidates:
            # Sort by node ID and pick the "highest"
            candidates.sort(key=lambda x: x.node_id, reverse=True)
            elected_master = candidates[0]

            if elected_master.node_id == self.local_node_id:
                self.become_master()
            else:
                self.follow_master(elected_master)

    def become_master(self):
        """Become the cluster master"""
        self.is_master = True
        self.master_node = self.nodes.get(self.local_node_id)

        print(f"Node {self.local_node_id} became cluster master")

        # Update cluster state
        conn = sqlite3.connect(CLUSTER_DB_FILE)
        c = conn.cursor()
        c.execute('INSERT OR REPLACE INTO cluster_state (key, value) VALUES (?, ?)',
                 ('master_node', self.local_node_id))
        conn.commit()
        conn.close()

    def follow_master(self, master_node):
        """Follow a master node"""
        self.is_master = False
        self.master_node = master_node

        print(f"Following master node: {master_node.node_id}")

    def send_heartbeat(self):
        """Send heartbeat to other nodes"""
        if not self.config['enabled']:
            return

        heartbeat_data = {
            'node_id': self.local_node_id,
            'ip': self.get_local_ip(),
            'port': self.config['api_port'],
            'role': 'master' if self.is_master else 'worker',
            'status': 'online',
            'timestamp': datetime.now().isoformat(),
            'services': self.get_local_services()
        }

        for node in self.nodes.values():
            if node.node_id != self.local_node_id:
                try:
                    response = requests.post(f"http://{node.ip}:{node.port}/cluster/heartbeat",
                                           json=heartbeat_data, timeout=5)
                    if response.status_code == 200:
                        node.status = 'online'
                        node.last_heartbeat = datetime.now()
                except:
                    node.status = 'offline'

    def receive_heartbeat(self, heartbeat_data):
        """Receive heartbeat from another node"""
        node_id = heartbeat_data['node_id']

        if node_id not in self.nodes:
            node = ClusterNode(
                heartbeat_data['node_id'],
                heartbeat_data['ip'],
                heartbeat_data['port'],
                heartbeat_data['role']
            )
            self.register_node(node)

        node = self.nodes[node_id]
        node.status = 'online'
        node.last_heartbeat = datetime.now()
        node.services = heartbeat_data.get('services', [])

        # If this is a master node and we're not master, follow it
        if heartbeat_data['role'] == 'master' and not self.is_master:
            self.follow_master(node)

    def get_local_services(self):
        """Get list of local services"""
        services = []
        local_ip = self.get_local_ip()

        # Check common ports
        service_ports = {
            'dns_server': 53,
            'web_panel': 3000,
            'logs_manager': 3004,
            'marketing_panel': 3001,
            'ai_panel': 3002,
            'cloud_panel': 3003,
            'api': 5000,
            'monitoring': 3005,
            'auth': 3006,
            'ui': 3007
        }

        for service_name, port in service_ports.items():
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(1)
                result = sock.connect_ex((local_ip, port))
                sock.close()

                status = 'running' if result == 0 else 'stopped'
                services.append({
                    'name': service_name,
                    'port': port,
                    'status': status
                })
            except:
                services.append({
                    'name': service_name,
                    'port': port,
                    'status': 'unknown'
                })

        return services

    def replicate_data(self, operation, table, record_id, data):
        """Replicate data changes across cluster"""
        if not self.config['replication_enabled'] or not self.is_master:
            return

        # Log replication event
        conn = sqlite3.connect(CLUSTER_DB_FILE)
        c = conn.cursor()

        c.execute('''
            INSERT INTO replication_log (operation, table_name, record_id, data)
            VALUES (?, ?, ?, ?)
        ''', (operation, table, record_id, json.dumps(data)))

        conn.commit()
        conn.close()

        # Send to worker nodes
        replication_data = {
            'operation': operation,
            'table': table,
            'record_id': record_id,
            'data': data,
            'timestamp': datetime.now().isoformat()
        }

        for node in self.nodes.values():
            if node.role == 'worker' and node.status == 'online':
                try:
                    requests.post(f"http://{node.ip}:{node.port}/cluster/replicate",
                                json=replication_data, timeout=10)
                except:
                    print(f"Failed to replicate to node {node.node_id}")

    def apply_replication(self, replication_data):
        """Apply replicated data changes"""
        if self.is_master:
            return  # Masters don't apply replications

        operation = replication_data['operation']
        table = replication_data['table']
        record_id = replication_data['record_id']
        data = replication_data['data']

        # Apply to local database
        # This is a simplified implementation
        print(f"Applying replication: {operation} on {table}:{record_id}")

    def balance_load(self):
        """Balance load across cluster nodes"""
        if not self.config['load_balancing'] or not self.is_master:
            return

        # Simple load balancing based on active connections
        # In a real implementation, this would be more sophisticated
        nodes_load = {}

        for node in self.nodes.values():
            if node.status == 'online':
                # Get node metrics
                try:
                    response = requests.get(f"http://{node.ip}:{node.port}/cluster/metrics", timeout=5)
                    metrics = response.json()
                    nodes_load[node.node_id] = metrics.get('active_connections', 0)
                except:
                    nodes_load[node.node_id] = 999  # High load if can't connect

        # Sort nodes by load
        sorted_nodes = sorted(nodes_load.items(), key=lambda x: x[1])

        print(f"Load balancing - Node loads: {nodes_load}")
        print(f"Least loaded node: {sorted_nodes[0][0] if sorted_nodes else 'None'}")

    def start(self):
        """Start cluster management"""
        if not self.config['enabled']:
            print("Cluster is disabled")
            return

        self.running = True
        print(f"Starting cluster manager for node {self.local_node_id}")

        # Register local node
        local_node = ClusterNode(
            self.local_node_id,
            self.get_local_ip(),
            self.config['api_port'],
            'worker'
        )
        self.register_node(local_node)

        # Start background threads
        threading.Thread(target=self.heartbeat_loop, daemon=True).start()
        threading.Thread(target=self.monitoring_loop, daemon=True).start()
        threading.Thread(target=self.maintenance_loop, daemon=True).start()

    def stop(self):
        """Stop cluster management"""
        self.running = False
        print("Stopping cluster manager")

    def heartbeat_loop(self):
        """Main heartbeat loop"""
        while self.running:
            try:
                self.discover_nodes()
                self.send_heartbeat()

                if not self.is_master:
                    self.start_election()

                time.sleep(self.heartbeat_interval)
            except Exception as e:
                print(f"Error in heartbeat loop: {e}")
                time.sleep(5)

    def monitoring_loop(self):
        """Monitoring and maintenance loop"""
        while self.running:
            try:
                # Check for failed nodes
                current_time = datetime.now()
                failed_nodes = []

                for node in self.nodes.values():
                    if node.node_id != self.local_node_id:
                        if node.last_heartbeat and (current_time - node.last_heartbeat).seconds > self.election_timeout:
                            node.status = 'offline'
                            failed_nodes.append(node.node_id)

                # Handle failover if master failed
                if self.master_node and self.master_node.status == 'offline' and not self.is_master:
                    print("Master node failed, starting election...")
                    self.start_election()

                # Load balancing
                self.balance_load()

                time.sleep(30)  # Check every 30 seconds
            except Exception as e:
                print(f"Error in monitoring loop: {e}")
                time.sleep(5)

    def maintenance_loop(self):
        """Maintenance tasks loop"""
        while self.running:
            try:
                # Clean up old replication logs
                conn = sqlite3.connect(CLUSTER_DB_FILE)
                c = conn.cursor()

                # Remove logs older than 7 days
                seven_days_ago = datetime.now() - timedelta(days=7)
                c.execute('DELETE FROM replication_log WHERE timestamp < ?',
                         (seven_days_ago.isoformat(),))

                conn.commit()
                conn.close()

                time.sleep(3600)  # Run daily
            except Exception as e:
                print(f"Error in maintenance loop: {e}")
                time.sleep(60)

# Global cluster manager instance
cluster_manager = ClusterManager()

if __name__ == '__main__':
    # Test cluster functionality
    cluster_manager.start()

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        cluster_manager.stop()

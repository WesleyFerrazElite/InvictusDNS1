from flask import Flask, request, jsonify, session, redirect, url_for, render_template_string
from flask_jwt_extended import JWTManager, jwt_required, create_access_token, get_jwt_identity, get_jwt
import pyotp
import qrcode
import io
import base64
import sqlite3
import os
import hashlib
import secrets
from datetime import datetime, timedelta
import json

app = Flask(__name__)
app.config['JWT_SECRET_KEY'] = 'invictus-dns-jwt-secret-key-2024'
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(hours=1)
jwt = JWTManager(app)

DESKTOP_DIR = os.path.expanduser('~/Desktop')
DB_FILE = os.path.join(DESKTOP_DIR, 'InvictusDNS_Data', 'dados', 'dns_logs.db')
USERS_DB_FILE = os.path.join(DESKTOP_DIR, 'InvictusDNS_Data', 'dados', 'users.db')

def init_auth_db():
    """Initialize authentication database"""
    conn = sqlite3.connect(USERS_DB_FILE)
    c = conn.cursor()

    # Users table
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE,
            password_hash TEXT NOT NULL,
            role TEXT DEFAULT 'user',
            two_factor_secret TEXT,
            two_factor_enabled BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_login TIMESTAMP,
            login_attempts INTEGER DEFAULT 0,
            locked_until TIMESTAMP,
            active BOOLEAN DEFAULT TRUE
        )
    ''')

    # Sessions table for tracking
    c.execute('''
        CREATE TABLE IF NOT EXISTS user_sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            session_token TEXT,
            ip_address TEXT,
            user_agent TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            expires_at TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')

    # Password reset tokens
    c.execute('''
        CREATE TABLE IF NOT EXISTS password_resets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            token TEXT UNIQUE,
            expires_at TIMESTAMP,
            used BOOLEAN DEFAULT FALSE,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')

    # Create default admin user if not exists
    c.execute('SELECT * FROM users WHERE username = ?', ('admin',))
    if not c.fetchone():
        default_password = hashlib.sha256('admin123'.encode()).hexdigest()
        c.execute('''
            INSERT INTO users (username, email, password_hash, role, active)
            VALUES (?, ?, ?, ?, ?)
        ''', ('admin', 'admin@invictusdns.local', default_password, 'admin', True))

    conn.commit()
    conn.close()

def hash_password(password):
    """Hash password with salt"""
    salt = secrets.token_hex(16)
    hashed = hashlib.sha256((password + salt).encode()).hexdigest()
    return f"{salt}:{hashed}"

def verify_password(password, hashed_password):
    """Verify password against hash"""
    try:
        salt, hashed = hashed_password.split(':')
        return hashlib.sha256((password + salt).encode()).hexdigest() == hashed
    except:
        return False

def generate_2fa_secret():
    """Generate 2FA secret"""
    return pyotp.random_base32()

def get_2fa_uri(username, secret):
    """Get 2FA URI for QR code"""
    return pyotp.totp.TOTP(secret).provisioning_uri(name=username, issuer_name="InvictusDNS")

def generate_qr_code(uri):
    """Generate QR code for 2FA"""
    qr = qrcode.QRCode(version=1, box_size=10, border=5)
    qr.add_data(uri)
    qr.make(fit=True)

    img = qr.make_image(fill_color="black", back_color="white")
    buffer = io.BytesIO()
    img.save(buffer, format="PNG")
    buffer.seek(0)
    return base64.b64encode(buffer.getvalue()).decode()

@app.route('/auth/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        data = request.get_json() if request.is_json else request.form
        username = data.get('username')
        password = data.get('password')
        two_factor_code = data.get('two_factor_code')

        if not username or not password:
            return jsonify({'error': 'Username and password required'}), 400

        conn = sqlite3.connect(USERS_DB_FILE)
        c = conn.cursor()

        # Get user
        c.execute('SELECT * FROM users WHERE username = ? AND active = 1', (username,))
        user = c.fetchone()

        if not user:
            conn.close()
            return jsonify({'error': 'Invalid credentials'}), 401

        user_dict = {
            'id': user[0], 'username': user[1], 'email': user[2],
            'password_hash': user[3], 'role': user[4], 'two_factor_secret': user[5],
            'two_factor_enabled': user[6], 'created_at': user[7], 'last_login': user[8],
            'login_attempts': user[9], 'locked_until': user[10], 'active': user[11]
        }

        # Check if account is locked
        if user_dict['locked_until'] and datetime.now() < datetime.fromisoformat(user_dict['locked_until']):
            conn.close()
            return jsonify({'error': 'Account temporarily locked'}), 423

        # Verify password
        if not verify_password(password, user_dict['password_hash']):
            # Increment login attempts
            c.execute('UPDATE users SET login_attempts = login_attempts + 1 WHERE id = ?', (user_dict['id'],))
            if user_dict['login_attempts'] + 1 >= 5:
                lock_until = datetime.now() + timedelta(minutes=30)
                c.execute('UPDATE users SET locked_until = ? WHERE id = ?', (lock_until.isoformat(), user_dict['id']))
            conn.commit()
            conn.close()
            return jsonify({'error': 'Invalid credentials'}), 401

        # Check 2FA if enabled
        if user_dict['two_factor_enabled']:
            if not two_factor_code:
                conn.close()
                return jsonify({'error': '2FA code required', 'requires_2fa': True}), 401

            totp = pyotp.TOTP(user_dict['two_factor_secret'])
            if not totp.verify(two_factor_code):
                conn.close()
                return jsonify({'error': 'Invalid 2FA code'}), 401

        # Successful login
        c.execute('''
            UPDATE users
            SET last_login = ?, login_attempts = 0, locked_until = NULL
            WHERE id = ?
        ''', (datetime.now().isoformat(), user_dict['id']))

        # Create session
        session_token = secrets.token_urlsafe(32)
        expires_at = datetime.now() + timedelta(hours=24)
        c.execute('''
            INSERT INTO user_sessions (user_id, session_token, ip_address, user_agent, expires_at)
            VALUES (?, ?, ?, ?, ?)
        ''', (user_dict['id'], session_token, request.remote_addr, request.headers.get('User-Agent'), expires_at.isoformat()))

        conn.commit()
        conn.close()

        # Create JWT token
        access_token = create_access_token(identity=username, additional_claims={'role': user_dict['role']})

        return jsonify({
            'access_token': access_token,
            'user': {
                'username': user_dict['username'],
                'role': user_dict['role'],
                'email': user_dict['email']
            },
            'session_token': session_token
        }), 200

    # GET request - show login form
    html = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>InvictusDNS - Login</title>
        <style>
            body { font-family: Arial, sans-serif; background: #f4f7f9; margin: 0; padding: 50px; }
            .login-container { max-width: 400px; margin: 0 auto; background: white; padding: 40px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
            h2 { text-align: center; color: #2c3e50; margin-bottom: 30px; }
            .form-group { margin-bottom: 20px; }
            label { display: block; margin-bottom: 5px; color: #555; }
            input { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 5px; font-size: 16px; }
            button { width: 100%; padding: 12px; background: #3498db; color: white; border: none; border-radius: 5px; font-size: 16px; cursor: pointer; }
            button:hover { background: #2980b9; }
            .error { color: #e74c3c; text-align: center; margin-top: 10px; }
            .two-factor { display: none; }
        </style>
    </head>
    <body>
        <div class="login-container">
            <h2>🔐 InvictusDNS Login</h2>
            <form id="loginForm">
                <div class="form-group">
                    <label for="username">Username:</label>
                    <input type="text" id="username" name="username" required>
                </div>
                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <div class="form-group two-factor" id="twoFactorGroup">
                    <label for="two_factor_code">2FA Code:</label>
                    <input type="text" id="two_factor_code" name="two_factor_code">
                </div>
                <button type="submit">Login</button>
            </form>
            <div id="error" class="error"></div>
        </div>

        <script>
            document.getElementById('loginForm').addEventListener('submit', async function(e) {
                e.preventDefault();

                const formData = new FormData(this);
                const data = Object.fromEntries(formData);

                try {
                    const response = await fetch('/auth/login', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(data)
                    });

                    const result = await response.json();

                    if (response.ok) {
                        localStorage.setItem('access_token', result.access_token);
                        window.location.href = '/dashboard';
                    } else {
                        document.getElementById('error').textContent = result.error;
                        if (result.requires_2fa) {
                            document.getElementById('twoFactorGroup').style.display = 'block';
                        }
                    }
                } catch (error) {
                    document.getElementById('error').textContent = 'Login failed';
                }
            });
        </script>
    </body>
    </html>
    """
    return html

@app.route('/auth/setup-2fa')
@jwt_required()
def setup_2fa():
    """Setup 2FA for user"""
    current_user = get_jwt_identity()

    conn = sqlite3.connect(USERS_DB_FILE)
    c = conn.cursor()
    c.execute('SELECT two_factor_secret, two_factor_enabled FROM users WHERE username = ?', (current_user,))
    user = c.fetchone()
    conn.close()

    if not user:
        return jsonify({'error': 'User not found'}), 404

    if user[1]:  # Already enabled
        return jsonify({'error': '2FA already enabled'}), 400

    # Generate new secret
    secret = generate_2fa_secret()
    uri = get_2fa_uri(current_user, secret)
    qr_code = generate_qr_code(uri)

    # Store secret temporarily (will be confirmed later)
    session['temp_2fa_secret'] = secret

    html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Setup 2FA - InvictusDNS</title>
        <style>
            body {{ font-family: Arial, sans-serif; background: #f4f7f9; margin: 0; padding: 50px; }}
            .container {{ max-width: 500px; margin: 0 auto; background: white; padding: 40px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); text-align: center; }}
            h2 {{ color: #2c3e50; margin-bottom: 20px; }}
            .qr-code {{ margin: 20px 0; }}
            .code {{ background: #f8f9fa; padding: 10px; border-radius: 5px; font-family: monospace; margin: 10px 0; }}
            form {{ margin-top: 30px; }}
            input {{ padding: 10px; margin: 10px; width: 200px; border: 1px solid #ddd; border-radius: 5px; }}
            button {{ padding: 10px 20px; background: #27ae60; color: white; border: none; border-radius: 5px; cursor: pointer; }}
            button:hover {{ background: #219a52; }}
        </style>
    </head>
    <body>
        <div class="container">
            <h2>🔐 Setup Two-Factor Authentication</h2>
            <p>Scan the QR code with your authenticator app:</p>
            <div class="qr-code">
                <img src="data:image/png;base64,{qr_code}" alt="QR Code">
            </div>
            <p>Or enter this code manually:</p>
            <div class="code">{secret}</div>

            <form action="/auth/verify-2fa" method="post">
                <input type="text" name="code" placeholder="Enter 6-digit code" required>
                <br>
                <button type="submit">Verify & Enable 2FA</button>
            </form>
        </div>
    </body>
    </html>
    """
    return html

@app.route('/auth/verify-2fa', methods=['POST'])
@jwt_required()
def verify_2fa():
    """Verify and enable 2FA"""
    current_user = get_jwt_identity()
    code = request.form.get('code')

    if not code:
        return jsonify({'error': 'Code required'}), 400

    temp_secret = session.get('temp_2fa_secret')
    if not temp_secret:
        return jsonify({'error': 'No 2FA setup in progress'}), 400

    totp = pyotp.TOTP(temp_secret)
    if not totp.verify(code):
        return jsonify({'error': 'Invalid code'}), 400

    # Enable 2FA
    conn = sqlite3.connect(USERS_DB_FILE)
    c = conn.cursor()
    c.execute('UPDATE users SET two_factor_secret = ?, two_factor_enabled = 1 WHERE username = ?',
             (temp_secret, current_user))
    conn.commit()
    conn.close()

    # Clear temp secret
    session.pop('temp_2fa_secret', None)

    return jsonify({'message': '2FA enabled successfully'}), 200

@app.route('/auth/change-password', methods=['POST'])
@jwt_required()
def change_password():
    """Change user password"""
    current_user = get_jwt_identity()
    data = request.get_json()

    current_password = data.get('current_password')
    new_password = data.get('new_password')

    if not current_password or not new_password:
        return jsonify({'error': 'Current and new password required'}), 400

    if len(new_password) < 8:
        return jsonify({'error': 'New password must be at least 8 characters'}), 400

    conn = sqlite3.connect(USERS_DB_FILE)
    c = conn.cursor()

    # Verify current password
    c.execute('SELECT password_hash FROM users WHERE username = ?', (current_user,))
    user = c.fetchone()

    if not user or not verify_password(current_password, user[0]):
        conn.close()
        return jsonify({'error': 'Current password incorrect'}), 400

    # Update password
    new_hash = hash_password(new_password)
    c.execute('UPDATE users SET password_hash = ? WHERE username = ?', (new_hash, current_user))
    conn.commit()
    conn.close()

    return jsonify({'message': 'Password changed successfully'}), 200

@app.route('/auth/logout', methods=['POST'])
@jwt_required()
def logout():
    """Logout user"""
    # In a real implementation, you'd blacklist the token
    # For now, just return success
    return jsonify({'message': 'Logged out successfully'}), 200

# Initialize database on startup
init_auth_db()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3006, debug=False)

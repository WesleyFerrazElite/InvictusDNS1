# InvictusDNS Portable

## Descrição
Versão portátil do InvictusDNS que funciona em Windows e Linux. Executável único que inicia todos os serviços automaticamente.

## Funcionalidades
- Auto-detecção de IP local
- DNS Server (porta 53)
- Web Panel (porta 3000)
- Marketing Panel (porta 3001)
- AI Panel (porta 3002)
- Cloud Panel (porta 3003)
- Compatível com Windows e Linux

## Instalação
1. Baixe o executável `InvictusDNS.exe` (Windows) ou `InvictusDNS` (Linux)
2. Execute o arquivo
3. O programa detectará automaticamente o IP e iniciará todos os serviços

## Uso
- Execute o arquivo executável
- O programa abrirá uma janela mostrando os serviços ativos
- Acesse os painéis via navegador usando o IP detectado
- Pressione Ctrl+C na janela para parar todos os serviços

## Acesso
- Web Panel: http://[IP]:3000 (login: admin/admin)
- Marketing Panel: http://[IP]:3001
- AI Panel: http://[IP]:3002
- Cloud Panel: http://[IP]:3003

## Configuração DNS
Configure seu dispositivo para usar o IP do servidor como DNS primário.

## Requisitos
- Windows 10+ ou Linux
- Permissões de administrador (para porta 53)
- Python 3.8+ (para desenvolvimento)

## Desenvolvimento
Para modificar o código:
1. Instale dependências: `pip install -r requirements_portable.txt`
2. Execute launcher: `python launcher.py`
3. Para testar: `python launcher.py --test`
4. Para buildar executável: `python build_exe.py`

## Arquivos
- `launcher.py`: Launcher principal
- `build_exe.py`: Script de build
- `requirements_portable.txt`: Dependências
- `icon.ico`: Ícone do executável

from flask import Flask, render_template_string, jsonify
import json
import os
from datetime import datetime, timedelta
from .metrics_collector import metrics_collector

app = Flask(__name__)

DESKTOP_DIR = os.path.expanduser('~/Desktop')
METRICS_FILE = os.path.join(DESKTOP_DIR, 'InvictusDNS_Data', 'dados', 'metrics.json')

@app.route('/monitoring/dashboard')
def dashboard():
    """Real-time monitoring dashboard"""
    html = """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>InvictusDNS - Monitoring Dashboard</title>
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <style>
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                margin: 0;
                padding: 20px;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: #333;
            }
            .container {
                max-width: 1400px;
                margin: 0 auto;
                background: white;
                border-radius: 15px;
                box-shadow: 0 20px 40px rgba(0,0,0,0.1);
                overflow: hidden;
            }
            .header {
                background: linear-gradient(135deg, #2c3e50 0%, #3498db 100%);
                color: white;
                padding: 30px;
                text-align: center;
            }
            .header h1 {
                margin: 0;
                font-size: 2.5em;
                font-weight: 300;
            }
            .header p {
                margin: 10px 0 0 0;
                opacity: 0.9;
                font-size: 1.1em;
            }
            .dashboard-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
                gap: 20px;
                padding: 30px;
            }
            .metric-card {
                background: #f8f9fa;
                border-radius: 10px;
                padding: 20px;
                box-shadow: 0 4px 6px rgba(0,0,0,0.07);
                border-left: 4px solid #3498db;
            }
            .metric-card h3 {
                margin: 0 0 15px 0;
                color: #2c3e50;
                font-size: 1.2em;
                display: flex;
                align-items: center;
            }
            .metric-card h3::before {
                content: '';
                width: 8px;
                height: 8px;
                background: #3498db;
                border-radius: 50%;
                margin-right: 10px;
            }
            .metric-value {
                font-size: 2em;
                font-weight: bold;
                color: #3498db;
                margin: 10px 0;
            }
            .metric-subtitle {
                color: #7f8c8d;
                font-size: 0.9em;
                margin-bottom: 15px;
            }
            .chart-container {
                position: relative;
                height: 300px;
                margin: 20px 0;
            }
            .status-indicator {
                display: inline-block;
                width: 12px;
                height: 12px;
                border-radius: 50%;
                margin-right: 8px;
            }
            .status-healthy { background: #27ae60; }
            .status-warning { background: #f39c12; }
            .status-critical { background: #e74c3c; }
            .refresh-btn {
                position: fixed;
                bottom: 30px;
                right: 30px;
                background: #3498db;
                color: white;
                border: none;
                border-radius: 50px;
                width: 60px;
                height: 60px;
                font-size: 24px;
                cursor: pointer;
                box-shadow: 0 4px 12px rgba(0,0,0,0.3);
                transition: all 0.3s ease;
            }
            .refresh-btn:hover {
                transform: scale(1.1);
                box-shadow: 0 6px 20px rgba(0,0,0,0.4);
            }
            .last-updated {
                text-align: center;
                color: #7f8c8d;
                font-size: 0.9em;
                margin-top: 20px;
                padding-bottom: 20px;
            }
            @media (max-width: 768px) {
                .dashboard-grid {
                    grid-template-columns: 1fr;
                    padding: 15px;
                }
                .header {
                    padding: 20px;
                }
                .header h1 {
                    font-size: 2em;
                }
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>📊 InvictusDNS Monitoring</h1>
                <p>Real-time system metrics and performance dashboard</p>
            </div>

            <div class="dashboard-grid">
                <!-- System Metrics -->
                <div class="metric-card">
                    <h3>🖥️ System Performance</h3>
                    <div class="metric-value" id="cpu-percent">--</div>
                    <div class="metric-subtitle">CPU Usage</div>
                    <canvas id="cpuChart" class="chart-container"></canvas>
                </div>

                <div class="metric-card">
                    <h3>💾 Memory Usage</h3>
                    <div class="metric-value" id="memory-percent">--</div>
                    <div class="metric-subtitle">RAM Usage</div>
                    <canvas id="memoryChart" class="chart-container"></canvas>
                </div>

                <!-- DNS Metrics -->
                <div class="metric-card">
                    <h3>🌐 DNS Queries</h3>
                    <div class="metric-value" id="dns-queries">--</div>
                    <div class="metric-subtitle">Queries (last hour)</div>
                    <canvas id="dnsChart" class="chart-container"></canvas>
                </div>

                <div class="metric-card">
                    <h3>⚡ Response Time</h3>
                    <div class="metric-value" id="avg-response">--</div>
                    <div class="metric-subtitle">Average (ms)</div>
                    <canvas id="responseChart" class="chart-container"></canvas>
                </div>

                <!-- Traffic Metrics -->
                <div class="metric-card">
                    <h3>📡 Network Traffic</h3>
                    <div class="metric-value" id="traffic-packets">--</div>
                    <div class="metric-subtitle">Packets (last hour)</div>
                    <canvas id="trafficChart" class="chart-container"></canvas>
                </div>

                <div class="metric-card">
                    <h3>🎯 Top Domains</h3>
                    <div id="top-domains" style="margin-top: 20px;">
                        <div style="color: #7f8c8d; font-style: italic;">Loading...</div>
                    </div>
                </div>

                <!-- Status Indicators -->
                <div class="metric-card">
                    <h3>🔴 System Status</h3>
                    <div style="margin-top: 20px;">
                        <div style="display: flex; align-items: center; margin-bottom: 10px;">
                            <span class="status-indicator status-healthy"></span>
                            <span>DNS Server</span>
                        </div>
                        <div style="display: flex; align-items: center; margin-bottom: 10px;">
                            <span class="status-indicator status-healthy"></span>
                            <span>Web Panel</span>
                        </div>
                        <div style="display: flex; align-items: center; margin-bottom: 10px;">
                            <span class="status-indicator status-healthy"></span>
                            <span>Database</span>
                        </div>
                    </div>
                </div>

                <div class="metric-card">
                    <h3>🚨 Recent Alerts</h3>
                    <div id="recent-alerts" style="margin-top: 20px;">
                        <div style="color: #7f8c8d; font-style: italic;">No recent alerts</div>
                    </div>
                </div>
            </div>

            <div class="last-updated">
                Last updated: <span id="last-updated">--</span>
            </div>
        </div>

        <button class="refresh-btn" onclick="refreshData()">🔄</button>

        <script>
            let cpuChart, memoryChart, dnsChart, responseChart, trafficChart;
            let metricsData = {};

            // Initialize charts
            function initCharts() {
                const chartOptions = {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false }
                    },
                    scales: {
                        y: { beginAtZero: true },
                        x: { display: false }
                    },
                    elements: {
                        point: { radius: 0 },
                        line: { borderWidth: 2 }
                    }
                };

                cpuChart = new Chart(document.getElementById('cpuChart'), {
                    type: 'line',
                    data: { labels: [], datasets: [{ data: [], borderColor: '#3498db', fill: true, backgroundColor: 'rgba(52, 152, 219, 0.1)' }] },
                    options: chartOptions
                });

                memoryChart = new Chart(document.getElementById('memoryChart'), {
                    type: 'line',
                    data: { labels: [], datasets: [{ data: [], borderColor: '#e74c3c', fill: true, backgroundColor: 'rgba(231, 76, 60, 0.1)' }] },
                    options: chartOptions
                });

                dnsChart = new Chart(document.getElementById('dnsChart'), {
                    type: 'line',
                    data: { labels: [], datasets: [{ data: [], borderColor: '#27ae60', fill: true, backgroundColor: 'rgba(39, 174, 96, 0.1)' }] },
                    options: chartOptions
                });

                responseChart = new Chart(document.getElementById('responseChart'), {
                    type: 'line',
                    data: { labels: [], datasets: [{ data: [], borderColor: '#f39c12', fill: true, backgroundColor: 'rgba(243, 156, 18, 0.1)' }] },
                    options: chartOptions
                });

                trafficChart = new Chart(document.getElementById('trafficChart'), {
                    type: 'line',
                    data: { labels: [], datasets: [{ data: [], borderColor: '#9b59b6', fill: true, backgroundColor: 'rgba(155, 89, 182, 0.1)' }] },
                    options: chartOptions
                });
            }

            // Update metrics display
            function updateMetrics(data) {
                if (!data.system || !data.dns || !data.traffic) return;

                // System metrics
                document.getElementById('cpu-percent').textContent = data.system.cpu_percent ? data.system.cpu_percent.toFixed(1) + '%' : '--';
                document.getElementById('memory-percent').textContent = data.system.memory_percent ? data.system.memory_percent.toFixed(1) + '%' : '--';

                // DNS metrics
                document.getElementById('dns-queries').textContent = data.dns.total_queries || '--';
                document.getElementById('avg-response').textContent = data.dns.avg_response_time ? data.dns.avg_response_time.toFixed(0) + 'ms' : '--';

                // Traffic metrics
                document.getElementById('traffic-packets').textContent = data.traffic.total_packets || '--';

                // Update timestamp
                document.getElementById('last-updated').textContent = new Date().toLocaleString();

                // Update charts
                updateCharts(data);
                updateTopDomains(data.dns.top_domains || []);
            }

            // Update charts with historical data
            function updateCharts(data) {
                // This would be enhanced to show historical data
                // For now, just update with current values
                if (cpuChart && data.system.cpu_percent !== undefined) {
                    cpuChart.data.datasets[0].data.push(data.system.cpu_percent);
                    cpuChart.data.labels.push(new Date().toLocaleTimeString());
                    if (cpuChart.data.datasets[0].data.length > 20) {
                        cpuChart.data.datasets[0].data.shift();
                        cpuChart.data.labels.shift();
                    }
                    cpuChart.update();
                }

                if (memoryChart && data.system.memory_percent !== undefined) {
                    memoryChart.data.datasets[0].data.push(data.system.memory_percent);
                    memoryChart.data.labels.push(new Date().toLocaleTimeString());
                    if (memoryChart.data.datasets[0].data.length > 20) {
                        memoryChart.data.datasets[0].data.shift();
                        memoryChart.data.labels.shift();
                    }
                    memoryChart.update();
                }

                if (dnsChart && data.dns.total_queries !== undefined) {
                    dnsChart.data.datasets[0].data.push(data.dns.total_queries);
                    dnsChart.data.labels.push(new Date().toLocaleTimeString());
                    if (dnsChart.data.datasets[0].data.length > 20) {
                        dnsChart.data.datasets[0].data.shift();
                        dnsChart.data.labels.shift();
                    }
                    dnsChart.update();
                }

                if (responseChart && data.dns.avg_response_time !== undefined) {
                    responseChart.data.datasets[0].data.push(data.dns.avg_response_time);
                    responseChart.data.labels.push(new Date().toLocaleTimeString());
                    if (responseChart.data.datasets[0].data.length > 20) {
                        responseChart.data.datasets[0].data.shift();
                        responseChart.data.labels.shift();
                    }
                    responseChart.update();
                }

                if (trafficChart && data.traffic.total_packets !== undefined) {
                    trafficChart.data.datasets[0].data.push(data.traffic.total_packets);
                    trafficChart.data.labels.push(new Date().toLocaleTimeString());
                    if (trafficChart.data.datasets[0].data.length > 20) {
                        trafficChart.data.datasets[0].data.shift();
                        trafficChart.data.labels.shift();
                    }
                    trafficChart.update();
                }
            }

            // Update top domains display
            function updateTopDomains(domains) {
                const container = document.getElementById('top-domains');
                if (!domains || domains.length === 0) {
                    container.innerHTML = '<div style="color: #7f8c8d; font-style: italic;">No data available</div>';
                    return;
                }

                let html = '';
                domains.slice(0, 5).forEach((domain, index) => {
                    html += `
                        <div style="display: flex; justify-content: space-between; margin-bottom: 8px; padding: 8px; background: rgba(52, 152, 219, 0.1); border-radius: 5px;">
                            <span style="font-weight: 500;">${index + 1}. ${domain.domain}</span>
                            <span style="color: #3498db; font-weight: bold;">${domain.count}</span>
                        </div>
                    `;
                });
                container.innerHTML = html;
            }

            // Fetch metrics data
            async function fetchMetrics() {
                try {
                    const response = await fetch('/api/statistics');
                    const data = await response.json();
                    updateMetrics(data);
                } catch (error) {
                    console.error('Error fetching metrics:', error);
                }
            }

            // Refresh data
            function refreshData() {
                fetchMetrics();
            }

            // Initialize
            document.addEventListener('DOMContentLoaded', function() {
                initCharts();
                fetchMetrics();
                // Auto-refresh every 30 seconds
                setInterval(fetchMetrics, 30000);
            });
        </script>
    </body>
    </html>
    """
    return html

@app.route('/api/metrics/current')
def get_current_metrics():
    """API endpoint for current metrics"""
    return jsonify(metrics_collector.get_current_metrics())

@app.route('/api/metrics/history/<metric_type>')
def get_metrics_history(metric_type):
    """API endpoint for metrics history"""
    hours = request.args.get('hours', 24, type=int)
    return jsonify(metrics_collector.get_metrics_history(metric_type, hours))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3005, debug=False)

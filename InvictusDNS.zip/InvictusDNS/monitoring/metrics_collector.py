import psutil
import sqlite3
import os
import json
import time
from datetime import datetime, timedelta
from collections import defaultdict, deque
import threading

DESKTOP_DIR = os.path.expanduser('~/Desktop')
DB_FILE = os.path.join(DESKTOP_DIR, 'InvictusDNS_Data', 'dados', 'dns_logs.db')
METRICS_FILE = os.path.join(DESKTOP_DIR, 'InvictusDNS_Data', 'dados', 'metrics.json')

class MetricsCollector:
    def __init__(self):
        self.running = False
        self.metrics_history = defaultdict(lambda: deque(maxlen=1000))  # Keep last 1000 data points
        self.current_metrics = {}
        self.lock = threading.Lock()

    def collect_system_metrics(self):
        """Collect system-level metrics"""
        try:
            return {
                'cpu_percent': psutil.cpu_percent(interval=1),
                'memory_percent': psutil.virtual_memory().percent,
                'memory_used': psutil.virtual_memory().used,
                'memory_total': psutil.virtual_memory().total,
                'disk_usage': psutil.disk_usage('/').percent,
                'network_connections': len(psutil.net_connections()),
                'load_average': psutil.getloadavg() if hasattr(psutil, 'getloadavg') else [0, 0, 0],
                'timestamp': datetime.now().isoformat()
            }
        except Exception as e:
            print(f"Error collecting system metrics: {e}")
            return {}

    def collect_dns_metrics(self):
        """Collect DNS-specific metrics"""
        try:
            conn = sqlite3.connect(DB_FILE)
            cursor = conn.cursor()

            # Last hour metrics
            hour_ago = datetime.now() - timedelta(hours=1)

            # Total queries
            cursor.execute('''
                SELECT COUNT(*) as total_queries,
                       AVG(response_time) as avg_response_time,
                       MAX(response_time) as max_response_time,
                       MIN(response_time) as min_response_time
                FROM dns_logs
                WHERE timestamp >= ?
            ''', (hour_ago.isoformat(),))

            dns_stats = cursor.fetchone()

            # Queries by category
            cursor.execute('''
                SELECT category, COUNT(*) as count
                FROM dns_logs
                WHERE timestamp >= ?
                GROUP BY category
            ''', (hour_ago.isoformat(),))

            categories = {row[0]: row[1] for row in cursor.fetchall()}

            # Top domains
            cursor.execute('''
                SELECT domain, COUNT(*) as count
                FROM dns_logs
                WHERE timestamp >= ?
                GROUP BY domain
                ORDER BY count DESC
                LIMIT 10
            ''', (hour_ago.isoformat(),))

            top_domains = [{'domain': row[0], 'count': row[1]} for row in cursor.fetchall()]

            # Top clients
            cursor.execute('''
                SELECT client_ip, COUNT(*) as count
                FROM dns_logs
                WHERE timestamp >= ?
                GROUP BY client_ip
                ORDER BY count DESC
                LIMIT 10
            ''', (hour_ago.isoformat(),))

            top_clients = [{'ip': row[0], 'count': row[1]} for row in cursor.fetchall()]

            conn.close()

            return {
                'total_queries': dns_stats[0] or 0,
                'avg_response_time': dns_stats[1] or 0,
                'max_response_time': dns_stats[2] or 0,
                'min_response_time': dns_stats[3] or 0,
                'categories': categories,
                'top_domains': top_domains,
                'top_clients': top_clients,
                'timestamp': datetime.now().isoformat()
            }

        except Exception as e:
            print(f"Error collecting DNS metrics: {e}")
            return {}

    def collect_traffic_metrics(self):
        """Collect network traffic metrics"""
        try:
            conn = sqlite3.connect(DB_FILE)
            cursor = conn.cursor()

            # Last hour traffic
            hour_ago = datetime.now() - timedelta(hours=1)

            cursor.execute('''
                SELECT
                    COUNT(*) as total_packets,
                    SUM(length) as total_bytes,
                    AVG(length) as avg_packet_size,
                    COUNT(DISTINCT src_ip) as unique_sources,
                    COUNT(DISTINCT dst_ip) as unique_destinations
                FROM traffic_logs
                WHERE timestamp >= ?
            ''', (hour_ago.isoformat(),))

            traffic_stats = cursor.fetchone()

            # Protocol distribution
            cursor.execute('''
                SELECT protocol, COUNT(*) as count, SUM(length) as bytes
                FROM traffic_logs
                WHERE timestamp >= ?
                GROUP BY protocol
            ''', (hour_ago.isoformat(),))

            protocols = [{'protocol': row[0], 'count': row[1], 'bytes': row[2]} for row in cursor.fetchall()]

            # Traffic by hour (last 24 hours)
            cursor.execute('''
                SELECT
                    strftime('%H', timestamp) as hour,
                    COUNT(*) as packets,
                    SUM(length) as bytes
                FROM traffic_logs
                WHERE timestamp >= datetime('now', '-24 hours')
                GROUP BY strftime('%H', timestamp)
                ORDER BY hour
            ''')

            hourly_traffic = [{'hour': row[0], 'packets': row[1], 'bytes': row[2]} for row in cursor.fetchall()]

            conn.close()

            return {
                'total_packets': traffic_stats[0] or 0,
                'total_bytes': traffic_stats[1] or 0,
                'avg_packet_size': traffic_stats[2] or 0,
                'unique_sources': traffic_stats[3] or 0,
                'unique_destinations': traffic_stats[4] or 0,
                'protocols': protocols,
                'hourly_traffic': hourly_traffic,
                'timestamp': datetime.now().isoformat()
            }

        except Exception as e:
            print(f"Error collecting traffic metrics: {e}")
            return {}

    def collect_all_metrics(self):
        """Collect all metrics"""
        with self.lock:
            metrics = {
                'system': self.collect_system_metrics(),
                'dns': self.collect_dns_metrics(),
                'traffic': self.collect_traffic_metrics(),
                'collection_time': datetime.now().isoformat()
            }

            self.current_metrics = metrics

            # Store in history
            for key, value in metrics.items():
                if isinstance(value, dict) and 'timestamp' in value:
                    self.metrics_history[key].append(value)

            return metrics

    def get_metrics_history(self, metric_type, hours=24):
        """Get historical metrics"""
        with self.lock:
            if metric_type not in self.metrics_history:
                return []

            # Filter by time
            cutoff_time = datetime.now() - timedelta(hours=hours)
            history = list(self.metrics_history[metric_type])

            return [m for m in history
                   if datetime.fromisoformat(m['timestamp']) > cutoff_time]

    def get_current_metrics(self):
        """Get current metrics"""
        with self.lock:
            return self.current_metrics.copy()

    def save_metrics_to_file(self):
        """Save current metrics to file"""
        try:
            os.makedirs(os.path.dirname(METRICS_FILE), exist_ok=True)
            with open(METRICS_FILE, 'w') as f:
                json.dump(self.current_metrics, f, indent=2)
        except Exception as e:
            print(f"Error saving metrics to file: {e}")

    def start_collection(self, interval=60):
        """Start background metrics collection"""
        self.running = True

        def collection_loop():
            while self.running:
                self.collect_all_metrics()
                self.save_metrics_to_file()
                time.sleep(interval)

        thread = threading.Thread(target=collection_loop, daemon=True)
        thread.start()
        print(f"Metrics collection started (interval: {interval}s)")

    def stop_collection(self):
        """Stop metrics collection"""
        self.running = False
        print("Metrics collection stopped")

# Global instance
metrics_collector = MetricsCollector()

if __name__ == '__main__':
    # Test metrics collection
    metrics = metrics_collector.collect_all_metrics()
    print(json.dumps(metrics, indent=2))

import sqlite3
import pandas as pd
import numpy as np
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler, LabelEncoder
import joblib
import os
import time
from datetime import datetime, timedelta
import logging

class MLAnomalyDetector:
    def __init__(self, db_path='data/dns_logs.db', model_path='models/anomaly_detector.pkl'):
        self.db_path = db_path
        self.model_path = model_path
        self.model = None
        self.scaler = None
        self.label_encoders = {}
        self.is_trained = False

        # Criar diretório para modelos se não existir
        os.makedirs(os.path.dirname(model_path), exist_ok=True)

        # Carregar modelo se existir
        self.load_model()

    def load_model(self):
        """Carrega modelo treinado se existir"""
        try:
            if os.path.exists(self.model_path):
                self.model = joblib.load(self.model_path)
                self.scaler = joblib.load(self.model_path.replace('.pkl', '_scaler.pkl'))
                self.label_encoders = joblib.load(self.model_path.replace('.pkl', '_encoders.pkl'))
                self.is_trained = True
                logging.info("Modelo de detecção de anomalias carregado com sucesso")
            else:
                logging.info("Nenhum modelo treinado encontrado")
        except Exception as e:
            logging.error(f"Erro ao carregar modelo: {e}")

    def save_model(self):
        """Salva modelo treinado"""
        try:
            joblib.dump(self.model, self.model_path)
            joblib.dump(self.scaler, self.model_path.replace('.pkl', '_scaler.pkl'))
            joblib.dump(self.label_encoders, self.model_path.replace('.pkl', '_encoders.pkl'))
            logging.info("Modelo salvo com sucesso")
        except Exception as e:
            logging.error(f"Erro ao salvar modelo: {e}")

    def get_training_data(self, days=30):
        """Obtém dados de treinamento do banco de dados"""
        try:
            conn = sqlite3.connect(self.db_path)
            query = f"""
                SELECT client_ip, domain, response_ip, category, response_time, timestamp
                FROM dns_logs
                WHERE timestamp >= datetime('now', '-{days} days')
                ORDER BY timestamp DESC
                LIMIT 10000
            """
            df = pd.read_sql_query(query, conn)
            conn.close()

            if len(df) < 100:
                logging.warning("Poucos dados para treinamento")
                return None

            return df
        except Exception as e:
            logging.error(f"Erro ao obter dados de treinamento: {e}")
            return None

    def preprocess_data(self, df):
        """Pré-processa dados para treinamento"""
        try:
            # Codificar IPs (simplificado - usar apenas octetos)
            df['client_ip_octet'] = df['client_ip'].apply(lambda x: int(x.split('.')[-1]) if '.' in x else 0)

            # Codificar domínios (comprimento do domínio)
            df['domain_length'] = df['domain'].str.len()

            # Codificar categoria
            if 'category' not in self.label_encoders:
                self.label_encoders['category'] = LabelEncoder()
                self.label_encoders['category'].fit(df['category'].fillna('unknown'))

            df['category_encoded'] = self.label_encoders['category'].transform(df['category'].fillna('unknown'))

            # Tempo de resposta (preencher NaN com média)
            df['response_time'] = df['response_time'].fillna(df['response_time'].mean())

            # Selecionar features
            features = ['client_ip_octet', 'domain_length', 'category_encoded', 'response_time']
            X = df[features].values

            # Normalizar
            if self.scaler is None:
                self.scaler = StandardScaler()
                X_scaled = self.scaler.fit_transform(X)
            else:
                X_scaled = self.scaler.transform(X)

            return X_scaled
        except Exception as e:
            logging.error(f"Erro no pré-processamento: {e}")
            return None

    def train_model(self, contamination=0.1):
        """Treina modelo de detecção de anomalias"""
        try:
            df = self.get_training_data()
            if df is None or len(df) < 100:
                return False, "Dados insuficientes para treinamento"

            X = self.preprocess_data(df)
            if X is None:
                return False, "Erro no pré-processamento"

            # Treinar Isolation Forest
            self.model = IsolationForest(
                contamination=contamination,
                random_state=42,
                n_estimators=100
            )

            self.model.fit(X)
            self.is_trained = True
            self.save_model()

            # Calcular estatísticas
            predictions = self.model.predict(X)
            anomaly_count = np.sum(predictions == -1)
            anomaly_rate = anomaly_count / len(predictions)

            return True, f"Modelo treinado com sucesso. Taxa de anomalias: {anomaly_rate:.2%}"

        except Exception as e:
            logging.error(f"Erro no treinamento: {e}")
            return False, f"Erro no treinamento: {str(e)}"

    def detect_anomaly(self, client_ip, domain, response_ip, category, response_time):
        """Detecta anomalia em uma consulta DNS"""
        if not self.is_trained:
            return False, "Modelo não treinado"

        try:
            # Pré-processar dados da consulta
            client_ip_octet = int(client_ip.split('.')[-1]) if '.' in client_ip else 0
            domain_length = len(domain)
            category_encoded = self.label_encoders['category'].transform([category])[0] if category in self.label_encoders['category'].classes_ else 0
            response_time = response_time if response_time is not None else 0.1

            # Criar array de features
            features = np.array([[client_ip_octet, domain_length, category_encoded, response_time]])

            # Normalizar
            features_scaled = self.scaler.transform(features)

            # Prever
            prediction = self.model.predict(features_scaled)

            # -1 = anomalia, 1 = normal
            is_anomaly = prediction[0] == -1

            # Calcular score de anomalia
            scores = self.model.decision_function(features_scaled)
            anomaly_score = scores[0]

            return is_anomaly, anomaly_score

        except Exception as e:
            logging.error(f"Erro na detecção: {e}")
            return False, 0.0

    def get_anomaly_stats(self):
        """Retorna estatísticas de anomalias detectadas"""
        try:
            if not self.is_trained:
                return {"status": "not_trained"}

            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            # Contar anomalias nas últimas 24 horas
            cursor.execute("""
                SELECT COUNT(*) as total_queries,
                       SUM(CASE WHEN anomaly_score < -0.5 THEN 1 ELSE 0 END) as anomalies
                FROM dns_logs
                WHERE timestamp >= datetime('now', '-1 day')
            """)

            result = cursor.fetchone()
            total_queries = result[0] or 0
            anomalies = result[1] or 0

            conn.close()

            return {
                "status": "trained",
                "total_queries_24h": total_queries,
                "anomalies_24h": anomalies,
                "anomaly_rate": anomalies / total_queries if total_queries > 0 else 0
            }

        except Exception as e:
            logging.error(f"Erro ao obter estatísticas: {e}")
            return {"status": "error", "message": str(e)}

# Instância global
anomaly_detector = MLAnomalyDetector()

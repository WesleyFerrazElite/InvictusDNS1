#!/usr/bin/env python3
"""
Create custom icon for InvictusDNS executable
"""

from PIL import Image, ImageDraw, ImageFont
import os

def create_icon():
    """Create a simple DNS-themed icon"""
    size = (256, 256)
    img = Image.new('RGBA', size, (70, 130, 180, 255))  # Steel blue background
    draw = ImageDraw.Draw(img)

    # Draw DNS symbol (stylized globe with arrows)
    center = (128, 128)
    radius = 100

    # Outer circle
    draw.ellipse((center[0]-radius, center[1]-radius, center[0]+radius, center[1]+radius),
                 fill=(255, 255, 255, 200), outline=(0, 0, 0, 255), width=3)

    # Inner circles for globe effect
    draw.ellipse((center[0]-70, center[1]-70, center[0]+70, center[1]+70),
                 fill=(135, 206, 235, 150))
    draw.ellipse((center[0]-40, center[1]-40, center[0]+40, center[1]+40),
                 fill=(70, 130, 180, 200))

    # DNS arrows (simplified)
    arrow_points = [(128, 28), (138, 48), (118, 48)]  # Up arrow
    draw.polygon(arrow_points, fill=(255, 255, 0, 255))

    arrow_points = [(128, 228), (138, 208), (118, 208)]  # Down arrow
    draw.polygon(arrow_points, fill=(255, 255, 0, 255))

    arrow_points = [(28, 128), (48, 118), (48, 138)]  # Left arrow
    draw.polygon(arrow_points, fill=(255, 255, 0, 255))

    arrow_points = [(228, 128), (208, 118), (208, 138)]  # Right arrow
    draw.polygon(arrow_points, fill=(255, 255, 0, 255))

    # Text "DNS"
    try:
        font = ImageFont.truetype("arial.ttf", 36)
    except:
        font = ImageFont.load_default()

    bbox = draw.textbbox((0, 0), "DNS", font=font)
    text_width = bbox[2] - bbox[0]
    text_height = bbox[3] - bbox[1]
    text_x = center[0] - text_width // 2
    text_y = center[1] - text_height // 2

    draw.text((text_x, text_y), "DNS", fill=(255, 255, 255, 255), font=font)

    # Save as ICO
    img.save('icon.ico', format='ICO', sizes=[(256, 256), (128, 128), (64, 64), (32, 32), (16, 16)])
    print("Icon created: icon.ico")

if __name__ == '__main__':
    create_icon()

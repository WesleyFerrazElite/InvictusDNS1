import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import sqlite3
import os
import json
import requests
from datetime import datetime, timedelta
import threading
import time

DESKTOP_DIR = os.path.expanduser('~/Desktop')
DB_FILE = os.path.join(DESKTOP_DIR, 'InvictusDNS_Data', 'dados', 'dns_logs.db')
CONFIG_FILE = os.path.join(DESKTOP_DIR, 'InvictusDNS_Data', 'dados', 'notifications_config.json')

class NotificationManager:
    def __init__(self):
        self.config = self.load_config()
        self.alert_history = []
        self.running = False

    def load_config(self):
        """Load notification configuration"""
        default_config = {
            'email': {
                'enabled': False,
                'smtp_server': 'smtp.gmail.com',
                'smtp_port': 587,
                'username': '',
                'password': '',
                'recipients': []
            },
            'webhook': {
                'enabled': False,
                'url': '',
                'headers': {}
            },
            'alerts': {
                'threat_detection': True,
                'high_traffic': True,
                'server_down': True,
                'unusual_activity': True
            },
            'thresholds': {
                'queries_per_minute': 100,
                'blocked_domains_threshold': 10,
                'traffic_spike_threshold': 1000
            }
        }

        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r') as f:
                loaded_config = json.load(f)
                # Merge with defaults
                for key, value in default_config.items():
                    if key not in loaded_config:
                        loaded_config[key] = value
                return loaded_config
        else:
            self.save_config(default_config)
            return default_config

    def save_config(self, config):
        """Save notification configuration"""
        os.makedirs(os.path.dirname(CONFIG_FILE), exist_ok=True)
        with open(CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=4)

    def send_email_alert(self, subject, message):
        """Send email alert"""
        if not self.config['email']['enabled']:
            return

        try:
            msg = MIMEMultipart()
            msg['From'] = self.config['email']['username']
            msg['To'] = ', '.join(self.config['email']['recipients'])
            msg['Subject'] = f"InvictusDNS Alert: {subject}"

            msg.attach(MIMEText(message, 'plain'))

            server = smtplib.SMTP(self.config['email']['smtp_server'],
                                self.config['email']['smtp_port'])
            server.starttls()
            server.login(self.config['email']['username'],
                        self.config['email']['password'])
            text = msg.as_string()
            server.sendmail(self.config['email']['username'],
                          self.config['email']['recipients'], text)
            server.quit()

            print(f"Email alert sent: {subject}")

        except Exception as e:
            print(f"Failed to send email alert: {e}")

    def send_webhook_alert(self, alert_data):
        """Send webhook alert"""
        if not self.config['webhook']['enabled']:
            return

        try:
            headers = self.config['webhook'].get('headers', {})
            headers['Content-Type'] = 'application/json'

            response = requests.post(
                self.config['webhook']['url'],
                json=alert_data,
                headers=headers,
                timeout=10
            )

            if response.status_code == 200:
                print("Webhook alert sent successfully")
            else:
                print(f"Webhook alert failed: {response.status_code}")

        except Exception as e:
            print(f"Failed to send webhook alert: {e}")

    def check_threat_detection(self):
        """Check for threat patterns"""
        if not self.config['alerts']['threat_detection']:
            return

        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()

        # Check for high number of blocked queries in last hour
        cursor.execute('''
            SELECT COUNT(*) as blocked_count
            FROM dns_logs
            WHERE category = 'threat'
            AND timestamp >= datetime('now', '-1 hour')
        ''')

        result = cursor.fetchone()
        blocked_count = result[0] if result else 0

        if blocked_count >= self.config['thresholds']['blocked_domains_threshold']:
            alert_data = {
                'type': 'threat_detection',
                'message': f'High threat activity detected: {blocked_count} blocked queries in last hour',
                'timestamp': datetime.now().isoformat(),
                'severity': 'high',
                'data': {
                    'blocked_count': blocked_count,
                    'time_window': '1 hour'
                }
            }

            self.send_alert('High Threat Activity Detected', alert_data['message'], alert_data)

        conn.close()

    def check_high_traffic(self):
        """Check for high traffic patterns"""
        if not self.config['alerts']['high_traffic']:
            return

        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()

        # Check DNS queries per minute
        cursor.execute('''
            SELECT COUNT(*) as query_count
            FROM dns_logs
            WHERE timestamp >= datetime('now', '-1 minute')
        ''')

        result = cursor.fetchone()
        query_count = result[0] if result else 0

        if query_count >= self.config['thresholds']['queries_per_minute']:
            alert_data = {
                'type': 'high_traffic',
                'message': f'High DNS traffic detected: {query_count} queries per minute',
                'timestamp': datetime.now().isoformat(),
                'severity': 'medium',
                'data': {
                    'query_count': query_count,
                    'time_window': '1 minute'
                }
            }

            self.send_alert('High DNS Traffic', alert_data['message'], alert_data)

        # Check traffic volume
        cursor.execute('''
            SELECT SUM(length) as total_bytes
            FROM traffic_logs
            WHERE timestamp >= datetime('now', '-1 minute')
        ''')

        result = cursor.fetchone()
        total_bytes = result[0] if result else 0

        if total_bytes and total_bytes >= self.config['thresholds']['traffic_spike_threshold']:
            alert_data = {
                'type': 'traffic_spike',
                'message': f'Traffic spike detected: {total_bytes} bytes in last minute',
                'timestamp': datetime.now().isoformat(),
                'severity': 'medium',
                'data': {
                    'total_bytes': total_bytes,
                    'time_window': '1 minute'
                }
            }

            self.send_alert('Traffic Spike Detected', alert_data['message'], alert_data)

        conn.close()

    def check_unusual_activity(self):
        """Check for unusual activity patterns"""
        if not self.config['alerts']['unusual_activity']:
            return

        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()

        # Check for new blocked IPs
        cursor.execute('''
            SELECT COUNT(*) as new_blocks
            FROM blocked_ips
            WHERE timestamp >= datetime('now', '-1 hour')
        ''')

        result = cursor.fetchone()
        new_blocks = result[0] if result else 0

        if new_blocks > 0:
            alert_data = {
                'type': 'unusual_activity',
                'message': f'Unusual activity: {new_blocks} new IPs blocked in last hour',
                'timestamp': datetime.now().isoformat(),
                'severity': 'low',
                'data': {
                    'new_blocks': new_blocks,
                    'time_window': '1 hour'
                }
            }

            self.send_alert('Unusual Activity Detected', alert_data['message'], alert_data)

        conn.close()

    def send_alert(self, subject, message, alert_data=None):
        """Send alert through all enabled channels"""
        # Avoid duplicate alerts (simple rate limiting)
        current_time = datetime.now()
        recent_alerts = [a for a in self.alert_history
                        if (current_time - a['time']).seconds < 300  # 5 minutes
                        and a['subject'] == subject]

        if recent_alerts:
            return  # Skip duplicate alert

        # Record alert
        self.alert_history.append({
            'subject': subject,
            'message': message,
            'time': current_time
        })

        # Keep only last 100 alerts
        if len(self.alert_history) > 100:
            self.alert_history = self.alert_history[-100:]

        # Send through enabled channels
        self.send_email_alert(subject, message)
        if alert_data:
            self.send_webhook_alert(alert_data)

        print(f"Alert sent: {subject}")

    def start_monitoring(self):
        """Start background monitoring"""
        self.running = True
        def monitor_loop():
            while self.running:
                try:
                    self.check_threat_detection()
                    self.check_high_traffic()
                    self.check_unusual_activity()
                except Exception as e:
                    print(f"Error in monitoring loop: {e}")

                time.sleep(60)  # Check every minute

        thread = threading.Thread(target=monitor_loop, daemon=True)
        thread.start()
        print("Notification monitoring started")

    def stop_monitoring(self):
        """Stop background monitoring"""
        self.running = False
        print("Notification monitoring stopped")

# Global instance
notification_manager = NotificationManager()

if __name__ == '__main__':
    # Test notifications
    notification_manager.send_alert(
        'Test Alert',
        'This is a test notification from InvictusDNS'
    )

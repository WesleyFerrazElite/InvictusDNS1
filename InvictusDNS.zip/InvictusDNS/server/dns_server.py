import socket
import sqlite3
import time
import threading
import os
import logging
from dnslib import DNSRecord, QTYPE, A, RR
from scapy.all import sniff, IP, TCP, UDP
from monitoring.ml_anomaly_detector import anomaly_detector
from utils.ip_obfuscator import obfuscate_ip
from security.advanced_security import analyze_threats, is_quarantined

# Configure logging
log_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'logs')
os.makedirs(log_dir, exist_ok=True)
log_file = os.path.join(log_dir, 'dns_server.log')
logging.basicConfig(filename=log_file, level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Configurações
IP_PUBLICOS = ["187.94.39.155", "187.94.39.160", "187.94.43.50", "143.0.200.126"]
DNS_PORT = 53
FORWARD_DNS = ['8.8.8.8', '1.1.1.1', '187.94.39.10', '187.94.39.15']  # Faster first
FORWARD_PORT = 53
DB_FILE = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data', 'dns_logs.db')
CACHE_TTL = 300  # 5 minutes
CACHE_MAX_SIZE = 1000  # Máximo de entradas no cache
dns_cache = {}  # domain: (ip, timestamp)

# Inicializar banco de dados
def init_db():
    conn = sqlite3.connect(DB_FILE)
    conn.execute("PRAGMA journal_mode=WAL")  # Allow concurrent reads/writes
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS dns_logs (
                    id INTEGER PRIMARY KEY,
                    timestamp TEXT,
                    client_ip TEXT,
                    domain TEXT,
                    response_ip TEXT,
                    category TEXT,
                    response_time REAL,
                    anomaly_score REAL
                )''')
    c.execute('''CREATE TABLE IF NOT EXISTS blocked_domains (
                    id INTEGER PRIMARY KEY,
                    domain TEXT,
                    user_id INTEGER
                )''')
    c.execute('''CREATE TABLE IF NOT EXISTS blocked_ips (
                    id INTEGER PRIMARY KEY,
                    ip TEXT,
                    user_id INTEGER
                )''')
    c.execute('''CREATE TABLE IF NOT EXISTS data_usage (
                    id INTEGER PRIMARY KEY,
                    ip TEXT,
                    timestamp TEXT,
                    data_mb REAL
                )''')
    c.execute('''CREATE TABLE IF NOT EXISTS traffic_logs (
                    id INTEGER PRIMARY KEY,
                    timestamp TEXT,
                    src_ip TEXT,
                    dst_ip TEXT,
                    src_port INTEGER,
                    dst_port INTEGER,
                    protocol TEXT,
                    length INTEGER,
                    info TEXT
                )''')
    # Indexes for faster queries
    c.execute('CREATE INDEX IF NOT EXISTS idx_dns_logs_timestamp ON dns_logs (timestamp)')
    c.execute('CREATE INDEX IF NOT EXISTS idx_dns_logs_client_ip ON dns_logs (client_ip)')
    c.execute('CREATE INDEX IF NOT EXISTS idx_dns_logs_domain ON dns_logs (domain)')
    c.execute('CREATE INDEX IF NOT EXISTS idx_blocked_domains_domain ON blocked_domains (domain)')
    c.execute('CREATE INDEX IF NOT EXISTS idx_blocked_ips_ip ON blocked_ips (ip)')
    c.execute('CREATE INDEX IF NOT EXISTS idx_data_usage_ip ON data_usage (ip)')
    c.execute('CREATE INDEX IF NOT EXISTS idx_traffic_logs_timestamp ON traffic_logs (timestamp)')
    conn.commit()
    conn.close()

# Log da consulta
def log_query(client_ip, domain, response_ip, category, response_time, anomaly_score=None):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    timestamp = time.strftime('%Y-%m-%d %H:%M:%S')
    # Ofuscar IP para privacidade nos logs
    obfuscated_ip = obfuscate_ip(client_ip)
    c.execute("INSERT INTO dns_logs (timestamp, client_ip, domain, response_ip, category, response_time, anomaly_score) VALUES (?, ?, ?, ?, ?, ?, ?)",
              (timestamp, obfuscated_ip, domain, response_ip, category, response_time, anomaly_score))
    conn.commit()
    conn.close()

# Log do uso de dados (estimado em MB)
def log_data_usage(client_ip, data_mb):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    timestamp = time.strftime('%Y-%m-%d %H:%M:%S')
    # Ofuscar IP para privacidade nos logs
    obfuscated_ip = obfuscate_ip(client_ip)
    c.execute("INSERT INTO data_usage (ip, timestamp, data_mb) VALUES (?, ?, ?)",
              (obfuscated_ip, timestamp, data_mb))
    conn.commit()
    conn.close()

# Log do tráfego (otimizado - só loga tráfego relevante)
def log_traffic(pkt):
    if IP in pkt:
        src_ip = pkt[IP].src
        dst_ip = pkt[IP].dst
        length = len(pkt)
        protocol = pkt[IP].proto
        proto_name = "TCP" if protocol == 6 else "UDP" if protocol == 17 else "OTHER"
        src_port = pkt[TCP].sport if TCP in pkt else pkt[UDP].sport if UDP in pkt else 0
        dst_port = pkt[TCP].dport if TCP in pkt else pkt[UDP].dport if UDP in pkt else 0

        # Só logar tráfego relevante (não localhost e portas comuns)
        if src_ip != '127.0.0.1' and dst_ip != '127.0.0.1' and (src_port not in [53, 80, 443] and dst_port not in [53, 80, 443]):
            # Ofuscar IPs para privacidade nos logs
            obfuscated_src = obfuscate_ip(src_ip)
            obfuscated_dst = obfuscate_ip(dst_ip)
            info = f"{proto_name} {obfuscated_src}:{src_port} -> {obfuscated_dst}:{dst_port}"
            conn = sqlite3.connect(DB_FILE)
            c = conn.cursor()
            c.execute("INSERT INTO traffic_logs (timestamp, src_ip, dst_ip, src_port, dst_port, protocol, length, info) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                      (time.strftime('%Y-%m-%d %H:%M:%S'), obfuscated_src, obfuscated_dst, src_port, dst_port, proto_name, length, info))
            conn.commit()
            conn.close()

# Obter categoria do domínio
def get_category(domain):
    porn_keywords = ['pornhub', 'xvideos', 'xhamster', 'porn', 'sex', 'adult']
    game_keywords = ['steam', 'epicgames', 'riot', 'blizzard', 'ubisoft', 'ea', 'game']
    malware_keywords = ['malware', 'virus', 'trojan', 'ransomware']  # exemplo
    if any(k in domain for k in porn_keywords):
        return 'porn'
    if any(k in domain for k in game_keywords):
        return 'game'
    if any(k in domain for k in malware_keywords):
        return 'malware'
    return 'other'

# Verificar se domínio está bloqueado
def is_blocked_domain(domain):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("SELECT 1 FROM blocked_domains WHERE domain = ?", (domain,))
    result = c.fetchone()
    conn.close()
    return result is not None

# Verificar se IP está bloqueado
def is_blocked_ip(ip):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("SELECT 1 FROM blocked_ips WHERE ip = ?", (ip,))
    result = c.fetchone()
    conn.close()
    return result is not None

# Resolver domínio via DNS forward
def resolve_domain(domain):
    # Check cache first
    if domain in dns_cache:
        ip, timestamp = dns_cache[domain]
        if time.time() - timestamp < CACHE_TTL:
            return ip
        else:
            del dns_cache[domain]  # Expired

    # Limpar cache se estiver muito grande
    if len(dns_cache) > CACHE_MAX_SIZE:
        # Remover entradas mais antigas
        current_time = time.time()
        expired = [k for k, v in dns_cache.items() if current_time - v[1] > CACHE_TTL]
        for k in expired:
            del dns_cache[k]
        # Se ainda estiver grande, remover metade das entradas mais antigas
        if len(dns_cache) > CACHE_MAX_SIZE:
            sorted_items = sorted(dns_cache.items(), key=lambda x: x[1][1])
            to_remove = len(sorted_items) // 2
            for k, _ in sorted_items[:to_remove]:
                del dns_cache[k]

    # Redirecionar domínios específicos para o painel de marketing
    marketing_domains = ['marketing.invictusdns.com', 'promo.invictusdns.com']
    marketing_ip = '187.94.39.155'  # IP do servidor onde o painel está hospedado
    if domain in marketing_domains:
        dns_cache[domain] = (marketing_ip, time.time())
        return marketing_ip

    # Retornar IPs públicos fixos para domínios específicos
    if domain == 'meuservidor1.com':
        ip = '187.94.39.155'
        dns_cache[domain] = (ip, time.time())
        return ip
    if domain == 'meuservidor2.com':
        ip = '187.94.39.160'
        dns_cache[domain] = (ip, time.time())
        return ip
    # Temporário para teste: retornar IP fake
    if domain == 'google.com':
        ip = '142.250.184.206'  # Um IP de google.com
        dns_cache[domain] = (ip, time.time())
        return ip
    if domain == 'example.com':
        ip = '93.184.216.34'  # IP oficial example.com
        dns_cache[domain] = (ip, time.time())
        return ip
    try:
        # Criar query DNS
        q = DNSRecord.question(domain, QTYPE.A)
        for fwd in FORWARD_DNS:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                sock.settimeout(2)  # Faster timeout
                sock.sendto(q.pack(), (fwd, FORWARD_PORT))
                data, _ = sock.recvfrom(4096)
                sock.close()
                response = DNSRecord.parse(data)
                # Extrair IP da resposta
                for rr in response.rr:
                    if rr.rtype == QTYPE.A:
                        ip = str(rr.rdata)
                        dns_cache[domain] = (ip, time.time())
                        return ip
                return None
            except:
                continue
        return None
    except:
        return None

# Servidor DNS
def dns_server():
    init_db()
    # Iniciar sniffer de tráfego em thread separada
    def start_sniffer():
        try:
            # Tentar capturar na interface padrão; no Windows, pode precisar de Npcap
            sniff(prn=log_traffic, store=0)
        except Exception as e:
            logging.error(f"Erro no sniffer: {e}. Possível causa: Npcap não instalado ou permissões insuficientes.")
            print(f"Erro no sniffer: {e}. Instale Npcap para monitoramento de tráfego.")

    sniffer_thread = threading.Thread(target=start_sniffer, daemon=True)
    sniffer_thread.start()
    print("Sniffer de tráfego iniciado...")
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind(('0.0.0.0', DNS_PORT))
    print(f"Servidor DNS rodando na porta {DNS_PORT}...")

    # Lista de IPs permitidos (exemplo: só permite IPs da rede local)
    allowed_ips = ['0.0.0.0/0']  # Permitir todos os IPs

    def ip_allowed(ip):
        try:
            import ipaddress
            ip_addr = ipaddress.ip_address(ip)
            for net in allowed_ips:
                if '/' in net:
                    if ip_addr in ipaddress.ip_network(net):
                        return True
                else:
                    if ip == net:
                        return True
            return False
        except ImportError:
            # Fallback se ipaddress não estiver disponível
            return True

    def process_request(data, addr):
        client_ip = addr[0]
        logging.info(f"Recebida consulta DNS de {client_ip}")
        print(f"Recebida consulta DNS de {client_ip}")
        if is_blocked_ip(client_ip) or not ip_allowed(client_ip):
            logging.warning(f"Consulta recusada de IP bloqueado ou não permitido: {client_ip}")
            print(f"Consulta recusada de IP bloqueado ou não permitido: {client_ip}")
            return
        try:
            request = DNSRecord.parse(data)
            domain = str(request.q.qname).rstrip('.')
            logging.info(f"Consulta para domínio: {domain}")
            print(f"Consulta para domínio: {domain}")
            if is_blocked_domain(domain) or is_quarantined(domain):
                reply = request.reply()
                reply.header.rcode = 3  # NXDOMAIN
                sock.sendto(reply.pack(), addr)
                threat_type = 'quarantined' if is_quarantined(domain) else 'blocked'
                log_query(client_ip, domain, None, threat_type, 0)
                log_data_usage(client_ip, 0.001)
                logging.info(f"Domínio {threat_type}: {domain}")
                return
            start_time = time.time()
            response_ip = resolve_domain(domain)
            end_time = time.time()
            response_time = end_time - start_time
            category = get_category(domain)

            # Análise avançada de segurança
            threat_analysis = analyze_threats(client_ip, domain, {'response_ip': response_ip, 'category': category})

            # Detectar anomalias usando ML
            is_anomaly, anomaly_score = anomaly_detector.detect_anomaly(
                client_ip, domain, response_ip or '', category, response_time
            )

            # Log de ameaças detectadas
            if threat_analysis['threat_detected']:
                logging.warning(f"AMEAÇA DETECTADA: {domain} - Score: {threat_analysis['overall_threat_score']:.3f}")
                print(f"AMEAÇA DETECTADA: {domain} - Score: {threat_analysis['overall_threat_score']:.3f}")

            if response_ip:
                # Criar resposta
                reply = request.reply()
                reply.add_answer(RR(domain, QTYPE.A, rdata=A(response_ip)))
                sock.sendto(reply.pack(), addr)
                log_query(client_ip, domain, response_ip, category, response_time, anomaly_score)
                log_data_usage(client_ip, 0.001)
                logging.info(f"Resposta enviada para {client_ip} com IP {response_ip}")
                print(f"Resposta enviada para {client_ip} com IP {response_ip}")
                if is_anomaly:
                    logging.warning(f"ANOMALIA DETECTADA: {client_ip} -> {domain} (Score: {anomaly_score:.3f})")
                    print(f"ANOMALIA DETECTADA: {client_ip} -> {domain} (Score: {anomaly_score:.3f})")
            else:
                # Resposta de erro
                reply = request.reply()
                reply.header.rcode = 2  # SERVFAIL
                sock.sendto(reply.pack(), addr)
                log_query(client_ip, domain, None, category, response_time, anomaly_score)
                log_data_usage(client_ip, 0.001)
                logging.warning(f"Falha ao resolver domínio {domain} para {client_ip}")
                print(f"Falha ao resolver domínio {domain} para {client_ip}")
        except Exception as e:
            logging.error(f"Erro: {e}")
            print(f"Erro: {e}")

    while True:
        data, addr = sock.recvfrom(4096)
        threading.Thread(target=process_request, args=(data, addr), daemon=True).start()

if __name__ == '__main__':
    dns_server()

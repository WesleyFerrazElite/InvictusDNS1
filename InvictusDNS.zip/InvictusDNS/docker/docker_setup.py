import os
import json
from pathlib import Path

# Docker and Kubernetes configuration for InvictusDNS

DOCKER_COMPOSE_TEMPLATE = """
version: '3.8'

services:
  invictus-dns-master:
    build:
      context: .
      dockerfile: Dockerfile.master
    ports:
      - "53:53/udp"
      - "53:53/tcp"
      - "3000:3000"
      - "5000:5000"
      - "5001:5001"
    volumes:
      - ./data:/app/data
      - ./logs:/app/logs
    environment:
      - NODE_ROLE=master
      - CLUSTER_ENABLED=true
    networks:
      - invictus-network
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:5000/api/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  invictus-dns-worker:
    build:
      context: .
      dockerfile: Dockerfile.worker
    ports:
      - "3001-3007:3001-3007"
    volumes:
      - ./data:/app/data
      - ./logs:/app/logs
    environment:
      - NODE_ROLE=worker
      - CLUSTER_ENABLED=true
      - MASTER_NODE=invictus-dns-master
    networks:
      - invictus-network
    restart: unless-stopped
    depends_on:
      - invictus-dns-master
    deploy:
      replicas: 2

  prometheus:
    image: prom/prometheus:latest
    ports:
      - "9090:9090"
    volumes:
      - ./monitoring/prometheus.yml:/etc/prometheus/prometheus.yml
      - prometheus_data:/prometheus
    networks:
      - invictus-network
    restart: unless-stopped

  grafana:
    image: grafana/grafana:latest
    ports:
      - "3008:3000"
    volumes:
      - grafana_data:/var/lib/grafana
      - ./monitoring/grafana/provisioning:/etc/grafana/provisioning
    environment:
      - GF_SECURITY_ADMIN_PASSWORD=admin
    networks:
      - invictus-network
    restart: unless-stopped

  redis:
    image: redis:alpine
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data
    networks:
      - invictus-network
    restart: unless-stopped

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx/nginx.conf:/etc/nginx/nginx.conf
      - ./nginx/ssl:/etc/nginx/ssl
      - ./logs/nginx:/var/log/nginx
    networks:
      - invictus-network
    restart: unless-stopped
    depends_on:
      - invictus-dns-master
      - invictus-dns-worker

networks:
  invictus-network:
    driver: bridge

volumes:
  prometheus_data:
  grafana_data:
  redis_data:
"""

DOCKERFILE_MASTER = """
FROM python:3.9-slim

# Install system dependencies
RUN apt-get update && apt-get install -y \\
    curl \\
    dnsutils \\
    net-tools \\
    iptables \\
    && rm -rf /var/lib/apt/lists/*

# Set working directory
WORKDIR /app

# Copy requirements and install Python dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application code
COPY . .

# Create necessary directories
RUN mkdir -p /app/data /app/logs /app/backup

# Set permissions
RUN chmod +x /app/run_windows.py

# Expose ports
EXPOSE 53/udp 53/tcp 3000 5000 5001

# Health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=5s --retries=3 \\
    CMD curl -f http://localhost:5000/api/health || exit 1

# Start command
CMD ["python", "run_windows.py"]
"""

DOCKERFILE_WORKER = """
FROM python:3.9-slim

# Install system dependencies
RUN apt-get update && apt-get install -y \\
    curl \\
    && rm -rf /var/lib/apt/lists/*

# Set working directory
WORKDIR /app

# Copy requirements and install Python dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application code
COPY . .

# Create necessary directories
RUN mkdir -p /app/data /app/logs

# Expose ports for web panels
EXPOSE 3001 3002 3003 3004 3005 3006 3007

# Health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=5s --retries=3 \\
    CMD curl -f http://localhost:3000/api/health || exit 1

# Start command
CMD ["python", "panels/web_panel.py"]
"""

KUBERNETES_DEPLOYMENT = """
apiVersion: apps/v1
kind: Deployment
metadata:
  name: invictus-dns-master
  labels:
    app: invictus-dns
    component: master
spec:
  replicas: 1
  selector:
    matchLabels:
      app: invictus-dns
      component: master
  template:
    metadata:
      labels:
        app: invictus-dns
        component: master
    spec:
      containers:
      - name: invictus-dns
        image: invictus-dns:latest
        ports:
        - containerPort: 53
          protocol: UDP
        - containerPort: 53
          protocol: TCP
        - containerPort: 3000
        - containerPort: 5000
        - containerPort: 5001
        volumeMounts:
        - name: data-volume
          mountPath: /app/data
        - name: logs-volume
          mountPath: /app/logs
        env:
        - name: NODE_ROLE
          value: "master"
        - name: CLUSTER_ENABLED
          value: "true"
        livenessProbe:
          httpGet:
            path: /api/health
            port: 5000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /api/health
            port: 5000
          initialDelaySeconds: 5
          periodSeconds: 5
      volumes:
      - name: data-volume
        persistentVolumeClaim:
          claimName: invictus-dns-data-pvc
      - name: logs-volume
        persistentVolumeClaim:
          claimName: invictus-dns-logs-pvc
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: invictus-dns-worker
  labels:
    app: invictus-dns
    component: worker
spec:
  replicas: 3
  selector:
    matchLabels:
      app: invictus-dns
      component: worker
  template:
    metadata:
      labels:
        app: invictus-dns
        component: worker
    spec:
      containers:
      - name: invictus-dns
        image: invictus-dns:latest
        ports:
        - containerPort: 3001
        - containerPort: 3002
        - containerPort: 3003
        - containerPort: 3004
        - containerPort: 3005
        - containerPort: 3006
        - containerPort: 3007
        volumeMounts:
        - name: data-volume
          mountPath: /app/data
        - name: logs-volume
          mountPath: /app/logs
        env:
        - name: NODE_ROLE
          value: "worker"
        - name: CLUSTER_ENABLED
          value: "true"
        - name: MASTER_NODE
          value: "invictus-dns-master"
        livenessProbe:
          httpGet:
            path: /api/health
            port: 3000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /api/health
            port: 3000
          initialDelaySeconds: 5
          periodSeconds: 5
      volumes:
      - name: data-volume
        persistentVolumeClaim:
          claimName: invictus-dns-data-pvc
      - name: logs-volume
        persistentVolumeClaim:
          claimName: invictus-dns-logs-pvc
---
apiVersion: v1
kind: Service
metadata:
  name: invictus-dns-master
spec:
  selector:
    app: invictus-dns
    component: master
  ports:
  - name: dns-udp
    port: 53
    protocol: UDP
    targetPort: 53
  - name: dns-tcp
    port: 53
    protocol: TCP
    targetPort: 53
  - name: web
    port: 3000
    targetPort: 3000
  - name: api
    port: 5000
    targetPort: 5000
  - name: cluster
    port: 5001
    targetPort: 5001
  type: LoadBalancer
---
apiVersion: v1
kind: Service
metadata:
  name: invictus-dns-worker
spec:
  selector:
    app: invictus-dns
    component: worker
  ports:
  - name: logs
    port: 3004
    targetPort: 3004
  - name: marketing
    port: 3001
    targetPort: 3001
  - name: ai
    port: 3002
    targetPort: 3002
  - name: cloud
    port: 3003
    targetPort: 3003
  - name: monitoring
    port: 3005
    targetPort: 3005
  - name: auth
    port: 3006
    targetPort: 3006
  - name: ui
    port: 3007
    targetPort: 3007
  type: LoadBalancer
---
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: invictus-dns-data-pvc
spec:
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      storage: 10Gi
---
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: invictus-dns-logs-pvc
spec:
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      storage: 5Gi
"""

PROMETHEUS_CONFIG = """
global:
  scrape_interval: 15s
  evaluation_interval: 15s

rule_files:
  # - "first_rules.yml"
  # - "second_rules.yml"

scrape_configs:
  - job_name: 'invictus-dns-master'
    static_configs:
      - targets: ['invictus-dns-master:5000']
    metrics_path: '/metrics'
    scrape_interval: 5s

  - job_name: 'invictus-dns-worker'
    static_configs:
      - targets: ['invictus-dns-worker:3000']
    metrics_path: '/metrics'
    scrape_interval: 5s

  - job_name: 'node-exporter'
    static_configs:
      - targets: ['node-exporter:9100']
"""

REQUIREMENTS_DOCKER = """
Flask==2.3.3
Flask-RESTful==0.3.10
Flask-JWT-Extended==4.5.2
Flask-Cors==4.0.0
Werkzeug==2.3.7
requests==2.31.0
psutil==5.9.5
sqlite3
pyotp==2.9.0
qrcode==7.4.2
bcrypt==4.0.1
cryptography==41.0.4
celery==5.3.1
redis==4.6.0
prometheus-client==0.17.1
gunicorn==21.2.0
"""

NGINX_CONFIG = """
events {
    worker_connections 1024;
}

http {
    upstream invictus_dns_backend {
        server invictus-dns-master:3000;
        server invictus-dns-worker:3000;
    }

    upstream invictus_dns_api {
        server invictus-dns-master:5000;
        server invictus-dns-worker:3000;
    }

    server {
        listen 80;
        server_name localhost;

        # Security headers
        add_header X-Frame-Options "SAMEORIGIN" always;
        add_header X-XSS-Protection "1; mode=block" always;
        add_header X-Content-Type-Options "nosniff" always;
        add_header Referrer-Policy "no-referrer-when-downgrade" always;
        add_header Content-Security-Policy "default-src 'self' http: https: data: blob: 'unsafe-inline'" always;

        # Main application
        location / {
            proxy_pass http://invictus_dns_backend;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
        }

        # API endpoints
        location /api/ {
            proxy_pass http://invictus_dns_api;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
        }

        # Static files
        location /static/ {
            alias /app/static/;
            expires 1y;
            add_header Cache-Control "public, immutable";
        }
    }
}
"""

def create_docker_files():
    """Create all Docker-related files"""

    # Create docker directory structure
    docker_dir = Path("docker")
    docker_dir.mkdir(exist_ok=True)

    monitoring_dir = docker_dir / "monitoring"
    monitoring_dir.mkdir(exist_ok=True)

    nginx_dir = docker_dir / "nginx"
    nginx_dir.mkdir(exist_ok=True)

    # Docker Compose
    with open(docker_dir / "docker-compose.yml", "w") as f:
        f.write(DOCKER_COMPOSE_TEMPLATE)

    # Dockerfiles
    with open(docker_dir / "Dockerfile.master", "w") as f:
        f.write(DOCKERFILE_MASTER)

    with open(docker_dir / "Dockerfile.worker", "w") as f:
        f.write(DOCKERFILE_WORKER)

    # Kubernetes
    with open(docker_dir / "k8s-deployment.yml", "w") as f:
        f.write(KUBERNETES_DEPLOYMENT)

    # Prometheus
    with open(monitoring_dir / "prometheus.yml", "w") as f:
        f.write(PROMETHEUS_CONFIG)

    # Requirements
    with open(docker_dir / "requirements.txt", "w") as f:
        f.write(REQUIREMENTS_DOCKER)

    # Nginx
    with open(nginx_dir / "nginx.conf", "w") as f:
        f.write(NGINX_CONFIG)

    print("Docker files created successfully!")

def create_dockerignore():
    """Create .dockerignore file"""
    dockerignore_content = """
__pycache__
*.pyc
*.pyo
*.pyd
.Python
env
venv
.venv
pip-log.txt
pip-delete-this-directory.txt
.tox
.coverage
.coverage.*
.cache
nosetests.xml
coverage.xml
*.cover
*.log
.git
.mypy_cache
.pytest_cache
.hypothesis
node_modules
.DS_Store
.vscode
.idea
*.swp
*.swo
*~
data/
logs/
backup/
*.db
*.sqlite
*.sqlite3
"""

    with open(".dockerignore", "w") as f:
        f.write(dockerignore_content)

def create_build_script():
    """Create build script for Docker images"""
    build_script = """#!/bin/bash

# InvictusDNS Docker Build Script

set -e

echo "🏗️ Building InvictusDNS Docker images..."

# Build master image
echo "Building master image..."
docker build -f docker/Dockerfile.master -t invictus-dns:master .

# Build worker image
echo "Building worker image..."
docker build -f docker/Dockerfile.worker -t invictus-dns:worker .

# Tag latest
docker tag invictus-dns:master invictus-dns:latest

echo "✅ Docker images built successfully!"
echo ""
echo "🚀 To start the cluster:"
echo "docker-compose -f docker/docker-compose.yml up -d"
echo ""
echo "📊 Access points:"
echo "- Web UI: http://localhost"
echo "- API: http://localhost/api"
echo "- Prometheus: http://localhost:9090"
echo "- Grafana: http://localhost:3008 (admin/admin)"
echo ""
echo "🛑 To stop:"
echo "docker-compose -f docker/docker-compose.yml down"
"""

    with open("docker/build.sh", "w") as f:
        f.write(build_script)

    # Make executable
    os.chmod("docker/build.sh", 0o755)

if __name__ == "__main__":
    create_docker_files()
    create_dockerignore()
    create_build_script()
    print("Docker setup completed!")

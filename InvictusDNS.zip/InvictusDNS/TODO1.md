# TODO: Implementar Endpoints da API para o Painel de Configuração de Rede

## Passos para Completar a Tarefa

1. **✅ Adicionar rotas GET para status e configurações:**
   - /api/network_status: Retornar status atual da rede (PPPoE, Bridge, Firewall, DHCP).
   - /api/interfaces: Retornar lista de interfaces de rede disponíveis.
   - /api/network_config: Retornar a configuração atual da rede em JSON.

2. **✅ Adicionar rotas POST para configurações PPPoE:**
   - /api/configure_pppoe: Atualizar configuração PPPoE no dicionário e salvar.
   - /api/pppoe_connect: Conectar PPPoE usando subprocess (pon).
   - /api/pppoe_disconnect: Desconectar PPPoE usando subprocess (poff).

3. **✅ Adicionar rotas POST para configurações Bridge:**
   - /api/configure_bridge: Atualizar configuração Bridge e salvar.
   - /api/create_bridge: Criar bridge usando ip link.
   - /api/destroy_bridge: Destruir bridge usando ip link.

4. **✅ Adicionar rotas POST para configurações VLAN:**
   - /api/configure_vlan: Atualizar configuração VLAN e salvar.
   - /api/create_vlans: Criar VLANs usando ip link.
   - /api/destroy_vlans: Destruir VLANs usando ip link.

5. **✅ Adicionar rotas POST para configurações Firewall:**
   - /api/configure_firewall: Atualizar configuração Firewall e salvar.
   - /api/apply_firewall_rules: Aplicar regras usando iptables.
   - /api/flush_firewall: Limpar regras usando iptables.

6. **✅ Adicionar rotas POST para configurações QoS:**
   - /api/configure_qos: Atualizar configuração QoS e salvar.
   - /api/apply_qos: Aplicar QoS usando tc.
   - /api/remove_qos: Remover QoS usando tc.

7. **✅ Adicionar rotas POST para configurações DHCP:**
   - /api/configure_dhcp: Atualizar configuração DHCP e salvar.
   - /api/restart_dhcp: Reiniciar serviço DHCP usando systemctl.
   - /api/stop_dhcp: Parar serviço DHCP usando systemctl.

8. **✅ Adicionar rotas POST para configurações de Roteamento:**
   - /api/configure_routing: Atualizar configuração de roteamento e salvar.
   - /api/apply_nat: Aplicar NAT usando iptables.
   - /api/remove_nat: Remover NAT usando iptables.

9. **✅ Adicionar rota adicional se necessário:**
   - /api/detailed_status: Para status detalhado, adicionado como alias para /api/network_status.

10. **Testar as mudanças:**
    - Executar o aplicativo Flask e verificar se as APIs respondem corretamente.
    - Verificar se os comandos subprocess funcionam no sistema Linux.

## Notas
- Todas as rotas POST devem retornar JSON com chave 'message' indicando sucesso ou erro.
- Usar try/except para capturar erros nos subprocess.
- Atualizar network_config e salvar para cada configuração.
- Assumir ambiente Linux para comandos como ip, iptables, systemctl.

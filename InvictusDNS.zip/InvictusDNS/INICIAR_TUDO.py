#!/usr/bin/env python3
"""
InvictusDNS - INICIADOR COMPLETO
Inicia TODOS os componentes do sistema com um clique
Compatível com Windows e Linux
"""

import sys
import os
import time
import threading
import subprocess
import platform
import logging
import json
from pathlib import Path
import importlib.util

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/iniciar_tudo.log'),
        logging.StreamHandler(sys.stdout)
    ]
)

class InvictusDNSLauncher:
    """
    Launcher completo do InvictusDNS
    """

    def __init__(self):
        self.logger = logging.getLogger("InvictusDNS.Launcher")
        self.running = False
        self.threads = []
        self.processes = []
        self.components = []

        # Componentes a iniciar
        self.components_list = [
            {'name': 'DNS Server', 'port': 53, 'module': 'server/dns_server.py', 'type': 'thread'},
            {'name': 'Web Panel (Admin)', 'port': 3000, 'module': 'panels/web_panel.py', 'type': 'process'},
            {'name': 'AI Panel', 'port': 3002, 'module': 'panels/ai_panel.py', 'type': 'process'},
            {'name': 'Marketing Panel', 'port': 3001, 'module': 'panels/marketing_panel.py', 'type': 'process'},
            {'name': 'Cloud Panel', 'port': 3003, 'module': 'panels/cloud_panel.py', 'type': 'process'},
            {'name': 'AI Core', 'port': None, 'module': 'ai_core', 'type': 'import'},
            {'name': 'Agents System', 'port': None, 'module': 'agents', 'type': 'import'},
            {'name': 'Security System', 'port': None, 'module': 'security/advanced_security.py', 'type': 'import'},
            {'name': 'ML Anomaly Detector', 'port': None, 'module': 'monitoring/ml_anomaly_detector.py', 'type': 'import'},
            {'name': 'Cluster Manager', 'port': None, 'module': 'cluster/cluster_manager.py', 'type': 'import'},
            {'name': 'Cloud Backup', 'port': None, 'module': 'backup/cloud_backup.py', 'type': 'import'},
            {'name': 'PPOE Manager', 'port': None, 'module': 'ppoe/ppoe_manager.py', 'type': 'import'},
            {'name': 'Configuration Manager', 'port': None, 'module': 'config/config_manager.py', 'type': 'import'},
            {'name': 'Notification System', 'port': None, 'module': 'notifications/notification_system.py', 'type': 'import'},
            {'name': 'Automation Engine', 'port': None, 'module': 'automation/automation_engine.py', 'type': 'import'},
            {'name': 'Analytics Dashboard', 'port': None, 'module': 'analytics/analytics_dashboard.py', 'type': 'import'},
            {'name': 'API Gateway', 'port': 8080, 'module': 'api/api_gateway.py', 'type': 'process'},
            {'name': 'Mobile API', 'port': 8081, 'module': 'mobile/mobile_api.py', 'type': 'process'},
            {'name': 'Watchdog Service', 'port': None, 'module': 'services/watchdog.py', 'type': 'thread'},
            {'name': 'Load Balancer', 'port': None, 'module': 'network/load_balancer.py', 'type': 'import'}
        ]

    def print_banner(self):
        """Imprime banner do sistema"""
        print("=" * 60)
        print("    INVICTUS DNS - SISTEMA COMPLETO INTEGRADO")
        print("=" * 60)
        print()
        print("Iniciando TODOS os componentes:")
        print()

        for i, comp in enumerate(self.components_list, 1):
            port_info = f" (porta {comp['port']})" if comp['port'] else ""
            print("2d")

        print()
        print("=" * 60)
        print("Pressione Ctrl+C para parar todos os serviços")
        print("=" * 60)
        print()

    def check_dependencies(self):
        """Verifica dependências"""
        self.logger.info("Verificando dependências...")

        # Verificar Python
        if sys.version_info < (3, 8):
            self.logger.error("Python 3.8+ necessário")
            return False

        # Verificar módulos essenciais
        required_modules = ['flask', 'psutil', 'sqlite3', 'threading', 'subprocess']
        for module in required_modules:
            try:
                importlib.import_module(module)
            except ImportError:
                self.logger.error(f"Módulo {module} não encontrado")
                return False

        self.logger.info("Dependências OK")
        return True

    def start_component(self, component):
        """Inicia um componente específico"""
        name = component['name']
        module = component['module']
        comp_type = component['type']
        port = component['port']

        try:
            if comp_type == 'process':
                # Iniciar como processo separado
                if os.path.exists(module):
                    cmd = [sys.executable, module] if platform.system() == 'Windows' else ['python3', module]
                    self.logger.info(f"Iniciando {name}...")
                    process = subprocess.Popen(
                        cmd,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        cwd=os.getcwd()
                    )
                    self.processes.append((name, process))
                    time.sleep(2)  # Aguardar inicialização

                    if process.poll() is None:
                        self.logger.info(f"✅ {name} iniciado (PID: {process.pid})")
                        if port:
                            self.logger.info(f"   📡 Porta: {port}")
                    else:
                        stdout, stderr = process.communicate()
                        self.logger.error(f"❌ Erro ao iniciar {name}")
                        if stderr:
                            self.logger.error(f"STDERR: {stderr.decode()}")
                        return False
                else:
                    self.logger.warning(f"⚠️  Módulo {module} não encontrado")
                    return False

            elif comp_type == 'thread':
                # Iniciar como thread
                def thread_func():
                    try:
                        if module.endswith('.py'):
                            spec = importlib.util.spec_from_file_location(name, module)
                            mod = importlib.util.module_from_spec(spec)
                            spec.loader.exec_module(mod)
                            # Assumir que tem uma função main ou run
                            if hasattr(mod, 'main'):
                                mod.main()
                            elif hasattr(mod, 'run'):
                                mod.run()
                            else:
                                self.logger.warning(f"⚠️  {name}: função main/run não encontrada")
                        else:
                            # Importar módulo
                            mod = importlib.import_module(module.replace('/', '.').replace('.py', ''))
                            if hasattr(mod, 'main'):
                                mod.main()
                            elif hasattr(mod, 'run'):
                                mod.run()
                            else:
                                self.logger.warning(f"⚠️  {name}: função main/run não encontrada")
                    except Exception as e:
                        self.logger.error(f"❌ Erro na thread {name}: {e}")

                thread = threading.Thread(target=thread_func, daemon=True, name=name)
                thread.start()
                self.threads.append(thread)
                self.logger.info(f"✅ {name} iniciado (thread)")

            elif comp_type == 'import':
                # Apenas importar e inicializar
                try:
                    if module.endswith('.py'):
                        spec = importlib.util.spec_from_file_location(name, module)
                        mod = importlib.util.module_from_spec(spec)
                        spec.loader.exec_module(mod)
                    else:
                        mod = importlib.import_module(module.replace('/', '.').replace('.py', ''))

                    # Tentar inicializar se houver função init
                    if hasattr(mod, 'init'):
                        mod.init()
                    elif hasattr(mod, 'initialize'):
                        mod.initialize()
                    elif hasattr(mod, 'start'):
                        mod.start()

                    self.logger.info(f"✅ {name} inicializado")

                except Exception as e:
                    self.logger.error(f"❌ Erro ao inicializar {name}: {e}")
                    return False

            return True

        except Exception as e:
            self.logger.error(f"❌ Erro ao iniciar {name}: {e}")
            return False

    def start_all(self):
        """Inicia todos os componentes"""
        self.logger.info("Iniciando sistema InvictusDNS completo...")

        success_count = 0
        total_count = len(self.components_list)

        for component in self.components_list:
            if self.start_component(component):
                success_count += 1
            time.sleep(0.5)  # Pequena pausa entre inicializações

        self.logger.info(f"Sistema iniciado: {success_count}/{total_count} componentes OK")

        if success_count > 0:
            self.logger.info("\n" + "="*60)
            self.logger.info("PAINÉIS DISPONÍVEIS:")
            for comp in self.components_list:
                if comp['port']:
                    self.logger.info(f"- {comp['name']}: http://localhost:{comp['port']}")
            self.logger.info("="*60)

        return success_count > 0

    def monitor_system(self):
        """Monitora o sistema enquanto roda"""
        while self.running:
            try:
                # Verificar processos ativos
                active_processes = 0
                for name, process in self.processes[:]:
                    if process.poll() is not None:
                        self.logger.warning(f"Processo {name} parou inesperadamente")
                        self.processes.remove((name, process))
                    else:
                        active_processes += 1

                # Log status periódico
                if int(time.time()) % 60 == 0:  # A cada minuto
                    self.logger.info(f"Status: {active_processes} processos ativos, {len(self.threads)} threads ativas")

                time.sleep(10)

            except Exception as e:
                self.logger.error(f"Erro no monitoramento: {e}")
                time.sleep(30)

    def stop_all(self):
        """Para todos os componentes"""
        self.logger.info("Parando sistema InvictusDNS...")

        # Parar processos
        for name, process in self.processes:
            try:
                self.logger.info(f"Parando {name}...")
                process.terminate()
                try:
                    process.wait(timeout=5)
                    self.logger.info(f"✅ {name} parado")
                except subprocess.TimeoutExpired:
                    self.logger.warning(f"Forçando parada de {name}")
                    process.kill()
                    self.logger.info(f"✅ {name} forçado parada")
            except Exception as e:
                self.logger.error(f"Erro ao parar {name}: {e}")

        # Aguardar threads
        for thread in self.threads:
            if thread.is_alive():
                thread.join(timeout=2)

        self.logger.info("Sistema InvictusDNS completamente parado")

    def run(self):
        """Executa o launcher"""
        try:
            self.print_banner()

            if not self.check_dependencies():
                self.logger.error("Dependências não atendidas. Abortando.")
                return

            self.running = True

            # Iniciar monitoramento em thread separada
            monitor_thread = threading.Thread(target=self.monitor_system, daemon=True)
            monitor_thread.start()

            # Iniciar todos os componentes
            if self.start_all():
                self.logger.info("Sistema InvictusDNS rodando! Pressione Ctrl+C para parar.")

                # Manter rodando
                try:
                    while self.running:
                        time.sleep(1)
                except KeyboardInterrupt:
                    self.logger.info("Interrupção recebida...")
                    self.stop_all()
            else:
                self.logger.error("Falha ao iniciar componentes essenciais")

        except Exception as e:
            self.logger.error(f"Erro fatal: {e}")
            self.stop_all()

def main():
    """Ponto de entrada principal"""
    # Verificar se estamos no diretório correto
    if not os.path.exists('server/dns_server.py'):
        print("Erro: Execute este arquivo do diretório raiz do InvictusDNS")
        input("Pressione Enter para sair...")
        sys.exit(1)

    # Criar e executar launcher
    launcher = InvictusDNSLauncher()
    launcher.run()

if __name__ == '__main__':
    main()

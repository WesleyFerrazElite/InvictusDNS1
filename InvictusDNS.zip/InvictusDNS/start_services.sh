#!/bin/bash
# Script para iniciar todos os serviços do InvictusDNS

# Iniciar servidor DNS
sudo python server/dns_server.py &

# Iniciar painel web
cd panels
python web_panel.py &

# Iniciar painel de marketing
python marketing_panel.py &

# Iniciar painel de IA
python ai_panel.py &

echo "Serviços iniciados. Use stop_services.sh para parar."

import sqlite3
import os
import time

DB_FILE = os.path.join(os.path.dirname(__file__), 'data', 'dns_logs.db')

def cleanup_old_logs():
    """Remove logs antigos para manter o banco leve."""
    init_db()
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()

    # Manter apenas logs dos últimos 30 dias
    thirty_days_ago = time.time() - (30 * 24 * 60 * 60)
    c.execute("DELETE FROM dns_logs WHERE timestamp < ?", (time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(thirty_days_ago)),))

    # Manter apenas logs de tráfego dos últimos 7 dias
    seven_days_ago = time.time() - (7 * 24 * 60 * 60)
    c.execute("DELETE FROM traffic_logs WHERE timestamp < ?", (time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(seven_days_ago)),))

    # Manter apenas uso de dados dos últimos 90 dias
    ninety_days_ago = time.time() - (90 * 24 * 60 * 60)
    c.execute("DELETE FROM data_usage WHERE timestamp < ?", (time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(ninety_days_ago)),))

    # Otimizar banco de dados
    c.execute("VACUUM")

    deleted_dns = c.rowcount
    conn.commit()
    conn.close()

    print(f"Limpeza concluída. Removidos {deleted_dns} registros antigos.")

def init_db():
    """Garante que as tabelas existem."""
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS dns_logs (
                    id INTEGER PRIMARY KEY,
                    timestamp TEXT,
                    client_ip TEXT,
                    domain TEXT,
                    response_ip TEXT,
                    category TEXT,
                    response_time REAL
                )''')
    c.execute('''CREATE TABLE IF NOT EXISTS traffic_logs (
                    id INTEGER PRIMARY KEY,
                    timestamp TEXT,
                    src_ip TEXT,
                    dst_ip TEXT,
                    src_port INTEGER,
                    dst_port INTEGER,
                    protocol TEXT,
                    length INTEGER,
                    info TEXT
                )''')
    c.execute('''CREATE TABLE IF NOT EXISTS data_usage (
                    id INTEGER PRIMARY KEY,
                    timestamp TEXT,
                    ip TEXT,
                    data_mb REAL
                )''')
    conn.commit()
    conn.close()

if __name__ == "__main__":
    cleanup_old_logs()

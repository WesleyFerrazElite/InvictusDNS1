from flask import Flask, render_template_string, request, jsonify, session
import json
import os
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'invictus-dns-ui-secret-key-2024'

DESKTOP_DIR = os.path.expanduser('~/Desktop')
CONFIG_FILE = os.path.join(DESKTOP_DIR, 'InvictusDNS_Data', 'dados', 'ui_config.json')

def load_ui_config():
    """Load UI configuration"""
    default_config = {
        'theme': 'light',
        'language': 'pt-BR',
        'dashboard_layout': 'grid',
        'auto_refresh': True,
        'refresh_interval': 30,
        'notifications_enabled': True,
        'compact_mode': False
    }

    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, 'r') as f:
            loaded_config = json.load(f)
            # Merge with defaults
            for key, value in default_config.items():
                if key not in loaded_config:
                    loaded_config[key] = value
            return loaded_config
    else:
        save_ui_config(default_config)
        return default_config

def save_ui_config(config):
    """Save UI configuration"""
    os.makedirs(os.path.dirname(CONFIG_FILE), exist_ok=True)
    with open(CONFIG_FILE, 'w') as f:
        json.dump(config, f, indent=4)

ui_config = load_ui_config()

@app.route('/ui/settings', methods=['GET', 'POST'])
def ui_settings():
    """UI Settings page"""
    if request.method == 'POST':
        data = request.get_json()
        global ui_config
        ui_config.update(data)
        save_ui_config(ui_config)
        return jsonify({'message': 'Settings saved successfully'}), 200

    # Enhanced UI with theme switching and responsive design
    html = f"""
    <!DOCTYPE html>
    <html lang="{ui_config.get('language', 'pt-BR')}" data-theme="{ui_config.get('theme', 'light')}">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>InvictusDNS - Enhanced Interface</title>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
        <style>
            :root {{
                --primary-color: #3498db;
                --secondary-color: #2c3e50;
                --success-color: #27ae60;
                --warning-color: #f39c12;
                --danger-color: #e74c3c;
                --light-bg: #f8f9fa;
                --dark-bg: #1a1a1a;
                --text-light: #333;
                --text-dark: #f8f9fa;
                --border-color: #ddd;
                --shadow: 0 4px 6px rgba(0,0,0,0.1);
            }}

            [data-theme="dark"] {{
                --primary-color: #5dade2;
                --secondary-color: #34495e;
                --light-bg: #2c2c2c;
                --dark-bg: #1a1a1a;
                --text-light: #f8f9fa;
                --text-dark: #333;
                --border-color: #444;
            }}

            * {{
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }}

            body {{
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: var(--light-bg);
                color: var(--text-light);
                transition: all 0.3s ease;
                overflow-x: hidden;
            }}

            [data-theme="dark"] body {{
                background: var(--dark-bg);
                color: var(--text-dark);
            }}

            .navbar {{
                background: var(--secondary-color);
                padding: 1rem 2rem;
                display: flex;
                justify-content: space-between;
                align-items: center;
                box-shadow: var(--shadow);
                position: sticky;
                top: 0;
                z-index: 1000;
            }}

            .navbar-brand {{
                color: white;
                font-size: 1.5rem;
                font-weight: bold;
                text-decoration: none;
                display: flex;
                align-items: center;
                gap: 10px;
            }}

            .navbar-nav {{
                display: flex;
                list-style: none;
                gap: 2rem;
                align-items: center;
            }}

            .nav-link {{
                color: white;
                text-decoration: none;
                padding: 0.5rem 1rem;
                border-radius: 5px;
                transition: background 0.3s ease;
                display: flex;
                align-items: center;
                gap: 8px;
            }}

            .nav-link:hover {{
                background: rgba(255,255,255,0.1);
            }}

            .theme-toggle {{
                background: none;
                border: none;
                color: white;
                font-size: 1.2rem;
                cursor: pointer;
                padding: 0.5rem;
                border-radius: 50%;
                transition: background 0.3s ease;
            }}

            .theme-toggle:hover {{
                background: rgba(255,255,255,0.1);
            }}

            .container {{
                max-width: 1400px;
                margin: 0 auto;
                padding: 2rem;
            }}

            .dashboard-header {{
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 2rem;
                flex-wrap: wrap;
                gap: 1rem;
            }}

            .dashboard-title {{
                font-size: 2.5rem;
                font-weight: 300;
                color: var(--secondary-color);
            }}

            [data-theme="dark"] .dashboard-title {{
                color: var(--text-dark);
            }}

            .stats-grid {{
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
                gap: 1.5rem;
                margin-bottom: 2rem;
            }}

            .stat-card {{
                background: white;
                border-radius: 15px;
                padding: 1.5rem;
                box-shadow: var(--shadow);
                border-left: 4px solid var(--primary-color);
                transition: transform 0.3s ease, box-shadow 0.3s ease;
                position: relative;
                overflow: hidden;
            }}

            [data-theme="dark"] .stat-card {{
                background: var(--light-bg);
                color: var(--text-light);
            }}

            .stat-card:hover {{
                transform: translateY(-5px);
                box-shadow: 0 8px 25px rgba(0,0,0,0.15);
            }}

            .stat-card::before {{
                content: '';
                position: absolute;
                top: 0;
                right: 0;
                width: 100px;
                height: 100px;
                background: linear-gradient(135deg, rgba(52, 152, 219, 0.1), rgba(52, 152, 219, 0.05));
                border-radius: 50%;
                transform: translate(30px, -30px);
            }}

            .stat-icon {{
                font-size: 2.5rem;
                color: var(--primary-color);
                margin-bottom: 1rem;
                position: relative;
                z-index: 1;
            }}

            .stat-value {{
                font-size: 2.5rem;
                font-weight: bold;
                color: var(--secondary-color);
                margin-bottom: 0.5rem;
                position: relative;
                z-index: 1;
            }}

            [data-theme="dark"] .stat-value {{
                color: var(--text-dark);
            }}

            .stat-label {{
                color: #7f8c8d;
                font-size: 0.9rem;
                text-transform: uppercase;
                letter-spacing: 1px;
                position: relative;
                z-index: 1;
            }}

            .charts-section {{
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
                gap: 1.5rem;
                margin-bottom: 2rem;
            }}

            .chart-card {{
                background: white;
                border-radius: 15px;
                padding: 1.5rem;
                box-shadow: var(--shadow);
                position: relative;
            }}

            [data-theme="dark"] .chart-card {{
                background: var(--light-bg);
            }}

            .chart-header {{
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 1rem;
            }}

            .chart-title {{
                font-size: 1.2rem;
                font-weight: 600;
                color: var(--secondary-color);
            }}

            [data-theme="dark"] .chart-title {{
                color: var(--text-dark);
            }}

            .chart-container {{
                position: relative;
                height: 300px;
            }}

            .settings-panel {{
                background: white;
                border-radius: 15px;
                padding: 2rem;
                box-shadow: var(--shadow);
                margin-top: 2rem;
            }}

            [data-theme="dark"] .settings-panel {{
                background: var(--light-bg);
            }}

            .settings-grid {{
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                gap: 2rem;
            }}

            .setting-group {{
                background: var(--light-bg);
                border-radius: 10px;
                padding: 1.5rem;
                border: 1px solid var(--border-color);
            }}

            [data-theme="dark"] .setting-group {{
                background: var(--dark-bg);
                border-color: var(--border-color);
            }}

            .setting-group h3 {{
                color: var(--secondary-color);
                margin-bottom: 1rem;
                font-size: 1.1rem;
            }}

            [data-theme="dark"] .setting-group h3 {{
                color: var(--text-dark);
            }}

            .form-group {{
                margin-bottom: 1rem;
            }}

            .form-label {{
                display: block;
                margin-bottom: 0.5rem;
                color: var(--text-light);
                font-weight: 500;
            }}

            [data-theme="dark"] .form-label {{
                color: var(--text-dark);
            }}

            .form-control {{
                width: 100%;
                padding: 0.75rem;
                border: 1px solid var(--border-color);
                border-radius: 8px;
                background: white;
                color: var(--text-light);
                font-size: 1rem;
                transition: border-color 0.3s ease, box-shadow 0.3s ease;
            }}

            [data-theme="dark"] .form-control {{
                background: var(--dark-bg);
                color: var(--text-dark);
                border-color: var(--border-color);
            }}

            .form-control:focus {{
                outline: none;
                border-color: var(--primary-color);
                box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.1);
            }}

            .form-select {{
                appearance: none;
                background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3e%3cpath stroke='%236b7280' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='m6 8 4 4 4-4'/%3e%3c/svg%3e");
                background-position: right 0.5rem center;
                background-repeat: no-repeat;
                background-size: 1.5em 1.5em;
                padding-right: 2.5rem;
            }}

            .switch {{
                position: relative;
                display: inline-block;
                width: 60px;
                height: 34px;
            }}

            .switch input {{
                opacity: 0;
                width: 0;
                height: 0;
            }}

            .slider {{
                position: absolute;
                cursor: pointer;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background-color: #ccc;
                transition: .4s;
                border-radius: 34px;
            }}

            .slider:before {{
                position: absolute;
                content: "";
                height: 26px;
                width: 26px;
                left: 4px;
                bottom: 4px;
                background-color: white;
                transition: .4s;
                border-radius: 50%;
            }}

            input:checked + .slider {{
                background-color: var(--primary-color);
            }}

            input:checked + .slider:before {{
                transform: translateX(26px);
            }}

            .btn {{
                padding: 0.75rem 1.5rem;
                border: none;
                border-radius: 8px;
                cursor: pointer;
                font-size: 1rem;
                font-weight: 500;
                text-decoration: none;
                display: inline-flex;
                align-items: center;
                gap: 8px;
                transition: all 0.3s ease;
            }}

            .btn-primary {{
                background: var(--primary-color);
                color: white;
            }}

            .btn-primary:hover {{
                background: #2980b9;
                transform: translateY(-2px);
                box-shadow: 0 4px 12px rgba(52, 152, 219, 0.3);
            }}

            .btn-success {{
                background: var(--success-color);
                color: white;
            }}

            .btn-success:hover {{
                background: #219a52;
                transform: translateY(-2px);
                box-shadow: 0 4px 12px rgba(39, 174, 96, 0.3);
            }}

            .notification {{
                position: fixed;
                top: 20px;
                right: 20px;
                background: var(--success-color);
                color: white;
                padding: 1rem 1.5rem;
                border-radius: 8px;
                box-shadow: var(--shadow);
                z-index: 10000;
                transform: translateX(400px);
                transition: transform 0.3s ease;
                max-width: 300px;
            }}

            .notification.show {{
                transform: translateX(0);
            }}

            .notification.error {{
                background: var(--danger-color);
            }}

            @media (max-width: 768px) {{
                .navbar {{
                    padding: 1rem;
                    flex-direction: column;
                    gap: 1rem;
                }}

                .navbar-nav {{
                    flex-wrap: wrap;
                    justify-content: center;
                    gap: 1rem;
                }}

                .container {{
                    padding: 1rem;
                }}

                .dashboard-header {{
                    flex-direction: column;
                    text-align: center;
                }}

                .dashboard-title {{
                    font-size: 2rem;
                }}

                .stats-grid {{
                    grid-template-columns: 1fr;
                }}

                .charts-section {{
                    grid-template-columns: 1fr;
                }}

                .settings-grid {{
                    grid-template-columns: 1fr;
                }}
            }}

            @keyframes fadeIn {{
                from {{ opacity: 0; transform: translateY(20px); }}
                to {{ opacity: 1; transform: translateY(0); }}
            }}

            .fade-in {{
                animation: fadeIn 0.5s ease;
            }}
        </style>
    </head>
    <body>
        <nav class="navbar">
            <a href="/" class="navbar-brand">
                <i class="fas fa-shield-alt"></i>
                InvictusDNS
            </a>
            <ul class="navbar-nav">
                <li><a href="/dashboard" class="nav-link"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="/monitoring/dashboard" class="nav-link"><i class="fas fa-chart-line"></i> Monitoring</a></li>
                <li><a href="/logs_manager" class="nav-link"><i class="fas fa-file-alt"></i> Logs</a></li>
                <li><a href="/ui/settings" class="nav-link active"><i class="fas fa-cog"></i> Settings</a></li>
                <li><button class="theme-toggle" onclick="toggleTheme()"><i class="fas fa-moon"></i></button></li>
            </ul>
        </nav>

        <div class="container">
            <div class="dashboard-header">
                <h1 class="dashboard-title">🎨 Enhanced Interface Settings</h1>
            </div>

            <div class="settings-panel">
                <form id="settingsForm">
                    <div class="settings-grid">
                        <div class="setting-group">
                            <h3><i class="fas fa-palette"></i> Appearance</h3>
                            <div class="form-group">
                                <label class="form-label">Theme</label>
                                <select class="form-control form-select" name="theme">
                                    <option value="light" {'selected' if ui_config.get('theme') == 'light' else ''}>Light</option>
                                    <option value="dark" {'selected' if ui_config.get('theme') == 'dark' else ''}>Dark</option>
                                    <option value="auto" {'selected' if ui_config.get('theme') == 'auto' else ''}>Auto (System)</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Language</label>
                                <select class="form-control form-select" name="language">
                                    <option value="pt-BR" {'selected' if ui_config.get('language') == 'pt-BR' else ''}>Português (Brasil)</option>
                                    <option value="en-US" {'selected' if ui_config.get('language') == 'en-US' else ''}>English (US)</option>
                                    <option value="es-ES" {'selected' if ui_config.get('language') == 'es-ES' else ''}>Español</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="switch">
                                    <input type="checkbox" name="compact_mode" {'checked' if ui_config.get('compact_mode') else ''}>
                                    <span class="slider"></span>
                                </label>
                                <span style="margin-left: 10px;">Compact Mode</span>
                            </div>
                        </div>

                        <div class="setting-group">
                            <h3><i class="fas fa-sync-alt"></i> Behavior</h3>
                            <div class="form-group">
                                <label class="switch">
                                    <input type="checkbox" name="auto_refresh" {'checked' if ui_config.get('auto_refresh') else ''}>
                                    <span class="slider"></span>
                                </label>
                                <span style="margin-left: 10px;">Auto Refresh</span>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Refresh Interval (seconds)</label>
                                <input type="number" class="form-control" name="refresh_interval" value="{ui_config.get('refresh_interval', 30)}" min="10" max="300">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Dashboard Layout</label>
                                <select class="form-control form-select" name="dashboard_layout">
                                    <option value="grid" {'selected' if ui_config.get('dashboard_layout') == 'grid' else ''}>Grid</option>
                                    <option value="list" {'selected' if ui_config.get('dashboard_layout') == 'list' else ''}>List</option>
                                    <option value="compact" {'selected' if ui_config.get('dashboard_layout') == 'compact' else ''}>Compact</option>
                                </select>
                            </div>
                        </div>

                        <div class="setting-group">
                            <h3><i class="fas fa-bell"></i> Notifications</h3>
                            <div class="form-group">
                                <label class="switch">
                                    <input type="checkbox" name="notifications_enabled" {'checked' if ui_config.get('notifications_enabled') else ''}>
                                    <span class="slider"></span>
                                </label>
                                <span style="margin-left: 10px;">Enable Notifications</span>
                            </div>
                        </div>
                    </div>

                    <div style="text-align: center; margin-top: 2rem;">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Save Settings
                        </button>
                        <button type="button" class="btn btn-success" onclick="resetSettings()">
                            <i class="fas fa-undo"></i> Reset to Defaults
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <div id="notification" class="notification">
            <i class="fas fa-check"></i>
            <span id="notification-text">Settings saved successfully!</span>
        </div>

        <script>
            function toggleTheme() {{
                const html = document.documentElement;
                const currentTheme = html.getAttribute('data-theme');
                const newTheme = currentTheme === 'dark' ? 'light' : 'dark';

                html.setAttribute('data-theme', newTheme);
                localStorage.setItem('theme', newTheme);

                const themeIcon = document.querySelector('.theme-toggle i');
                themeIcon.className = newTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
            }}

            function showNotification(message, type = 'success') {{
                const notification = document.getElementById('notification');
                const text = document.getElementById('notification-text');
                const icon = notification.querySelector('i');

                text.textContent = message;
                notification.className = `notification ${{type}} show`;

                if (type === 'error') {{
                    icon.className = 'fas fa-exclamation-triangle';
                }} else {{
                    icon.className = 'fas fa-check';
                }}

                setTimeout(() => {{
                    notification.classList.remove('show');
                }}, 3000);
            }}

            function resetSettings() {{
                if (confirm('Are you sure you want to reset all settings to defaults?')) {{
                    fetch('/ui/settings', {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify({{
                            theme: 'light',
                            language: 'pt-BR',
                            dashboard_layout: 'grid',
                            auto_refresh: true,
                            refresh_interval: 30,
                            notifications_enabled: true,
                            compact_mode: false
                        }})
                    }})
                    .then(response => response.json())
                    .then(data => {{
                        showNotification(data.message || 'Settings reset successfully!');
                        setTimeout(() => location.reload(), 1000);
                    }})
                    .catch(error => {{
                        showNotification('Error resetting settings', 'error');
                    }});
                }}
            }}

            // Load saved theme
            const savedTheme = localStorage.getItem('theme') || '{ui_config.get("theme", "light")}';
            document.documentElement.setAttribute('data-theme', savedTheme);
            const themeIcon = document.querySelector('.theme-toggle i');
            themeIcon.className = savedTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';

            // Handle form submission
            document.getElementById('settingsForm').addEventListener('submit', function(e) {{
                e.preventDefault();

                const formData = new FormData(this);
                const data = Object.fromEntries(formData);

                // Convert checkbox values
                data.auto_refresh = this.auto_refresh.checked;
                data.notifications_enabled = this.notifications_enabled.checked;
                data.compact_mode = this.compact_mode.checked;

                // Convert number values
                data.refresh_interval = parseInt(data.refresh_interval);

                fetch('/ui/settings', {{
                    method: 'POST',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify(data)
                }})
                .then(response => response.json())
                .then(data => {{
                    showNotification(data.message || 'Settings saved successfully!');
                }})
                .catch(error => {{
                    showNotification('Error saving settings', 'error');
                }});
            }});

            // Add fade-in animation
            document.addEventListener('DOMContentLoaded', function() {{
                document.body.classList.add('fade-in');
            }});
        </script>
    </body>
    </html>
    """
    return html

@app.route('/ui/preview')
def ui_preview():
    """Preview of enhanced UI components"""
    return render_template_string("""
    <!DOCTYPE html>
    <html>
    <head>
        <title>UI Components Preview</title>
        <style>
            body { font-family: Arial, sans-serif; padding: 20px; }
            .component { margin: 20px 0; padding: 20px; border: 1px solid #ddd; border-radius: 8px; }
        </style>
    </head>
    <body>
        <h1>Enhanced UI Components Preview</h1>
        <div class="component">
            <h3>Modern Cards</h3>
            <p>Cards with shadows, hover effects, and responsive design</p>
        </div>
        <div class="component">
            <h3>Interactive Charts</h3>
            <p>Real-time charts using Chart.js with smooth animations</p>
        </div>
        <div class="component">
            <h3>Theme Switching</h3>
            <p>Light/Dark mode toggle with smooth transitions</p>
        </div>
    </body>
    </html>
    """)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3007, debug=False)

# 🛡️ InvictusDNS - Sistema Completo de DNS com IA Integrada

## 📋 Visão Geral Detalhada

O **InvictusDNS** é uma solução abrangente e avançada de servidor DNS público que combina resolução inteligente de domínios, monitoramento com inteligência artificial, painéis web administrativos, backup seguro na nuvem, aplicações móveis multiplataforma e um sistema modular de agentes IA. Desenvolvido para ser totalmente cross-platform (Windows/Linux/Mac), oferece proteção avançada contra ameaças, categorização automática de conteúdo, escalabilidade via cluster e uma experiência de usuário intuitiva com IA conversacional.

### 🏗️ Arquitetura Modular
O sistema é organizado em módulos independentes que se comunicam via APIs REST e agentes IA especializados. Cada pasta representa um componente específico do ecossistema.

---

## 📁 Estrutura Detalhada das Pastas

### 🤖 `agents/` - Sistema de Agentes IA
Contém agentes especializados para diferentes funções:
- `agent_coordinator.py`: Coordena todos os agentes, gerencia comunicação e tarefas.
- `analytics_agent.py`: Análise de dados, relatórios e previsões.
- `automation_agent.py`: Automação de processos e workflows.
- `base_agent.py`: Classe base para todos os agentes.
- `communication_agent.py`: Comunicação inter-agentes e integrações externas.
- `learning_agent.py`: Aprendizado contínuo e adaptação do sistema.
- `network_agent.py`: Otimização de rede e monitoramento.
- `security_agent.py`: Detecção e resposta a ameaças.

### 🌐 `api/` - APIs REST
Interfaces de programação para integração:
- `rest_api.py`: Endpoints principais para estatísticas, controle e dados.
- `__init__.py`: Inicialização do módulo API.

### 📱 `app/` - Interfaces Web Móveis
Aplicações web responsivas:
- `index.html` e `index_new.html`: Interfaces móveis para VPN simulada e controle.

### 🔐 `auth/` - Autenticação Avançada
Sistema de segurança de acesso:
- `advanced_auth.py`: Autenticação biométrica, criptografia quântica, detecção de root/jailbreak.

### ☁️ `backup/` - Backup na Nuvem
Sistema de armazenamento seguro:
- `cloud_backup.py`: Criptografia AES, upload múltiplo, quotas por usuário.

### 🔗 `cluster/` - Gerenciamento de Cluster
Escalabilidade horizontal:
- `cluster_manager.py`: Distribuição de carga, failover, sincronização.

### ⚙️ `config/` - Configurações do Sistema
Arquivos de configuração:
- `default.json`: Configurações padrão de todos os módulos.

### 🏭 `core-services/` - Serviços Core
Serviços fundamentais em subpastas:
- `api-gateway/`: Gateway de API para roteamento.
- `auth-service/`: Serviço de autenticação centralizado.
- `dns-service/`: Serviço DNS principal.
- `user-service/`: Gerenciamento de usuários.

### 📊 `dados/` - Dados Locais
Pasta para armazenamento local (atualmente vazia, usada dinamicamente).

### 🗄️ `data/` - Bancos de Dados
Armazenamento persistente:
- `dns_logs.db`: Logs de consultas DNS.
- `marketing.db`: Dados de marketing.
- `users.db`: Usuários do sistema.
- `users/`: Subpasta para dados específicos de usuários.

### 🐳 `docker/` - Containerização
Configurações Docker:
- `ai-orchestrator.Dockerfile`: Container para orquestração IA.
- `api-gateway.Dockerfile`: Container para gateway API.
- `dns-service.Dockerfile`: Container para serviço DNS.
- `docker_setup.py`: Script de configuração Docker.
- `ml-analytics.Dockerfile`: Container para analytics ML.

### 📚 `docs/` - Documentação
Documentação técnica:
- `api_documentation.py`: Documentação automática da API.

### 📁 `InvictusDNS_Data/` - Dados do Sistema
Dados específicos do InvictusDNS:
- `dados/`: Subpasta para dados estruturados.

### ☸️ `k8s/` - Kubernetes
Orquestração em cluster:
- `configmaps.yml`: Configurações compartilhadas.
- `deployment.yml`: Deployments dos serviços.
- `ingress.yml`: Regras de entrada.
- `services.yml`: Definições de serviços.

### 📝 `logs/` - Logs do Sistema
Registros de operação:
- `ai_panel_service.log`: Logs do painel IA.
- `iniciar_tudo.log`: Logs do inicializador completo.

### 📱 `mobile_app/` - Aplicações Móveis
Apps multiplataforma:
- `flutter/`: App Flutter (Android/iOS).
- `kotlin_multiplatform/`: App Kotlin Multiplatform.
- `react_native/`: App React Native.
- `README.md`: Documentação dos apps móveis.

### 📈 `monitoring/` - Monitoramento
Sistema de observabilidade:
- `dashboard.py`: Dashboard de métricas.
- `metrics_collector.py`: Coleta de métricas.
- `ml_anomaly_detector.py`: Detecção de anomalias por ML.

### 🔔 `notifications/` - Notificações
Sistema de alertas:
- `alert_system.py`: Sistema de alertas e notificações.

### 🎛️ `panels/` - Painéis Web
Interfaces administrativas:
- `ai_panel.py`: Painel de IA com chat e controle.
- `cloud_panel.py`: Painel de backup na nuvem.
- `logs_manager.py`: Gerenciamento de logs.
- `marketing_panel.py`: Painel de marketing.
- `web_panel.py`: Painel administrativo principal.
- Versões avançadas: `ai_panel_advanced.py`, etc.

### 📜 `scripts/` - Scripts do Sistema
Automação e serviços:
- `invictus-dns.service`: Serviço systemd para DNS.
- `start_services.sh`: Script de inicialização.
- `watchdog.sh`: Monitor de processos.
- `cluster/`: Scripts para cluster.

### 🛡️ `security/` - Segurança
Proteção avançada:
- `advanced_security.py`: Módulo de segurança principal.

### 🌐 `server/` - Servidor DNS
Núcleo do DNS:
- `dns_server.py`: Servidor DNS inteligente.
- `data/`: Dados específicos do servidor.

### 🗃️ `sql/` - Scripts SQL
Banco de dados:
- `init.sql`: Inicialização do banco.

### 🧪 `tests/` - Testes
Suite de testes:
- `test_suite.py`: Testes automatizados.

### 🎨 `ui/` - Interfaces de Usuário
UI aprimorada:
- `enhanced_interface.py`: Interfaces avançadas.

### 👤 `user_data/` - Dados de Usuário
Configurações por usuário:
- `cloud_config.json`: Configurações de nuvem.

### 🔧 `utils/` - Utilitários
Ferramentas auxiliares:
- `ip_obfuscator.py`: Ofuscação de IPs.

---

## 📄 Arquivos Raiz Detalhados

### 🚀 Inicialização e Instalação
- `INICIAR_TUDO.bat` / `INICIAR_TUDO.py`: Inicializador completo do sistema.
- `installer.py`: Instalador automático.
- `launcher.py`: Launcher principal.
- `setup.bat` / `setup.sh`: Scripts de configuração.

### ⚙️ Configuração
- `.env`: Chaves de API para provedores IA.
- `.env.example`: Template das configurações.
- `ai_config.json`: Configuração específica da IA.
- `network_config.json`: Configuração de rede.

### 📋 Documentação
- `README.md`: Este arquivo (visão geral).
- `README_AI_PANEL.md`: Guia do painel IA.
- `README_CORE_SERVICES.md`: Serviços core.
- `README_INICIAR.md`: Como iniciar.
- `README_Portable.md`: Versão portable.
- `TUTORIAL_INSTALACAO.txt`: Tutorial de instalação.
- `INSTALL_GUIA_RAPIDO.md`: Instalação rápida.
- `INSTALL.md`: Instalação detalhada.

### 🐍 Dependências e Build
- `requirements.txt` / `requirements_portable.txt`: Dependências Python.
- `build_exe.py` / `build_exe_with_icon.py`: Build de executáveis.
- `create_icon.py`: Criação de ícones.

### 🗃️ Bancos e Dados
- `dns_logs.db`: Logs DNS (SQLite).
- `cookies.txt` / `cookies1.txt`: Cookies (se aplicável).

### 🔧 Utilitários
- `cleanup.py`: Limpeza do sistema.
- `deploy.py`: Script de deploy.
- `test_db.py`: Teste de bancos.
- `monitor_services.py`: Monitor de serviços.

### 🐳 Containerização
- `docker-compose.yml` / `docker-compose.core.yml`: Compose Docker.

### 📊 Monitoramento
- `architecture.md`: Documentação da arquitetura.
- `TODO.md` / `TODO1.md` / `TODO_AI_CONFIG.md`: Lista de tarefas.
- `ALL_PANELS_GUIDE.md`: Guia de todos os painéis.

---

## 🌟 Funcionalidades Principais

### 🔍 Servidor DNS Inteligente
- Resolução de domínios para IPs brasileiros específicos.
- Categorização automática: porn, game, malware, other.
- Bloqueio inteligente via painel web.
- Cache TTL de 5 minutos.
- Logs detalhados com timestamp, IP, domínio, categoria, tempo de resposta.
- Monitoramento de tráfego TCP/UDP.

### 🤖 IA Integrada Avançada
- **Painel IA (porta 3002)**: Chat conversacional, comandos automáticos, toggles para ativar/desativar provedores.
- **Agentes IA**: 7 agentes especializados para segurança, rede, aprendizado, automação, analytics, comunicação.
- **Provedores Suportados**: OpenAI, Groq, Google Gemini, Anthropic Claude, Blackbox, GLM, DeepInfra.
- **Comandos Avançados**: Executar scripts, gerenciar processos, configurar DNS, controlar todo o sistema.

### 🌐 Painéis Web Administrativos
- **Web Panel (porta 3000)**: Dashboard com estatísticas, usuários, logs, bloqueios, VPN/PPPoE, mapa de dispositivos.
- **Marketing Panel (porta 3001)**: Página promocional editável.
- **AI Panel (porta 3002)**: Controle total da IA.
- **Cloud Panel (porta 3003)**: Backup com criptografia, quotas, admin.

### 📱 Aplicações Móveis
- **Flutter**: App nativo Android/iOS com autenticação biométrica.
- **Kotlin Multiplatform**: Versão multiplataforma.
- **React Native**: Híbrida com integração completa.
- **Web App**: Interface responsiva em `/app/`.

### ☁️ Backup na Nuvem Seguro
- Criptografia AES end-to-end.
- Upload de arquivos/pastas (ZIP).
- Quotas por usuário.
- Delete/restore.

### 🔗 Cluster e Escalabilidade
- Suporte a múltiplos servidores.
- Load balancing automático.
- Failover e recuperação.

### 🛡️ Segurança Avançada
- Criptografia quântica.
- Zero logs de navegação pessoal.
- Detecção automática de ameaças.
- Rate limiting e verificações de integridade.

---

## 🚀 Instalação e Inicialização

### Pré-requisitos
- Python 3.8+
- pip
- Conexão internet para APIs IA

### Instalação Completa
```bash
python installer.py
```
Escolha opção 1 para instalação completa. O instalador:
- Instala dependências Python.
- Configura firewall (portas 53, 3000-3003).
- Cria arquivo `.env` para chaves API.
- Copia todos os arquivos para diretório de instalação.
- Cria atalhos na área de trabalho.
- Inicia o sistema automaticamente.

### Inicialização Manual
```bash
python INICIAR_TUDO.py
```
Inicia todos os componentes: DNS, painéis, IA, agentes, monitoramento.

### Configuração da IA
1. Edite `.env` com suas chaves API.
2. Acesse painel IA em http://localhost:3002.
3. Use toggles para ativar/desativar provedores.
4. Digite comandos como "execute script", "manage dns", etc.

---

## 📊 Monitoramento e Logs

### Logs em Tempo Real
- `dns_server.log`: Consultas DNS.
- `logs/iniciar_tudo.log`: Inicialização.
- `logs/ai_panel_service.log`: Atividades IA.

### Métricas Disponíveis
- Consultas DNS/segundo.
- Tráfego de rede.
- Ameaças bloqueadas.
- Performance de resposta.
- Uso de CPU/memória/disco.

---

## 🔧 APIs e Integração

### Endpoints REST Principais
- `GET /api/server_usage`: Estatísticas do servidor.
- `GET /api/connected_devices`: Dispositivos conectados.
- `POST /api/block_domain`: Bloquear domínio.
- `GET /api/dns_logs`: Logs DNS.
- `POST /api/ai/process`: Processar comando IA.

### Webhooks
Configure webhooks para notificações automáticas.

---

## 🧪 Testes

Execute testes automatizados:
```bash
python -m pytest tests/
```

---

## 🤝 Contribuição

1. Fork o projeto.
2. Crie branch para feature.
3. Commit mudanças.
4. Push e abra Pull Request.

---

## 📄 Licença

MIT License - veja LICENSE para detalhes.

---

## 📞 Suporte

- **Logs**: Verifique `logs/` para debugging.
- **Documentação**: Pasta `docs/`.
- **Issues**: GitHub Issues.

---

**InvictusDNS** - Transformando a internet em um lugar mais seguro e inteligente com IA. 🛡️✨🤖

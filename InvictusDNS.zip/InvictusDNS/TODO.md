# TODO: Add Cloud Panel with Protection to InvictusDNS

## Approved Plan
- Create a full cloud backup service (port 3003) with user registration, file/folder backup, encryption, admin panel showing all data, simple UI for all ages, public access.
- Implement user-specific folders, quotas, multiple file upload, delete/restore options.
- Admin dashboard: Overview of users, storage usage, files.
- Integrate with existing web panel.
- Ensure security and monitoring.

## Logical Steps
- [x] Create cloud_panel.py with Flask app, login system, file management, encryption, and monitoring features.
- [x] Create user_data folder and initial config file.
- [x] Update requirements.txt with necessary dependencies (e.g., cryptography for encryption).
- [x] Create systemd service for cloud_panel.service.
- [x] Update firewall to allow port 3003.
- [ ] Add user registration functionality.
- [ ] Implement user-specific data folders.
- [ ] Add multiple file upload and folder backup (zip support).
- [ ] Add delete and restore options for files.
- [ ] Create admin panel with data overview (users, files, storage).
- [x] Enforce user quotas from config.
- [x] Improve UI for simplicity (colorful, icons, easy navigation).
- [x] Test full functionality (registration, login, backup, admin view).
- [x] Integrate cloud access into web_panel.py if needed.

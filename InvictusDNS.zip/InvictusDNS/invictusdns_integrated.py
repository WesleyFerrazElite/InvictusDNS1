#!/usr/bin/env python3
"""
InvictusDNS - Sistema Integrado Completo
Inicia tudo junto: DNS Server, Painéis Web, IA Completa, Agentes, Segurança, ML
Compatível com Windows e Linux.
"""

import sys
import os
import time
import threading
import subprocess
import signal
import platform
import logging
import json
from pathlib import Path
from flask import Flask, render_template_string, request, jsonify
import sqlite3
import psutil
import socket
import requests
from datetime import datetime
import importlib.util

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/invictusdns_integrated.log'),
        logging.StreamHandler(sys.stdout)
    ]
)

class InvictusDNSIntegrated:
    """
    Sistema InvictusDNS completamente integrado
    """

    def __init__(self):
        self.logger = logging.getLogger("InvictusDNS.Integrated")
        self.running = False
        self.threads = []
        self.processes = []
        self.flask_apps = {}

        # Configurações
        self.config = self._load_config()
        self._setup_environment()

    def _load_config(self):
        """Carrega configuração integrada"""
        config_path = 'config/integrated_config.json'
        if os.path.exists(config_path):
            with open(config_path, 'r') as f:
                return json.load(f)

        # Configuração padrão integrada
        return {
            'system': {
                'name': 'InvictusDNS Integrated AI System',
                'version': '2.0.0',
                'auto_start': True
            },
            'dns_server': {
                'enabled': True,
                'port': 53,
                'host': '0.0.0.0'
            },
            'panels': {
                'web_admin': {'enabled': True, 'port': 3000, 'name': 'Painel Admin'},
                'ai_panel': {'enabled': True, 'port': 3002, 'name': 'Painel IA'},
                'marketing': {'enabled': True, 'port': 3001, 'name': 'Painel Marketing'},
                'cloud': {'enabled': True, 'port': 3003, 'name': 'Painel Cloud'}
            },
            'ai_system': {
                'enabled': True,
                'ai_core': True,
                'agents': True,
                'security': True,
                'ml_anomaly': True,
                'automation': True
            },
            'monitoring': {
                'enabled': True,
                'interval': 30
            }
        }

    def _setup_environment(self):
        """Configura ambiente necessário"""
        # Criar diretórios
        dirs = ['logs', 'data', 'config', 'models', 'temp']
        for d in dirs:
            Path(d).mkdir(exist_ok=True)

        # Salvar configuração
        with open('config/integrated_config.json', 'w') as f:
            json.dump(self.config, f, indent=2)

    def start(self):
        """Inicia o sistema integrado completo"""
        try:
            self.logger.info("=== INVictusDNS Sistema Integrado Iniciando ===")
            self.running = True

            # Inicializar componentes em ordem de dependência
            self._init_database()
            self._init_ai_system()
            self._start_dns_server()
            self._start_web_panels()
            self._start_monitoring()

            self.logger.info("Sistema InvictusDNS totalmente integrado iniciado!")
            self.logger.info("Acesse os painéis:")
            for panel, config in self.config['panels'].items():
                if config['enabled']:
                    self.logger.info(f"- {config['name']}: http://localhost:{config['port']}")

            # Manter sistema rodando
            self._main_loop()

        except Exception as e:
            self.logger.error(f"Erro ao iniciar sistema: {e}")
            self.stop()
            raise

    def _init_database(self):
        """Inicializa banco de dados"""
        self.logger.info("Inicializando banco de dados...")
        try:
            # Importar e executar inicialização do DNS server
            spec = importlib.util.spec_from_file_location("dns_server", "server/dns_server.py")
            dns_module = importlib.util.module_from_spec(spec)

            # Executar apenas a função init_db
            spec.loader.exec_module(dns_module)
            dns_module.init_db()

            self.logger.info("Banco de dados inicializado")
        except Exception as e:
            self.logger.error(f"Erro ao inicializar banco: {e}")

    def _init_ai_system(self):
        """Inicializa sistema completo de IA"""
        if not self.config['ai_system']['enabled']:
            return

        self.logger.info("Inicializando sistema de IA completo...")

        try:
            # AI Core
            if self.config['ai_system']['ai_core']:
                self.logger.info("Iniciando AI Core...")
                from ai_core import initialize_ai_core
                ai_config = {'online_learning': True, 'continuous_learning': True}
                initialize_ai_core(ai_config)

            # Agentes
            if self.config['ai_system']['agents']:
                self.logger.info("Iniciando sistema de agentes...")
                from agents import initialize_agent_system
                agent_config = {'coordination_interval': 30, 'auto_scaling': True}
                initialize_agent_system(agent_config)

            # Segurança Avançada
            if self.config['ai_system']['security']:
                self.logger.info("Iniciando segurança avançada...")
                # Já inicializada automaticamente pelos módulos

            # ML Anomaly Detector
            if self.config['ai_system']['ml_anomaly']:
                self.logger.info("Iniciando ML Anomaly Detector...")
                from monitoring.ml_anomaly_detector import anomaly_detector
                # Treinar modelo se necessário
                if not os.path.exists('models/anomaly_detector.pkl'):
                    anomaly_detector.train_model()

            # Automação
            if self.config['ai_system']['automation']:
                self.logger.info("Iniciando sistema de automação...")

            self.logger.info("Sistema de IA completamente inicializado")

        except Exception as e:
            self.logger.error(f"Erro ao inicializar IA: {e}")

    def _start_dns_server(self):
        """Inicia servidor DNS"""
        if not self.config['dns_server']['enabled']:
            return

        self.logger.info("Iniciando servidor DNS...")

        def dns_thread():
            try:
                # Importar e executar servidor DNS
                spec = importlib.util.spec_from_file_location("dns_server", "server/dns_server.py")
                dns_module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(dns_module)

                # Substituir main loop para thread
                dns_module.dns_server()

            except Exception as e:
                self.logger.error(f"Erro no servidor DNS: {e}")

        thread = threading.Thread(target=dns_thread, daemon=True, name="DNS_Server")
        thread.start()
        self.threads.append(thread)

        # Aguardar inicialização
        time.sleep(2)
        self.logger.info("Servidor DNS iniciado na porta 53")

    def _start_web_panels(self):
        """Inicia todos os painéis web"""
        self.logger.info("Iniciando painéis web...")

        # Painel Admin (porta 3000)
        if self.config['panels']['web_admin']['enabled']:
            self._start_panel('web_panel', 3000, "Painel Admin")

        # Painel IA (porta 3002)
        if self.config['panels']['ai_panel']['enabled']:
            self._start_panel('ai_panel', 3002, "Painel IA")

        # Painel Marketing (porta 3001)
        if self.config['panels']['marketing']['enabled']:
            self._start_panel('marketing_panel', 3001, "Painel Marketing")

        # Painel Cloud (porta 3003)
        if self.config['panels']['cloud']['enabled']:
            self._start_panel('cloud_panel', 3003, "Painel Cloud")

    def _start_panel(self, panel_name, port, display_name):
        """Inicia um painel específico"""
        try:
            panel_path = f"panels/{panel_name}.py"

            if not os.path.exists(panel_path):
                self.logger.warning(f"Painel {panel_name} não encontrado: {panel_path}")
                return

            def panel_thread():
                try:
                    # Executar painel em subprocesso para isolamento
                    if platform.system() == 'Windows':
                        cmd = [sys.executable, panel_path]
                    else:
                        cmd = ['python3', panel_path]

                    self.logger.info(f"Iniciando {display_name} na porta {port}")
                    process = subprocess.Popen(
                        cmd,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        cwd=os.getcwd()
                    )

                    self.processes.append((display_name, process))

                    # Aguardar um pouco para ver se iniciou
                    time.sleep(3)
                    if process.poll() is None:
                        self.logger.info(f"{display_name} iniciado com sucesso (PID: {process.pid})")
                    else:
                        stdout, stderr = process.communicate()
                        self.logger.error(f"Erro ao iniciar {display_name}:")
                        if stdout:
                            self.logger.error(f"STDOUT: {stdout.decode()}")
                        if stderr:
                            self.logger.error(f"STDERR: {stderr.decode()}")

                except Exception as e:
                    self.logger.error(f"Erro na thread do {display_name}: {e}")

            thread = threading.Thread(target=panel_thread, daemon=True, name=f"{panel_name}_thread")
            thread.start()
            self.threads.append(thread)

        except Exception as e:
            self.logger.error(f"Erro ao iniciar {display_name}: {e}")

    def _start_monitoring(self):
        """Inicia sistema de monitoramento"""
        if not self.config['monitoring']['enabled']:
            return

        self.logger.info("Iniciando monitoramento do sistema...")

        def monitoring_thread():
            while self.running:
                try:
                    self._check_system_health()
                    time.sleep(self.config['monitoring']['interval'])
                except Exception as e:
                    self.logger.error(f"Erro no monitoramento: {e}")
                    time.sleep(30)

        thread = threading.Thread(target=monitoring_thread, daemon=True, name="Monitoring")
        thread.start()
        self.threads.append(thread)

    def _check_system_health(self):
        """Verifica saúde do sistema"""
        try:
            health_info = {
                'timestamp': datetime.now().isoformat(),
                'cpu_percent': psutil.cpu_percent(),
                'memory_percent': psutil.virtual_memory().percent,
                'disk_percent': psutil.disk_usage('/').percent,
                'threads_active': len(self.threads),
                'processes_active': len([p for _, p in self.processes if p.poll() is None])
            }

            # Verificar se painéis estão respondendo
            for panel, config in self.config['panels'].items():
                if config['enabled']:
                    port = config['port']
                    try:
                        # Testar conexão local
                        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                        sock.settimeout(1)
                        result = sock.connect_ex(('127.0.0.1', port))
                        health_info[f'{panel}_status'] = 'online' if result == 0 else 'offline'
                        sock.close()
                    except:
                        health_info[f'{panel}_status'] = 'error'

            # Log se houver problemas
            if health_info['cpu_percent'] > 90:
                self.logger.warning(f"CPU alta: {health_info['cpu_percent']:.1f}%")
            if health_info['memory_percent'] > 85:
                self.logger.warning(f"Memória alta: {health_info['memory_percent']:.1f}%")
            # Verificar processos caídos
            for name, process in self.processes[:]:
                if process.poll() is not None:
                    self.logger.error(f"Processo {name} parou inesperadamente")
                    self.processes.remove((name, process))

            # Salvar status em arquivo
            with open('logs/system_health.json', 'w') as f:
                json.dump(health_info, f, indent=2)

        except Exception as e:
            self.logger.error(f"Erro na verificação de saúde: {e}")

    def _main_loop(self):
        """Loop principal do sistema integrado"""
        try:
            while self.running:
                # Verificar saúde geral
                time.sleep(10)

                # Log status periódico
                if int(time.time()) % 300 == 0:  # A cada 5 minutos
                    self.logger.info("Sistema InvictusDNS rodando - Status OK")

        except KeyboardInterrupt:
            self.logger.info("Interrupção recebida, parando sistema...")
            self.stop()

    def stop(self):
        """Para o sistema integrado completo"""
        self.logger.info("Parando sistema InvictusDNS integrado...")
        self.running = False

        # Parar processos
        for name, process in self.processes:
            try:
                self.logger.info(f"Parando {name}...")
                process.terminate()
                process.wait(timeout=5)
                self.logger.info(f"{name} parado")
            except subprocess.TimeoutExpired:
                self.logger.warning(f"Forçando parada de {name}")
                process.kill()
            except Exception as e:
                self.logger.error(f"Erro ao parar {name}: {e}")

        # Aguardar threads
        for thread in self.threads:
            if thread.is_alive():
                thread.join(timeout=2)

        self.logger.info("Sistema InvictusDNS integrado parado completamente")

def main():
    """Ponto de entrada principal"""
    print("InvictusDNS - Sistema Integrado Completo")
    print("=" * 50)
    print("Este comando inicia TUDO junto:")
    print("- Servidor DNS (porta 53)")
    print("- Painel Admin (porta 3000)")
    print("- Painel IA (porta 3002)")
    print("- Painel Marketing (porta 3001)")
    print("- Painel Cloud (porta 3003)")
    print("- Sistema de IA completo (AI Core, Agentes, Segurança, ML)")
    print("=" * 50)

    # Verificar se estamos no diretório correto
    if not os.path.exists('server/dns_server.py'):
        print("Erro: Execute este comando do diretório raiz do InvictusDNS")
        sys.exit(1)

    # Criar instância e iniciar
    system = InvictusDNSIntegrated()

    try:
        system.start()
    except KeyboardInterrupt:
        system.stop()
    except Exception as e:
        print(f"Erro fatal: {e}")
        system.stop()
        sys.exit(1)

if __name__ == '__main__':
    main()

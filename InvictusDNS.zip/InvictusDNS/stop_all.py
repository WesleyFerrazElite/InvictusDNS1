#!/usr/bin/env python3
"""
InvictusDNS - Parar Todos os Serviços
Para todos os processos relacionados ao InvictusDNS.
Compatível com Windows e Linux.
"""

import subprocess
import sys
import os
import signal
import platform

def kill_process_by_name(name, command):
    """Mata processos por nome de comando"""
    try:
        if platform.system() == 'Windows':
            # No Windows, usar taskkill
            result = subprocess.run(['tasklist', '/FI', f'IMAGENAME eq {name}'], capture_output=True, text=True)
            if 'python.exe' in result.stdout:
                subprocess.run(['taskkill', '/F', '/IM', name], check=True)
                print(f"Processo {name} terminado.")
        else:
            # No Linux/Mac, usar pkill
            subprocess.run(['pkill', '-f', command], check=True)
            print(f"Processos com '{command}' terminados.")
    except subprocess.CalledProcessError:
        print(f"Nenhum processo encontrado para '{command}'.")
    except Exception as e:
        print(f"Erro ao terminar processos: {e}")

def main():
    print("InvictusDNS - Parando Todos os Serviços...")

    # Parar processos Python relacionados ao InvictusDNS
    kill_process_by_name('python.exe', 'dns_server.py')
    kill_process_by_name('python.exe', 'web_panel.py')
    kill_process_by_name('python.exe', 'marketing_panel.py')
    kill_process_by_name('python.exe', 'cloud_panel.py')
    kill_process_by_name('python.exe', 'ai_panel.py')

    # Também tentar matar por porta (se netstat estiver disponível)
    try:
        if platform.system() == 'Windows':
            # Verificar portas no Windows
            ports = ['3000', '3001', '3002', '3003', '53']
            for port in ports:
                result = subprocess.run(['netstat', '-ano'], capture_output=True, text=True)
                for line in result.stdout.split('\n'):
                    if f':{port} ' in line and 'LISTENING' in line:
                        pid = line.split()[-1]
                        subprocess.run(['taskkill', '/F', '/PID', pid], check=True)
                        print(f"Processo na porta {port} (PID {pid}) terminado.")
        else:
            # No Linux, usar fuser ou ss
            ports = ['3000', '3001', '3002', '3003', '53']
            for port in ports:
                try:
                    subprocess.run(['fuser', '-k', f'{port}/tcp'], check=True)
                    print(f"Processos na porta {port} terminados.")
                except subprocess.CalledProcessError:
                    pass
    except Exception as e:
        print(f"Aviso: Não foi possível verificar portas: {e}")

    print("Todos os serviços do InvictusDNS foram parados.")

if __name__ == '__main__':
    main()

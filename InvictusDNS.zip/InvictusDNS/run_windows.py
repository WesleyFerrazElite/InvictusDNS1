import os
import sys
import subprocess
import threading
import time
import socket
import psutil
import requests

def get_local_ip():
    """Obtém o IP local da máquina."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return "127.0.0.1"

def get_public_ip():
    """Obtém o IP público da máquina."""
    try:
        response = requests.get('https://api.ipify.org?format=json')
        return response.json()['ip']
    except:
        return "Não detectado"

def start_dns_server():
    """Inicia o servidor DNS."""
    print("Iniciando servidor DNS...")
    try:
        subprocess.Popen([sys.executable, "server/dns_server.py"])
        print("Servidor DNS iniciado na porta 53.")
    except Exception as e:
        print(f"Erro ao iniciar DNS server: {e}")

def start_web_panel():
    """Inicia o painel web."""
    print("Iniciando painel web...")
    try:
        subprocess.Popen([sys.executable, "panels/web_panel.py"])
        print("Painel web iniciado na porta 3000.")
    except Exception as e:
        print(f"Erro ao iniciar web panel: {e}")

def start_logs_manager():
    """Inicia o gerenciador de logs."""
    print("Iniciando gerenciador de logs...")
    try:
        subprocess.Popen([sys.executable, "panels/logs_manager.py"])
        print("Gerenciador de logs iniciado na porta 3004.")
    except Exception as e:
        print(f"Erro ao iniciar logs manager: {e}")

def start_marketing_panel():
    """Inicia o painel de marketing."""
    print("Iniciando painel de marketing...")
    try:
        subprocess.Popen([sys.executable, "panels/marketing_panel.py"])
        print("Painel de marketing iniciado na porta 3001.")
    except Exception as e:
        print(f"Erro ao iniciar marketing panel: {e}")

def start_ai_panel():
    """Inicia o painel de IA."""
    print("Iniciando painel de IA...")
    try:
        subprocess.Popen([sys.executable, "panels/ai_panel.py"])
        print("Painel de IA iniciado na porta 3002.")
    except Exception as e:
        print(f"Erro ao iniciar AI panel: {e}")

def start_cloud_panel():
    """Inicia o painel de nuvem."""
    print("Iniciando painel de nuvem...")
    try:
        subprocess.Popen([sys.executable, "panels/cloud_panel.py"])
        print("Painel de nuvem iniciado na porta 3003.")
    except Exception as e:
        print(f"Erro ao iniciar cloud panel: {e}")

def monitor_services():
    """Monitora os serviços e reinicia se necessário."""
    services = {
        "dns_server.py": start_dns_server,
        "web_panel.py": start_web_panel,
        "marketing_panel.py": start_marketing_panel,
        "ai_panel.py": start_ai_panel,
        "cloud_panel.py": start_cloud_panel
    }

    cleanup_counter = 0

    while True:
        for script, start_func in services.items():
            found = False
            for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
                try:
                    if proc.info['cmdline'] and script in ' '.join(proc.info['cmdline']):
                        found = True
                        break
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            if not found:
                print(f"Reiniciando {script}...")
                start_func()

        # Executar limpeza a cada 24 horas (86400 segundos / 10 = 8640 iterações)
        cleanup_counter += 1
        if cleanup_counter >= 8640:
            print("Executando limpeza automática de logs antigos...")
            try:
                subprocess.run([sys.executable, "cleanup.py"], check=True)
            except subprocess.CalledProcessError as e:
                print(f"Erro na limpeza: {e}")
            cleanup_counter = 0

        time.sleep(10)

def create_data_structure():
    """Cria a estrutura de dados na área de trabalho."""
    desktop_dir = os.path.expanduser('~/Desktop')
    data_dir = os.path.join(desktop_dir, 'InvictusDNS_Data')

    # Criar diretórios principais
    os.makedirs(os.path.join(data_dir, 'dados'), exist_ok=True)
    os.makedirs(os.path.join(data_dir, 'logs'), exist_ok=True)
    os.makedirs(os.path.join(data_dir, 'data_backup'), exist_ok=True)
    os.makedirs(os.path.join(data_dir, 'dados', 'users'), exist_ok=True)

    print(f"📁 Estrutura de dados criada em: {data_dir}")

def main():
    print("InvictusDNS - Iniciando serviços...")
    create_data_structure()
    local_ip = get_local_ip()
    public_ip = get_public_ip()
    print(f"IP local detectado: {local_ip}")
    print(f"IP público detectado: {public_ip}")
    print("Configure seu dispositivo ou roteador para usar este IP como DNS primário.")
    print("Para acesso público, configure o port forwarding nas portas 53, 3000-3004.")
    print("📁 Todos os dados serão salvos na pasta 'InvictusDNS_Data' da área de trabalho.")

    # Iniciar todos os serviços
    start_dns_server()
    time.sleep(2)
    start_web_panel()
    time.sleep(2)
    start_logs_manager()
    time.sleep(2)
    start_marketing_panel()
    time.sleep(2)
    start_ai_panel()
    time.sleep(2)
    start_cloud_panel()
    time.sleep(2)

    print("\nTodos os serviços iniciados!")
    print("Acesse:")
    print("- Painel Web: http://localhost:3000 (login: admin/senha123)")
    print("- Gerenciador de Logs: http://localhost:3004")
    print("- Painel Marketing: http://localhost:3001")
    print("- Painel IA: http://localhost:3002")
    print("- Painel Nuvem: http://localhost:3003")
    print("\nO InvictusDNS está rodando. Configure seu dispositivo para usar este IP como DNS.")
    print("Pressione Ctrl+C para parar.")

    # Iniciar monitoramento em thread separada
    monitor_thread = threading.Thread(target=monitor_services, daemon=True)
    monitor_thread.start()

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nParando serviços...")
        for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
            try:
                if proc.info['cmdline'] and any(s in ' '.join(proc.info['cmdline']) for s in ["dns_server.py", "web_panel.py", "logs_manager.py", "marketing_panel.py", "ai_panel.py", "cloud_panel.py"]):
                    proc.terminate()
                    print(f"Serviço {proc.info['name']} parado.")
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        print("InvictusDNS parado. Até logo!")

if __name__ == "__main__":
    main()

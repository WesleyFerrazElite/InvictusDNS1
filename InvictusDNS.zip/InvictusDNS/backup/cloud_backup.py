import os
import json
import sqlite3
import zipfile
import tempfile
import shutil
from datetime import datetime, timedelta
from pathlib import Path
import threading
import time
import boto3
from google.cloud import storage
from onedrive.api import OneDriveAPI
import dropbox
from cryptography.fernet import Fernet
import base64
import hashlib

DESKTOP_DIR = os.path.expanduser('~/Desktop')
BACKUP_CONFIG_FILE = os.path.join(DESKTOP_DIR, 'InvictusDNS_Data', 'dados', 'backup_config.json')
BACKUP_DIR = os.path.join(DESKTOP_DIR, 'InvictusDNS_Data', 'backup')

class BackupManager:
    def __init__(self):
        self.config = self.load_backup_config()
        self.encryption_key = self.generate_encryption_key()
        self.cipher = Fernet(self.encryption_key)
        self.running = False

        # Ensure backup directory exists
        os.makedirs(BACKUP_DIR, exist_ok=True)

    def generate_encryption_key(self):
        """Generate or load encryption key"""
        key_file = os.path.join(BACKUP_DIR, '.backup_key')

        if os.path.exists(key_file):
            with open(key_file, 'rb') as f:
                return f.read()
        else:
            key = Fernet.generate_key()
            with open(key_file, 'wb') as f:
                f.write(key)
            return key

    def load_backup_config(self):
        """Load backup configuration"""
        default_config = {
            'enabled': True,
            'schedule': {
                'daily': True,
                'weekly': True,
                'monthly': True,
                'time': '03:00'  # 3 AM
            },
            'retention': {
                'daily': 7,    # Keep 7 daily backups
                'weekly': 4,   # Keep 4 weekly backups
                'monthly': 12  # Keep 12 monthly backups
            },
            'providers': {
                'local': {
                    'enabled': True,
                    'path': BACKUP_DIR
                },
                'aws_s3': {
                    'enabled': False,
                    'bucket': '',
                    'region': 'us-east-1',
                    'access_key': '',
                    'secret_key': ''
                },
                'google_drive': {
                    'enabled': False,
                    'credentials_file': '',
                    'folder_id': ''
                },
                'onedrive': {
                    'enabled': False,
                    'client_id': '',
                    'client_secret': '',
                    'folder_path': 'InvictusDNS_Backups'
                },
                'dropbox': {
                    'enabled': False,
                    'access_token': '',
                    'folder_path': '/InvictusDNS_Backups'
                }
            },
            'encryption': {
                'enabled': True,
                'algorithm': 'AES256'
            },
            'compression': {
                'enabled': True,
                'level': 6  # 1-9, 6 is default
            },
            'include': {
                'database': True,
                'logs': True,
                'config': True,
                'user_data': True
            },
            'exclude_patterns': [
                '*.tmp',
                '*.log.old',
                'cache/*'
            ]
        }

        if os.path.exists(BACKUP_CONFIG_FILE):
            with open(BACKUP_CONFIG_FILE, 'r') as f:
                loaded_config = json.load(f)
                # Merge with defaults
                for key, value in default_config.items():
                    if key not in loaded_config:
                        loaded_config[key] = value
                return loaded_config
        else:
            self.save_backup_config(default_config)
            return default_config

    def save_backup_config(self, config):
        """Save backup configuration"""
        os.makedirs(os.path.dirname(BACKUP_CONFIG_FILE), exist_ok=True)
        with open(BACKUP_CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=4)

    def create_backup(self, backup_type='manual', name=None):
        """Create a backup"""
        if not self.config['enabled']:
            return {'error': 'Backup is disabled'}

        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_name = name or f"backup_{backup_type}_{timestamp}"

        try:
            # Create temporary directory for backup
            with tempfile.TemporaryDirectory() as temp_dir:
                backup_path = os.path.join(temp_dir, f"{backup_name}.zip")

                # Collect files to backup
                files_to_backup = self.collect_backup_files()

                # Create encrypted zip archive
                with zipfile.ZipFile(backup_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                    for file_path, arcname in files_to_backup:
                        if self.config['encryption']['enabled']:
                            # Encrypt file content
                            with open(file_path, 'rb') as f:
                                data = f.read()
                            encrypted_data = self.cipher.encrypt(data)
                            zipf.writestr(arcname + '.enc', encrypted_data)
                        else:
                            zipf.write(file_path, arcname)

                # Calculate backup size
                backup_size = os.path.getsize(backup_path)

                # Upload to configured providers
                upload_results = self.upload_backup(backup_path, backup_name)

                # Store backup metadata
                metadata = {
                    'name': backup_name,
                    'type': backup_type,
                    'created_at': datetime.now().isoformat(),
                    'size': backup_size,
                    'files_count': len(files_to_backup),
                    'encryption': self.config['encryption']['enabled'],
                    'compression': self.config['compression']['enabled'],
                    'providers': upload_results
                }

                self.store_backup_metadata(metadata)

                # Clean up old backups
                self.cleanup_old_backups()

                return {
                    'success': True,
                    'backup_name': backup_name,
                    'size': backup_size,
                    'files_count': len(files_to_backup),
                    'providers': upload_results
                }

        except Exception as e:
            return {'error': f'Backup creation failed: {str(e)}'}

    def collect_backup_files(self):
        """Collect files to include in backup"""
        files_to_backup = []
        base_path = os.path.join(DESKTOP_DIR, 'InvictusDNS_Data')

        if self.config['include']['database']:
            # Add database files
            db_files = [
                'dados/dns_logs.db',
                'dados/users.db',
                'dados/cluster.db',
                'dados/backup_config.json'
            ]
            for db_file in db_files:
                full_path = os.path.join(base_path, db_file)
                if os.path.exists(full_path):
                    files_to_backup.append((full_path, db_file))

        if self.config['include']['logs']:
            # Add log files
            logs_dir = os.path.join(base_path, 'logs')
            if os.path.exists(logs_dir):
                for root, dirs, files in os.walk(logs_dir):
                    for file in files:
                        if not any(file.endswith(pattern.strip('*')) for pattern in self.config['exclude_patterns']):
                            full_path = os.path.join(root, file)
                            rel_path = os.path.relpath(full_path, base_path)
                            files_to_backup.append((full_path, rel_path))

        if self.config['include']['config']:
            # Add configuration files
            config_files = [
                'dados/ui_config.json',
                'dados/cluster_config.json',
                'dados/backup_config.json'
            ]
            for config_file in config_files:
                full_path = os.path.join(base_path, config_file)
                if os.path.exists(full_path):
                    files_to_backup.append((full_path, config_file))

        if self.config['include']['user_data']:
            # Add user data
            user_data_dir = os.path.join(base_path, 'user_data')
            if os.path.exists(user_data_dir):
                for root, dirs, files in os.walk(user_data_dir):
                    for file in files:
                        full_path = os.path.join(root, file)
                        rel_path = os.path.relpath(full_path, base_path)
                        files_to_backup.append((full_path, rel_path))

        return files_to_backup

    def upload_backup(self, backup_path, backup_name):
        """Upload backup to configured providers"""
        results = {}

        # Local storage
        if self.config['providers']['local']['enabled']:
            local_path = os.path.join(self.config['providers']['local']['path'], f"{backup_name}.zip")
            try:
                shutil.copy2(backup_path, local_path)
                results['local'] = {'status': 'success', 'path': local_path}
            except Exception as e:
                results['local'] = {'status': 'error', 'error': str(e)}

        # AWS S3
        if self.config['providers']['aws_s3']['enabled']:
            try:
                s3_client = boto3.client(
                    's3',
                    aws_access_key_id=self.config['providers']['aws_s3']['access_key'],
                    aws_secret_access_key=self.config['providers']['aws_s3']['secret_key'],
                    region_name=self.config['providers']['aws_s3']['region']
                )

                bucket = self.config['providers']['aws_s3']['bucket']
                key = f"backups/{backup_name}.zip"

                s3_client.upload_file(backup_path, bucket, key)
                results['aws_s3'] = {'status': 'success', 'bucket': bucket, 'key': key}

            except Exception as e:
                results['aws_s3'] = {'status': 'error', 'error': str(e)}

        # Google Drive
        if self.config['providers']['google_drive']['enabled']:
            try:
                from google.oauth2 import service_account
                from googleapiclient.discovery import build
                from googleapiclient.http import MediaFileUpload

                credentials = service_account.Credentials.from_service_account_file(
                    self.config['providers']['google_drive']['credentials_file']
                )

                service = build('drive', 'v3', credentials=credentials)

                file_metadata = {
                    'name': f"{backup_name}.zip",
                    'parents': [self.config['providers']['google_drive']['folder_id']]
                }

                media = MediaFileUpload(backup_path, mimetype='application/zip')
                file = service.files().create(body=file_metadata, media_body=media, fields='id').execute()

                results['google_drive'] = {'status': 'success', 'file_id': file.get('id')}

            except Exception as e:
                results['google_drive'] = {'status': 'error', 'error': str(e)}

        # OneDrive
        if self.config['providers']['onedrive']['enabled']:
            try:
                api = OneDriveAPI(
                    client_id=self.config['providers']['onedrive']['client_id'],
                    client_secret=self.config['providers']['onedrive']['client_secret']
                )

                folder_path = self.config['providers']['onedrive']['folder_path']
                file_path = f"{folder_path}/{backup_name}.zip"

                with open(backup_path, 'rb') as f:
                    api.upload_file(file_path, f)

                results['onedrive'] = {'status': 'success', 'path': file_path}

            except Exception as e:
                results['onedrive'] = {'status': 'error', 'error': str(e)}

        # Dropbox
        if self.config['providers']['dropbox']['enabled']:
            try:
                dbx = dropbox.Dropbox(self.config['providers']['dropbox']['access_token'])

                folder_path = self.config['providers']['dropbox']['folder_path']
                file_path = f"{folder_path}/{backup_name}.zip"

                with open(backup_path, 'rb') as f:
                    dbx.files_upload(f.read(), file_path)

                results['dropbox'] = {'status': 'success', 'path': file_path}

            except Exception as e:
                results['dropbox'] = {'status': 'error', 'error': str(e)}

        return results

    def restore_backup(self, backup_name, provider='local'):
        """Restore from backup"""
        try:
            # Download backup if from cloud provider
            backup_path = self.download_backup(backup_name, provider)

            if not backup_path:
                return {'error': 'Failed to download backup'}

            # Extract backup
            extract_dir = tempfile.mkdtemp()

            with zipfile.ZipFile(backup_path, 'r') as zipf:
                for member in zipf.namelist():
                    if member.endswith('.enc'):
                        # Decrypt file
                        encrypted_data = zipf.read(member)
                        decrypted_data = self.cipher.decrypt(encrypted_data)
                        output_path = os.path.join(extract_dir, member[:-4])  # Remove .enc extension
                        os.makedirs(os.path.dirname(output_path), exist_ok=True)
                        with open(output_path, 'wb') as f:
                            f.write(decrypted_data)
                    else:
                        zipf.extract(member, extract_dir)

            # Restore files
            base_path = os.path.join(DESKTOP_DIR, 'InvictusDNS_Data')
            restored_files = []

            for root, dirs, files in os.walk(extract_dir):
                for file in files:
                    src_path = os.path.join(root, file)
                    rel_path = os.path.relpath(src_path, extract_dir)
                    dst_path = os.path.join(base_path, rel_path)

                    os.makedirs(os.path.dirname(dst_path), exist_ok=True)
                    shutil.copy2(src_path, dst_path)
                    restored_files.append(rel_path)

            # Cleanup
            shutil.rmtree(extract_dir)
            if os.path.exists(backup_path):
                os.unlink(backup_path)

            return {
                'success': True,
                'files_restored': len(restored_files),
                'files': restored_files
            }

        except Exception as e:
            return {'error': f'Restore failed: {str(e)}'}

    def download_backup(self, backup_name, provider):
        """Download backup from provider"""
        if provider == 'local':
            backup_path = os.path.join(self.config['providers']['local']['path'], f"{backup_name}.zip")
            if os.path.exists(backup_path):
                return backup_path
        # Implement cloud downloads as needed
        return None

    def store_backup_metadata(self, metadata):
        """Store backup metadata"""
        metadata_file = os.path.join(BACKUP_DIR, 'backups.json')

        if os.path.exists(metadata_file):
            with open(metadata_file, 'r') as f:
                backups = json.load(f)
        else:
            backups = []

        backups.append(metadata)

        with open(metadata_file, 'w') as f:
            json.dump(backups, f, indent=4)

    def list_backups(self):
        """List all backups"""
        metadata_file = os.path.join(BACKUP_DIR, 'backups.json')

        if os.path.exists(metadata_file):
            with open(metadata_file, 'r') as f:
                return json.load(f)
        return []

    def cleanup_old_backups(self):
        """Clean up old backups based on retention policy"""
        backups = self.list_backups()

        # Group by type
        daily_backups = [b for b in backups if b['type'] == 'daily']
        weekly_backups = [b for b in backups if b['type'] == 'weekly']
        monthly_backups = [b for b in backups if b['type'] == 'monthly']

        # Sort by creation date (newest first)
        daily_backups.sort(key=lambda x: x['created_at'], reverse=True)
        weekly_backups.sort(key=lambda x: x['created_at'], reverse=True)
        monthly_backups.sort(key=lambda x: x['created_at'], reverse=True)

        # Remove old backups
        to_remove = []

        if len(daily_backups) > self.config['retention']['daily']:
            to_remove.extend(daily_backups[self.config['retention']['daily']:])

        if len(weekly_backups) > self.config['retention']['weekly']:
            to_remove.extend(weekly_backups[self.config['retention']['weekly']:])

        if len(monthly_backups) > self.config['retention']['monthly']:
            to_remove.extend(monthly_backups[self.config['retention']['monthly']:])

        # Remove from storage
        for backup in to_remove:
            self.delete_backup(backup['name'])

        # Update metadata
        current_backups = [b for b in backups if b not in to_remove]
        metadata_file = os.path.join(BACKUP_DIR, 'backups.json')
        with open(metadata_file, 'w') as f:
            json.dump(current_backups, f, indent=4)

    def delete_backup(self, backup_name):
        """Delete a backup"""
        # Remove from local storage
        local_path = os.path.join(self.config['providers']['local']['path'], f"{backup_name}.zip")
        if os.path.exists(local_path):
            os.unlink(local_path)

        # Implement cloud deletion as needed

    def start_scheduler(self):
        """Start backup scheduler"""
        self.running = True
        scheduler_thread = threading.Thread(target=self.scheduler_loop, daemon=True)
        scheduler_thread.start()

    def stop_scheduler(self):
        """Stop backup scheduler"""
        self.running = False

    def scheduler_loop(self):
        """Main scheduler loop"""
        while self.running:
            now = datetime.now()
            schedule_time = self.config['schedule']['time']

            # Check if it's time for scheduled backups
            if now.strftime('%H:%M') == schedule_time:
                # Daily backup
                if self.config['schedule']['daily']:
                    self.create_backup('daily')

                # Weekly backup (Sundays)
                if self.config['schedule']['weekly'] and now.weekday() == 6:
                    self.create_backup('weekly')

                # Monthly backup (1st of month)
                if self.config['schedule']['monthly'] and now.day == 1:
                    self.create_backup('monthly')

                # Wait for next day
                time.sleep(86400)  # 24 hours
            else:
                # Check again in 1 minute
                time.sleep(60)

# Global backup manager instance
backup_manager = BackupManager()

if __name__ == '__main__':
    # Test backup functionality
    result = backup_manager.create_backup('test')
    print("Backup result:", result)

#!/bin/bash
# InvictusDNS Setup Script for Linux/macOS
# Execute com sudo para instalação completa

set -e  # Exit on any error

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Banner
echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║                    INVICTUS DNS - SETUP                      ║"
echo "║              Instalador Linux/macOS com IA Integrada        ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""

# Verificar se está executando como root/sudo
if [[ $EUID -eq 0 ]]; then
    echo -e "${GREEN}✅ Executando como root/sudo${NC}"
else
    echo -e "${YELLOW}⚠️  Recomenda-se executar com sudo para configuração completa${NC}"
    echo "Pressione Enter para continuar ou Ctrl+C para cancelar..."
    read -r || exit 1
fi

# Verificar Python
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}❌ Python3 não encontrado!${NC}"
    echo "Instale Python 3.8+ primeiro:"
    echo "Ubuntu/Debian: sudo apt update && sudo apt install python3 python3-pip"
    echo "CentOS/RHEL: sudo yum install python3 python3-pip"
    echo "macOS: brew install python3"
    exit 1
fi

PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
echo -e "${GREEN}✅ Python $PYTHON_VERSION encontrado${NC}"

# Menu de opções
echo ""
echo "Selecione o tipo de instalação:"
echo "1. Instalação Completa (recomendado)"
echo "2. Apenas dependências (para desenvolvimento)"
echo "3. Desinstalar"
echo ""

read -r -p "Escolha (1-3): " choice

case $choice in
    1)
        echo ""
        echo "🚀 Iniciando instalação completa..."
        echo ""

        # Instalar dependências Python
        echo "📦 Instalando dependências Python..."

        if [[ -f "requirements_portable.txt" ]]; then
            echo "Instalando requirements_portable.txt..."
            pip3 install -r requirements_portable.txt
            echo -e "${GREEN}✅ requirements_portable.txt instalado${NC}"
        else
            echo -e "${YELLOW}⚠️  requirements_portable.txt não encontrado${NC}"
        fi

        if [[ -f "requirements.txt" ]]; then
            echo "Instalando requirements.txt..."
            pip3 install -r requirements.txt
            echo -e "${GREEN}✅ requirements.txt instalado${NC}"
        else
            echo -e "${YELLOW}⚠️  requirements.txt não encontrado${NC}"
        fi

        # Configurar firewall
        echo ""
        echo "🔥 Configurando firewall..."

        if command -v ufw &> /dev/null; then
            echo "Configurando UFW..."
            sudo ufw allow 53/tcp
            sudo ufw allow 53/udp
            sudo ufw allow 3000:3003/tcp
            sudo ufw --force enable
            echo -e "${GREEN}✅ Firewall UFW configurado${NC}"
        elif command -v firewall-cmd &> /dev/null; then
            echo "Configurando firewalld..."
            sudo firewall-cmd --permanent --add-port=53/tcp
            sudo firewall-cmd --permanent --add-port=53/udp
            sudo firewall-cmd --permanent --add-port=3000-3003/tcp
            sudo firewall-cmd --reload
            echo -e "${GREEN}✅ Firewall firewalld configurado${NC}"
        else
            echo -e "${YELLOW}⚠️  Nenhum firewall gerenciado encontrado${NC}"
            echo "Configure manualmente as portas: 53, 3000-3003"
        fi

        # Criar arquivo .env
        echo ""
        echo "🔑 Criando arquivo de configuração APIs..."
        if [[ ! -f ".env" ]]; then
            cat > .env << 'EOF'
# InvictusDNS - Chaves de API para IA
# Obtenha suas chaves nos sites oficiais dos provedores

# OpenAI (https://platform.openai.com/api-keys)
OPENAI_API_KEY=sk-your-openai-api-key-here

# Groq (https://console.groq.com/keys)
GROQ_API_KEY=gsk-your-groq-api-key-here

# Google Gemini (https://makersuite.google.com/app/apikey)
GOOGLE_API_KEY=your-google-gemini-api-key-here

# Anthropic Claude (https://console.anthropic.com/)
ANTHROPIC_API_KEY=sk-ant-your-anthropic-api-key-here

# Blackbox AI (https://www.blackbox.ai/)
BLACKBOX_API_KEY=your-blackbox-api-key-here

# GLM (ZhipuAI) (https://open.bigmodel.cn/)
GLM_API_KEY=your-glm-api-key-here

# DeepInfra (https://deepinfra.com/)
DEEPINFRA_API_KEY=your-deepinfra-api-key-here

# ===========================================
# INSTRUÇÕES:
# 1. Preencha APENAS as chaves dos provedores que você quer usar
# 2. Deixe as outras em branco ou comente com #
# 3. Reinicie o InvictusDNS após alterar
# 4. Mantenha este arquivo SEGURO e não compartilhe!
# ===========================================
EOF
            echo -e "${GREEN}✅ Arquivo .env criado${NC}"
        else
            echo -e "${BLUE}ℹ️  Arquivo .env já existe${NC}"
        fi

        # Criar scripts de inicialização
        echo ""
        echo "📜 Criando scripts de inicialização..."

        # start_invictus.sh
        cat > start_invictus.sh << 'EOF'
#!/bin/bash
# InvictusDNS - Iniciar Todos os Serviços
echo "Iniciando InvictusDNS com IA..."

# Iniciar em background
python3 start_all.py &

echo "Serviços iniciados!"
echo "Acesse:"
echo "- Painel Web: http://localhost:3000 (admin/senha123)"
echo "- Painel IA: http://localhost:3002"
echo "- Painel Marketing: http://localhost:3001"
echo "- Painel Cloud: http://localhost:3003"
EOF

        # stop_invictus.sh
        cat > stop_invictus.sh << 'EOF'
#!/bin/bash
# InvictusDNS - Parar Todos os Serviços
echo "Parando InvictusDNS..."

# Matar processos Python relacionados
pkill -f "python3.*dns_server.py" || true
pkill -f "python3.*web_panel.py" || true
pkill -f "python3.*ai_panel.py" || true
pkill -f "python3.*marketing_panel.py" || true
pkill -f "python3.*cloud_panel.py" || true

echo "Serviços parados!"
EOF

        chmod +x start_invictus.sh stop_invictus.sh
        echo -e "${GREEN}✅ Scripts criados: start_invictus.sh, stop_invictus.sh${NC}"

        # Instalar no sistema
        echo ""
        echo "💾 Instalando InvictusDNS no sistema..."

        INSTALL_DIR="/opt/InvictusDNS"
        sudo mkdir -p "$INSTALL_DIR"

        # Copiar arquivos (excluindo alguns)
        echo "Copiando arquivos..."
        sudo rsync -av --exclude='__pycache__' --exclude='.git' --exclude='dist' \
            --exclude='build' --exclude='node_modules' ./ "$INSTALL_DIR/"

        # Tornar scripts executáveis
        sudo chmod +x "$INSTALL_DIR/launcher.py"
        sudo chmod +x "$INSTALL_DIR/start_all.py"

        # Criar atalho na área de trabalho
        echo ""
        echo "🔗 Criando atalho na área de trabalho..."

        DESKTOP_DIR="$HOME/Desktop"
        mkdir -p "$DESKTOP_DIR"

        DESKTOP_FILE="$DESKTOP_DIR/InvictusDNS.desktop"
        cat > "$DESKTOP_FILE" << EOF
[Desktop Entry]
Name=InvictusDNS
Exec=$INSTALL_DIR/launcher.py
Type=Application
Terminal=false
Icon=dns
Comment=InvictusDNS com IA integrada
EOF

        chmod +x "$DESKTOP_FILE"
        echo -e "${GREEN}✅ Atalho criado: $DESKTOP_FILE${NC}"

        # Testar instalação
        echo ""
        echo "🧪 Testando instalação..."

        if python3 -c "import flask, sqlite3, psutil" 2>/dev/null; then
            echo -e "${GREEN}✅ Dependências básicas OK${NC}"
        else
            echo -e "${RED}❌ Erro nas dependências${NC}"
            exit 1
        fi

        if [[ -f "$INSTALL_DIR/launcher.py" ]]; then
            echo -e "${GREEN}✅ launcher.py encontrado${NC}"
        else
            echo -e "${RED}❌ launcher.py não encontrado${NC}"
        fi

        if [[ -f "$INSTALL_DIR/panels/ai_panel.py" ]]; then
            echo -e "${GREEN}✅ ai_panel.py encontrado${NC}"
        else
            echo -e "${RED}❌ ai_panel.py não encontrado${NC}"
        fi

        echo -e "${GREEN}✅ Teste concluído!${NC}"

        # Informações finais
        ;;
    2)
        echo ""
        echo "📦 Instalando apenas dependências..."

        pip3 install -r requirements_portable.txt
        pip3 install -r requirements.txt

        echo -e "${GREEN}✅ Dependências instaladas!${NC}"
        echo "Execute setup.sh novamente e escolha opção 1 para instalação completa"
        exit 0
        ;;
    3)
        echo ""
        echo "🗑️  Desinstalando InvictusDNS..."

        if [[ -d "/opt/InvictusDNS" ]]; then
            sudo rm -rf "/opt/InvictusDNS"
            echo -e "${GREEN}✅ Removido: /opt/InvictusDNS${NC}"
        fi

        DESKTOP_FILE="$HOME/Desktop/InvictusDNS.desktop"
        if [[ -f "$DESKTOP_FILE" ]]; then
            rm "$DESKTOP_FILE"
            echo -e "${GREEN}✅ Removido atalho da área de trabalho${NC}"
        fi

        echo -e "${GREEN}✅ Desinstalação concluída!${NC}"
        exit 0
        ;;
    *)
        echo -e "${RED}❌ Opção inválida!${NC}"
        exit 1
        ;;
esac

# Informações pós-instalação (apenas para instalação completa)
echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║                  INSTALAÇÃO CONCLUÍDA!                       ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""
echo "🎯 PRÓXIMOS PASSOS:"
echo ""
echo "1️⃣ CONFIGURAR APIs:"
echo "   - Edite o arquivo .env com suas chaves de API"
echo "   - Mínimo necessário: OpenAI ou Groq"
echo ""
echo "2️⃣ INICIAR SISTEMA:"
echo "   - Use o atalho na área de trabalho"
echo "   - Ou execute: python3 launcher.py"
echo ""
echo "3️⃣ ACESSAR PAINÉIS:"
echo "   - Painel Web: http://localhost:3000 (admin/senha123)"
echo "   - Painel IA: http://localhost:3002 (admin/senha123)"
echo "   - Painel Marketing: http://localhost:3001"
echo "   - Painel Cloud: http://localhost:3003"
echo ""
echo "4️⃣ CONFIGURAR DNS:"
echo "   - No seu dispositivo: DNS = IP do servidor"
echo "   - Teste acessando sites"
echo ""
echo "📚 DOCUMENTAÇÃO:"
echo "   - README_AI_PANEL.md - Guia completo da IA"
echo "   - TUTORIAL_INSTALACAO.txt - Instalação detalhada"
echo ""
echo "🔧 SCRIPTS ÚTEIS:"
echo "   - start_invictus.sh - Iniciar tudo"
echo "   - stop_invictus.sh - Parar tudo"
echo ""
echo "⚠️  IMPORTANTE:"
echo "   - Mantenha as chaves API seguras"
echo "   - Faça backup regular das configurações"
echo "   - Monitore os logs em logs/"
echo ""
echo -e "${GREEN}🎉 BEM-VINDO AO INVICTUS DNS COM IA!${NC}"
echo ""

import sqlite3

DB_FILE = '/home/invictus/Desktop/InvictusDNS/data/dns_logs.db'

try:
    conn = sqlite3.connect(DB_FILE, timeout=10)
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM dns_logs")
    count = c.fetchone()[0]
    print(f"Database opened successfully. Total logs: {count}")
    conn.close()
except Exception as e:
    print(f"Error: {e}")

import os
import sys
import subprocess
import threading
import time
import psutil

def start_dns_server():
    """Inicia o servidor DNS."""
    try:
        subprocess.Popen([sys.executable, os.path.join(os.path.dirname(__file__), "server", "dns_server.py")])
    except Exception as e:
        print(f"Erro ao iniciar DNS server: {e}")

def start_web_panel():
    """Inicia o painel web."""
    try:
        subprocess.Popen([sys.executable, os.path.join(os.path.dirname(__file__), "panels", "web_panel.py")])
    except Exception as e:
        print(f"Erro ao iniciar web panel: {e}")

def monitor_services():
    """Monitora os serviços essenciais e reinicia se necessário."""
    services = {
        "dns_server.py": start_dns_server,
        "web_panel.py": start_web_panel,
    }

    cleanup_counter = 0

    while True:
        for script, start_func in services.items():
            found = False
            for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
                try:
                    if proc.info['cmdline'] and script in ' '.join(proc.info['cmdline']):
                        found = True
                        break
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            if not found:
                print(f"Reiniciando {script}...")
                start_func()

        # Executar limpeza a cada 24 horas
        cleanup_counter += 1
        if cleanup_counter >= 8640:  # 86400 / 10 = 8640
            print("Executando limpeza automática...")
            try:
                subprocess.run([sys.executable, os.path.join(os.path.dirname(__file__), "cleanup.py")], check=True)
            except subprocess.CalledProcessError as e:
                print(f"Erro na limpeza: {e}")
            cleanup_counter = 0

        time.sleep(10)

if __name__ == "__main__":
    monitor_services()

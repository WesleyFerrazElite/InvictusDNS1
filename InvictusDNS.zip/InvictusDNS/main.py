"""
InvictusDNS AI System Main Entry Point

This is the main entry point for the InvictusDNS AI system. It initializes
all components, starts the agent system, and provides the main application
loop.

Features:
- System initialization and startup
- Agent system coordination
- AI core integration
- Web interface (optional)
- Configuration management
- Logging and monitoring
- Graceful shutdown handling

Author: BLACKBOXAI
"""

import sys
import time
import json
import logging
import signal
import argparse
from pathlib import Path
from typing import Dict, Any, Optional

# Import InvictusDNS components
from agents import initialize_agent_system, shutdown_agent_system, get_coordinator
from ai_core import initialize_ai_core, get_ai_core

# Optional web interface
try:
    from flask import Flask, request, jsonify
    FLASK_AVAILABLE = True
except ImportError:
    FLASK_AVAILABLE = False

class InvictusDNSApp:
    """
    Main InvictusDNS application class.

    Manages the lifecycle of the entire AI system including agents,
    AI core, and optional web interface.
    """

    def __init__(self, config_path: str = None):
        """
        Initialize the InvictusDNS application.

        Args:
            config_path: Path to configuration file
        """
        self.config_path = config_path or 'config/default.json'
        self.config = self._load_config()

        # Setup logging
        self._setup_logging()

        # System components
        self.agent_coordinator = None
        self.ai_core = None
        self.web_app = None
        self.web_thread = None

        # System state
        self.running = False
        self.start_time = None

        self.logger = logging.getLogger("InvictusDNS.Main")
        self.logger.info("InvictusDNS application initialized")

    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from file"""
        try:
            if Path(self.config_path).exists():
                with open(self.config_path, 'r') as f:
                    config = json.load(f)
                self.logger.info(f"Configuration loaded from {self.config_path}")
            else:
                # Use default configuration
                config = self._get_default_config()
                self.logger.info("Using default configuration")
        except Exception as e:
            self.logger.error(f"Error loading configuration: {e}")
            config = self._get_default_config()

        return config

    def _get_default_config(self) -> Dict[str, Any]:
        """Get default configuration"""
        return {
            'system': {
                'name': 'InvictusDNS AI System',
                'version': '1.0.0',
                'log_level': 'INFO',
                'data_directory': 'data/',
                'model_directory': 'models/'
            },
            'agents': {
                'coordination_interval': 30,
                'max_agents': 20,
                'auto_scaling': True
            },
            'ai_core': {
                'online_learning': True,
                'continuous_learning': True,
                'external_services': {}
            },
            'web_interface': {
                'enabled': True,
                'host': 'localhost',
                'port': 8080,
                'debug': False
            },
            'security': {
                'auto_response': True,
                'threat_thresholds': {
                    'suspicious_connections': 10,
                    'failed_logins': 5
                }
            },
            'network': {
                'load_balancing': True,
                'monitoring_interval': 30
            },
            'learning': {
                'adaptive_learning': True,
                'retrain_interval': 3600
            },
            'automation': {
                'max_concurrent_rules': 10,
                'auto_response': True
            },
            'analytics': {
                'data_retention_days': 90,
                'analysis_interval': 300
            },
            'communication': {
                'message_queue_size': 1000,
                'retry_attempts': 3
            }
        }

    def _setup_logging(self):
        """Setup logging configuration"""
        log_config = self.config.get('system', {}).get('log_level', 'INFO')

        # Create logs directory if it doesn't exist
        Path('logs').mkdir(exist_ok=True)

        # Configure logging
        logging.basicConfig(
            level=getattr(logging, log_config.upper()),
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler('logs/invictusdns.log'),
                logging.StreamHandler(sys.stdout)
            ]
        )

    def start(self):
        """Start the InvictusDNS system"""
        try:
            self.logger.info("Starting InvictusDNS AI System...")
            self.start_time = time.time()
            self.running = True

            # Create data directories
            self._create_data_directories()

            # Initialize AI Core
            self.logger.info("Initializing AI Core...")
            ai_config = self.config.get('ai_core', {})
            initialize_ai_core(ai_config)
            self.ai_core = get_ai_core()

            # Initialize Agent System
            self.logger.info("Initializing Agent System...")
            agent_config = self.config.get('agents', {})
            initialize_agent_system(agent_config)
            self.agent_coordinator = get_coordinator()

            # Start Web Interface (if enabled)
            if self.config.get('web_interface', {}).get('enabled', False):
                self._start_web_interface()

            # Setup signal handlers
            self._setup_signal_handlers()

            self.logger.info("InvictusDNS AI System started successfully")
            self.logger.info(f"System components: AI Core, {len(self.agent_coordinator.agents)} Agents")

            # Main application loop
            self._main_loop()

        except Exception as e:
            self.logger.error(f"Error starting InvictusDNS system: {e}")
            self.stop()
            raise

    def stop(self):
        """Stop the InvictusDNS system"""
        try:
            self.logger.info("Stopping InvictusDNS AI System...")
            self.running = False

            # Stop web interface
            if self.web_thread and self.web_thread.is_alive():
                self.logger.info("Stopping web interface...")
                # Web server will stop when main thread ends

            # Shutdown agent system
            if self.agent_coordinator:
                self.logger.info("Shutting down agent system...")
                shutdown_agent_system()

            # Shutdown AI core
            if self.ai_core:
                self.logger.info("Shutting down AI core...")
                # AI core cleanup if needed

            uptime = time.time() - self.start_time if self.start_time else 0
            self.logger.info(f"InvictusDNS AI System stopped (uptime: {uptime:.2f}s)")

        except Exception as e:
            self.logger.error(f"Error stopping InvictusDNS system: {e}")

    def _main_loop(self):
        """Main application loop"""
        try:
            while self.running:
                # Monitor system health
                self._monitor_system_health()

                # Process any pending tasks
                self._process_pending_tasks()

                # Sleep to prevent busy waiting
                time.sleep(1)

        except KeyboardInterrupt:
            self.logger.info("Received keyboard interrupt")
            self.stop()
        except Exception as e:
            self.logger.error(f"Error in main loop: {e}")
            self.stop()

    def _create_data_directories(self):
        """Create necessary data directories"""
        directories = [
            'data',
            'data/models',
            'data/agent_configs',
            'data/analytics_dashboards',
            'data/analytics_reports',
            'data/automation_rules',
            'data/automation_workflows',
            'data/communication_channels',
            'data/notification_rules',
            'logs',
            'config'
        ]

        for directory in directories:
            Path(directory).mkdir(parents=True, exist_ok=True)

        self.logger.info("Data directories created")

    def _start_web_interface(self):
        """Start the web interface"""
        if not FLASK_AVAILABLE:
            self.logger.warning("Flask not available, skipping web interface")
            return

        try:
            from threading import Thread

            web_config = self.config.get('web_interface', {})
            host = web_config.get('host', 'localhost')
            port = web_config.get('port', 8080)
            debug = web_config.get('debug', False)

            self.web_app = Flask(__name__)

            # Register routes
            self._register_web_routes()

            # Start web server in separate thread
            self.web_thread = Thread(
                target=self.web_app.run,
                kwargs={
                    'host': host,
                    'port': port,
                    'debug': debug,
                    'use_reloader': False
                },
                daemon=True
            )
            self.web_thread.start()

            self.logger.info(f"Web interface started on http://{host}:{port}")

        except Exception as e:
            self.logger.error(f"Error starting web interface: {e}")

    def _register_web_routes(self):
        """Register web interface routes"""
        if not self.web_app:
            return

        @self.web_app.route('/')
        def index():
            return jsonify({
                'name': 'InvictusDNS AI System',
                'version': self.config['system']['version'],
                'status': 'running',
                'uptime': time.time() - self.start_time if self.start_time else 0
            })

        @self.web_app.route('/api/status')
        def system_status():
            if self.agent_coordinator:
                status = self.agent_coordinator.get_system_status()
                return jsonify(status)
            return jsonify({'error': 'Agent coordinator not available'})

        @self.web_app.route('/api/agents')
        def agent_status():
            if self.agent_coordinator:
                agents = self.agent_coordinator.get_agent_health()
                return jsonify(agents)
            return jsonify({'error': 'Agent coordinator not available'})

        @self.web_app.route('/api/agents/<agent_id>')
        def agent_details(agent_id):
            if self.agent_coordinator:
                status = self.agent_coordinator.get_agent_status(agent_id)
                if status:
                    return jsonify(status)
                return jsonify({'error': 'Agent not found'}), 404
            return jsonify({'error': 'Agent coordinator not available'})

        @self.web_app.route('/api/ai/process', methods=['POST'])
        def process_nlp():
            if not self.ai_core:
                return jsonify({'error': 'AI core not available'}), 500

            data = request.get_json()
            if not data or 'text' not in data:
                return jsonify({'error': 'Text input required'}), 400

            result = self.ai_core.process_natural_language(data['text'])
            return jsonify(result)

        @self.web_app.route('/api/ai/decision', methods=['POST'])
        def make_decision():
            if not self.ai_core:
                return jsonify({'error': 'AI core not available'}), 500

            data = request.get_json()
            if not data or 'situation' not in data or 'options' not in data:
                return jsonify({'error': 'Situation and options required'}), 400

            result = self.ai_core.make_decision(data['situation'], data['options'])
            return jsonify(result)

        @self.web_app.route('/api/analytics')
        def get_analytics():
            if self.agent_coordinator:
                # Get analytics from analytics agent
                analytics_agent = self.agent_coordinator.get_agent('analytics_agent')
                if analytics_agent:
                    # This would call the analytics agent's get_analytics method
                    return jsonify({'message': 'Analytics endpoint - implementation pending'})
            return jsonify({'error': 'Analytics not available'})

    def _setup_signal_handlers(self):
        """Setup signal handlers for graceful shutdown"""
        def signal_handler(signum, frame):
            self.logger.info(f"Received signal {signum}")
            self.stop()

        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)

        # Handle SIGUSR1 for reload (if supported)
        try:
            signal.signal(signal.SIGUSR1, self._reload_config)
        except (OSError, ValueError):
            pass  # Signal not supported on this platform

    def _reload_config(self, signum=None, frame=None):
        """Reload configuration"""
        try:
            self.logger.info("Reloading configuration...")
            old_config = self.config.copy()
            self.config = self._load_config()

            # Apply new configuration to components
            if self.agent_coordinator:
                # Update agent coordinator config
                pass

            if self.ai_core:
                # Update AI core config
                pass

            self.logger.info("Configuration reloaded")

        except Exception as e:
            self.logger.error(f"Error reloading configuration: {e}")

    def _monitor_system_health(self):
        """Monitor overall system health"""
        try:
            if not self.agent_coordinator:
                return

            system_status = self.agent_coordinator.get_system_status()

            # Check for critical issues
            if system_status.get('system_health') == 'critical':
                self.logger.error("System health is critical!")

            # Check agent health
            agent_health = self.agent_coordinator.get_agent_health()
            unhealthy_count = sum(1 for health in agent_health.values()
                                if health.get('health') in ['unhealthy', 'error'])

            if unhealthy_count > 0:
                self.logger.warning(f"{unhealthy_count} agents are unhealthy")

            # Log periodic health summary
            if int(time.time()) % 300 == 0:  # Every 5 minutes
                self.logger.info(f"System health: {system_status.get('system_health')}, "
                               f"Active agents: {system_status.get('active_agents')}")

        except Exception as e:
            self.logger.error(f"Error monitoring system health: {e}")

    def _process_pending_tasks(self):
        """Process any pending system tasks"""
        # This could handle things like:
        # - Configuration updates
        # - Agent restarts
        # - Data cleanup
        # - Report generation
        pass

def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(description='InvictusDNS AI System')
    parser.add_argument('--config', '-c', help='Path to configuration file')
    parser.add_argument('--log-level', '-l', choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'],
                       help='Logging level')
    parser.add_argument('--web-only', action='store_true',
                       help='Start only web interface (for development)')

    args = parser.parse_args()

    # Override config path if provided
    config_path = args.config

    # Create and start application
    app = InvictusDNSApp(config_path)

    # Override log level if provided
    if args.log_level:
        logging.getLogger().setLevel(getattr(logging, args.log_level))

    try:
        if args.web_only:
            # Start only web interface for development
            app._start_web_interface()
            if app.web_thread:
                app.web_thread.join()
        else:
            # Start full system
            app.start()

    except KeyboardInterrupt:
        app.stop()
    except Exception as e:
        logging.error(f"Fatal error: {e}")
        app.stop()
        sys.exit(1)

if __name__ == '__main__':
    main()

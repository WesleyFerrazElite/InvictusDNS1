import re
import requests
import hashlib
import time
import sqlite3
import logging
import threading
from datetime import datetime, timedelta
from urllib.parse import urlparse
import os
from utils.ip_obfuscator import deobfuscate_ip

class AdvancedSecurity:
    def __init__(self, db_file='data/dns_logs.db'):
        self.db_file = db_file
        self.threat_databases = {
            'malware_domains': 'https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts',
            'phishing_sites': 'https://raw.githubusercontent.com/mitchellkrogza/Phishing.Database/master/phishing-domains-ACTIVE.txt',
            'c2_servers': 'https://feodotracker.abuse.ch/downloads/ipblocklist.txt'
        }
        self.local_threat_cache = {
            'malware_domains': set(),
            'phishing_sites': set(),
            'c2_servers': set()
        }
        self.suspicious_patterns = {
            'phishing_keywords': [
                'login', 'signin', 'account', 'password', 'bank', 'paypal', 'ebay',
                'amazon', 'facebook', 'google', 'microsoft', 'apple', 'verification',
                'confirm', 'secure', 'update', 'alert', 'notification'
            ],
            'malware_indicators': [
                'exe', 'dll', 'bat', 'cmd', 'scr', 'pif', 'com', 'vbs', 'js',
                'jar', 'zip', 'rar', '7z', 'tar', 'gz', 'deb', 'rpm'
            ],
            'c2_patterns': [
                r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d{2,5}\b',  # IP:PORT
                r'[a-zA-Z0-9-]+\.[a-zA-Z]{2,}\.\d{2,5}',  # domain.port
                r'https?://[^\s/$.?#].[^\s]*'  # URLs with suspicious patterns
            ]
        }
        self.quarantine_list = set()
        self.incident_log = []
        self.load_threat_databases()
        self.start_background_updates()

    def load_threat_databases(self):
        """Carrega bases de dados de ameaças externas"""
        for threat_type, url in self.threat_databases.items():
            try:
                response = requests.get(url, timeout=10)
                if response.status_code == 200:
                    lines = response.text.split('\n')
                    threats = set()
                    for line in lines:
                        line = line.strip()
                        if line and not line.startswith('#'):
                            # Extrair domínios/IPs válidos
                            if threat_type == 'malware_domains':
                                if line.startswith('0.0.0.0'):
                                    domain = line.split()[1] if len(line.split()) > 1 else None
                                    if domain:
                                        threats.add(domain.lower())
                            elif threat_type in ['phishing_sites', 'c2_servers']:
                                if line and not line.startswith('#'):
                                    threats.add(line.lower().strip())
                    self.local_threat_cache[threat_type] = threats
                    logging.info(f"Carregadas {len(threats)} ameaças do tipo {threat_type}")
            except Exception as e:
                logging.error(f"Erro ao carregar base de dados {threat_type}: {e}")

    def start_background_updates(self):
        """Inicia atualização periódica das bases de ameaças"""
        def update_thread():
            while True:
                time.sleep(3600)  # Atualizar a cada hora
                self.load_threat_databases()

        thread = threading.Thread(target=update_thread, daemon=True)
        thread.start()

    def analyze_domain_for_malware(self, domain):
        """Analisa domínio para indicadores de malware"""
        domain_lower = domain.lower()

        # Verificar em bases de dados externas
        if domain_lower in self.local_threat_cache['malware_domains']:
            return {'threat_level': 'high', 'threat_type': 'malware_domain', 'confidence': 0.95}

        # Análise heurística
        score = 0
        reasons = []

        # Comprimento suspeito
        if len(domain) > 50:
            score += 0.3
            reasons.append('domínio muito longo')

        # Caracteres aleatórios (possível DGA)
        if self._is_dga_like(domain):
            score += 0.4
            reasons.append('padrão DGA detectado')

        # Subdomínios excessivos
        if domain.count('.') > 3:
            score += 0.2
            reasons.append('muitos subdomínios')

        # Extensões suspeitas
        suspicious_tlds = ['.tk', '.ml', '.ga', '.cf', '.gq', '.xyz', '.top', '.club']
        if any(domain.endswith(tld) for tld in suspicious_tlds):
            score += 0.3
            reasons.append('TLD suspeito')

        # Palavras-chave suspeitas
        malware_keywords = ['malware', 'trojan', 'virus', 'ransomware', 'botnet', 'exploit']
        if any(keyword in domain_lower for keyword in malware_keywords):
            score += 0.5
            reasons.append('palavras-chave suspeitas')

        if score >= 0.5:
            return {
                'threat_level': 'medium' if score < 0.7 else 'high',
                'threat_type': 'malware_suspicious',
                'confidence': score,
                'reasons': reasons
            }

        return {'threat_level': 'low', 'threat_type': 'clean', 'confidence': 1 - score}

    def detect_phishing(self, domain, query_context=None):
        """Detecta tentativas de phishing"""
        domain_lower = domain.lower()

        # Verificar em bases de dados
        if domain_lower in self.local_threat_cache['phishing_sites']:
            return {'is_phishing': True, 'confidence': 0.95, 'source': 'external_database'}

        # Análise heurística
        score = 0
        reasons = []

        # Similaridade com domínios conhecidos
        legitimate_domains = ['google.com', 'facebook.com', 'amazon.com', 'paypal.com', 'microsoft.com']
        for legit in legitimate_domains:
            if self._calculate_similarity(domain_lower, legit) > 0.8:
                score += 0.4
                reasons.append(f'similar ao domínio legítimo {legit}')

        # Palavras-chave de phishing
        for keyword in self.suspicious_patterns['phishing_keywords']:
            if keyword in domain_lower:
                score += 0.2
                reasons.append(f'contém palavra-chave suspeita: {keyword}')

        # Padrões de phishing comuns
        if re.search(r'\d{4,}', domain):  # Números sequenciais
            score += 0.1
            reasons.append('contém números sequenciais')

        if '-' in domain and domain.count('-') > 1:
            score += 0.1
            reasons.append('múltiplos hífens')

        # HTTPS obrigatório para sites legítimos
        if query_context and 'https' not in str(query_context).lower():
            score += 0.1
            reasons.append('consulta sem HTTPS')

        return {
            'is_phishing': score >= 0.4,
            'confidence': score,
            'reasons': reasons if reasons else []
        }

    def detect_c2_servers(self, domain, ip=None):
        """Detecta servidores de comando e controle (C2)"""
        domain_lower = domain.lower()

        # Verificar em bases de dados
        if ip and ip in self.local_threat_cache['c2_servers']:
            return {'is_c2': True, 'confidence': 0.9, 'source': 'ip_blocklist'}

        if domain_lower in self.local_threat_cache['c2_servers']:
            return {'is_c2': True, 'confidence': 0.9, 'source': 'domain_blocklist'}

        # Análise de padrões C2
        score = 0
        reasons = []

        # Padrões de comunicação C2
        for pattern in self.suspicious_patterns['c2_patterns']:
            if re.search(pattern, domain_lower):
                score += 0.3
                reasons.append(f'corresponde padrão C2: {pattern}')

        # IPs hardcoded suspeitos
        if ip and self._is_suspicious_ip(ip):
            score += 0.4
            reasons.append('IP suspeito detectado')

        # Domínios dinâmicos
        dynamic_providers = ['dyndns', 'no-ip', 'duckdns', 'afraid']
        if any(provider in domain_lower for provider in dynamic_providers):
            score += 0.3
            reasons.append('provedor DNS dinâmico')

        return {
            'is_c2': score >= 0.4,
            'confidence': score,
            'reasons': reasons
        }

    def analyze_behavior(self, client_ip, domain, query_count, time_window=300):
        """Analisa comportamento suspeito baseado em padrões de consulta"""
        try:
            conn = sqlite3.connect(self.db_file)
            cursor = conn.cursor()

            # Desofuscar IP para análise
            real_ip = deobfuscate_ip(client_ip) or client_ip

            # Consultas recentes do mesmo IP
            cursor.execute("""
                SELECT COUNT(*), GROUP_CONCAT(DISTINCT domain)
                FROM dns_logs
                WHERE client_ip = ? AND timestamp > datetime('now', '-{} seconds')
            """.format(time_window), (client_ip,))

            result = cursor.fetchone()
            recent_queries = result[0] if result else 0
            domains_queried = result[1].split(',') if result and result[1] else []

            conn.close()

            # Análise de comportamento
            score = 0
            reasons = []

            # Alta frequência de consultas
            if recent_queries > 100:
                score += 0.5
                reasons.append(f'alta frequência: {recent_queries} consultas em {time_window}s')

            # Muitos domínios diferentes
            if len(domains_queried) > 50:
                score += 0.3
                reasons.append(f'muitos domínios únicos: {len(domains_queried)}')

            # Padrão de varredura
            if self._is_scanning_pattern(domains_queried):
                score += 0.4
                reasons.append('padrão de varredura detectado')

            return {
                'suspicious_behavior': score >= 0.3,
                'behavior_score': score,
                'reasons': reasons,
                'query_rate': recent_queries / time_window
            }

        except Exception as e:
            logging.error(f"Erro na análise de comportamento: {e}")
            return {'suspicious_behavior': False, 'behavior_score': 0, 'reasons': []}

    def quarantine_domain(self, domain, reason, confidence):
        """Coloca domínio em quarentena"""
        if domain not in self.quarantine_list:
            self.quarantine_list.add(domain)
            self.incident_log.append({
                'timestamp': datetime.now().isoformat(),
                'action': 'quarantine',
                'target': domain,
                'reason': reason,
                'confidence': confidence
            })
            logging.warning(f"Domínio {domain} colocado em quarentena: {reason}")

    def automatic_response(self, threat_analysis, client_ip, domain):
        """Resposta automática a ameaças detectadas"""
        responses = []

        # Análise de malware
        if threat_analysis.get('malware_analysis', {}).get('threat_level') in ['medium', 'high']:
            self.quarantine_domain(domain, 'malware_detected', threat_analysis['malware_analysis']['confidence'])
            responses.append('domain_quarantined')

        # Detecção de phishing
        if threat_analysis.get('phishing_analysis', {}).get('is_phishing'):
            self.quarantine_domain(domain, 'phishing_detected', threat_analysis['phishing_analysis']['confidence'])
            responses.append('phishing_blocked')

        # Servidores C2
        if threat_analysis.get('c2_analysis', {}).get('is_c2'):
            self.quarantine_domain(domain, 'c2_server_detected', threat_analysis['c2_analysis']['confidence'])
            responses.append('c2_blocked')

        # Comportamento suspeito
        if threat_analysis.get('behavior_analysis', {}).get('suspicious_behavior'):
            # Poderia implementar rate limiting ou bloqueio temporário
            responses.append('suspicious_behavior_logged')

        return responses

    def comprehensive_threat_analysis(self, client_ip, domain, query_context=None):
        """Análise completa de ameaças"""
        analysis = {
            'timestamp': datetime.now().isoformat(),
            'client_ip': client_ip,
            'domain': domain
        }

        # Análise de malware
        analysis['malware_analysis'] = self.analyze_domain_for_malware(domain)

        # Detecção de phishing
        analysis['phishing_analysis'] = self.detect_phishing(domain, query_context)

        # Detecção de C2
        analysis['c2_analysis'] = self.detect_c2_servers(domain)

        # Análise de comportamento
        analysis['behavior_analysis'] = self.analyze_behavior(client_ip, domain, 1)

        # Resposta automática
        analysis['automatic_responses'] = self.automatic_response(analysis, client_ip, domain)

        # Pontuação geral de ameaça
        threat_scores = [
            analysis['malware_analysis']['confidence'] if analysis['malware_analysis']['threat_level'] != 'low' else 0,
            analysis['phishing_analysis']['confidence'] if analysis['phishing_analysis']['is_phishing'] else 0,
            analysis['c2_analysis']['confidence'] if analysis['c2_analysis']['is_c2'] else 0,
            analysis['behavior_analysis']['behavior_score']
        ]

        analysis['overall_threat_score'] = max(threat_scores)
        analysis['threat_detected'] = analysis['overall_threat_score'] >= 0.5

        return analysis

    def _is_dga_like(self, domain):
        """Verifica se domínio parece gerado por algoritmo (DGA)"""
        # Análise de entropia
        import math
        entropy = 0
        for char in set(domain):
            p = domain.count(char) / len(domain)
            entropy -= p * math.log2(p)

        # Alta entropia + comprimento médio = possível DGA
        return entropy > 3.5 and len(domain) > 10

    def _calculate_similarity(self, str1, str2):
        """Calcula similaridade entre strings usando distância de Levenshtein"""
        def levenshtein(s1, s2):
            if len(s1) < len(s2):
                return levenshtein(s2, s1)
            if len(s2) == 0:
                return len(s1)
            previous_row = list(range(len(s2) + 1))
            for i, c1 in enumerate(s1):
                current_row = [i + 1]
                for j, c2 in enumerate(s2):
                    insertions = previous_row[j + 1] + 1
                    deletions = current_row[j] + 1
                    substitutions = previous_row[j] + (c1 != c2)
                    current_row.append(min(insertions, deletions, substitutions))
                previous_row = current_row
            return previous_row[-1]

        max_len = max(len(str1), len(str2))
        if max_len == 0:
            return 1.0
        return 1 - levenshtein(str1, str2) / max_len

    def _is_suspicious_ip(self, ip):
        """Verifica se IP é suspeito"""
        try:
            octets = ip.split('.')
            if len(octets) != 4:
                return False

            # IPs reservados ou suspeitos
            suspicious_ranges = [
                (0, 0, 0, 0),  # 0.0.0.0
                (10, 0, 0, 0),  # 10.0.0.0/8
                (127, 0, 0, 0), # 127.0.0.0/8 (localhost)
                (169, 254, 0, 0), # 169.254.0.0/16 (link-local)
                (172, 16, 0, 0), # 172.16.0.0/12
                (192, 0, 2, 0),  # 192.0.2.0/24 (teste)
                (192, 168, 0, 0), # 192.168.0.0/16
                (198, 18, 0, 0),  # 198.18.0.0/15 (benchmark)
                (198, 51, 100, 0), # 198.51.100.0/24 (teste)
                (203, 0, 113, 0),  # 203.0.113.0/24 (teste)
                (224, 0, 0, 0),   # 224.0.0.0/4 (multicast)
                (240, 0, 0, 0),   # 240.0.0.0/4 (reservado)
            ]

            ip_int = tuple(map(int, octets))
            for suspicious in suspicious_ranges:
                if ip_int[:len(suspicious)] == suspicious:
                    return True

            return False
        except:
            return False

    def _is_scanning_pattern(self, domains):
        """Detecta padrão de varredura de portas/domínios"""
        if len(domains) < 10:
            return False

        # Verificar se muitos domínios seguem padrão sequencial
        numeric_parts = []
        for domain in domains[:20]:  # Analisar primeiros 20
            match = re.search(r'(\d+)', domain)
            if match:
                numeric_parts.append(int(match.group(1)))

        if len(numeric_parts) >= 5:
            # Verificar se números são sequenciais
            sorted_nums = sorted(numeric_parts)
            sequential_count = 0
            for i in range(1, len(sorted_nums)):
                if sorted_nums[i] - sorted_nums[i-1] <= 5:  # Diferença pequena
                    sequential_count += 1

            if sequential_count >= len(sorted_nums) * 0.7:  # 70% sequenciais
                return True

        return False

    def get_security_stats(self):
        """Retorna estatísticas de segurança"""
        return {
            'quarantined_domains': len(self.quarantine_list),
            'threat_databases_size': {k: len(v) for k, v in self.local_threat_cache.items()},
            'incident_count': len(self.incident_log),
            'recent_incidents': self.incident_log[-10:] if self.incident_log else []
        }

# Instância global
advanced_security = AdvancedSecurity()

# Funções de conveniência
def analyze_threats(client_ip, domain, query_context=None):
    return advanced_security.comprehensive_threat_analysis(client_ip, domain, query_context)

def is_quarantined(domain):
    return domain in advanced_security.quarantine_list

def get_security_stats():
    return advanced_security.get_security_stats()

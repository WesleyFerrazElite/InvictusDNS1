# 🧠 InvictusDNS - Guia Completo do Painel de IA

## 📋 Visão Geral
Este documento explica **COMPLETAMENTE** como configurar e usar o Painel de IA do InvictusDNS, incluindo instalação, portas, APIs, funcionalidades e tudo mais.

---

## 🚀 INSTALAÇÃO E CONFIGURAÇÃO

### 1. **Pré-requisitos do Sistema**
```bash
# Windows
- Python 3.8+ (baixe de python.org)
- Permissões de administrador
- Firewall desabilitado temporariamente para portas 53, 3000-3003

# Linux
- Python 3.8+ (sudo apt install python3)
- Permissões root/sudo
- UFW ou firewall configurado
```

### 2. **Instalação das Dependências**
```bash
# Instalar dependências básicas
pip install -r requirements_portable.txt

# Para funcionalidades avançadas de IA
pip install -r requirements.txt

# Dependências específicas do painel IA:
Flask==2.3.3              # Framework web
Werkzeug==2.3.7          # Utilitários web
cryptography==41.0.4     # Criptografia para chaves API
psutil==5.9.5           # Monitoramento sistema
Pillow==10.0.0          # Processamento imagens
dnslib==0.9.23          # Biblioteca DNS
scapy==2.5.0            # Análise de rede
requests==2.31.0        # Requisições HTTP
sqlite3                 # Banco de dados
```

### 3. **Configuração das Chaves de API**
Crie um arquivo `.env` na raiz do projeto:
```env
# APIs de IA (obtenha em seus respectivos sites)
OPENAI_API_KEY=sk-your-openai-key-here
GROQ_API_KEY=gsk-your-groq-key-here
GOOGLE_API_KEY=your-google-gemini-key-here
ANTHROPIC_API_KEY=sk-ant-your-anthropic-key-here
BLACKBOX_API_KEY=your-blackbox-key-here
GLM_API_KEY=your-glm-key-here
DEEPINFRA_API_KEY=your-deepinfra-key-here
```

### 4. **Portas Necessárias**
```bash
# Portas que precisam estar liberadas:
53   - Servidor DNS (UDP/TCP)
3000 - Painel Web Principal (HTTP)
3001 - Painel Marketing (HTTP)
3002 - Painel IA (HTTP)           <-- FOCO DESTE GUIA
3003 - Painel Cloud (HTTP)

# Comandos para liberar portas:

# Windows (PowerShell como admin):
netsh advfirewall firewall add rule name="InvictusDNS DNS" dir=in action=allow protocol=UDP localport=53
netsh advfirewall firewall add rule name="InvictusDNS Web" dir=in action=allow protocol=TCP localport=3000-3003

# Linux (Ubuntu/Debian):
sudo ufw allow 53
sudo ufw allow 3000:3003/tcp
sudo ufw reload
```

---

## 🎯 INICIANDO O PAINEL IA

### 1. **Método 1: Iniciar Tudo Junto**
```bash
python start_all.py
# OU
python launcher.py
```

### 2. **Método 2: Iniciar Apenas o Painel IA**
```bash
python panels/ai_panel.py
# OU
python start_web_panel.py  # Se configurado para IA
```

### 3. **Acesso ao Painel**
```
URL: http://localhost:3002
Login: admin / senha123
```

---

## 🛠️ FUNCIONALIDADES DO PAINEL IA

### **Aba 1: Chat com IA**
- **Chat interativo** com múltiplas IAs
- **Comandos automáticos**: A IA pode executar ações como bloquear domínios
- **Histórico de conversas** em tempo real
- **Suporte a português** e outros idiomas

### **Aba 2: Configurações**
- **Ativar/Desativar IA**: Controle geral do sistema
- **Provedores**: OpenAI, Groq, Google, Anthropic, etc.
- **Modos de comportamento**: Ativo, Passivo, Aprendizado
- **Limites de taxa**: Controle de uso de tokens/requisições

### **Aba 3: APIs**
- **Status das APIs**: Ver quais estão ativas
- **Gerenciamento de chaves**: Configurar/remover chaves
- **Modelos disponíveis**: Listar modelos por provedor
- **Teste de conectividade**: Verificar se APIs funcionam

### **Aba 4: Machine Learning**
- **Detecção de anomalias**: Usando IsolationForest
- **Treinamento de modelo**: Botão para retreinar
- **Estatísticas**: Taxa de anomalias, consultas 24h
- **Anomalias recentes**: Lista das últimas detecções

### **Aba 5: Automação**
- **Regras ativas**: Lista de regras configuradas
- **Adicionar regras**: Criar novas regras de automação
- **Histórico de execuções**: Ver quando regras foram executadas
- **Regras inteligentes**: Baseadas em padrões de tráfego

### **Aba 6: Segurança**
- **Estatísticas de segurança**: Domínios em quarentena, incidentes
- **Análise de ameaças**: Verificar domínios suspeitos
- **Lista de quarentena**: Domínios bloqueados automaticamente
- **Status do sistema**: Firewall, antivírus, última verificação

### **Aba 7: Tarefas**
- **Atribuir tarefas**: Pedir para IA executar ações específicas
- **Lista de tarefas**: Ver tarefas pendentes/executadas
- **Monitoramento**: Acompanhar progresso das tarefas

### **Aba 8: Monitoramento**
- **Uso do sistema**: CPU, memória, disco
- **Processos ativos**: Lista dos processos rodando
- **Informações do sistema**: SO, versão, uptime
- **Métricas em tempo real**: Updates a cada 2-10 segundos

---

## 🔧 CONFIGURAÇÃO AVANÇADA

### **Arquivo ai_config.json**
```json
{
  "enabled": true,
  "primary_provider": "openai",
  "secondary_provider": "groq",
  "language": "pt-BR",
  "behavior_mode": "active",
  "rate_limits": {
    "max_tokens_per_hour": 10000,
    "max_requests_per_minute": 60
  },
  "apis": {
    "openai": {
      "enabled": true,
      "key": "",
      "models": ["gpt-3.5-turbo", "gpt-4"]
    },
    "groq": {
      "enabled": true,
      "key": "",
      "models": ["llama2-70b-4096"]
    }
  },
  "automation_rules": [],
  "security_features": {
    "malware_detection": true,
    "phishing_detection": true,
    "ddos_protection": true,
    "anomaly_detection": true
  },
  "learning": {
    "supervised_learning": true,
    "continuous_training": true,
    "data_retention_days": 90
  },
  "monitoring": {
    "real_time_alerts": true,
    "performance_metrics": true,
    "detailed_logging": true
  }
}
```

### **APIs Suportadas**
1. **OpenAI**: GPT-3.5, GPT-4
2. **Groq**: Llama models (mais rápido)
3. **Google Gemini**: Gemini 1.5
4. **Anthropic Claude**: Claude 3
5. **Blackbox AI**: Modelos customizados
6. **GLM (ZhipuAI)**: GLM-4
7. **DeepInfra**: Llama 2 70B

---

## 🌐 ENDPOINTS DA API REST

### **Base URL**: `http://localhost:3002/api`

### **Autenticação**
Todos os endpoints requerem login no painel web.

### **Endpoints Principais**
```
GET  /api/health              # Status da API
POST /api/ai_interact         # Interagir com IA
POST /api/assign_task         # Atribuir tarefa
GET  /api/tasks               # Listar tarefas
GET  /api/security_stats      # Estatísticas de segurança
GET  /api/os_usage            # Uso do sistema
GET  /api/processes           # Processos ativos
GET  /api/system_info         # Info do sistema
GET  /api/ai_config           # Configuração da IA
POST /api/toggle_ai           # Ativar/desativar IA
POST /api/train_ml            # Treinar modelo ML
GET  /api/ml_status           # Status do ML
GET  /api/anomaly_stats       # Estatísticas de anomalias
POST /api/analyze_domain      # Analisar domínio
GET  /api/quarantine_list     # Lista de quarentena
```

### **Exemplo de Uso da API**
```python
import requests

# Login (se necessário)
# response = requests.post('http://localhost:3002/', data={'username': 'admin', 'password': 'senha123'})

# Interagir com IA
response = requests.post('http://localhost:3002/api/ai_interact',
                        json={'message': 'Olá IA, como está?'})
print(response.json())

# Ver estatísticas de segurança
response = requests.get('http://localhost:3002/api/security_stats')
print(response.json())
```

---

## 🔒 SEGURANÇA E CRIPTOGRAFIA

### **Criptografia de Chaves API**
- **Algoritmo**: Fernet (AES 128)
- **Chave**: Gerada automaticamente e armazenada em `backup_key`
- **Armazenamento**: Chaves criptografadas no arquivo de config

### **Funcionalidades de Segurança**
- **Detecção de Malware**: Baseada em bancos de dados externos
- **Análise de Phishing**: Verificação de URLs suspeitas
- **Proteção DDoS**: Detecção de ataques distribuídos
- **Quarentena**: Isolamento automático de ameaças
- **Ofuscação de IP**: Proteção de privacidade dos usuários

### **Monitoramento em Tempo Real**
- **Logs detalhados**: Todas as ações são registradas
- **Alertas automáticos**: Notificações de ameaças
- **Auditoria completa**: Histórico de todas as operações

---

## 🤖 INTELIGÊNCIA ARTIFICIAL

### **Modos de Operação**
1. **Ativo**: IA toma decisões automaticamente
2. **Passivo**: Apenas sugestões, sem ações automáticas
3. **Aprendizado**: Modo de treinamento contínuo

### **Capacidades da IA**
- **Análise de logs**: Detecção de padrões suspeitos
- **Bloqueio automático**: Domínios/IPs maliciosos
- **Respostas inteligentes**: Correção de configurações
- **Previsão de ameaças**: Machine Learning para anomalias
- **Comandos em linguagem natural**: "Bloqueie o domínio x.com"

### **Machine Learning**
- **Algoritmo**: Isolation Forest para detecção de anomalias
- **Treinamento**: Automático com dados históricos
- **Métricas**: Score de anomalia, taxa de detecção
- **Retreinamento**: Manual ou automático

---

## 📊 MONITORAMENTO E LOGS

### **Logs Disponíveis**
- `dns_server.log`: Logs do servidor DNS
- `ai_panel.log`: Logs específicos do painel IA
- `security.log`: Eventos de segurança
- `ml_anomalies.log`: Detecções de anomalias

### **Métricas em Tempo Real**
- **Sistema**: CPU, memória, disco, processos
- **Rede**: Consultas DNS, tráfego, conexões
- **Segurança**: Ameaças detectadas, quarentena
- **IA**: Uso de tokens, respostas por minuto

### **Dashboards**
- **Painel IA**: Interface web completa
- **API REST**: Dados JSON para integrações
- **WebSocket**: Updates em tempo real (futuro)

---

## 🚨 TROUBLESHOOTING

### **Problema: IA não responde**
```bash
# Verificar chaves API
cat .env

# Testar conectividade
python -c "import openai; print('OpenAI OK' if openai.api_key else 'Chave faltando')"

# Ver logs
tail -f ai_panel.log
```

### **Problema: Porta ocupada**
```bash
# Windows
netstat -ano | findstr :3002

# Linux
lsof -i :3002

# Matar processo
taskkill /PID <PID> /F  # Windows
kill -9 <PID>           # Linux
```

### **Problema: Dependências faltando**
```bash
pip install --upgrade pip
pip install -r requirements_portable.txt
pip install -r requirements.txt
```

### **Problema: Firewall bloqueando**
```bash
# Windows
netsh advfirewall firewall add rule name="InvictusDNS IA" dir=in action=allow protocol=TCP localport=3002

# Linux
sudo ufw allow 3002/tcp
```

---

## 🔄 ATUALIZAÇÕES E BACKUP

### **Backup da Configuração**
```bash
python backup/cloud_backup.py
# Cria backup criptografado de todas as configurações
```

### **Atualização do Sistema**
```bash
git pull origin main
pip install -r requirements.txt --upgrade
python installer.py  # Reinstalar se necessário
```

### **Restauração**
```bash
python backup/cloud_backup.py --restore backup_name.zip
```

---

## 📞 SUPORTE E DOCUMENTAÇÃO

### **Documentação Completa**
- `README.md`: Visão geral do projeto
- `docs/api_documentation.py`: Documentação da API
- `TUTORIAL_INSTALACAO.txt`: Guia de instalação
- `TODO_AI_CONFIG.md`: Roadmap e funcionalidades

### **Logs de Debug**
```bash
# Habilitar debug
export FLASK_DEBUG=1
python panels/ai_panel.py

# Ver logs em tempo real
tail -f logs/ai_panel.log
```

### **Comunidade**
- **Discord**: [Servidor Discord](https://discord.gg/invictusdns)
- **GitHub Issues**: Para bugs e solicitações
- **Email**: support@invictusdns.com

---

## 🎯 DICAS FINAIS

1. **Sempre teste em ambiente seguro** antes de produção
2. **Monitore os logs regularmente** para detectar problemas
3. **Mantenha as chaves API seguras** e rotacione periodicamente
4. **Faça backups regulares** das configurações
5. **Atualize as dependências** mensalmente
6. **Use HTTPS em produção** (configurar SSL)
7. **Configure alertas** para monitoramento 24/7

---

**🎉 Parabéns! Agora você tem controle total sobre a IA do InvictusDNS!**

**URL do Painel**: http://localhost:3002
**Login**: admin / senha123

**Precisa de ajuda?** Consulte os logs ou abra uma issue no GitHub.

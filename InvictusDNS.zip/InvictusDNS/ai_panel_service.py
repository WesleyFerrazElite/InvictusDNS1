import subprocess
import time
import os
import signal
import sys
import logging
from datetime import datetime

class AIPanelService:
    def __init__(self):
        self.process = None
        self.running = False
        self.log_file = 'logs/ai_panel_service.log'

        # Criar diretório de logs se não existir
        os.makedirs('logs', exist_ok=True)

        # Configurar logging
        logging.basicConfig(
            filename=self.log_file,
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )

    def start(self):
        """Inicia o painel de IA como serviço"""
        if self.running:
            print("Serviço já está rodando!")
            return

        try:
            print("Iniciando InvictusDNS AI Panel Service...")
            logging.info("Iniciando serviço do painel de IA")

            # Comando para executar o painel
            cmd = [sys.executable, os.path.join(os.getcwd(), 'panels', 'ai_panel_enhanced.py')]

            # Iniciar processo
            self.process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                cwd=os.getcwd()
            )

            self.running = True
            print(f"✅ Serviço iniciado com PID: {self.process.pid}")
            print("🌐 URL: http://localhost:3002")
            print("👤 Login: admin / senha123")
            logging.info(f"Serviço iniciado com PID: {self.process.pid}")

            # Monitorar o processo
            self.monitor()

        except Exception as e:
            print(f"❌ Erro ao iniciar serviço: {e}")
            logging.error(f"Erro ao iniciar serviço: {e}")
            self.running = False

    def stop(self):
        """Para o serviço do painel de IA"""
        if not self.running or not self.process:
            print("Serviço não está rodando!")
            return

        try:
            print("Parando InvictusDNS AI Panel Service...")
            logging.info("Parando serviço do painel de IA")

            # Enviar sinal de interrupção
            self.process.terminate()

            # Aguardar até 10 segundos para terminar graciosamente
            try:
                self.process.wait(timeout=10)
                print("✅ Serviço parado com sucesso")
                logging.info("Serviço parado com sucesso")
            except subprocess.TimeoutExpired:
                # Forçar parada se não terminou graciosamente
                self.process.kill()
                print("⚠️ Serviço forçado a parar")
                logging.warning("Serviço forçado a parar")

            self.running = False
            self.process = None

        except Exception as e:
            print(f"❌ Erro ao parar serviço: {e}")
            logging.error(f"Erro ao parar serviço: {e}")

    def restart(self):
        """Reinicia o serviço"""
        print("Reiniciando InvictusDNS AI Panel Service...")
        logging.info("Reiniciando serviço")
        self.stop()
        time.sleep(2)  # Aguardar um pouco
        self.start()

    def status(self):
        """Verifica o status do serviço"""
        if self.running and self.process:
            try:
                # Verificar se o processo ainda está vivo
                self.process.poll()
                if self.process.returncode is None:
                    print("✅ Serviço está rodando")
                    print(f"   PID: {self.process.pid}")
                    print("   URL: http://localhost:3002")
                    return True
                else:
                    print("❌ Serviço parou inesperadamente")
                    logging.error("Serviço parou inesperadamente")
                    self.running = False
                    return False
            except Exception as e:
                print(f"❌ Erro ao verificar status: {e}")
                return False
        else:
            print("❌ Serviço não está rodando")
            return False

    def monitor(self):
        """Monitora o processo em background"""
        try:
            while self.running and self.process:
                # Verificar se processo ainda está vivo
                retcode = self.process.poll()
                if retcode is not None:
                    # Processo terminou
                    print(f"⚠️ Processo terminou com código: {retcode}")
                    logging.warning(f"Processo terminou com código: {retcode}")

                    # Tentar ler stderr para debug
                    if self.process.stderr:
                        stderr_output = self.process.stderr.read().decode('utf-8', errors='ignore')
                        if stderr_output:
                            print("Erro do processo:")
                            print(stderr_output)
                            logging.error(f"Erro do processo: {stderr_output}")

                    self.running = False
                    break

                time.sleep(1)  # Verificar a cada segundo

        except KeyboardInterrupt:
            print("\n🛑 Interrupção detectada, parando serviço...")
            self.stop()
        except Exception as e:
            print(f"❌ Erro no monitoramento: {e}")
            logging.error(f"Erro no monitoramento: {e}")

def main():
    service = AIPanelService()

    if len(sys.argv) < 2:
        print("Uso: python ai_panel_service.py [start|stop|restart|status]")
        print("Ou execute diretamente para modo interativo")
        return

    command = sys.argv[1].lower()

    if command == 'start':
        service.start()
    elif command == 'stop':
        service.stop()
    elif command == 'restart':
        service.restart()
    elif command == 'status':
        service.status()
    else:
        print(f"Comando desconhecido: {command}")

if __name__ == '__main__':
    if len(sys.argv) > 1:
        # Modo comando
        main()
    else:
        # Modo interativo
        service = AIPanelService()

        print("=== InvictusDNS AI Panel Service ===")
        print("Comandos disponíveis:")
        print("  start   - Iniciar serviço")
        print("  stop    - Parar serviço")
        print("  restart - Reiniciar serviço")
        print("  status  - Verificar status")
        print("  exit    - Sair")
        print()

        while True:
            try:
                cmd = input("AI Panel Service> ").strip().lower()

                if cmd == 'start':
                    service.start()
                elif cmd == 'stop':
                    service.stop()
                elif cmd == 'restart':
                    service.restart()
                elif cmd == 'status':
                    service.status()
                elif cmd in ['exit', 'quit', 'q']:
                    if service.running:
                        service.stop()
                    break
                elif cmd == '':
                    continue
                else:
                    print(f"Comando desconhecido: {cmd}")
                    print("Comandos: start, stop, restart, status, exit")

            except KeyboardInterrupt:
                print("\nSaindo...")
                if service.running:
                    service.stop()
                break
            except Exception as e:
                print(f"Erro: {e}")

        print("Serviço finalizado.")

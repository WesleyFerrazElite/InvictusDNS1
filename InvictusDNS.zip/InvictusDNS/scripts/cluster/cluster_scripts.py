#!/usr/bin/env python3
"""
InvictusDNS Cluster Management Scripts
"""

import os
import sys
import json
import subprocess
import argparse
import time
from pathlib import Path

# Add parent directories to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

def setup_cluster():
    """Setup cluster configuration"""
    print("🚀 Setting up InvictusDNS cluster...")

    config = {
        'cluster_name': 'InvictusDNS-Cluster',
        'nodes': [
            {
                'id': 'master-01',
                'ip': '127.0.0.1',
                'port': 5001,
                'role': 'master',
                'services': ['dns', 'api', 'monitoring']
            },
            {
                'id': 'worker-01',
                'ip': '127.0.0.1',
                'port': 5002,
                'role': 'worker',
                'services': ['web', 'logs', 'ai']
            },
            {
                'id': 'worker-02',
                'ip': '127.0.0.1',
                'port': 5003,
                'role': 'worker',
                'services': ['marketing', 'cloud', 'backup']
            }
        ],
        'load_balancing': {
            'enabled': True,
            'algorithm': 'round_robin'
        },
        'replication': {
            'enabled': True,
            'sync_interval': 30
        },
        'monitoring': {
            'enabled': True,
            'metrics_interval': 60
        }
    }

    config_dir = Path('InvictusDNS_Data/dados')
    config_dir.mkdir(parents=True, exist_ok=True)

    config_file = config_dir / 'cluster_config.json'
    with open(config_file, 'w') as f:
        json.dump(config, f, indent=2)

    print(f"✅ Cluster configuration saved to {config_file}")

def start_cluster():
    """Start all cluster nodes"""
    print("🔄 Starting InvictusDNS cluster...")

    # Load cluster configuration
    config_file = Path('InvictusDNS_Data/dados/cluster_config.json')
    if not config_file.exists():
        print("❌ Cluster configuration not found. Run 'setup-cluster' first.")
        return

    with open(config_file, 'r') as f:
        config = json.load(f)

    # Start master node
    master_node = next((node for node in config['nodes'] if node['role'] == 'master'), None)
    if master_node:
        print(f"🏗️ Starting master node: {master_node['id']}")
        start_node(master_node)

    # Start worker nodes
    worker_nodes = [node for node in config['nodes'] if node['role'] == 'worker']
    for node in worker_nodes:
        print(f"🏗️ Starting worker node: {node['id']}")
        start_node(node)

    print("✅ Cluster started successfully!")

def start_node(node_config):
    """Start a cluster node"""
    node_id = node_config['id']
    port = node_config['port']

    # Create node-specific environment
    env = os.environ.copy()
    env['NODE_ID'] = node_id
    env['NODE_PORT'] = str(port)
    env['NODE_ROLE'] = node_config['role']

    # Start services based on node role
    if node_config['role'] == 'master':
        # Start DNS server, API, monitoring
        services = [
            ('server/dns_server.py', 'DNS Server'),
            ('api/rest_api.py', 'REST API'),
            ('monitoring/metrics_collector.py', 'Metrics Collector')
        ]
    else:
        # Start web panels based on services
        services = []
        service_mapping = {
            'web': ('panels/web_panel.py', 'Web Panel'),
            'logs': ('panels/logs_manager.py', 'Logs Manager'),
            'ai': ('panels/ai_panel.py', 'AI Panel'),
            'marketing': ('panels/marketing_panel.py', 'Marketing Panel'),
            'cloud': ('panels/cloud_panel.py', 'Cloud Panel'),
            'backup': ('backup/cloud_backup.py', 'Backup Service')
        }

        for service in node_config.get('services', []):
            if service in service_mapping:
                services.append(service_mapping[service])

    # Start each service
    for script, name in services:
        try:
            cmd = [sys.executable, script]
            process = subprocess.Popen(
                cmd,
                env=env,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                cwd=os.getcwd()
            )
            print(f"  ✅ Started {name} (PID: {process.pid})")
        except Exception as e:
            print(f"  ❌ Failed to start {name}: {e}")

def stop_cluster():
    """Stop all cluster nodes"""
    print("🛑 Stopping InvictusDNS cluster...")

    # Find and kill all Python processes related to InvictusDNS
    try:
        result = subprocess.run(
            ['pgrep', '-f', 'python.*InvictusDNS'],
            capture_output=True,
            text=True
        )

        if result.returncode == 0:
            pids = result.stdout.strip().split('\n')
            for pid in pids:
                if pid.strip():
                    try:
                        subprocess.run(['kill', pid.strip()])
                        print(f"✅ Killed process {pid.strip()}")
                    except:
                        pass

        print("✅ Cluster stopped successfully!")
    except Exception as e:
        print(f"❌ Error stopping cluster: {e}")

def check_cluster_status():
    """Check cluster status"""
    print("📊 Checking cluster status...")

    # Load cluster configuration
    config_file = Path('InvictusDNS_Data/dados/cluster_config.json')
    if not config_file.exists():
        print("❌ Cluster configuration not found.")
        return

    with open(config_file, 'r') as f:
        config = json.load(f)

    print(f"Cluster: {config['cluster_name']}")
    print(f"Nodes: {len(config['nodes'])}")
    print()

    # Check each node
    for node in config['nodes']:
        status = check_node_status(node)
        status_icon = "🟢" if status['online'] else "🔴"
        print(f"{status_icon} {node['id']} ({node['role']}) - {node['ip']}:{node['port']}")
        print(f"  Services: {', '.join(node.get('services', []))}")
        print(f"  Status: {'Online' if status['online'] else 'Offline'}")
        if status['services']:
            print(f"  Running services: {', '.join(status['services'])}")
        print()

def check_node_status(node_config):
    """Check status of a specific node"""
    import requests

    try:
        # Try to connect to node's API
        response = requests.get(f"http://{node_config['ip']}:{node_config['port']}/cluster/status", timeout=5)
        if response.status_code == 200:
            data = response.json()
            return {
                'online': True,
                'services': data.get('services', [])
            }
    except:
        pass

    return {
        'online': False,
        'services': []
    }

def scale_cluster(num_workers):
    """Scale cluster to specified number of workers"""
    print(f"⚖️ Scaling cluster to {num_workers} workers...")

    config_file = Path('InvictusDNS_Data/dados/cluster_config.json')
    if not config_file.exists():
        print("❌ Cluster configuration not found.")
        return

    with open(config_file, 'r') as f:
        config = json.load(f)

    current_workers = len([n for n in config['nodes'] if n['role'] == 'worker'])

    if num_workers > current_workers:
        # Add workers
        for i in range(current_workers + 1, num_workers + 1):
            new_worker = {
                'id': f'worker-{i:02d}',
                'ip': '127.0.0.1',
                'port': 5000 + i,
                'role': 'worker',
                'services': ['web', 'logs']
            }
            config['nodes'].append(new_worker)
            print(f"➕ Added worker node: {new_worker['id']}")

    elif num_workers < current_workers:
        # Remove workers
        workers_to_remove = current_workers - num_workers
        removed_workers = []

        for i in range(workers_to_remove):
            # Remove last worker
            for j, node in enumerate(config['nodes']):
                if node['role'] == 'worker':
                    removed_workers.append(node['id'])
                    config['nodes'].pop(j)
                    break

        for worker_id in removed_workers:
            print(f"➖ Removed worker node: {worker_id}")

    # Save updated configuration
    with open(config_file, 'w') as f:
        json.dump(config, f, indent=2)

    print("✅ Cluster scaling completed!")

def backup_cluster():
    """Create cluster-wide backup"""
    print("💾 Creating cluster backup...")

    from backup.cloud_backup import backup_manager

    result = backup_manager.create_backup('cluster')
    if result.get('success'):
        print("✅ Cluster backup completed!")
        print(f"   Backup name: {result['backup_name']}")
        print(f"   Size: {result['size']} bytes")
        print(f"   Files: {result['files_count']}")
    else:
        print(f"❌ Backup failed: {result.get('error')}")

def restore_cluster(backup_name):
    """Restore cluster from backup"""
    print(f"🔄 Restoring cluster from backup: {backup_name}")

    from backup.cloud_backup import backup_manager

    result = backup_manager.restore_backup(backup_name)
    if result.get('success'):
        print("✅ Cluster restore completed!")
        print(f"   Files restored: {result['files_restored']}")
    else:
        print(f"❌ Restore failed: {result.get('error')}")

def main():
    parser = argparse.ArgumentParser(description='InvictusDNS Cluster Management')
    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Setup command
    subparsers.add_parser('setup', help='Setup cluster configuration')

    # Start command
    subparsers.add_parser('start', help='Start cluster')

    # Stop command
    subparsers.add_parser('stop', help='Stop cluster')

    # Status command
    subparsers.add_parser('status', help='Check cluster status')

    # Scale command
    scale_parser = subparsers.add_parser('scale', help='Scale cluster')
    scale_parser.add_argument('num_workers', type=int, help='Number of worker nodes')

    # Backup command
    subparsers.add_parser('backup', help='Create cluster backup')

    # Restore command
    restore_parser = subparsers.add_parser('restore', help='Restore cluster from backup')
    restore_parser.add_argument('backup_name', help='Backup name to restore')

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return

    # Execute command
    if args.command == 'setup':
        setup_cluster()
    elif args.command == 'start':
        start_cluster()
    elif args.command == 'stop':
        stop_cluster()
    elif args.command == 'status':
        check_cluster_status()
    elif args.command == 'scale':
        scale_cluster(args.num_workers)
    elif args.command == 'backup':
        backup_cluster()
    elif args.command == 'restore':
        restore_cluster(args.backup_name)

if __name__ == '__main__':
    main()

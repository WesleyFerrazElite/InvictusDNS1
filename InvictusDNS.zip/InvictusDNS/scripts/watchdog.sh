#!/bin/bash

# InvictusDNS Watchdog - Verifica e reinicia serviços se necessário

# Verificar DNS Server
if ! pgrep -f "dns_server.py" > /dev/null; then
    echo "$(date): DNS Server parado, reiniciando..."
    cd /home/invictus/Desktop/InvictusDNS/server
    sudo python3 dns_server.py &
fi

# Verificar Web Panel
if ! pgrep -f "web_panel.py" > /dev/null; then
    echo "$(date): Web Panel parado, reiniciando..."
    cd /home/invictus/Desktop/InvictusDNS/panels
    python3 web_panel.py &
fi

# Verificar Marketing Panel
if ! pgrep -f "marketing_panel.py" > /dev/null; then
    echo "$(date): Marketing Panel parado, reiniciando..."
    cd /home/invictus/Desktop/InvictusDNS/panels
    python3 marketing_panel.py &
fi

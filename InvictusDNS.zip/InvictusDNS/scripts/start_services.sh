#!/bin/bash

# InvictusDNS - Script para iniciar serviços

echo "Iniciando InvictusDNS..."

# Iniciar DNS Server
cd ../server
sudo python3 dns_server.py &
echo "DNS Server iniciado na porta 53"

# Iniciar Web Panel
cd ../panels
python3 web_panel.py &
echo "Painel Web iniciado na porta 3000"

# Iniciar Marketing Panel
python3 marketing_panel.py &
echo "Painel de Marketing iniciado na porta 3001"

echo "Todos os serviços iniciados. Acesse os painéis via navegador."

"""
Configuration settings for Authentication Service
"""

import os
from typing import List, Optional
from pydantic import BaseSettings, Field

class Settings(BaseSettings):
    """Application settings"""

    # Application
    APP_NAME: str = Field(default="InvictusDNS Auth Service", env="APP_NAME")
    APP_VERSION: str = Field(default="1.0.0", env="APP_VERSION")
    DEBUG: bool = Field(default=False, env="DEBUG")
    ENV: str = Field(default="production", env="ENV")

    # Server
    AUTH_SERVICE_PORT: int = Field(default=3001, env="AUTH_SERVICE_PORT")
    AUTH_SERVICE_HOST: str = Field(default="0.0.0.0", env="AUTH_SERVICE_HOST")

    # Database
    DATABASE_URL: str = Field(..., env="DATABASE_URL")

    # Redis
    REDIS_HOST: str = Field(default="redis-service", env="REDIS_HOST")
    REDIS_PORT: int = Field(default=6379, env="REDIS_PORT")
    REDIS_DB: int = Field(default=0, env="REDIS_DB")
    REDIS_PASSWORD: Optional[str] = Field(default=None, env="REDIS_PASSWORD")

    # JWT
    JWT_SECRET: str = Field(..., env="JWT_SECRET")
    JWT_ALGORITHM: str = Field(default="HS256", env="JWT_ALGORITHM")
    JWT_EXPIRATION_HOURS: int = Field(default=24, env="JWT_EXPIRATION_HOURS")
    JWT_REFRESH_EXPIRATION_DAYS: int = Field(default=30, env="JWT_REFRESH_EXPIRATION_DAYS")

    # Password
    PASSWORD_MIN_LENGTH: int = Field(default=8, env="PASSWORD_MIN_LENGTH")
    PASSWORD_REQUIRE_UPPERCASE: bool = Field(default=True, env="PASSWORD_REQUIRE_UPPERCASE")
    PASSWORD_REQUIRE_LOWERCASE: bool = Field(default=True, env="PASSWORD_REQUIRE_LOWERCASE")
    PASSWORD_REQUIRE_DIGITS: bool = Field(default=True, env="PASSWORD_REQUIRE_DIGITS")
    PASSWORD_REQUIRE_SPECIAL: bool = Field(default=False, env="PASSWORD_REQUIRE_SPECIAL")

    # MFA
    MFA_ISSUER: str = Field(default="InvictusDNS", env="MFA_ISSUER")
    MFA_BACKUP_CODES_COUNT: int = Field(default=10, env="MFA_BACKUP_CODES_COUNT")

    # Account Lockout
    MAX_FAILED_LOGIN_ATTEMPTS: int = Field(default=5, env="MAX_FAILED_LOGIN_ATTEMPTS")
    ACCOUNT_LOCKOUT_DURATION_MINUTES: int = Field(default=30, env="ACCOUNT_LOCKOUT_DURATION_MINUTES")

    # CORS
    CORS_ORIGINS: List[str] = Field(
        default=["http://localhost:3000", "https://invictusdns.com"],
        env="CORS_ORIGINS"
    )

    # Email
    EMAIL_SMTP_SERVER: str = Field(default="smtp.gmail.com", env="EMAIL_SMTP_SERVER")
    EMAIL_SMTP_PORT: int = Field(default=587, env="EMAIL_SMTP_PORT")
    EMAIL_USE_TLS: bool = Field(default=True, env="EMAIL_USE_TLS")
    EMAIL_USER: str = Field(..., env="EMAIL_USER")
    EMAIL_PASSWORD: str = Field(..., env="EMAIL_PASSWORD")
    EMAIL_FROM: str = Field(default="InvictusDNS <noreply@invictusdns.com>", env="EMAIL_FROM")

    # Security
    BCRYPT_ROUNDS: int = Field(default=12, env="BCRYPT_ROUNDS")
    SECRET_KEY_LENGTH: int = Field(default=32, env="SECRET_KEY_LENGTH")

    # Rate Limiting
    RATE_LIMIT_REGISTER_PER_HOUR: int = Field(default=5, env="RATE_LIMIT_REGISTER_PER_HOUR")
    RATE_LIMIT_LOGIN_PER_MINUTE: int = Field(default=5, env="RATE_LIMIT_LOGIN_PER_MINUTE")
    RATE_LIMIT_PASSWORD_RESET_PER_HOUR: int = Field(default=3, env="RATE_LIMIT_PASSWORD_RESET_PER_HOUR")

    # Sessions
    SESSION_TIMEOUT_MINUTES: int = Field(default=480, env="SESSION_TIMEOUT_MINUTES")  # 8 hours

    # Logging
    LOG_LEVEL: str = Field(default="INFO", env="LOG_LEVEL")
    LOG_FORMAT: str = Field(default="json", env="LOG_FORMAT")

    # Metrics
    METRICS_ENABLED: bool = Field(default=True, env="METRICS_ENABLED")

    # Health Checks
    HEALTH_CHECK_ENABLED: bool = Field(default=True, env="HEALTH_CHECK_ENABLED")

    # OAuth2 (future)
    OAUTH2_ENABLED: bool = Field(default=False, env="OAUTH2_ENABLED")
    OAUTH2_GOOGLE_CLIENT_ID: Optional[str] = Field(default=None, env="OAUTH2_GOOGLE_CLIENT_ID")
    OAUTH2_GOOGLE_CLIENT_SECRET: Optional[str] = Field(default=None, env="OAUTH2_GOOGLE_CLIENT_SECRET")

    # Admin
    DEFAULT_ADMIN_USERNAME: str = Field(default="admin", env="DEFAULT_ADMIN_USERNAME")
    DEFAULT_ADMIN_EMAIL: str = Field(default="admin@invictusdns.com", env="DEFAULT_ADMIN_EMAIL")

    # Tenant
    DEFAULT_TENANT_NAME: str = Field(default="Default", env="DEFAULT_TENANT_NAME")
    DEFAULT_TENANT_DOMAIN: str = Field(default="invictusdns.com", env="DEFAULT_TENANT_DOMAIN")

    class Config:
        env_file = ".env"
        case_sensitive = False

# Global settings instance
settings = Settings()

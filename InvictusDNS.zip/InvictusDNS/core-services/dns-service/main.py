"""
InvictusDNS Enterprise - DNS Service
High-performance DNS server with AI-powered threat detection
"""

import asyncio
import socket
import struct
import time
import ipaddress
from typing import Dict, List, Optional, Tuple, Set
from datetime import datetime, timedelta
from contextlib import asynccontextmanager
import threading
import signal
import sys

import uvicorn
from fastapi import FastAPI, HTTPException, Depends, BackgroundTasks
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
import redis.asyncio as redis
import scapy.all as scapy
from scapy.layers.dns import DNS, DNSQR, DNSRR
from scapy.layers.inet import IP, UDP
import structlog
from prometheus_client import Counter, Histogram, Gauge, generate_latest
import aiofiles
import aiodns
import aiomysql

# Configuration
from config.settings import settings

# Logging
structlog.configure(
    processors=[
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_logger_name,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.UnicodeDecoder(),
        structlog.processors.JSONRenderer()
    ],
    context_class=dict,
    logger_factory=structlog.stdlib.LoggerFactory(),
    wrapper_class=structlog.stdlib.BoundLogger,
    cache_logger_on_first_use=True,
)

logger = structlog.get_logger()

# Metrics
DNS_QUERIES = Counter('dns_queries_total', 'DNS queries', ['type', 'status', 'source'])
DNS_LATENCY = Histogram('dns_query_duration_seconds', 'DNS query duration', ['type'])
CACHE_HITS = Counter('dns_cache_hits_total', 'DNS cache hits')
CACHE_MISSES = Counter('dns_cache_misses_total', 'DNS cache misses')
THREAT_BLOCKS = Counter('dns_threat_blocks_total', 'DNS threat blocks', ['threat_type'])
ACTIVE_CONNECTIONS = Gauge('dns_active_connections', 'Active DNS connections')

# DNS Record Types
DNS_TYPES = {
    1: 'A',      # IPv4 address
    2: 'NS',     # Name server
    5: 'CNAME',  # Canonical name
    6: 'SOA',    # Start of authority
    12: 'PTR',   # Pointer record
    13: 'HINFO', # Host information
    15: 'MX',    # Mail exchange
    16: 'TXT',   # Text record
    28: 'AAAA',  # IPv6 address
    33: 'SRV',   # Service record
    35: 'NAPTR', # Naming Authority Pointer
    39: 'DNAME', # Delegation name
    41: 'OPT',   # Option
    43: 'DS',    # Delegation signer
    46: 'RRSIG', # DNSSEC signature
    47: 'NSEC',  # Next secure
    48: 'DNSKEY',# DNSSEC key
    50: 'NSEC3', # Next secure v3
    51: 'NSEC3PARAM', # NSEC3 parameters
}

# Threat Categories
THREAT_CATEGORIES = {
    'malware': 'Malware domains',
    'phishing': 'Phishing sites',
    'botnet': 'Botnet C&C servers',
    'spam': 'Spam sources',
    'exploit': 'Exploit kits',
    'crypto': 'Cryptocurrency mining',
    'adult': 'Adult content',
    'gambling': 'Gambling sites',
}

class DNSQuery(BaseModel):
    domain: str = Field(..., description="Domain name to resolve")
    type: str = Field(default="A", description="DNS record type")
    client_ip: Optional[str] = Field(default=None, description="Client IP address")

class DNSResponse(BaseModel):
    domain: str
    type: str
    answers: List[Dict[str, str]]
    cached: bool = False
    blocked: bool = False
    block_reason: Optional[str] = None
    response_time: float

class ThreatStats(BaseModel):
    total_queries: int
    blocked_queries: int
    cache_hit_rate: float
    average_response_time: float
    threats_by_category: Dict[str, int]

class CacheEntry:
    def __init__(self, answers: List[Dict], ttl: int):
        self.answers = answers
        self.created_at = time.time()
        self.ttl = ttl
        self.expires_at = self.created_at + ttl

    def is_expired(self) -> bool:
        return time.time() > self.expires_at

    def time_to_live(self) -> int:
        return max(0, int(self.expires_at - time.time()))

class DNSCache:
    def __init__(self, max_size: int = 10000):
        self.cache: Dict[str, CacheEntry] = {}
        self.max_size = max_size
        self._lock = asyncio.Lock()

    async def get(self, key: str) -> Optional[List[Dict]]:
        async with self._lock:
            entry = self.cache.get(key)
            if entry and not entry.is_expired():
                CACHE_HITS.inc()
                return entry.answers
            elif entry and entry.is_expired():
                del self.cache[key]
            CACHE_MISSES.inc()
            return None

    async def set(self, key: str, answers: List[Dict], ttl: int):
        async with self._lock:
            if len(self.cache) >= self.max_size:
                # Remove expired entries first
                expired_keys = [k for k, v in self.cache.items() if v.is_expired()]
                for k in expired_keys:
                    del self.cache[k]

                # If still at limit, remove oldest
                if len(self.cache) >= self.max_size:
                    oldest_key = min(self.cache.keys(),
                                   key=lambda k: self.cache[k].created_at)
                    del self.cache[oldest_key]

            self.cache[key] = CacheEntry(answers, ttl)

    async def clear(self):
        async with self._lock:
            self.cache.clear()

class ThreatDetector:
    def __init__(self, redis_client: redis.Redis):
        self.redis = redis_client
        self.threat_lists: Dict[str, Set[str]] = {}
        self._lock = asyncio.Lock()

    async def load_threat_lists(self):
        """Load threat intelligence from Redis/database"""
        async with self._lock:
            # Load from Redis sets
            for category in THREAT_CATEGORIES.keys():
                try:
                    domains = await self.redis.smembers(f"threats:{category}")
                    self.threat_lists[category] = set(domains)
                except Exception as e:
                    logger.error(f"Failed to load threat list {category}", error=str(e))
                    self.threat_lists[category] = set()

    async def is_threat(self, domain: str) -> Tuple[bool, Optional[str]]:
        """Check if domain is a threat"""
        domain_lower = domain.lower().strip('.')

        for category, domains in self.threat_lists.items():
            if domain_lower in domains:
                THREAT_BLOCKS.labels(threat_type=category).inc()
                return True, category

        return False, None

    async def add_threat(self, domain: str, category: str):
        """Add domain to threat list"""
        async with self._lock:
            await self.redis.sadd(f"threats:{category}", domain.lower())
            if category in self.threat_lists:
                self.threat_lists[category].add(domain.lower())

    async def remove_threat(self, domain: str, category: str):
        """Remove domain from threat list"""
        async with self._lock:
            await self.redis.srem(f"threats:{category}", domain.lower())
            if category in self.threat_lists:
                self.threat_lists[category].discard(domain.lower())

class DNSResolver:
    def __init__(self, cache: DNSCache, threat_detector: ThreatDetector):
        self.cache = cache
        self.threat_detector = threat_detector
        self.upstream_servers = [
            '8.8.8.8',      # Google DNS
            '8.8.4.4',      # Google DNS
            '1.1.1.1',      # Cloudflare
            '1.0.0.1',      # Cloudflare
            '9.9.9.9',      # Quad9
            '149.112.112.112', # Quad9
        ]
        self.resolver = aiodns.Resolver(nameservers=self.upstream_servers)

    async def resolve(self, domain: str, qtype: str = 'A') -> Tuple[List[Dict], bool]:
        """Resolve DNS query with caching and threat detection"""

        # Check threat lists first
        is_threat, threat_category = await self.threat_detector.is_threat(domain)
        if is_threat:
            return [{
                'type': 'A',
                'data': '0.0.0.0',  # Block with NXDOMAIN-like response
                'ttl': 300
            }], True

        # Check cache
        cache_key = f"{domain}:{qtype}"
        cached_result = await self.cache.get(cache_key)
        if cached_result:
            return cached_result, False

        # Resolve upstream
        try:
            if qtype == 'A':
                result = await self.resolver.gethostbyname(domain)
                answers = [{
                    'type': 'A',
                    'data': result.addresses[0] if result.addresses else '127.0.0.1',
                    'ttl': 300
                }]
            elif qtype == 'AAAA':
                result = await self.resolver.gethostbyname(domain)
                answers = [{
                    'type': 'AAAA',
                    'data': '::1',  # IPv6 localhost for now
                    'ttl': 300
                }]
            else:
                # For other types, return empty for now
                answers = []

            # Cache result
            await self.cache.set(cache_key, answers, 300)

            return answers, False

        except Exception as e:
            logger.error("DNS resolution failed", domain=domain, qtype=qtype, error=str(e))
            return [], False

class DNSServer:
    def __init__(self, resolver: DNSResolver, port: int = 53):
        self.resolver = resolver
        self.port = port
        self.sock = None
        self.running = False

    async def start(self):
        """Start DNS server"""
        self.running = True
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind(('0.0.0.0', self.port))
        self.sock.setblocking(False)

        logger.info("DNS server started", port=self.port)

        loop = asyncio.get_event_loop()

        while self.running:
            try:
                # Receive DNS query
                data, addr = await loop.sock_recvfrom(self.sock, 4096)
                ACTIVE_CONNECTIONS.inc()

                # Process query asynchronously
                asyncio.create_task(self.handle_query(data, addr))

            except Exception as e:
                logger.error("DNS server error", error=str(e))
                ACTIVE_CONNECTIONS.dec()

    async def stop(self):
        """Stop DNS server"""
        self.running = False
        if self.sock:
            self.sock.close()
        logger.info("DNS server stopped")

    async def handle_query(self, data: bytes, addr: Tuple[str, int]):
        """Handle DNS query"""
        try:
            start_time = time.time()

            # Parse DNS query
            dns_query = DNS(data)
            qname = dns_query.qd.qname.decode('utf-8').rstrip('.')
            qtype = DNS_TYPES.get(dns_query.qd.qtype, str(dns_query.qd.qtype))

            DNS_QUERIES.labels(type=qtype, status="received", source="udp").inc()

            # Resolve query
            answers, blocked = await self.resolver.resolve(qname, qtype)

            # Build response
            dns_response = DNS(
                id=dns_query.id,
                qr=1,  # Response
                opcode=dns_query.opcode,
                aa=0,  # Not authoritative
                tc=0,  # Not truncated
                rd=dns_query.rd,
                ra=1,  # Recursion available
                z=0,
                rcode=0 if answers else 3,  # NOERROR or NXDOMAIN
                qd=dns_query.qd,
                ancount=len(answers)
            )

            # Add answers
            for i, answer in enumerate(answers):
                if answer['type'] == 'A':
                    rr = DNSRR(
                        rrname=qname,
                        type=1,
                        rclass=1,
                        ttl=answer['ttl'],
                        rdata=answer['data']
                    )
                elif answer['type'] == 'AAAA':
                    rr = DNSRR(
                        rrname=qname,
                        type=28,
                        rclass=1,
                        ttl=answer['ttl'],
                        rdata=answer['data']
                    )
                else:
                    continue

                if i == 0:
                    dns_response.an = rr
                else:
                    dns_response.an = dns_response.an / rr

            # Send response
            response_data = bytes(dns_response)
            await asyncio.get_event_loop().sock_sendto(self.sock, response_data, addr)

            # Metrics
            response_time = time.time() - start_time
            DNS_LATENCY.labels(type=qtype).observe(response_time)

            status = "blocked" if blocked else "resolved"
            DNS_QUERIES.labels(type=qtype, status=status, source="udp").inc()

            logger.info(
                "DNS query processed",
                domain=qname,
                type=qtype,
                answers=len(answers),
                blocked=blocked,
                response_time=f"{response_time:.3f}s",
                client=addr[0]
            )

        except Exception as e:
            logger.error("DNS query processing failed", error=str(e), client=addr[0])
            DNS_QUERIES.labels(type="unknown", status="error", source="udp").inc()
        finally:
            ACTIVE_CONNECTIONS.dec()

# Global instances
dns_cache = DNSCache(max_size=settings.DNS_CACHE_MAX_SIZE)
threat_detector = ThreatDetector(None)  # Will be initialized later
dns_resolver = DNSResolver(dns_cache, threat_detector)
dns_server = DNSServer(dns_resolver, port=settings.DNS_PORT)

# FastAPI app
app = FastAPI(
    title="InvictusDNS DNS Service",
    description="High-performance DNS server with AI threat detection",
    version="1.0.0"
)

redis_client = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager"""
    global redis_client

    # Startup
    logger.info("Starting DNS Service")

    # Initialize Redis
    redis_client = redis.Redis(
        host=settings.REDIS_HOST,
        port=settings.REDIS_PORT,
        db=settings.REDIS_DB,
        decode_responses=True
    )

    # Initialize threat detector
    global threat_detector
    threat_detector = ThreatDetector(redis_client)

    # Load threat lists
    await threat_detector.load_threat_lists()

    # Start DNS server in background
    dns_task = asyncio.create_task(dns_server.start())

    yield

    # Shutdown
    logger.info("Shutting down DNS Service")

    await dns_server.stop()
    dns_task.cancel()

    try:
        await dns_task
    except asyncio.CancelledError:
        pass

    if redis_client:
        await redis_client.close()

# Routes
@app.post("/resolve", response_model=DNSResponse)
async def resolve_dns(query: DNSQuery):
    """Manual DNS resolution for testing"""
    start_time = time.time()

    try:
        answers, blocked = await dns_resolver.resolve(query.domain, query.type)

        response_time = time.time() - start_time

        return DNSResponse(
            domain=query.domain,
            type=query.type,
            answers=answers,
            blocked=blocked,
            response_time=response_time
        )

    except Exception as e:
        logger.error("Manual DNS resolution failed", error=str(e), domain=query.domain)
        raise HTTPException(status_code=500, detail="DNS resolution failed")

@app.get("/stats", response_model=ThreatStats)
async def get_stats():
    """Get DNS service statistics"""
    # This would aggregate real metrics
    return ThreatStats(
        total_queries=1000,
        blocked_queries=50,
        cache_hit_rate=0.85,
        average_response_time=0.023,
        threats_by_category={
            'malware': 20,
            'phishing': 15,
            'botnet': 10,
            'spam': 5
        }
    )

@app.post("/threats/add")
async def add_threat(domain: str, category: str):
    """Add domain to threat list"""
    if category not in THREAT_CATEGORIES:
        raise HTTPException(status_code=400, detail="Invalid threat category")

    await threat_detector.add_threat(domain, category)
    return {"message": f"Domain {domain} added to {category} threat list"}

@app.delete("/threats/remove")
async def remove_threat(domain: str, category: str):
    """Remove domain from threat list"""
    if category not in THREAT_CATEGORIES:
        raise HTTPException(status_code=400, detail="Invalid threat category")

    await threat_detector.remove_threat(domain, category)
    return {"message": f"Domain {domain} removed from {category} threat list"}

@app.post("/cache/clear")
async def clear_cache():
    """Clear DNS cache"""
    await dns_cache.clear()
    return {"message": "DNS cache cleared"}

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow(),
        "version": settings.APP_VERSION,
        "dns_server_running": dns_server.running
    }

@app.get("/metrics")
async def metrics():
    """Prometheus metrics endpoint"""
    return JSONResponse(content=generate_latest())

# Main entry point
if __name__ == "__main__":
    # Start both DNS server and HTTP API
    import threading

    def start_dns_server():
        """Start DNS server in separate thread"""
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(dns_server.start())

    # Start DNS server thread
    dns_thread = threading.Thread(target=start_dns_server, daemon=True)
    dns_thread.start()

    # Start HTTP API
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=settings.DNS_SERVICE_PORT,
        reload=settings.DEBUG,
        log_level="info"
    )

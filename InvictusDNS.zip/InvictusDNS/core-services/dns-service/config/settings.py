"""
Configuration settings for DNS Service
"""

import os
from typing import List, Optional
from pydantic import BaseSettings, Field

class Settings(BaseSettings):
    """Application settings"""

    # Application
    APP_NAME: str = Field(default="InvictusDNS DNS Service", env="APP_NAME")
    APP_VERSION: str = Field(default="1.0.0", env="APP_VERSION")
    DEBUG: bool = Field(default=False, env="DEBUG")
    ENV: str = Field(default="production", env="ENV")

    # DNS Server
    DNS_PORT: int = Field(default=53, env="DNS_PORT")
    DNS_SERVICE_PORT: int = Field(default=3002, env="DNS_SERVICE_PORT")
    DNS_SERVICE_HOST: str = Field(default="0.0.0.0", env="DNS_SERVICE_HOST")

    # DNS Configuration
    DNS_CACHE_MAX_SIZE: int = Field(default=10000, env="DNS_CACHE_MAX_SIZE")
    DNS_CACHE_TTL: int = Field(default=300, env="DNS_CACHE_TTL")
    DNS_MAX_QUERY_SIZE: int = Field(default=4096, env="DNS_MAX_QUERY_SIZE")

    # Upstream DNS Servers
    DNS_UPSTREAM_SERVERS: List[str] = Field(
        default=[
            "8.8.8.8",      # Google DNS Primary
            "8.8.4.4",      # Google DNS Secondary
            "1.1.1.1",      # Cloudflare Primary
            "1.0.0.1",      # Cloudflare Secondary
            "9.9.9.9",      # Quad9 Primary
            "149.112.112.112" # Quad9 Secondary
        ],
        env="DNS_UPSTREAM_SERVERS"
    )

    # Redis
    REDIS_HOST: str = Field(default="redis-service", env="REDIS_HOST")
    REDIS_PORT: int = Field(default=6379, env="REDIS_PORT")
    REDIS_DB: int = Field(default=0, env="REDIS_DB")
    REDIS_PASSWORD: Optional[str] = Field(default=None, env="REDIS_PASSWORD")

    # Threat Detection
    THREAT_DETECTION_ENABLED: bool = Field(default=True, env="THREAT_DETECTION_ENABLED")
    THREAT_UPDATE_INTERVAL_MINUTES: int = Field(default=60, env="THREAT_UPDATE_INTERVAL_MINUTES")

    # AI Integration
    AI_SERVICE_URL: str = Field(default="http://ai-orchestrator:3005", env="AI_SERVICE_URL")
    AI_THREAT_ANALYSIS_ENABLED: bool = Field(default=True, env="AI_THREAT_ANALYSIS_ENABLED")

    # Rate Limiting
    DNS_RATE_LIMIT_REQUESTS_PER_MINUTE: int = Field(default=1000, env="DNS_RATE_LIMIT_REQUESTS_PER_MINUTE")
    DNS_RATE_LIMIT_BURST_SIZE: int = Field(default=100, env="DNS_RATE_LIMIT_BURST_SIZE")

    # Logging
    LOG_LEVEL: str = Field(default="INFO", env="LOG_LEVEL")
    LOG_FORMAT: str = Field(default="json", env="LOG_FORMAT")
    DNS_QUERY_LOG_ENABLED: bool = Field(default=True, env="DNS_QUERY_LOG_ENABLED")

    # Metrics
    METRICS_ENABLED: bool = Field(default=True, env="METRICS_ENABLED")
    METRICS_RETENTION_DAYS: int = Field(default=30, env="METRICS_RETENTION_DAYS")

    # Performance
    DNS_WORKER_THREADS: int = Field(default=4, env="DNS_WORKER_THREADS")
    DNS_CONNECTION_TIMEOUT: int = Field(default=5, env="DNS_CONNECTION_TIMEOUT")
    DNS_RESOLUTION_TIMEOUT: int = Field(default=10, env="DNS_RESOLUTION_TIMEOUT")

    # Security
    DNS_ALLOW_RECURSION: bool = Field(default=True, env="DNS_ALLOW_RECURSION")
    DNS_ALLOW_TRANSFERS: bool = Field(default=False, env="DNS_ALLOW_TRANSFERS")
    DNS_MAX_CACHE_ENTRIES: int = Field(default=50000, env="DNS_MAX_CACHE_ENTRIES")

    # Monitoring
    DNS_HEALTH_CHECK_ENABLED: bool = Field(default=True, env="DNS_HEALTH_CHECK_ENABLED")
    DNS_HEALTH_CHECK_INTERVAL_SECONDS: int = Field(default=30, env="DNS_HEALTH_CHECK_INTERVAL_SECONDS")

    # External Feeds
    THREAT_FEED_UPDATE_ENABLED: bool = Field(default=True, env="THREAT_FEED_UPDATE_ENABLED")
    THREAT_FEED_SOURCES: List[str] = Field(
        default=[
            "https://malware-filter.gitlab.io/malware-filter/urlhaus-filter-online.txt",
            "https://p2pblocklist.net/p2pblocklist.txt",
            "https://blocklist.cyberthreatcoalition.org/vetted/url.txt"
        ],
        env="THREAT_FEED_SOURCES"
    )

    # Database (for logging and analytics)
    DATABASE_URL: str = Field(default="postgresql://dns:dns@postgres/dns", env="DATABASE_URL")

    # Message Broker
    RABBITMQ_URL: str = Field(default="amqp://guest:guest@rabbitmq:5672/", env="RABBITMQ_URL")

    # CORS
    CORS_ORIGINS: List[str] = Field(
        default=["http://localhost:3000", "https://invictusdns.com"],
        env="CORS_ORIGINS"
    )

    class Config:
        env_file = ".env"
        case_sensitive = False

# Global settings instance
settings = Settings()

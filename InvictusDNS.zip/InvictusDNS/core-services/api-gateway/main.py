"""
InvictusDNS Enterprise - API Gateway Service
FastAPI-based API Gateway with authentication, rate limiting, and routing
"""

import asyncio
import time
import logging
from typing import Optional, Dict, Any
from datetime import datetime, timedelta
from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI, Request, Response, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
import redis.asyncio as redis
import jwt
import httpx
from prometheus_client import Counter, Histogram, Gauge, generate_latest
import structlog

# Configuration
from config.settings import settings

# Logging configuration
structlog.configure(
    processors=[
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_logger_name,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.UnicodeDecoder(),
        structlog.processors.JSONRenderer()
    ],
    context_class=dict,
    logger_factory=structlog.stdlib.LoggerFactory(),
    wrapper_class=structlog.stdlib.BoundLogger,
    cache_logger_on_first_use=True,
)

logger = structlog.get_logger()

# Metrics
REQUEST_COUNT = Counter('api_gateway_requests_total', 'Total requests', ['method', 'endpoint', 'status'])
REQUEST_LATENCY = Histogram('api_gateway_request_duration_seconds', 'Request duration', ['method', 'endpoint'])
ACTIVE_CONNECTIONS = Gauge('api_gateway_active_connections', 'Active connections')

# Models
class TokenData(BaseModel):
    user_id: str
    tenant_id: str
    roles: list[str] = []
    exp: datetime

class ServiceRoute(BaseModel):
    name: str
    url: str
    methods: list[str] = ["GET", "POST", "PUT", "DELETE"]
    auth_required: bool = True
    rate_limit: Optional[int] = None
    timeout: int = 30

class HealthResponse(BaseModel):
    status: str = "healthy"
    timestamp: datetime
    version: str
    services: Dict[str, bool]

# Service Routes Configuration
SERVICE_ROUTES = {
    "auth": ServiceRoute(
        name="auth-service",
        url="http://auth-service:3001",
        auth_required=False,
        rate_limit=100
    ),
    "users": ServiceRoute(
        name="user-service",
        url="http://user-service:3002",
        rate_limit=1000
    ),
    "dns": ServiceRoute(
        name="dns-service",
        url="http://dns-service:53",
        rate_limit=5000
    ),
    "radius": ServiceRoute(
        name="radius-service",
        url="http://radius-service:3003",
        rate_limit=1000
    ),
    "ipam": ServiceRoute(
        name="ipam-service",
        url="http://ipam-service:3004",
        rate_limit=500
    ),
    "mikrotik": ServiceRoute(
        name="mikrotik-service",
        url="http://mikrotik-service:3005",
        rate_limit=200
    ),
    "ai": ServiceRoute(
        name="ai-orchestrator",
        url="http://ai-orchestrator:3006",
        rate_limit=100
    ),
    "analytics": ServiceRoute(
        name="ml-analytics",
        url="http://ml-analytics:3007",
        rate_limit=50
    ),
    "threat": ServiceRoute(
        name="threat-intel",
        url="http://threat-intel:3008",
        rate_limit=200
    ),
    "billing": ServiceRoute(
        name="billing-service",
        url="http://billing-service:3009",
        rate_limit=500
    ),
    "crm": ServiceRoute(
        name="crm-service",
        url="http://crm-service:3010",
        rate_limit=300
    )
}

# Redis connection
redis_client: Optional[redis.Redis] = None

# HTTP client
http_client: Optional[httpx.AsyncClient] = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager"""
    global redis_client, http_client

    # Startup
    logger.info("Starting API Gateway")

    # Initialize Redis
    redis_client = redis.Redis(
        host=settings.REDIS_HOST,
        port=settings.REDIS_PORT,
        db=settings.REDIS_DB,
        decode_responses=True
    )

    # Initialize HTTP client
    http_client = httpx.AsyncClient(
        timeout=httpx.Timeout(30.0),
        limits=httpx.Limits(max_keepalive_connections=100, max_connections=1000)
    )

    # Test connections
    try:
        await redis_client.ping()
        logger.info("Redis connection established")
    except Exception as e:
        logger.error("Redis connection failed", error=str(e))

    yield

    # Shutdown
    logger.info("Shutting down API Gateway")

    if http_client:
        await http_client.aclose()

    if redis_client:
        await redis_client.close()

# FastAPI app
app = FastAPI(
    title="InvictusDNS API Gateway",
    description="Enterprise API Gateway for InvictusDNS",
    version="1.0.0",
    lifespan=lifespan
)

# Security
security = HTTPBearer(auto_error=False)

# Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

if settings.TRUSTED_HOSTS:
    app.add_middleware(
        TrustedHostMiddleware,
        allowed_hosts=settings.TRUSTED_HOSTS
    )

# Rate limiting
class RateLimiter:
    def __init__(self, redis_client: redis.Redis):
        self.redis = redis_client

    async def is_allowed(self, key: str, limit: int, window: int = 60) -> bool:
        """Check if request is within rate limit"""
        current = await self.redis.incr(key)
        if current == 1:
            await self.redis.expire(key, window)
        return current <= limit

rate_limiter = RateLimiter(redis_client) if redis_client else None

# Authentication
async def verify_token(credentials: Optional[HTTPAuthorizationCredentials] = Depends(security)) -> Optional[TokenData]:
    """Verify JWT token"""
    if not credentials:
        return None

    try:
        payload = jwt.decode(
            credentials.credentials,
            settings.JWT_SECRET,
            algorithms=[settings.JWT_ALGORITHM]
        )

        # Check expiration
        exp = datetime.fromtimestamp(payload.get("exp", 0))
        if exp < datetime.utcnow():
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token expired"
            )

        return TokenData(**payload)

    except jwt.PyJWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token"
        )

# Request processing
@app.middleware("http")
async def process_request(request: Request, call_next):
    """Process incoming requests"""
    start_time = time.time()

    # Track active connections
    ACTIVE_CONNECTIONS.inc()

    try:
        # Get client info
        client_ip = request.client.host if request.client else "unknown"
        user_agent = request.headers.get("user-agent", "unknown")

        # Log request
        logger.info(
            "Request received",
            method=request.method,
            url=str(request.url),
            client_ip=client_ip,
            user_agent=user_agent
        )

        # Process request
        response = await call_next(request)

        # Calculate latency
        latency = time.time() - start_time

        # Metrics
        REQUEST_COUNT.labels(
            method=request.method,
            endpoint=request.url.path,
            status=response.status_code
        ).inc()

        REQUEST_LATENCY.labels(
            method=request.method,
            endpoint=request.url.path
        ).observe(latency)

        # Log response
        logger.info(
            "Request completed",
            method=request.method,
            url=str(request.url),
            status=response.status_code,
            latency=f"{latency:.3f}s"
        )

        return response

    except Exception as e:
        # Log error
        logger.error(
            "Request failed",
            method=request.method,
            url=str(request.url),
            error=str(e),
            latency=f"{time.time() - start_time:.3f}s"
        )
        raise
    finally:
        ACTIVE_CONNECTIONS.dec()

# Routes
@app.get("/health")
async def health_check():
    """Health check endpoint"""
    services_status = {}

    # Check Redis
    try:
        if redis_client:
            await redis_client.ping()
            services_status["redis"] = True
        else:
            services_status["redis"] = False
    except:
        services_status["redis"] = False

    # Check services (basic connectivity)
    for service_name, route in SERVICE_ROUTES.items():
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                response = await client.get(f"{route.url}/health")
                services_status[service_name] = response.status_code == 200
        except:
            services_status[service_name] = False

    return HealthResponse(
        timestamp=datetime.utcnow(),
        version=settings.APP_VERSION,
        services=services_status
    )

@app.get("/metrics")
async def metrics():
    """Prometheus metrics endpoint"""
    return Response(
        content=generate_latest(),
        media_type="text/plain"
    )

@app.api_route("/{service}/{path:path}", methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"])
async def proxy_request(
    service: str,
    path: str,
    request: Request,
    token_data: Optional[TokenData] = Depends(verify_token)
):
    """Proxy requests to backend services"""

    # Check if service exists
    if service not in SERVICE_ROUTES:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Service '{service}' not found"
        )

    route = SERVICE_ROUTES[service]

    # Check authentication
    if route.auth_required and not token_data:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required"
        )

    # Check rate limiting
    if route.rate_limit and rate_limiter:
        client_ip = request.client.host if request.client else "unknown"
        rate_key = f"rate_limit:{service}:{client_ip}"

        if not await rate_limiter.is_allowed(rate_key, route.rate_limit):
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail="Rate limit exceeded"
            )

    # Build target URL
    target_url = f"{route.url}/{path}"

    # Add query parameters
    if request.url.query:
        target_url += f"?{request.url.query}"

    # Prepare headers
    headers = dict(request.headers)
    headers.pop("host", None)  # Remove host header

    # Add tenant context if authenticated
    if token_data:
        headers["X-Tenant-ID"] = token_data.tenant_id
        headers["X-User-ID"] = token_data.user_id
        headers["X-User-Roles"] = ",".join(token_data.roles)

    try:
        # Forward request
        async with httpx.AsyncClient(timeout=route.timeout) as client:
            response = await client.request(
                method=request.method,
                url=target_url,
                headers=headers,
                content=await request.body(),
                params=request.query_params
            )

            # Return response
            return Response(
                content=response.content,
                status_code=response.status_code,
                headers=dict(response.headers)
            )

    except httpx.TimeoutException:
        logger.error("Request timeout", service=service, url=target_url)
        raise HTTPException(
            status_code=status.HTTP_504_GATEWAY_TIMEOUT,
            detail="Service timeout"
        )

    except Exception as e:
        logger.error("Request failed", service=service, url=target_url, error=str(e))
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail="Service unavailable"
        )

# Main entry point
if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=settings.API_GATEWAY_PORT,
        reload=settings.DEBUG,
        log_level="info"
    )

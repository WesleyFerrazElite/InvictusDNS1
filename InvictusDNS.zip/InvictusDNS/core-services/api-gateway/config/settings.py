"""
Configuration settings for API Gateway
"""

import os
from typing import List, Optional
from pydantic import BaseSettings, Field

class Settings(BaseSettings):
    """Application settings"""

    # Application
    APP_NAME: str = Field(default="InvictusDNS API Gateway", env="APP_NAME")
    APP_VERSION: str = Field(default="1.0.0", env="APP_VERSION")
    DEBUG: bool = Field(default=False, env="DEBUG")
    ENV: str = Field(default="production", env="ENV")

    # Server
    API_GATEWAY_PORT: int = Field(default=80, env="API_GATEWAY_PORT")
    API_GATEWAY_HOST: str = Field(default="0.0.0.0", env="API_GATEWAY_HOST")

    # Redis
    REDIS_HOST: str = Field(default="redis-service", env="REDIS_HOST")
    REDIS_PORT: int = Field(default=6379, env="REDIS_PORT")
    REDIS_DB: int = Field(default=0, env="REDIS_DB")
    REDIS_PASSWORD: Optional[str] = Field(default=None, env="REDIS_PASSWORD")

    # JWT
    JWT_SECRET: str = Field(..., env="JWT_SECRET")
    JWT_ALGORITHM: str = Field(default="HS256", env="JWT_ALGORITHM")
    JWT_EXPIRATION_HOURS: int = Field(default=24, env="JWT_EXPIRATION_HOURS")

    # CORS
    CORS_ORIGINS: List[str] = Field(
        default=["http://localhost:3000", "https://invictusdns.com"],
        env="CORS_ORIGINS"
    )

    # Trusted Hosts
    TRUSTED_HOSTS: Optional[List[str]] = Field(default=None, env="TRUSTED_HOSTS")

    # Rate Limiting
    RATE_LIMIT_REQUESTS_PER_MINUTE: int = Field(default=1000, env="RATE_LIMIT_REQUESTS_PER_MINUTE")
    RATE_LIMIT_BURST_SIZE: int = Field(default=100, env="RATE_LIMIT_BURST_SIZE")

    # Timeouts
    REQUEST_TIMEOUT: int = Field(default=30, env="REQUEST_TIMEOUT")
    CONNECTION_TIMEOUT: int = Field(default=10, env="CONNECTION_TIMEOUT")

    # Logging
    LOG_LEVEL: str = Field(default="INFO", env="LOG_LEVEL")
    LOG_FORMAT: str = Field(default="json", env="LOG_FORMAT")

    # Metrics
    METRICS_ENABLED: bool = Field(default=True, env="METRICS_ENABLED")
    METRICS_PORT: int = Field(default=9090, env="METRICS_PORT")

    # Health Checks
    HEALTH_CHECK_ENABLED: bool = Field(default=True, env="HEALTH_CHECK_ENABLED")
    HEALTH_CHECK_INTERVAL_SECONDS: int = Field(default=60, env="HEALTH_CHECK_INTERVAL_SECONDS")

    # Circuit Breaker
    CIRCUIT_BREAKER_ENABLED: bool = Field(default=True, env="CIRCUIT_BREAKER_ENABLED")
    CIRCUIT_BREAKER_FAILURE_THRESHOLD: int = Field(default=5, env="CIRCUIT_BREAKER_FAILURE_THRESHOLD")
    CIRCUIT_BREAKER_RECOVERY_TIMEOUT: int = Field(default=60, env="CIRCUIT_BREAKER_RECOVERY_TIMEOUT")

    # Load Balancing
    LOAD_BALANCER_STRATEGY: str = Field(default="round_robin", env="LOAD_BALANCER_STRATEGY")

    # Security
    SSL_ENABLED: bool = Field(default=True, env="SSL_ENABLED")
    SSL_CERT_PATH: Optional[str] = Field(default=None, env="SSL_CERT_PATH")
    SSL_KEY_PATH: Optional[str] = Field(default=None, env="SSL_KEY_PATH")

    # Service Discovery
    SERVICE_DISCOVERY_ENABLED: bool = Field(default=True, env="SERVICE_DISCOVERY_ENABLED")
    SERVICE_DISCOVERY_TYPE: str = Field(default="kubernetes", env="SERVICE_DISCOVERY_TYPE")

    # Database (for gateway-specific data)
    DATABASE_URL: str = Field(default="postgresql://gateway:gateway@postgres/gateway", env="DATABASE_URL")

    # Message Broker
    RABBITMQ_URL: str = Field(default="amqp://guest:guest@rabbitmq:5672/", env="RABBITMQ_URL")

    # External APIs
    EXTERNAL_API_TIMEOUT: int = Field(default=30, env="EXTERNAL_API_TIMEOUT")
    EXTERNAL_API_RETRIES: int = Field(default=3, env="EXTERNAL_API_RETRIES")

    class Config:
        env_file = ".env"
        case_sensitive = False

# Global settings instance
settings = Settings()

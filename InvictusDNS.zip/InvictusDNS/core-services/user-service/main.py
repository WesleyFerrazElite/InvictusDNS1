"""
InvictusDNS Enterprise - User Management Service
Customer lifecycle, subscriptions, and profile management
"""

import asyncio
import uuid
from datetime import datetime, timedelta, timezone
from typing import Optional, Dict, Any, List
from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI, HTTPException, Depends, status, BackgroundTasks
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, Field, EmailStr, validator
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlalchemy import String, Boolean, DateTime, Text, Integer, Float, ForeignKey, select, update, delete, func
import jwt
import stripe
from prometheus_client import Counter, Histogram, generate_latest
import structlog

# Configuration
from config.settings import settings

# Logging
structlog.configure(
    processors=[
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_logger_name,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.UnicodeDecoder(),
        structlog.processors.JSONRenderer()
    ],
    context_class=dict,
    logger_factory=structlog.stdlib.LoggerFactory(),
    wrapper_class=structlog.stdlib.BoundLogger,
    cache_logger_on_first_use=True,
)

logger = structlog.get_logger()

# Metrics
USER_OPERATIONS = Counter('user_operations_total', 'User operations', ['operation', 'status'])
SUBSCRIPTION_EVENTS = Counter('subscription_events_total', 'Subscription events', ['event_type'])
BILLING_OPERATIONS = Counter('billing_operations_total', 'Billing operations', ['operation'])

# Database Models
class Base(DeclarativeBase):
    pass

class User(Base):
    __tablename__ = "users"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    tenant_id: Mapped[str] = mapped_column(String(36), nullable=False)
    username: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    email: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    full_name: Mapped[str] = mapped_column(String(255))
    phone: Mapped[str] = mapped_column(String(20))
    company: Mapped[str] = mapped_column(String(255))
    address: Mapped[Text] = mapped_column(Text)
    city: Mapped[str] = mapped_column(String(100))
    state: Mapped[str] = mapped_column(String(100))
    country: Mapped[str] = mapped_column(String(100))
    postal_code: Mapped[str] = mapped_column(String(20))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_verified: Mapped[bool] = mapped_column(Boolean, default=False)
    email_verified_at: Mapped[datetime] = mapped_column(DateTime, nullable=True)
    stripe_customer_id: Mapped[str] = mapped_column(String(255), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Plan(Base):
    __tablename__ = "plans"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[Text] = mapped_column(Text)
    price_monthly: Mapped[float] = mapped_column(Float, nullable=False)
    price_yearly: Mapped[float] = mapped_column(Float, nullable=False)
    currency: Mapped[str] = mapped_column(String(3), default="BRL")
    max_users: Mapped[int] = mapped_column(Integer, default=1)
    max_domains: Mapped[int] = mapped_column(Integer, default=10)
    features: Mapped[Text] = mapped_column(Text)  # JSON string
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    stripe_price_id_monthly: Mapped[str] = mapped_column(String(255), nullable=True)
    stripe_price_id_yearly: Mapped[str] = mapped_column(String(255), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class Subscription(Base):
    __tablename__ = "subscriptions"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False)
    plan_id: Mapped[str] = mapped_column(String(36), ForeignKey("plans.id"), nullable=False)
    stripe_subscription_id: Mapped[str] = mapped_column(String(255), nullable=True)
    status: Mapped[str] = mapped_column(String(50), default="active")  # active, canceled, past_due, etc.
    billing_cycle: Mapped[str] = mapped_column(String(20), default="monthly")  # monthly, yearly
    current_period_start: Mapped[datetime] = mapped_column(DateTime, nullable=True)
    current_period_end: Mapped[datetime] = mapped_column(DateTime, nullable=True)
    cancel_at_period_end: Mapped[bool] = mapped_column(Boolean, default=False)
    canceled_at: Mapped[datetime] = mapped_column(DateTime, nullable=True)
    trial_start: Mapped[datetime] = mapped_column(DateTime, nullable=True)
    trial_end: Mapped[datetime] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Invoice(Base):
    __tablename__ = "invoices"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False)
    subscription_id: Mapped[str] = mapped_column(String(36), ForeignKey("subscriptions.id"), nullable=True)
    stripe_invoice_id: Mapped[str] = mapped_column(String(255), nullable=True)
    amount: Mapped[float] = mapped_column(Float, nullable=False)
    currency: Mapped[str] = mapped_column(String(3), default="BRL")
    status: Mapped[str] = mapped_column(String(50), default="draft")  # draft, open, paid, void, uncollectible
    description: Mapped[Text] = mapped_column(Text)
    due_date: Mapped[datetime] = mapped_column(DateTime, nullable=True)
    paid_at: Mapped[datetime] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

# Pydantic Models
class UserCreate(BaseModel):
    username: str = Field(..., min_length=3, max_length=50)
    email: EmailStr
    full_name: str = Field(..., max_length=255)
    phone: Optional[str] = Field(None, max_length=20)
    company: Optional[str] = Field(None, max_length=255)
    address: Optional[str] = None
    city: Optional[str] = Field(None, max_length=100)
    state: Optional[str] = Field(None, max_length=100)
    country: Optional[str] = Field(None, max_length=100)
    postal_code: Optional[str] = Field(None, max_length=20)
    tenant_id: str

class UserUpdate(BaseModel):
    full_name: Optional[str] = Field(None, max_length=255)
    phone: Optional[str] = Field(None, max_length=20)
    company: Optional[str] = Field(None, max_length=255)
    address: Optional[str] = None
    city: Optional[str] = Field(None, max_length=100)
    state: Optional[str] = Field(None, max_length=100)
    country: Optional[str] = Field(None, max_length=100)
    postal_code: Optional[str] = Field(None, max_length=20)

class UserResponse(BaseModel):
    id: str
    username: str
    email: str
    full_name: Optional[str]
    phone: Optional[str]
    company: Optional[str]
    city: Optional[str]
    state: Optional[str]
    country: Optional[str]
    is_active: bool
    is_verified: bool
    email_verified_at: Optional[datetime]
    created_at: datetime
    updated_at: datetime

class PlanResponse(BaseModel):
    id: str
    name: str
    description: Optional[str]
    price_monthly: float
    price_yearly: float
    currency: str
    max_users: int
    max_domains: int
    features: Dict[str, Any]
    is_active: bool

class SubscriptionCreate(BaseModel):
    plan_id: str
    billing_cycle: str = Field(default="monthly", regex="^(monthly|yearly)$")
    trial_days: Optional[int] = Field(default=7, ge=0, le=365)

class SubscriptionResponse(BaseModel):
    id: str
    user_id: str
    plan: PlanResponse
    status: str
    billing_cycle: str
    current_period_start: Optional[datetime]
    current_period_end: Optional[datetime]
    cancel_at_period_end: bool
    trial_end: Optional[datetime]
    created_at: datetime

class InvoiceResponse(BaseModel):
    id: str
    user_id: str
    amount: float
    currency: str
    status: str
    description: Optional[str]
    due_date: Optional[datetime]
    paid_at: Optional[datetime]
    created_at: datetime

class BillingStats(BaseModel):
    total_revenue: float
    monthly_revenue: float
    active_subscriptions: int
    total_customers: int
    churn_rate: float
    average_revenue_per_user: float

# Security
security = HTTPBearer()

# Database
engine = create_async_engine(settings.DATABASE_URL, echo=settings.DEBUG)
async_session = async_sessionmaker(engine, expire_on_commit=False)

# Stripe
if settings.STRIPE_SECRET_KEY:
    stripe.api_key = settings.STRIPE_SECRET_KEY

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager"""
    logger.info("Starting User Management Service")

    # Create tables
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    # Create default plans if they don't exist
    await create_default_plans()

    yield

    logger.info("Shutting down User Management Service")

async def create_default_plans():
    """Create default subscription plans"""
    async with async_session() as session:
        # Check if plans already exist
        result = await session.execute(select(func.count()).select_from(Plan))
        count = result.scalar()

        if count > 0:
            return

        # Create default plans
        plans_data = [
            {
                "name": "Starter",
                "description": "Perfect for small businesses",
                "price_monthly": 49.90,
                "price_yearly": 499.00,
                "max_users": 5,
                "max_domains": 10,
                "features": {
                    "dns_resolution": True,
                    "basic_security": True,
                    "email_support": True,
                    "api_access": False,
                    "advanced_analytics": False
                }
            },
            {
                "name": "Professional",
                "description": "For growing companies",
                "price_monthly": 149.90,
                "price_yearly": 1499.00,
                "max_users": 25,
                "max_domains": 50,
                "features": {
                    "dns_resolution": True,
                    "advanced_security": True,
                    "priority_support": True,
                    "api_access": True,
                    "basic_analytics": True,
                    "custom_filters": True
                }
            },
            {
                "name": "Enterprise",
                "description": "Full-featured solution",
                "price_monthly": 499.90,
                "price_yearly": 4999.00,
                "max_users": 100,
                "max_domains": 500,
                "features": {
                    "dns_resolution": True,
                    "enterprise_security": True,
                    "24_7_support": True,
                    "api_access": True,
                    "advanced_analytics": True,
                    "custom_filters": True,
                    "white_label": True,
                    "dedicated_manager": True
                }
            }
        ]

        for plan_data in plans_data:
            plan = Plan(**plan_data)
            session.add(plan)

        await session.commit()
        logger.info("Default plans created")

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)) -> User:
    """Get current authenticated user"""
    try:
        payload = jwt.decode(credentials.credentials, settings.JWT_SECRET, algorithms=[settings.JWT_ALGORITHM])
        user_id: str = payload.get("sub")
        tenant_id: str = payload.get("tenant_id")

        if not user_id or not tenant_id:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token"
            )
    except jwt.PyJWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token"
        )

    async with async_session() as session:
        result = await session.execute(
            select(User).where(User.id == user_id, User.tenant_id == tenant_id, User.is_active == True)
        )
        user = result.scalar_one_or_none()

        if not user:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="User not found"
            )

        return user

async def get_db():
    """Database session dependency"""
    async with async_session() as session:
        try:
            yield session
        finally:
            await session.close()

# FastAPI app
app = FastAPI(
    title="InvictusDNS User Management Service",
    description="Customer lifecycle, subscriptions, and profile management",
    version="1.0.0",
    lifespan=lifespan
)

# Routes
@app.post("/users", response_model=UserResponse)
async def create_user(user_data: UserCreate, db: AsyncSession = Depends(get_db)):
    """Create new user"""
    USER_OPERATIONS.labels(operation="create", status="attempt").inc()

    try:
        # Check if user already exists
        result = await db.execute(
            select(User).where(
                (User.username == user_data.username) | (User.email == user_data.email)
            )
        )
        existing_user = result.first()
        if existing_user:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Username or email already exists"
            )

        # Create user
        user = User(**user_data.dict())
        db.add(user)

        # Create Stripe customer if billing is enabled
        if settings.STRIPE_SECRET_KEY:
            try:
                customer = stripe.Customer.create(
                    email=user.email,
                    name=user.full_name,
                    metadata={
                        "user_id": user.id,
                        "tenant_id": user.tenant_id
                    }
                )
                user.stripe_customer_id = customer.id
            except Exception as e:
                logger.error("Failed to create Stripe customer", error=str(e))

        await db.commit()
        await db.refresh(user)

        USER_OPERATIONS.labels(operation="create", status="success").inc()

        logger.info("User created", user_id=user.id, username=user.username)

        return UserResponse.from_orm(user)

    except HTTPException:
        raise
    except Exception as e:
        logger.error("User creation failed", error=str(e))
        USER_OPERATIONS.labels(operation="create", status="error").inc()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="User creation failed"
        )

@app.get("/users/me", response_model=UserResponse)
async def get_current_user_profile(current_user: User = Depends(get_current_user)):
    """Get current user profile"""
    return UserResponse.from_orm(current_user)

@app.put("/users/me", response_model=UserResponse)
async def update_current_user_profile(
    user_data: UserUpdate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Update current user profile"""
    try:
        update_data = user_data.dict(exclude_unset=True)
        update_data["updated_at"] = datetime.utcnow()

        await db.execute(
            update(User)
            .where(User.id == current_user.id)
            .values(**update_data)
        )
        await db.commit()

        # Refresh user data
        await db.refresh(current_user)

        USER_OPERATIONS.labels(operation="update", status="success").inc()

        return UserResponse.from_orm(current_user)

    except Exception as e:
        logger.error("User update failed", error=str(e), user_id=current_user.id)
        USER_OPERATIONS.labels(operation="update", status="error").inc()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Update failed"
        )

@app.get("/plans", response_model=List[PlanResponse])
async def get_plans(db: AsyncSession = Depends(get_db)):
    """Get available subscription plans"""
    try:
        result = await db.execute(
            select(Plan).where(Plan.is_active == True).order_by(Plan.price_monthly)
        )
        plans = result.scalars().all()

        return [PlanResponse(
            id=plan.id,
            name=plan.name,
            description=plan.description,
            price_monthly=plan.price_monthly,
            price_yearly=plan.price_yearly,
            currency=plan.currency,
            max_users=plan.max_users,
            max_domains=plan.max_domains,
            features=eval(plan.features) if plan.features else {},
            is_active=plan.is_active
        ) for plan in plans]

    except Exception as e:
        logger.error("Failed to get plans", error=str(e))
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get plans"
        )

@app.post("/subscriptions", response_model=SubscriptionResponse)
async def create_subscription(
    subscription_data: SubscriptionCreate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Create new subscription"""
    SUBSCRIPTION_EVENTS.labels(event_type="create").inc()

    try:
        # Check if user already has an active subscription
        result = await db.execute(
            select(Subscription).where(
                Subscription.user_id == current_user.id,
                Subscription.status.in_(["active", "trialing"])
            )
        )
        existing_subscription = result.first()
        if existing_subscription:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="User already has an active subscription"
            )

        # Get plan
        result = await db.execute(select(Plan).where(Plan.id == subscription_data.plan_id))
        plan = result.scalar_one_or_none()
        if not plan or not plan.is_active:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid plan"
            )

        # Calculate trial period
        trial_start = datetime.utcnow()
        trial_end = trial_start + timedelta(days=subscription_data.trial_days) if subscription_data.trial_days > 0 else None

        # Create subscription
        subscription = Subscription(
            user_id=current_user.id,
            plan_id=subscription_data.plan_id,
            billing_cycle=subscription_data.billing_cycle,
            status="trialing" if trial_end else "active",
            trial_start=trial_start if trial_end else None,
            trial_end=trial_end,
            current_period_start=trial_start,
            current_period_end=trial_end if trial_end else trial_start + timedelta(days=30 if subscription_data.billing_cycle == "monthly" else 365)
        )

        db.add(subscription)
        await db.commit()
        await db.refresh(subscription)

        # Load plan data for response
        result = await db.execute(select(Plan).where(Plan.id == subscription.plan_id))
        plan = result.scalar_one()

        logger.info("Subscription created", user_id=current_user.id, plan_id=plan.id)

        return SubscriptionResponse(
            id=subscription.id,
            user_id=subscription.user_id,
            plan=PlanResponse(
                id=plan.id,
                name=plan.name,
                description=plan.description,
                price_monthly=plan.price_monthly,
                price_yearly=plan.price_yearly,
                currency=plan.currency,
                max_users=plan.max_users,
                max_domains=plan.max_domains,
                features=eval(plan.features) if plan.features else {},
                is_active=plan.is_active
            ),
            status=subscription.status,
            billing_cycle=subscription.billing_cycle,
            current_period_start=subscription.current_period_start,
            current_period_end=subscription.current_period_end,
            cancel_at_period_end=subscription.cancel_at_period_end,
            trial_end=subscription.trial_end,
            created_at=subscription.created_at
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error("Subscription creation failed", error=str(e), user_id=current_user.id)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Subscription creation failed"
        )

@app.get("/subscriptions/current", response_model=SubscriptionResponse)
async def get_current_subscription(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get current user subscription"""
    try:
        result = await db.execute(
            select(Subscription, Plan)
            .join(Plan, Subscription.plan_id == Plan.id)
            .where(Subscription.user_id == current_user.id)
            .order_by(Subscription.created_at.desc())
            .limit(1)
        )
        row = result.first()

        if not row:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="No subscription found"
            )

        subscription, plan = row

        return SubscriptionResponse(
            id=subscription.id,
            user_id=subscription.user_id,
            plan=PlanResponse(
                id=plan.id,
                name=plan.name,
                description=plan.description,
                price_monthly=plan.price_monthly,
                price_yearly=plan.price_yearly,
                currency=plan.currency,
                max_users=plan.max_users,
                max_domains=plan.max_domains,
                features=eval(plan.features) if plan.features else {},
                is_active=plan.is_active
            ),
            status=subscription.status,
            billing_cycle=subscription.billing_cycle,
            current_period_start=subscription.current_period_start,
            current_period_end=subscription.current_period_end,
            cancel_at_period_end=subscription.cancel_at_period_end,
            trial_end=subscription.trial_end,
            created_at=subscription.created_at
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to get subscription", error=str(e), user_id=current_user.id)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get subscription"
        )

@app.get("/invoices", response_model=List[InvoiceResponse])
async def get_user_invoices(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get user invoices"""
    try:
        result = await db.execute(
            select(Invoice)
            .where(Invoice.user_id == current_user.id)
            .order_by(Invoice.created_at.desc())
        )
        invoices = result.scalars().all()

        return [InvoiceResponse.from_orm(invoice) for invoice in invoices]

    except Exception as e:
        logger.error("Failed to get invoices", error=str(e), user_id=current_user.id)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get invoices"
        )

@app.get("/billing/stats", response_model=BillingStats)
async def get_billing_stats(db: AsyncSession = Depends(get_db)):
    """Get billing statistics (admin only)"""
    try:
        # Calculate total revenue
        result = await db.execute(
            select(func.sum(Invoice.amount))
            .where(Invoice.status == "paid")
        )
        total_revenue = result.scalar() or 0.0

        # Calculate monthly revenue (last 30 days)
        thirty_days_ago = datetime.utcnow() - timedelta(days=30)
        result = await db.execute(
            select(func.sum(Invoice.amount))
            .where(Invoice.status == "paid", Invoice.paid_at >= thirty_days_ago)
        )
        monthly_revenue = result.scalar() or 0.0

        # Count active subscriptions
        result = await db.execute(
            select(func.count())
            .select_from(Subscription)
            .where(Subscription.status.in_(["active", "trialing"]))
        )
        active_subscriptions = result.scalar()

        # Count total customers
        result = await db.execute(
            select(func.count()).select_from(User).where(User.is_active == True)
        )
        total_customers = result.scalar()

        # Calculate churn rate (simplified)
        churn_rate = 0.05  # Placeholder

        # Calculate ARPU
        arpu = total_revenue / total_customers if total_customers > 0 else 0.0

        BILLING_OPERATIONS.labels(operation="stats").inc()

        return BillingStats(
            total_revenue=total_revenue,
            monthly_revenue=monthly_revenue,
            active_subscriptions=active_subscriptions,
            total_customers=total_customers,
            churn_rate=churn_rate,
            average_revenue_per_user=arpu
        )

    except Exception as e:
        logger.error("Failed to get billing stats", error=str(e))
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get billing stats"
        )

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow(),
        "version": settings.APP_VERSION
    }

@app.get("/metrics")
async def metrics():
    """Prometheus metrics endpoint"""
    return JSONResponse(content=generate_latest())

# Main entry point
if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=settings.USER_SERVICE_PORT,
        reload=settings.DEBUG,
        log_level="info"
    )

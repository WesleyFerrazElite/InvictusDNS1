#!/usr/bin/env python3
"""
InvictusDNS - Servidor DNS Principal
Executa o servidor DNS em background e mantém o processo ativo.
Compatível com Windows e Linux.
"""

import subprocess
import sys
import os
import time
import signal
import platform

def main():
    print("InvictusDNS - Iniciando Servidor DNS...")
    print(f"Sistema Operacional: {platform.system()}")

    # Caminho para o script do servidor DNS
    dns_script = os.path.join(os.path.dirname(__file__), 'server', 'dns_server.py')

    if not os.path.exists(dns_script):
        print(f"Erro: Arquivo {dns_script} não encontrado!")
        sys.exit(1)

    try:
        # Executar o servidor DNS
        if platform.system() == 'Windows':
            # No Windows, usar python.exe diretamente
            cmd = [sys.executable, dns_script]
        else:
            # No Linux/Mac, usar python3
            cmd = ['python3', dns_script]

        print(f"Executando: {' '.join(cmd)}")
        process = subprocess.Popen(cmd)

        print("Servidor DNS iniciado. PID:", process.pid)
        print("Pressione Ctrl+C para parar...")

        # Manter o processo ativo
        while True:
            time.sleep(1)
            if process.poll() is not None:
                print("Servidor DNS parou inesperadamente.")
                break

    except KeyboardInterrupt:
        print("\nParando servidor DNS...")
        if 'process' in locals():
            process.terminate()
            process.wait()
        print("Servidor DNS parado.")
    except Exception as e:
        print(f"Erro ao iniciar servidor DNS: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()
